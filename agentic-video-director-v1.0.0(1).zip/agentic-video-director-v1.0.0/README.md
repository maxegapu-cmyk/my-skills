# Agentic Video Director v1.0.0

A cross-runtime Agent Skill for code-built and hybrid AI video production, tuned for Claude Opus 5.5 and GPT-6. It focuses on real artifact delivery: brief → timed shot contract → build → render → targeted visual/audio QC → repair → final file.

## Install

### Claude Code / Opus 5.5
Copy the whole folder to:

```bash
~/.claude/skills/agentic-video-director/
```

### Codex / GPT-6
Copy the whole folder to:

```bash
~/.agents/skills/agentic-video-director/
```

Per-project installations may use the equivalent local skills directory supported by the host.

## First run

```bash
python3 scripts/doctor.py
```

Recommended technical base for code video:

```bash
npx skills add remotion-dev/skills
```

The official Remotion skill is a technical API/best-practice layer; this package is the directing/editorial layer. They are complementary.

## Trigger examples

- “用代码给这个 SaaS 做一个 30 秒发布宣传片，直接出 MP4。”
- “拿这首歌和素材做 45 秒 MV，认真卡点，不要 PPT 感。”
- “把这个 MP4 修得更电影化，保留故事和配音。”
- “做一个完全由代码绘制的 30 秒动画短片。”

## Package contents

- `SKILL.md` — short runtime workflow
- `references/` — model adapters, production routing, shot contract, MV timing, QC
- `examples/` — original example task prompts
- `scripts/doctor.py` — dependency probe
- `scripts/shotlist_check.py` — shot timing/coverage validator
- `scripts/qc_frames.py` — ffmpeg contact-sheet + ffprobe metadata
- `templates/shots.csv` — starter shot contract

## Design note
The package intentionally avoids a huge one-size-fits-all master prompt. Newer frontier models respond better to concise, relevant context. Model-specific behavior lives in small adapters loaded only when needed.
