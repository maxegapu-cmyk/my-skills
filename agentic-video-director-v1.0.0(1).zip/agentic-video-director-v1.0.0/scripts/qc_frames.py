#!/usr/bin/env python3
import argparse, json, shutil, subprocess
from pathlib import Path

def run(cmd):
    return subprocess.run(cmd, check=True, capture_output=True, text=True)

def probe(path):
    out=run(['ffprobe','-v','error','-show_entries','format=duration:stream=index,codec_type,codec_name,width,height,r_frame_rate','-of','json',str(path)])
    return json.loads(out.stdout)

def main():
    ap=argparse.ArgumentParser(description='Create a representative video QC contact sheet using ffmpeg.')
    ap.add_argument('video')
    ap.add_argument('--out', default='qc')
    ap.add_argument('--frames', type=int, default=12)
    args=ap.parse_args()
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        raise SystemExit('ffmpeg and ffprobe are required')
    src=Path(args.video)
    if not src.exists(): raise SystemExit(f'not found: {src}')
    outdir=Path(args.out); outdir.mkdir(parents=True,exist_ok=True)
    meta=probe(src)
    duration=float(meta.get('format',{}).get('duration') or 0)
    if duration <= 0: raise SystemExit('could not determine duration')
    n=max(4,args.frames)
    fps=n/duration
    sheet=outdir/'contact-sheet.jpg'
    # sample evenly; scale each tile to 480px wide; arrange 4 columns
    vf=f"fps={fps:.8f},scale=480:-2,tile=4x{(n+3)//4}:padding=8:margin=8"
    run(['ffmpeg','-y','-v','error','-i',str(src),'-vf',vf,'-frames:v','1','-q:v','2',str(sheet)])
    (outdir/'probe.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(sheet)
if __name__=='__main__': main()
