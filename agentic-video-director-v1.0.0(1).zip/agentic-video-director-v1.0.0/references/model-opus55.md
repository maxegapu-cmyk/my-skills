# Claude Opus 5.5 adapter

Use this adapter when the active model is Claude Opus 5.5 / `claude-opus-5-5`.

## Prompt shape
Opus 5.5 is strong enough that overspecified step-by-step micromanagement can reduce creative quality. Give it the **goal, artifact, hard constraints, creative latitude, and finish condition**. Let it solve local implementation details.

Recommended task frame:

```text
Goal: [what the viewer should feel/understand/do]
Artifact: [duration, format, resolution, fps, output path]
Inputs: [music, product repo, footage, brand assets]
Hard constraints: [must/must-not facts]
Creative latitude: [what it may decide itself]
Finish condition: build + render + inspect + repair concrete defects + deliver the real file.
```

## Opus-specific steering
- Prefer a few high-signal rules to a giant checklist.
- Do not repeatedly tell it to “double-check everything.” Opus-family guidance notes strong native self-correction; redundant verification can create over-verification and token waste.
- Ask for progress only at meaningful milestones: contract locked, first render, QC/final.
- Use subagents only for independent work that can run in parallel (research, asset inventory, alternate storyboard), not as default delegation.
- When the user already authorized creation/repair, state that routine reversible local steps may proceed without additional approval.
- For long projects, maintain a small durable state file (`PRODUCTION_STATE.md` or `shots.csv`) rather than narrating every action into chat.

## Video strengths to exploit
Opus 5.5 community demos show strong one-shot code drawing, Canvas/WebGL, Blender scripting, Remotion, audio synthesis and mixed pipelines. Use that autonomy for visual invention, but still anchor timing in a shot contract and inspect the render.

## Avoid
- 200-line “do exactly these coding steps” prompts for simple projects.
- Generic praise words (“stunning”, “epic”, “world class”) without visual evidence or constraints.
- Re-rendering the entire film after every microscopic tweak when a still/short segment can validate the fix.
