# Production modes

Choose the simplest primary mode that can satisfy the brief.

| Mode | Use when | Default stack | Key proof |
|---|---|---|---|
| CODE-FILM | Graphics, explainers, stylized shorts, abstract films | Remotion + SVG/Canvas/WebGL; optional Three.js | Deterministic frame output |
| CAPTURE-PROMO | Real app/SaaS/product interface is the subject | Playwright/screenshot capture + Remotion | Real UI states, not invented evidence |
| MV | Finished song/track drives structure | ffprobe + beat/section map + Remotion/ffmpeg + optional generated clips | Cuts/motion align with musical phrase and energy |
| HYBRID-AI | Photoreal/cinematic shots are impractical to draw in code | Image/video generation for source shots + Remotion/ffmpeg assembly | Consistency anchors survive between shots |
| EDIT-REPAIR | Existing video must be improved | ffmpeg/Remotion + source footage | Before/after defect is visibly corrected |
| 3D | Camera/object motion needs true geometry | Blender Python or Three.js + ffmpeg | Camera path, scale and spatial continuity |

## Routing
- If the product/UI must be truthful: prefer CAPTURE-PROMO.
- If music is supplied and edit rhythm matters most: MV.
- If the visual can be represented by shapes, type, diagrams or stylized art: CODE-FILM.
- If the visual requires actors/real locations/complex texture: HYBRID-AI.
- If the user gave an MP4 and asked to improve it: EDIT-REPAIR first; do not rebuild from scratch without a reason.
- If parallax/fake 3D stops being convincing: use 3D for only those shots.

## Mixed-mode rule
A project may mix modes shot-by-shot, but one mode remains the editorial backbone. Generated clips are media assets; Remotion/ffmpeg is still responsible for timing, typography, transitions, sound design and final delivery unless the brief says otherwise.
