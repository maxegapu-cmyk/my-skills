from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]

REQUIRED = [
    'SKILL.md', 'README.md', 'SOURCES.md',
    'references/model-opus55.md', 'references/model-gpt6.md',
    'references/production-modes.md', 'references/shot-contract.md',
    'references/mv-timing.md', 'references/quality-gates.md',
    'examples/01-product-launch.md', 'examples/02-music-video.md',
    'examples/03-code-film.md', 'examples/04-repair-existing-video.md',
    'scripts/doctor.py', 'scripts/shotlist_check.py', 'scripts/qc_frames.py',
]

def test_required_files_exist():
    missing = [p for p in REQUIRED if not (ROOT / p).exists()]
    assert not missing, f'missing: {missing}'

def test_skill_frontmatter_and_description():
    text = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
    assert text.startswith('---\n')
    head = text.split('---', 2)[1]
    assert re.search(r'^name:\s*[a-z0-9-]+\s*$', head, re.M)
    m = re.search(r'^description:\s*(.+)$', head, re.M)
    assert m
    desc = m.group(1).strip()
    assert desc.startswith('Use when ')
    assert len(desc) < 500

def test_skill_mentions_both_model_adapters_and_core_modes():
    text = (ROOT / 'SKILL.md').read_text(encoding='utf-8').lower()
    for needle in ['opus 5.5', 'gpt-6', 'mv', 'promo', 'render', 'inspect']:
        assert needle in text

def test_references_are_linked_from_skill():
    text = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
    for p in REQUIRED:
        if p.startswith('references/'):
            assert p in text, f'{p} not linked'
