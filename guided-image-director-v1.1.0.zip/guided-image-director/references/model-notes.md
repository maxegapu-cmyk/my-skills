# Model Notes

Use this file only when the target model or tool is known. The directing method remains vendor-neutral.

## OpenAI image generation / ChatGPT Images
Current public OpenAI guidance favors clear natural-language prompts. Ordinary requests often need only a few sentences covering purpose, subject, action, setting, visual character, and any important framing, lighting, or constraints. For edits, explicit “change X / preserve Y” instructions and small targeted revisions help limit drift.

**Director adaptation:**
- Prefer natural language over pseudo-parameters.
- Use compact prompts for ordinary generation.
- Expand only for complex relationships, text/layout, multiple references, or hard locks.
- For iterative repair, keep correct elements fixed and change one meaningful issue at a time.
- When text must appear in the image, give the exact string, placement, hierarchy, and avoid unnecessary extra text.

## Midjourney
Current public Midjourney guidance highlights subject, medium, environment, lighting, color, mood, and composition. Image Prompts can guide content/composition/color. Style References guide overall visual character such as color, medium, texture, and lighting rather than copying the depicted objects. Current documentation also distinguishes other reference/personalization mechanisms, so do not treat every image input as the same kind of control.

**Director adaptation:**
- Keep the text prompt concise and concrete.
- Describe the desired final image instead of narrating edit operations.
- When a style reference is strong, reduce redundant style words.
- Use parameters only when they serve a clear delivery need, such as aspect ratio or a supported reference-strength control.
- Do not assume parameter syntax or ranges remain stable across versions.

## Adobe Firefly
Current public Firefly guidance exposes composition references, style references, visual intensity, color/tone, lighting, and camera-angle controls. Adobe's recent realistic-photo tutorial explicitly demonstrates combining subject/location with pose, framing, lighting, camera choices, and material/texture detail.

**Director adaptation:**
- Separate composition control from style control when the interface supports both.
- Use text for subject, event, environment, and precise visual requirements; use dedicated controls when they express composition/style more directly.
- For product or portrait work, prioritize form/identity, pose/framing, material response, and controlled lighting before decorative effects.

## Google Imagen / Vertex AI
Google's public prompt guide recommends building from subject, context/background, and style, then iterating with details. It also documents photographic modifiers such as proximity, viewpoint, lighting, focus behavior, lens character, and image treatment, plus reference-based subject customization.

**Director adaptation:**
- Start with subject + context + style, then add only the modifiers that change the image meaningfully.
- Use photographic terms only when the output is intended to read as photography.
- Treat reference subject, control, and style inputs as distinct responsibilities when the chosen workflow supports them.

## Cross-model rules
- Never assume vendor syntax, parameter values, or reference semantics transfer between models.
- If the model is unknown, output portable natural language without vendor switches.
- Prefer visible consequences over technical vocabulary.
- When a dedicated UI control expresses composition, reference strength, or style better than text, let the interface control that variable and keep the prompt clean.
