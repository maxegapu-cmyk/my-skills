# Public Basis

This package is an original synthesis built from public image-generation guidance and general visual-direction practice. It does not depend on private workflows.

Public sources consulted for this revision:

- OpenAI Academy — **Creating images with ChatGPT** (Apr 10, 2026): purpose, subject, action, scene, style, framing/lighting/constraints; small targeted revisions; multiple-image role clarity; text and layout guidance.
  https://openai.com/academy/image-generation/

- Midjourney Documentation — **Prompt Basics**: subject, medium, environment, lighting, color, mood, composition; concise prompt construction.
  https://docs.midjourney.com/hc/en-us/articles/32023408776205-Prompt-Basics

- Midjourney Documentation — **Image Prompts**: image guidance for content, composition, and color, alongside distinct reference mechanisms.
  https://docs.midjourney.com/hc/en-us/articles/32040250122381-Image-Prompts

- Midjourney Documentation — **Style Reference**: style guidance for broad visual character such as color, medium, texture, and lighting; keep prompt content-focused.
  https://docs.midjourney.com/hc/en-us/articles/32180011136653-Style-Reference

- Adobe Firefly Help — **Generate images from text descriptions** (2026): separate composition/style reference controls plus color/tone, lighting, and camera-angle controls.
  https://helpx.adobe.com/firefly/web/work-with-images/generate-images/generate-images-from-text-descriptions.html

- Adobe Firefly Tutorial — **Generate realistic photos** (Apr 13, 2026): pose, framing, lighting, camera choices, texture/material detail, and reference consistency.
  https://helpx.adobe.com/uk/firefly/how-to/generate-realistic-photos.html

- Google Cloud Vertex AI — **Prompt and image attribute guide**: subject, context/background, style, iterative refinement, and photographic modifiers such as viewpoint, lighting, focus, and lens character.
  https://cloud.google.com/vertex-ai/generative-ai/docs/image/img-gen-prompt-guide

All runtime wording, decision rules, examples, and package structure in this skill were written independently for this package.
