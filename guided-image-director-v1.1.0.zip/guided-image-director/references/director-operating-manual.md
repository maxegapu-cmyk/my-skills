# Director Operating Manual

This manual turns widely published image-generation and visual-design principles into a decisive, model-agnostic directing workflow. It is written for use, not for lecture.

## A. Start with the result, not the vocabulary

Before thinking about style, determine the image's job. Typical jobs include:
- stop the scroll;
- sell or explain a product;
- establish a character;
- create a story beat;
- establish a world;
- communicate status, tension, warmth, danger, luxury, playfulness, or trust;
- provide a cover, poster, thumbnail, social asset, key visual, or concept frame.

A good direction can be summarized in one sentence: **what the viewer should notice first, what is happening, and why this frame matters.**

When the user's wording is vague, infer a practical job from context. Ask only if two plausible jobs require fundamentally different images.

## B. Build one visual thesis

Write an internal one-line thesis before prompting.

Examples:
- “A premium collectible feels expensive because one clean hero silhouette dominates a controlled, reflective studio world.”
- “Loneliness reads through one occupied seat surrounded by empty carriage rhythm, not through a giant word like SAD.”
- “Speed reads because the subject, camera, background streak, body lean, and directional light all agree on movement.”

If the frame tries to communicate five equal ideas, choose one primary idea and demote the others.

## C. Turn nouns into a beat

Static object lists create generic pictures. Direct a visible instant.

Resolve:
- what has just happened, is happening, or is about to happen;
- what the subject is reacting to;
- what the hands, posture, gaze, clothing, props, and environment are doing because of that beat;
- whether the image should feel frozen, posed, observed, interrupted, explosive, calm, or transitional.

Prefer actions that can actually be seen. “Tense” is abstract; “one hand grips the wet railing while she looks back toward the closing platform doors” is visible.

## D. Stage relationships, not inventory

Every important element needs a reason and a place.

Define:
- **hero** — owns the frame;
- **support** — explains, contrasts, or reinforces the hero;
- **environment** — creates context and depth;
- **negative space** — protects the hero, text, or breathing room.

Use foreground, midground, and background only when they help the image. Avoid filling every region. A frame with no quiet area often loses hierarchy.

### Salience budget
Allow only a few high-attention features at once. If the hero face, bright sign, neon floor, giant moon, sparks, logo, and background crowd all demand attention, the viewer has no path.

Reduce contrast, detail, saturation, scale, or sharpness in secondary regions before adding more detail to the hero.

## E. Place the camera for meaning

Camera direction is not decoration. Each choice should change what the viewer experiences.

Choose:
- close / medium / wide;
- eye-level / low / high / overhead / oblique;
- intimate near-camera / observational distance / monumental distance;
- expansive perspective / neutral perspective / compressed layers;
- shallow / moderate / deep focus when depth separation matters.

Use named focal lengths only if that distinction matters and is appropriate for the target model. Otherwise describe the visible perspective directly.

### Camera question
Ask internally: **Where is the viewer standing, and why there?**

If you cannot answer, camera jargon is probably filler.

## F. Direct attention deliberately

Plan the visual reading order:
1. first look;
2. second look;
3. optional third look.

Tools include:
- subject scale;
- placement;
- value contrast;
- sharpness;
- light intensity;
- color accent;
- leading lines;
- gaze direction;
- depth;
- repetition and interruption;
- negative space.

If everything is equally crisp, bright, saturated, and detailed, nothing is dominant.

## G. Give light a physical cause

Describe light through behavior rather than praise.

Resolve:
- **source** — sky, sun, window, lamp, sign, screen, fire, softbox, practical fixture;
- **direction** — left/right/front/back/top/below;
- **quality** — hard, soft, diffuse, scattered, dappled;
- **contrast** — gentle, moderate, dramatic;
- **falloff** — fast/slow, local/global;
- **environmental response** — bounce, reflections, haze, rim, wet shine, translucent glow, cast shadow.

“Cinematic lighting” alone is not a lighting plan.

## H. Build color as a relationship

Choose color only after job, hero, and light are clear.

Useful decisions:
- dominant family;
- supporting family;
- accent color only if it has a job;
- warm / cool / neutral / split-temperature;
- muted / moderate / saturated;
- low / medium / high color contrast.

Color should reinforce hierarchy and mood. Do not add trendy color labels that fight the scene's physical light.

## I. Make materials tell the truth

For important materials, specify how the surface behaves.

Useful variables:
- matte / satin / glossy;
- smooth / rough / fibrous / brushed / polished;
- rigid / soft / heavy / lightweight;
- transparent / translucent / opaque;
- clean / worn / scratched / dusty / damp / oily;
- broad reflection / sharp highlight / subsurface softness / microtexture.

The material description should match the light. “Wet asphalt” needs reflections; “brushed metal” should not behave like mirror chrome unless intended.

## J. Choose a production character, not a pile of styles

Useful medium families include:
- documentary photography;
- editorial portrait;
- studio product photography;
- cinematic frame;
- graphic poster;
- ink or pencil illustration;
- watercolor or gouache;
- cel animation;
- painterly concept art;
- stylized or realistic 3D;
- miniature/diorama;
- collage/mixed media.

Use one main production character and at most a small number of supporting aesthetic cues. If a strong style reference is present, keep style text light to avoid conflict.

## K. Reference triage

Before combining references, decide what each reference is trusted for.

Possible roles:
- identity/content;
- outfit/product shape;
- pose;
- composition;
- environment;
- lighting;
- palette;
- material treatment;
- style/medium.

### Quality check
A reference should not automatically be trusted for a role it represents poorly. A face hidden in profile is weak identity evidence; a tiny compressed product image is weak material evidence; a style image with unusual content should not donate those objects unless requested.

### Conflict rule
When two references disagree, preserve the user-declared priority. If no priority is given, protect identity/content and the requested image job before decorative aesthetics.

### Reference economy
Use the smallest reference set that communicates the target. Extra references increase ambiguity and can dilute control.

## L. Commercial and layout work

For ads, posters, thumbnails, packaging, key art, or social assets, add delivery logic:
- final orientation/aspect intent;
- hero scale;
- safe negative space;
- logo/text region;
- reading order;
- crop resilience;
- whether a product must remain geometrically faithful;
- whether hands, labels, interfaces, or packaging are business-critical.

Treat typography and layout as geometry. When exact text matters, provide the exact string, placement, hierarchy, alignment, and “no other text” constraint when appropriate.

## M. Prompt compiler

After directing, compress decisions into image-model language.

Recommended order:
1. image type/job;
2. hero and defining traits;
3. visible beat;
4. environment;
5. staging/composition;
6. camera/viewpoint;
7. lighting;
8. color structure;
9. material/detail cues;
10. medium/style;
11. locks and exclusions.

### Density selection
Use the minimum useful density:
- **Compact** — ordinary single-subject image, few constraints.
- **Standard** — meaningful staging, camera, lighting, or reference guidance.
- **Constrained** — multi-subject relationships, layout/text, exact product/character requirements, or surgical edits.

Longer is not automatically stronger. Delete any phrase whose removal would not visibly change the intended image.

## N. Strong-guidance mode

When the user is inexperienced or gives a vague request:
- do not ask them to choose among ten camera, color, or style options;
- infer a coherent default based on the image job;
- state one recommended direction;
- provide the ready prompt;
- mention at most one high-value alternative only when it changes the creative strategy, not merely the adjective set.

The system should feel like a director making decisions, not a form the user has to complete.

## O. First-pass review

Judge in this order:
1. correct hero/content;
2. readable beat/action;
3. clear hierarchy;
4. correct crop and viewpoint;
5. believable light source and shadow behavior;
6. color supports hierarchy/mood;
7. material credibility;
8. coherent production character;
9. anatomy, text, perspective, object, or clutter errors.

Return a verdict before commentary.

## P. Revision ladder

Use the smallest intervention that can solve the failure.

1. **Local correction** — one object, limb, text block, reflection, color, crop, or background detail.
2. **Directed correction** — one subsystem such as pose, composition, light, material, or background hierarchy.
3. **Prompt recompile** — several connected decisions are wrong but the concept is sound.
4. **Concept reset** — only when the central image job or visual thesis failed.

Prefer targeted, step-by-step revisions. Keep correct elements locked while changing the failing part.

## Q. Series direction

For multiple images, define constants before shot prompts:
- identity;
- recurring wardrobe/product form;
- world/environment rules;
- palette family;
- realism/stylization level;
- production character;
- recurring props or graphic rules.

Then define shot variables:
- beat/action;
- staging;
- framing;
- camera;
- time/local light;
- local environment state.

Before each new shot, check that variable changes do not accidentally rewrite a constant.

## R. Common failure patterns

### “Professional” becomes jargon soup
Fix: remove unsupported camera bodies, lens brands, film stocks, render engines, and quality chants. Keep only choices with a visible role.

### Mood exists but event does not
Fix: replace abstract emotion words with posture, gaze, action, environment response, and framing.

### Background steals the image
Fix: lower secondary contrast, saturation, detail, or focus; enlarge/protect the hero; use negative space.

### Plastic-looking realism
Fix: specify plausible surface response, microtexture, irregularity, wear, soft tissue/fabric behavior, and physically consistent light instead of “hyperreal 8K.”

### Reference style hijacks content
Fix: narrow the style reference's role; simplify conflicting style text; preserve requested identity/content explicitly.

### Edit drifts everywhere
Fix: state one change and explicitly preserve already-correct composition, identity, environment, or layout.

### Series changes identity between shots
Fix: move identity and recurring appearance into series constants; keep shot prompts focused on variables only.

## S. Fast directing presets

### One-line vague idea
Job → visual thesis → beat → hero → one composition → motivated light → one palette relationship → prompt.

### Character portrait
Identity → expression/beat → posture → framing → eye direction → light → background separation → skin/hair/fabric behavior → medium.

### Product ad
Product truth → usage or hero context → composition → negative space → controlled reflections → material fidelity → brand palette → text/layout region.

### Cinematic frame
Narrative beat → blocking → viewer position → practical/motivated light → atmosphere → palette → physical texture → continuity locks.

### Illustration/concept
World function → silhouette → depth → dominant shapes → value/light structure → palette → surface language → medium.

### Review/repair
Verdict → largest visible failure → smallest fix → preserve list → revised instruction only.
