#!/usr/bin/env python3
"""Prompt reverse-engineering helper for reverse-anything.

Goals:
- infer repeated constants independently of phrase order;
- infer variable slots by semantic role instead of sequence gaps alone;
- parse multiline positive/negative prompts safely;
- report separate lexical, order and evidence scores so a textual reconstruction
  cannot masquerade as a successful reverse-engineering result.

Only Python 3.9+ standard library is required.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter, OrderedDict, defaultdict
from difflib import SequenceMatcher
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

VERSION = "2.0.0"

# ---------------------------------------------------------------- categories
CATEGORIES = OrderedDict([
    ("参数", []),
    ("画质", ["8k", "4k", "hd", "uhd", "masterpiece", "best quality", "high quality", "ultra detailed",
             "highly detailed", "sharp focus", "photorealistic", "hyperrealistic", "award winning", "raw photo",
             "高清", "超清", "高画质", "细节丰富", "超写实", "写实", "杰作", "最佳质量", "精细"]),
    ("镜头", ["shot", "close-up", "closeup", "close up", "wide angle", "wide-angle", "lens", "mm", "macro",
             "bokeh", "depth of field", "dof", "aerial", "drone", "pov", "dolly", "pan", "tilt", "zoom",
             "tracking", "handheld", "low angle", "high angle", "bird's eye", "eye level", "telephoto",
             "f/", "aperture", "focus", "镜头", "特写", "近景", "中景", "远景", "全景", "俯拍", "仰拍", "航拍",
             "推镜", "拉镜", "摇镜", "跟拍", "运镜", "景深", "虚化", "广角", "长焦", "微距", "视角", "机位", "平视"]),
    ("构图", ["composition", "centered", "symmetr", "rule of thirds", "full body", "half body", "portrait",
             "landscape orientation", "framing", "negative space", "构图", "居中", "对称", "三分法", "全身",
             "半身", "留白", "画面", "比例"]),
    ("光线", ["light", "lighting", "sunlight", "golden hour", "blue hour", "backlight", "rim light", "neon",
             "glow", "shadow", "volumetric", "cinematic lighting", "studio lighting", "soft light", "hard light",
             "光", "光线", "逆光", "侧光", "顶光", "柔光", "硬光", "霓虹", "黄金时刻", "阴影", "体积光", "丁达尔",
             "暖光", "冷光", "布光", "日落", "夕阳", "晨光"]),
    ("色彩", ["color", "colour", "palette", "monochrome", "pastel", "vibrant", "muted", "teal and orange",
             "black and white", "saturated", "desaturated", "hue", "tone", "色", "色调", "配色", "饱和",
             "黑白", "莫兰迪", "马卡龙", "暖色", "冷色", "胶片色"]),
    ("风格", ["style", "in the style of", "art", "aesthetic", "anime", "cinematic", "film", "illustration",
             "painting", "watercolor", "oil", "3d", "render", "octane", "unreal engine", "pixar", "ghibli",
             "cyberpunk", "vaporwave", "minimalist", "surreal", "vintage", "retro", "photography", "editorial",
             "风格", "画风", "插画", "水彩", "油画", "国风", "二次元", "动漫", "赛博朋克", "电影感", "胶片",
             "极简", "复古", "超现实", "渲染", "摄影", "国潮", "水墨", "像素"]),
    ("情绪", ["mood", "atmosphere", "dreamy", "moody", "serene", "dramatic", "melancholic", "cozy", "epic",
             "mysterious", "氛围", "梦幻", "忧郁", "宁静", "温馨", "史诗", "神秘", "治愈", "压抑", "浪漫", "情绪"]),
    ("运动", ["moving", "motion", "slow motion", "timelapse", "time-lapse", "walks", "walking", "running",
             "turns", "flying", "camera moves", "transition", "seconds", "fps", "loop",
             "运动", "慢动作", "延时", "转身", "奔跑", "行走", "飞", "转场", "秒", "帧", "循环", "动作", "缓缓"]),
    ("场景", ["background", "in a", "in the", "at the", "street", "city", "forest", "room", "studio", "beach",
             "mountain", "sky", "ocean", "rain", "rainy", "snow", "snowy", "fog", "sunset", "park", "sofa", "desk", "window",
             "road", "desert", "alley", "station", "kitchen", "bedroom", "office",
             "interior", "exterior", "indoor", "outdoor", "night", "day", "背景", "场景", "街道", "城市", "森林",
             "室内", "室外", "海边", "山", "天空", "夜晚", "白天", "雨", "雪", "雾"]),
])

PARAM_PATTERNS = [
    (r"--[a-zA-Z][\w-]*(?:\s+[^\s,，-][^\s,，]*)?", "Midjourney 参数"),
    (r"\([^()]+:\s*[0-9.]+\)", "权重语法"),
    (r"<lora:[^>]+>", "LoRA"),
    (r"\b(?:seed|steps|cfg|sampler|ar|aspect ratio)\s*[:=]\s*[\w.:/-]+", "生成参数"),
]

NEG_LABEL_RE = re.compile(r"^\s*(negative\s*prompt|negative|负面提示词|反向提示词)\s*[:：]\s*(.*)$", re.I)
POS_LABEL_RE = re.compile(r"^\s*(positive\s*prompt|prompt|正向提示词|正面提示词)\s*[:：]\s*(.*)$", re.I)
INLINE_NEG_RE = re.compile(r"(?i)(?:^|\s)(negative\s*prompt|负面提示词|反向提示词)\s*[:：]\s*")
SPLIT_RE = re.compile(r"[,，;；、\n]+|(?<=[。.!！?？])\s+")
TOKEN_RE = re.compile(r"[\w\u4e00-\u9fff]+", re.UNICODE)

STABLE_CATEGORIES = ("风格", "画质", "光线", "色彩", "镜头", "构图", "参数")
DEFAULT_CATEGORY_ORDER = ["主体", "运动", "场景", "构图", "镜头", "光线", "色彩", "风格", "情绪", "画质"]


def normalize(p: str) -> str:
    return re.sub(r"\s+", " ", p.strip().strip("。. ").lower())


def phrase_tokens(p: str) -> List[str]:
    return TOKEN_RE.findall(normalize(p))


def classify(phrase: str) -> str:
    """Lightweight deterministic classification; never treated as ground truth."""
    low = normalize(phrase)
    for pat, _ in PARAM_PATTERNS:
        if re.fullmatch(pat, phrase.strip(), flags=re.I):
            return "参数"
    scores: Dict[str, float] = defaultdict(float)
    for cat, words in CATEGORIES.items():
        for w in words:
            # Single Chinese characters such as “色/光” create many false positives inside nouns.
            if len(w) == 1 and "\u4e00" <= w <= "\u9fff":
                continue
            if w in low:
                # longer signals are more discriminative than short generic words
                scores[cat] += min(3.0, max(1.0, len(w) / 4.0))
    if not scores:
        return "主体"
    best = max(scores, key=scores.get)
    # Subject phrases often mention a scene token incidentally; do not let one weak scene hit dominate.
    if best == "场景" and scores[best] < 2.0 and len(phrase_tokens(phrase)) >= 4:
        return "主体"
    return best


def _extract_negative_block(text: str) -> Tuple[str, Optional[str]]:
    """Extract a line-labelled negative block without turning it into another sample."""
    positive: List[str] = []
    negative: List[str] = []
    neg_mode = False
    saw_label = False
    for line in text.splitlines():
        m = NEG_LABEL_RE.match(line)
        if m:
            saw_label = True
            neg_mode = True
            if m.group(2).strip():
                negative.append(m.group(2).strip())
            continue
        p = POS_LABEL_RE.match(line)
        if p:
            saw_label = True
            neg_mode = False
            if p.group(2).strip():
                positive.append(p.group(2).strip())
            continue
        (negative if neg_mode else positive).append(line)
    if saw_label:
        neg = " ".join(x.strip() for x in negative if x.strip()) or None
        return "\n".join(positive).strip(), neg

    # Also handle common single-line form: "... Negative prompt: ..."
    m = INLINE_NEG_RE.search(text)
    if m and m.start() > 0:
        return text[:m.start()].strip(), text[m.end():].strip() or None
    return text.strip(), None


def split_prompt(text: str) -> dict:
    positive, negative = _extract_negative_block(text)
    params: List[str] = []
    for pat, _ in PARAM_PATTERNS:
        for hit in re.findall(pat, positive, flags=re.I):
            if isinstance(hit, tuple):
                hit = next((x for x in hit if x), "")
            if str(hit).strip():
                params.append(str(hit).strip())
        positive = re.sub(pat, " ", positive, flags=re.I)
    phrases = [p.strip() for p in SPLIT_RE.split(positive) if p and p.strip(" .。")]
    return {"phrases": phrases, "params": params, "negative": negative}


# ---------------------------------------------------------------- sample reading
def _split_auto(raw: str) -> List[str]:
    # Explicit separators are authoritative.
    if re.search(r"(?m)^\s*-{3,}\s*$", raw):
        return [x.strip() for x in re.split(r"(?m)^\s*-{3,}\s*$", raw) if x.strip()]

    lines = [x.rstrip() for x in raw.splitlines()]
    nonempty = [x for x in lines if x.strip()]
    if not nonempty:
        return []

    # Labelled prompt blocks: each Prompt: starts a new sample; negative lines stay attached.
    prompt_starts = [i for i, line in enumerate(lines) if POS_LABEL_RE.match(line)]
    if len(prompt_starts) >= 2:
        parts = []
        for idx, start in enumerate(prompt_starts):
            end = prompt_starts[idx + 1] if idx + 1 < len(prompt_starts) else len(lines)
            parts.append("\n".join(lines[start:end]).strip())
        return [x for x in parts if x]

    # If a negative label exists, the whole block is one prompt unless an explicit separator was used.
    if any(NEG_LABEL_RE.match(line) for line in lines):
        return [raw.strip()]

    # Blank-line separated paragraphs are safer than unconditional line splitting for multiline prompts.
    blocks = [x.strip() for x in re.split(r"\n\s*\n+", raw) if x.strip()]
    if len(blocks) > 1:
        return blocks

    # Backward compatible: a plain file with several non-empty lines means one prompt per line.
    if len(nonempty) > 1:
        return [x.strip() for x in nonempty]
    return [raw.strip()]


def read_samples(paths: Sequence[str], sep: Optional[str], input_mode: str = "auto") -> List[str]:
    samples: List[str] = []
    for p in paths:
        raw = sys.stdin.read() if p == "-" else Path(p).read_text(encoding="utf-8")
        raw = raw.strip()
        if not raw:
            continue
        if len(paths) > 1 and p != "-" and input_mode in ("auto", "file"):
            samples.append(raw)
            continue
        if sep is not None:
            parts = raw.split(sep)
        elif input_mode == "file":
            parts = [raw]
        elif input_mode == "line":
            parts = [x for x in raw.splitlines() if x.strip()]
        elif input_mode == "block":
            parts = re.split(r"(?m)^\s*-{3,}\s*$|\n\s*\n+", raw)
        else:
            parts = _split_auto(raw)
        samples.extend(x.strip() for x in parts if x and x.strip())
    return samples


# ---------------------------------------------------------------- matching / metrics
def phrase_similarity(a: str, b: str) -> float:
    na, nb = normalize(a), normalize(b)
    if na == nb:
        return 1.0
    ta, tb = set(phrase_tokens(a)), set(phrase_tokens(b))
    jac = len(ta & tb) / max(1, len(ta | tb))
    seq = SequenceMatcher(None, na, nb, autojunk=False).ratio()
    return max(jac, seq * 0.92)


def multiset_overlap(a: Iterable[str], b: Iterable[str]) -> Tuple[float, float, float]:
    ca, cb = Counter(normalize(x) for x in a), Counter(normalize(x) for x in b)
    overlap = sum((ca & cb).values())
    precision = overlap / max(1, sum(ca.values()))
    recall = overlap / max(1, sum(cb.values()))
    f1 = 2 * precision * recall / max(1e-9, precision + recall)
    return precision, recall, f1


def lcs_ratio(a: Sequence[str], b: Sequence[str]) -> float:
    """Order score. Reordering constants should lower this even if lexical coverage is perfect."""
    aa, bb = [normalize(x) for x in a], [normalize(x) for x in b]
    if not bb:
        return 1.0 if not aa else 0.0
    prev = [0] * (len(bb) + 1)
    for x in aa:
        cur = [0]
        for j, y in enumerate(bb, 1):
            cur.append(prev[j - 1] + 1 if x == y else max(cur[-1], prev[j]))
        prev = cur
    return prev[-1] / max(1, len(bb))


def _constant_candidates(parsed: List[dict], threshold: float, fuzzy: float) -> List[dict]:
    """Find recurrent phrases regardless of their order in each sample."""
    n = len(parsed)
    seeds: List[str] = []
    for p in parsed:
        for phrase in p["phrases"]:
            if normalize(phrase) not in {normalize(x) for x in seeds}:
                seeds.append(phrase)

    clusters: List[dict] = []
    consumed: set = set()
    for seed in seeds:
        ns = normalize(seed)
        if ns in consumed:
            continue
        hits: List[Optional[str]] = []
        matched_norms = {ns}
        for sample in parsed:
            best, score = None, 0.0
            for phrase in sample["phrases"]:
                s = phrase_similarity(seed, phrase)
                if s > score:
                    best, score = phrase, s
            if best is not None and score >= fuzzy:
                hits.append(best)
                matched_norms.add(normalize(best))
            else:
                hits.append(None)
        rate = sum(x is not None for x in hits) / max(1, n)
        if rate >= threshold:
            representative = Counter(normalize(x) for x in hits if x).most_common(1)[0][0]
            # Keep casing/punctuation from first matching original phrase.
            display = next(x for x in hits if x and normalize(x) == representative)
            clusters.append({
                "text": display,
                "category": classify(display),
                "presence": round(rate, 3),
                "variants": [x for x in hits],
                "fuzzy": len(matched_norms) > 1,
            })
            consumed.update(matched_norms)
    return clusters


def _match_constant(phrase: str, constants: Sequence[dict], fuzzy: float) -> Optional[int]:
    best_i, best_s = None, 0.0
    for i, c in enumerate(constants):
        s = phrase_similarity(phrase, c["text"])
        if s > best_s:
            best_i, best_s = i, s
    return best_i if best_i is not None and best_s >= fuzzy else None




def _constant_sequence(sample: dict, constants: Sequence[dict], fuzzy: float) -> List[int]:
    seq: List[int] = []
    for phrase in sample["phrases"]:
        ci = _match_constant(phrase, constants, fuzzy)
        if ci is not None:
            seq.append(ci)
    return seq


def _anchored_slots(parsed: List[dict], constants: Sequence[dict], fuzzy: float, base_i: int) -> Optional[Tuple[List[dict], List[str]]]:
    """Build slots between stable constant anchors when every sample shares the same constant order.

    This is much stronger than semantic-role matching for ordinary prompt families: if every sample
    has two changing phrases before the same fixed style suffix, those two positions are empirical
    slots even when a lightweight classifier mistakes a subject phrase for motion/color.
    """
    if not constants:
        return None
    canonical = _constant_sequence(parsed[base_i], constants, fuzzy)
    if not canonical or any(_constant_sequence(sample, constants, fuzzy) != canonical for sample in parsed):
        return None

    all_gaps: List[List[List[str]]] = []
    for sample in parsed:
        gaps: List[List[str]] = [[] for _ in range(len(canonical) + 1)]
        anchor_pos = 0
        for phrase in sample["phrases"]:
            ci = _match_constant(phrase, constants, fuzzy)
            if ci is not None and anchor_pos < len(canonical) and ci == canonical[anchor_pos]:
                anchor_pos += 1
            else:
                gaps[anchor_pos].append(phrase)
        all_gaps.append(gaps)

    slots: List[dict] = []
    slot_names = Counter()
    placeholders: Dict[Tuple[int, int], str] = {}
    for gap_i in range(len(canonical) + 1):
        width = max(len(gaps[gap_i]) for gaps in all_gaps)
        for pos in range(width):
            vals = [gaps[gap_i][pos] if pos < len(gaps[gap_i]) else None for gaps in all_gaps]
            observed = [v for v in vals if v]
            cats = Counter(classify(v) for v in observed)
            cat = cats.most_common(1)[0][0] if cats else "主体"
            agreement = (cats.most_common(1)[0][1] / len(observed)) if observed else 0.0
            # Common prompt convention + empirical position: first changing prefix is usually subject, second scene.
            # Only use this fallback when category evidence is mixed, never when the classifier is consistent.
            if gap_i == 0 and agreement < 0.67:
                cat = "主体" if pos == 0 else ("场景" if pos == 1 else cat)
            slot_names[cat] += 1
            name = cat if slot_names[cat] == 1 else f"{cat}{slot_names[cat]}"
            distinct = len({normalize(v) for v in observed})
            slot = {
                "key": f"gap:{gap_i}:{pos}", "name": name, "category": cat, "values": vals,
                "optional": any(v is None for v in vals), "distinct": distinct,
                "evidence": "variable" if distinct >= 2 else "weak",
                "alignment": "constant-anchor",
            }
            slots.append(slot)
            placeholders[(gap_i, pos)] = "{{" + name + "}}"

    parts: List[str] = []
    # Reconstruct canonical template as gap0, C0, gap1, C1 ...
    base_gaps = all_gaps[base_i]
    slot_by_key = {s["key"]: s for s in slots}
    for gap_i in range(len(canonical) + 1):
        width = max(len(gaps[gap_i]) for gaps in all_gaps)
        for pos in range(width):
            s = slot_by_key[f"gap:{gap_i}:{pos}"]
            token = "{{" + s["name"] + "}}"
            if s["optional"]:
                token = "[可选：" + token + "]"
            parts.append(token)
        if gap_i < len(canonical):
            parts.append(constants[canonical[gap_i]]["text"] )
    return slots, parts


def _positional_variable_slots(parsed: List[dict], constants: Sequence[dict], fuzzy: float, base_i: int) -> Optional[Tuple[List[dict], List[str]]]:
    """Align non-constant phrases by relative variable position when counts match.

    Useful when fixed style components are reordered across prompts but the variable payload
    remains a stable prefix/body such as subject + scene.
    """
    variables: List[List[str]] = []
    for sample in parsed:
        vals = [p for p in sample["phrases"] if _match_constant(p, constants, fuzzy) is None]
        variables.append(vals)
    widths = {len(v) for v in variables}
    if len(widths) != 1 or not widths or next(iter(widths)) == 0:
        return None
    width = next(iter(widths))
    slots: List[dict] = []
    used = Counter()
    for pos in range(width):
        vals = [v[pos] for v in variables]
        cats = Counter(classify(v) for v in vals)
        cat, count = cats.most_common(1)[0]
        agreement = count / len(vals)
        if agreement < 0.67:
            cat = "主体" if pos == 0 else ("场景" if pos == 1 else cat)
        used[cat] += 1
        name = cat if used[cat] == 1 else f"{cat}{used[cat]}"
        slots.append({
            "key": f"pos:{pos}", "name": name, "category": cat, "values": vals,
            "optional": False, "distinct": len({normalize(v) for v in vals}),
            "evidence": "variable" if len({normalize(v) for v in vals}) >= 2 else "weak",
            "alignment": "variable-position",
        })

    # Template keeps the base sample's observed ordering, replacing variables in their own order.
    parts: List[str] = []
    var_pos = 0
    for phrase in parsed[base_i]["phrases"]:
        ci = _match_constant(phrase, constants, fuzzy)
        if ci is not None:
            parts.append(constants[ci]["text"] )
        else:
            s = slots[var_pos]
            parts.append("{{" + s["name"] + "}}")
            var_pos += 1
    return slots, parts


def _slot_values(parsed: List[dict], constants: Sequence[dict], fuzzy: float) -> Tuple[List[dict], List[List[Tuple[str, Optional[str]]]]]:
    per_sample: List[List[Tuple[str, Optional[str]]]] = []
    for sample in parsed:
        roles: List[Tuple[str, Optional[str]]] = []
        cat_counts = Counter()
        for phrase in sample["phrases"]:
            ci = _match_constant(phrase, constants, fuzzy)
            if ci is not None:
                roles.append(("const", str(ci)))
                continue
            cat = classify(phrase)
            cat_counts[cat] += 1
            roles.append((f"slot:{cat}:{cat_counts[cat]}", phrase))
        per_sample.append(roles)

    slot_keys: List[str] = []
    for roles in per_sample:
        for role, _ in roles:
            if role.startswith("slot:") and role not in slot_keys:
                slot_keys.append(role)

    # Deterministic ordering: category semantics first, ordinal second.
    cat_rank = {c: i for i, c in enumerate(DEFAULT_CATEGORY_ORDER)}
    def sort_key(key: str):
        _, cat, idx = key.split(":", 2)
        return (cat_rank.get(cat, 999), cat, int(idx))
    slot_keys.sort(key=sort_key)

    used_names = Counter()
    slots: List[dict] = []
    for key in slot_keys:
        _, cat, _ = key.split(":", 2)
        vals: List[Optional[str]] = []
        for roles in per_sample:
            v = next((value for role, value in roles if role == key), None)
            vals.append(v)
        used_names[cat] += 1
        name = cat if used_names[cat] == 1 else f"{cat}{used_names[cat]}"
        nonempty = [normalize(v) for v in vals if v]
        slots.append({
            "key": key,
            "name": name,
            "category": cat,
            "values": vals,
            "optional": any(v is None for v in vals),
            "distinct": len(set(nonempty)),
            "evidence": "variable" if len(set(nonempty)) >= 2 else "weak",
        })
    return slots, per_sample


def _template_from_base(parsed: List[dict], base_i: int, constants: Sequence[dict], slots: Sequence[dict], fuzzy: float) -> Tuple[List[str], dict]:
    slot_by_key = {s["key"]: s for s in slots}
    cat_counts = Counter()
    parts: List[str] = []
    order_tokens: List[str] = []
    for phrase in parsed[base_i]["phrases"]:
        ci = _match_constant(phrase, constants, fuzzy)
        if ci is not None:
            parts.append(constants[ci]["text"])
            order_tokens.append(f"C{ci}")
            continue
        cat = classify(phrase)
        cat_counts[cat] += 1
        key = f"slot:{cat}:{cat_counts[cat]}"
        s = slot_by_key[key]
        token = "{{" + s["name"] + "}}"
        if s["optional"]:
            token = "[可选：" + token + "]"
        parts.append(token)
        order_tokens.append(f"S:{key}")
    return parts, {"tokens": order_tokens}


def _fill_template_parts(parts: Sequence[str], slots: Sequence[dict], sample_i: int) -> List[str]:
    out: List[str] = []
    for part in parts:
        replaced = False
        for s in slots:
            plain = "{{" + s["name"] + "}}"
            optional = "[可选：" + plain + "]"
            if part in (plain, optional):
                if s["values"][sample_i]:
                    out.append(s["values"][sample_i])
                replaced = True
                break
        if not replaced:
            out.append(part)
    return out


def _constant_order_score(parsed: List[dict], constants: Sequence[dict], fuzzy: float) -> float:
    if len(constants) <= 1 or len(parsed) <= 1:
        return 1.0
    orders = []
    for sample in parsed:
        seq = []
        for phrase in sample["phrases"]:
            ci = _match_constant(phrase, constants, fuzzy)
            if ci is not None and ci not in seq:
                seq.append(ci)
        orders.append(seq)
    base = max(orders, key=len)
    scores = []
    for seq in orders:
        # Reuse LCS logic on stringified ids.
        scores.append(lcs_ratio([str(x) for x in base], [str(x) for x in seq]))
    return sum(scores) / len(scores)


def extract_template(samples: List[str], threshold: float, fuzzy: float = 0.94) -> dict:
    parsed = [split_prompt(s) for s in samples]
    n = len(samples)
    base_i = max(range(n), key=lambda i: len(parsed[i]["phrases"]))
    constants = _constant_candidates(parsed, threshold, fuzzy)
    anchored = _anchored_slots(parsed, constants, fuzzy, base_i)
    if anchored is not None:
        slots, template_parts = anchored
        slot_alignment = "constant-anchor"
    else:
        positional = _positional_variable_slots(parsed, constants, fuzzy, base_i)
        if positional is not None:
            slots, template_parts = positional
            slot_alignment = "variable-position"
        else:
            slots, _ = _slot_values(parsed, constants, fuzzy)
            template_parts, _ = _template_from_base(parsed, base_i, constants, slots, fuzzy)
            slot_alignment = "semantic-fallback"

    # Params are compared as multisets/normalized strings, not sets with silent duplicate loss.
    param_counts = [Counter(normalize(x) for x in p["params"]) for p in parsed]
    common_param_counter = param_counts[0].copy() if param_counts else Counter()
    for c in param_counts[1:]:
        common_param_counter &= c
    all_param_counter = Counter()
    for c in param_counts:
        all_param_counter |= c
    common_params = list(common_param_counter.elements())
    variable_params = list((all_param_counter - common_param_counter).elements())

    negs = [normalize(p["negative"]) if p["negative"] else None for p in parsed]
    neg_common = parsed[0]["negative"] if negs and negs[0] and all(v == negs[0] for v in negs) else None

    lexical_precision, lexical_recall, lexical_f1, order_scores = [], [], [], []
    reconstructions = []
    for i in range(n):
        filled_parts = _fill_template_parts(template_parts, slots, i)
        p, r, f = multiset_overlap(filled_parts, parsed[i]["phrases"])
        lexical_precision.append(round(p, 3))
        lexical_recall.append(round(r, 3))
        lexical_f1.append(round(f, 3))
        order_scores.append(round(lcs_ratio(filled_parts, parsed[i]["phrases"]), 3))
        reconstructions.append(filled_parts)

    # Slot evidence: a slot with only one observed value is structurally possible but not empirically variable.
    evidenced_slots = [s for s in slots if s["distinct"] >= 2]
    slot_evidence = len(evidenced_slots) / max(1, len(slots)) if slots else 1.0
    const_presence = sum(c["presence"] for c in constants) / max(1, len(constants)) if constants else 0.0
    const_order = _constant_order_score(parsed, constants, fuzzy)
    avg_lex = sum(lexical_f1) / max(1, n)
    avg_order = sum(order_scores) / max(1, n)

    warnings: List[str] = []
    if const_order < 0.85:
        warnings.append("固定成分在不同样本中的顺序不稳定；可提炼组件骨架，但不能声称存在唯一固定句序。")
    if slot_alignment == "semantic-fallback":
        warnings.append("无法用固定成分锚点稳定对齐变量槽，已退回语义分类；槽位名称需人工复核。")
    if slot_evidence < 0.75:
        warnings.append("部分槽位缺少至少两个不同取值，变量身份证据不足。")
    if len(samples) < 3:
        warnings.append("样本少于 3 条，常量/变量判断容易过拟合。")
    if any(p["negative"] for p in parsed) and not neg_common:
        warnings.append("负面提示词不一致，应作为独立变量或可选模块处理。")
    if not constants:
        warnings.append("没有找到稳定重复常量；这批样本可能不属于同一母版，或需要降低阈值后人工复核。")

    # Conservative verdict. Lexical reconstruction alone is insufficient.
    if avg_lex >= 0.95 and avg_order >= 0.90 and const_order >= 0.90 and slot_evidence >= 0.75 and len(samples) >= 3:
        verdict = "PASS"
        verdict_zh = "结构逆向通过"
    elif avg_lex >= 0.85 and const_presence >= threshold * 0.9:
        verdict = "PARTIAL"
        verdict_zh = "部分通过，需人工/生成验证"
    else:
        verdict = "FAIL"
        verdict_zh = "证据不足，不能宣称逆向成功"

    template = "，".join(template_parts)
    if common_params:
        template += " " + " ".join(common_params)

    return {
        "engine_version": VERSION,
        "samples": n,
        "threshold": threshold,
        "fuzzy_threshold": fuzzy,
        "base_sample": base_i + 1,
        "template": template,
        "constants": constants,
        "slots": slots,
        "common_params": common_params,
        "variable_params": variable_params,
        "negative_common": neg_common,
        "metrics": {
            "lexical_precision": lexical_precision,
            "lexical_recall": lexical_recall,
            "lexical_f1": lexical_f1,
            "order_score": order_scores,
            "average_lexical_f1": round(avg_lex, 3),
            "average_order_score": round(avg_order, 3),
            "constant_presence": round(const_presence, 3),
            "constant_order_stability": round(const_order, 3),
            "slot_evidence": round(slot_evidence, 3),
        },
        "verdict": verdict,
        "verdict_zh": verdict_zh,
        "warnings": warnings,
        "slot_alignment": slot_alignment,
        "reconstructions": reconstructions,
    }


def anatomy(sample: str) -> dict:
    x = split_prompt(sample)
    comp: Dict[str, List[str]] = OrderedDict()
    for p in x["phrases"]:
        comp.setdefault(classify(p), []).append(p)
    return {"engine_version": VERSION, "components": comp, "params": x["params"], "negative": x["negative"]}


# ---------------------------------------------------------------- output
def md_single(a: dict) -> str:
    out = ["# 提示词成分拆解（单条样本）", "", f"> 引擎 v{a['engine_version']}。单条样本只能做结构推断，不能证明哪些词是真正常量。", ""]
    out += ["| 成分 | 内容 |", "| --- | --- |"]
    for cat, items in a["components"].items():
        out.append(f"| {cat} | {'；'.join(items)} |")
    if a["params"]:
        out.append(f"| 参数 | {' '.join(a['params'])} |")
    if a["negative"]:
        out.append(f"| 负面词 | {a['negative']} |")
    slots = [c for c in a["components"] if c not in STABLE_CATEGORIES]
    keep = [c for c in a["components"] if c in STABLE_CATEGORIES]
    out += ["", "## 候选母版", "",
            "这是**候选结构**，不是实证母版：",
            f"- 候选变量槽：{'、'.join(slots) or '（无）'}",
            f"- 候选稳定成分：{'、'.join(keep) or '（无）'}", "",
            "```", "，".join("{{" + c + "}}" if c in slots else "；".join(a["components"][c])
                            for c in a["components"]) + ((" " + " ".join(a["params"])) if a["params"] else ""), "```", "",
            "至少再给 2 条同系列样本，并做一次新槽值迁移测试，才能把推断升级为较强证据。"]
    return "\n".join(out)


def md_multi(r: dict) -> str:
    m = r["metrics"]
    out = [f"# 母版逆向（{r['samples']} 条样本）", "",
           f"**判定：{r['verdict_zh']}（{r['verdict']}）**", "",
           "## 候选母版", "", "```", r["template"], "```", ""]
    if r["negative_common"]:
        out += [f"负面词（全部样本一致）：`{r['negative_common']}`", ""]
    out += ["## 稳定成分", "", "这些成分按跨样本出现率识别，不要求原始句序一致：", ""]
    if r["constants"]:
        for c in r["constants"]:
            fuzzy = "；近似匹配" if c.get("fuzzy") else ""
            out.append(f"- [{c['category']}] {c['text']}（出现率 {c['presence']:.0%}{fuzzy}）")
    else:
        out.append("- （无）")
    out += ["", "## 变量槽", "", "| 槽位 | 类型 | 不同取值数 | 证据 | 各样本取值 |", "| --- | --- | ---: | --- | --- |"]
    for s in r["slots"]:
        vals = " / ".join(f"#{i + 1}:{v}" for i, v in enumerate(s["values"]) if v) or "（无）"
        tag = "（可选）" if s["optional"] else ""
        ev = "有变化证据" if s["evidence"] == "variable" else "弱：仅一个观察值"
        out.append(f"| {{{{{s['name']}}}}}{tag} | {s['category']} | {s['distinct']} | {ev} | {vals} |")
    if r["common_params"] or r["variable_params"]:
        out += ["", f"参数常量：{' '.join(r['common_params']) or '无'}；参数变量：{' '.join(r['variable_params']) or '无'}"]
    out += ["", "## 验证评分", "",
            "这里不再用单一“覆盖率”冒充成功：",
            f"- 文本成分 F1：{', '.join(f'#{i+1} {x:.0%}' for i, x in enumerate(m['lexical_f1']))}（均值 {m['average_lexical_f1']:.0%}）",
            f"- 句序一致度：{', '.join(f'#{i+1} {x:.0%}' for i, x in enumerate(m['order_score']))}（均值 {m['average_order_score']:.0%}）",
            f"- 常量出现稳定度：{m['constant_presence']:.0%}",
            f"- 常量顺序稳定度：{m['constant_order_stability']:.0%}",
            f"- 槽位变化证据率：{m['slot_evidence']:.0%}", ""]
    if r["warnings"]:
        out += ["## 风险提示", ""] + [f"- {w}" for w in r["warnings"]]
    out += ["", "## 怎么解释这个判定", "",
            "PASS 只代表“文本结构证据较强”；真正的生成机制逆向仍需至少一次**迁移复现**：换全新的主体/场景生成，确认风格与关键行为仍稳定。",
            "如果文本 F1 很高但句序或常量顺序很低，只能说明这些词都出现了，不能说明存在唯一固定母版句序。"]
    return "\n".join(out)


def main() -> None:
    ap = argparse.ArgumentParser(description="提示词逆向 v2：区分文本复原、句序稳定和变量证据")
    ap.add_argument("inputs", nargs="+", help="文件路径，或 - 表示标准输入")
    ap.add_argument("--sep", help="自定义样本分隔符")
    ap.add_argument("--input-mode", choices=["auto", "line", "block", "file"], default="auto",
                    help="输入拆分方式；auto 会保护 Negative Prompt 多行块")
    ap.add_argument("--threshold", type=float, default=1.0, help="稳定成分最低跨样本出现率，默认 1.0")
    ap.add_argument("--fuzzy", type=float, default=0.94, help="短语近似匹配阈值，默认 0.94")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--version", action="version", version=VERSION)
    a = ap.parse_args()
    if not 0 < a.threshold <= 1:
        ap.error("--threshold 必须在 (0, 1] 范围内")
    if not 0.5 <= a.fuzzy <= 1:
        ap.error("--fuzzy 建议在 [0.5, 1] 范围内")
    samples = read_samples(a.inputs, a.sep, a.input_mode)
    if not samples:
        sys.exit("没有读到提示词")
    if len(samples) == 1:
        res = anatomy(samples[0])
        print(json.dumps(res, ensure_ascii=False, indent=2) if a.json else md_single(res))
    else:
        res = extract_template(samples, a.threshold, a.fuzzy)
        print(json.dumps(res, ensure_ascii=False, indent=2) if a.json else md_multi(res))


if __name__ == "__main__":
    main()
