# QA Gates

## P0 structural hard fails
Reject before expensive production when any of these occur:
- missing/duplicate shot or event identity
- invalid/out-of-order shot/event timing
- event outside shot window
- unknown event type
- missing UI component or incomplete component states
- invalid anchor/tracking/occlusion/perspective enum
- normalized geometry outside [0,1]
- moving anchor without monotonic keyframes/external track
- hotspot without an anchor
- state mutation without Canonical Action ID
- duplicate commit
- QTE missing success/timeout action or positive window
- progress regression/overflow
- settlement before required completion
- strict upstream mode invents a Node/Action ID not in the upstream contract

## Required adversarial run

```bash
python scripts/stress_project.py project.json --output stress-report.json
```

Release candidate requires zero missed mutations plus PASS for double-commit blocking, deterministic timeout and save/load restoration.

## Visual/interaction review
A valid schema can still look bad. Review actual imagery for face/action collisions, unreadable copy, weak selection acknowledgement, HUD-only consequences, stale UI, hotspot slip, incorrect foreground occlusion, bad perspective, low contrast and simultaneous effect noise.

Use `storyboard.html` for shot-level review and `preview.html` for exact CET timing. For the fusion execution path run `run_fusion_probe.py`; it proves track/mask compositing mechanics, **not** the quality of a tracker on the client's real shot.

## Evidence cannot be self-declared
Legacy booleans such as `pixel_fusion_verified: true` do not certify a release. Final status requires measured evidence objects:
- pixel fusion: actual footage, report ref, measured anchor error, at least one occlusion case, contrast check;
- runtime: target, report ref, double-commit, QTE timeout, save/load, measured branch latency;
- audio: rendered output, report ref, sync check.

PREVIS may pass without these. FINAL VIDEO / INTERACTIVE RUNTIME may not.

## Release replay
Run full tests, golden WorkBuddy build, browser JS execution, stress suite and fusion probe; rebuild manifest; archive; extract into a new directory; rerun everything from extracted bytes; verify hashes. Development-tree PASS is not release PASS.
