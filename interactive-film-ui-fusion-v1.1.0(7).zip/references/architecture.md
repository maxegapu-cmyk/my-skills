# Architecture

## Boundary
This is an add-on to interactive-film systems. Upstream owns story graph, player identity, branch budget, canonical state/actions, continuity and director truth. UI Fusion owns visible interaction execution.

```text
approved nodes/actions/media
        ↓
Canonical Event Timeline (CET)
        ├─ UI component/state specs + SVG starters
        ├─ fusion anchors / track / mask contracts
        ├─ WorkBuddy-style storyboard + AI bottom-plate prompt pack
        ├─ frame-synced browser preview
        ├─ deterministic runtime/stress simulation
        └─ adapter handoffs
             ├─ Web/H5
             ├─ Remotion/linear effect video
             └─ Unity/existing FMV runtime
```

## Why CET is central
Do not let UI code become a second story engine. Event/action identity and state deltas are shared across all outputs. The board, linear effect video and actual interactive runtime are different renderings of one truth.

## Three clocks
- Media clock: what frame is really presented.
- Overlay clock: what event/UI is active.
- Commit ledger: what legal canonical action mutated state.

These may advance differently; only the commit ledger changes canonical state.

## Production order
1. upstream/story/state approval;
2. CET + UI states + safe zones;
3. storyboard and timing preview;
4. stress/runtime simulation;
5. AI/real bottom plates;
6. hardest real fusion shot (tracking + foreground crossing) first;
7. batch render/runtime implementation;
8. measured evidence + fresh-package replay.

A visually polished mockup is not evidence that a runtime or real-footage fusion path works.
