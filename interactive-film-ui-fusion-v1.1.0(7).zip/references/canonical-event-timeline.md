# Canonical Event Timeline (CET)

CET is the only cross-renderer interaction timeline. UI code, Remotion, Web/Phaser and Unity may render it differently; they may not invent a second action/state truth.

## Event shape

```json
{
  "id": "e021",
  "type": "HOTSPOT_HIT",
  "at": 12.6,
  "duration_sec": 0.45,
  "component": "quest-card",
  "anchor": "sword-2",
  "interaction_instance": "find-swords",
  "action_id": "quest.find_sword_2",
  "commit_once": true,
  "state_write": {"quest.found": 2}
}
```

## Event families
- Lifecycle: `GAME_START`, `HUD_ENTER`, `HUD_CLEAR`, `BRAND_OUTRO`
- Quest: `QUEST_OPEN`, `QUEST_PROGRESS`, `QUEST_COMPLETE`, `QUEST_FAIL`
- Interaction: `HOTSPOT_OPEN`, `HOTSPOT_HIT`, `CHOICE_OPEN`, `ACTION_COMMIT`, `QTE_OPEN`, `QTE_TIMEOUT`
- Response: `RESPONSE_PULSE`, `STAMP_IMPACT`, `ACHIEVEMENT_UNLOCK`, `MAP_UNLOCK`, `COLLECTION_UPDATE`
- Meta: `ROUTE_REVEAL`, `TIP_OPEN`, `COLLECTION_COMPLETE`, `SETTLEMENT_OPEN`, `REWARD_REVEAL`

## Commit semantics
Visual selection is not state mutation. Preferred lifecycle:

`OPEN → AWAITING_INPUT → SELECTED → COMMITTED → REACT → STATE_PULSE → CLEAR → NEXT_HOOK`

`COMMITTED` occurs once per canonical action. A rerender, double click, dropped video frame, animation replay or adapter retry cannot repeat the mutation.

## QTE is a three-result contract
A real QTE must explicitly carry:
- `action_id`: opening/arming the interaction;
- `success_action_id`: legal successful player action;
- `timeout_action_id`: deterministic no-action/timeout result;
- `window_sec`: positive interaction window.

Without a success action the linear preview may look correct while the real runtime remains ambiguous; treat that as P0.

## Progress
Progress declares integer `current` and stable `total`. It cannot regress/overflow unless a separate canonical reset action explicitly authorizes it.

## Timing
Author in seconds and preserve source shot/node IDs. Adapters may convert to frame index/playback time/video-frame callbacks but preserve event IDs, canonical action IDs and state deltas exactly.
