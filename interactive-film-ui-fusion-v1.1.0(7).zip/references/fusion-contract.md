# Video Fusion Contract

## Anchor types
- `SCREEN`: fixed HUD
- `POINT`: tracked point
- `BOX`: rectangular target
- `QUAD`: four-corner plane
- `OBJECT`: semantic object + track
- `CHARACTER`: tracked person
- `WORLD_REGION`: larger interactive area

## Tracking
- `static`
- `keyframe`: normalized time/geometry samples
- `external-track`: replaceable CV/tool output via `track_ref`

Tracking producers are adapters. The core contract must survive changing tracker/model.

## Occlusion
- `none`
- `foreground-mask`
- `object-mask`

If foreground crosses a world-attached UI, specify a mask path/producer. Do not fake world attachment with a permanently screen-front graphic.

## Perspective
- `none`
- `affine`
- `homography`

Use homography for UI attached to a real planar sign/surface when four-corner perspective matters.

## Normalization
Geometry is normalized [0,1] relative to source frame. Tracks remain portable across 1080p/4K/renderers.

## Production proof
`run_fusion_probe.py` creates a real MP4 diagnostic proving normalized moving anchor → overlay → foreground mask → encoded/decoded video. Final client footage still needs its own measured evidence: anchor error, occlusion cases, contrast and subjective integration.

If tracking confidence is poor, degrade to a screen-space callout instead of pretending the overlay is physically attached.
