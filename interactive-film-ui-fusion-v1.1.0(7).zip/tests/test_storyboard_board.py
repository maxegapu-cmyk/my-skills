import json
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class StoryboardBoardTests(unittest.TestCase):
    def test_workbuddy_board_contains_18_visual_cards_and_production_text(self):
        from scripts.generate_storyboard_board import generate_storyboard_board
        project=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        with tempfile.TemporaryDirectory() as td:
            out=Path(td)/'storyboard.html'
            generate_storyboard_board(project,out)
            text=out.read_text(encoding='utf-8')
            self.assertEqual(text.count('class="shot-card"'),18)
            self.assertIn('一城揽三国',text)
            self.assertIn('田子坊',text)
            self.assertIn('西门吹雪',text)
            self.assertIn('隐藏成就',text)
            self.assertIn('S 评级',text)
            self.assertIn('voiceover',text)
            self.assertIn('data-shot="L18"',text)

if __name__=='__main__': unittest.main()

class StoryboardMediaTests(unittest.TestCase):
    def test_local_still_can_be_embedded_for_portable_client_board(self):
        from scripts.generate_storyboard_board import generate_storyboard_board
        import base64
        project=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            # 1x1 PNG
            png=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Zs5sAAAAASUVORK5CYII=')
            (td/'still.png').write_bytes(png)
            project['shots'][0]['media']={'still_src':'still.png'}
            out=td/'board.html'
            generate_storyboard_board(project,out,base_dir=td)
            text=out.read_text(encoding='utf-8')
            self.assertIn('data:image/png;base64,',text)
            self.assertIn('class="shot-media"',text)

if __name__=='__main__': unittest.main()
