import copy
import json
import unittest
from pathlib import Path
from scripts.validate_project import validate_project

ROOT = Path(__file__).resolve().parents[1]

class ValidationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = json.loads((ROOT / 'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))

    def test_golden_project_validates(self):
        self.assertEqual(validate_project(self.project), [])

    def test_duplicate_commit_is_rejected(self):
        p = copy.deepcopy(self.project)
        dup = copy.deepcopy(p['shots'][5]['events'][1])
        dup['id'] = 'e999'
        p['shots'][5]['events'].append(dup)
        errors = validate_project(p)
        self.assertTrue(any('duplicate commit' in e.lower() for e in errors), errors)

    def test_bad_normalized_coordinate_is_rejected(self):
        p = copy.deepcopy(self.project)
        p['anchors']['sword-1']['keyframes'][0]['x'] = 1.2
        errors = validate_project(p)
        self.assertTrue(any('coordinate' in e.lower() for e in errors), errors)

    def test_qte_without_timeout_is_rejected(self):
        p = copy.deepcopy(self.project)
        del p['shots'][6]['events'][0]['timeout_action_id']
        errors = validate_project(p)
        self.assertTrue(any('timeout' in e.lower() for e in errors), errors)

    def test_missing_component_is_rejected(self):
        p = copy.deepcopy(self.project)
        p['shots'][0]['events'][0]['component'] = 'missing-widget'
        errors = validate_project(p)
        self.assertTrue(any('component' in e.lower() for e in errors), errors)

if __name__ == '__main__':
    unittest.main()
