import copy
import json
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class UpstreamCompatTests(unittest.TestCase):
    def test_normalizes_old_interactive_film_runtime_contract(self):
        from scripts.import_upstream_contract import normalize_upstream_contract
        upstream={
            'project_id':'legacy-film',
            'nodes':[
                {'id':'NODE_A01','interaction':{
                    'start_sec':3.2,'end_sec':5.0,'pause_behavior':'continue',
                    'actions':[{'id':'look_sword','action_id':'a.look_sword'}, {'id':'leave','action_id':'a.leave'}],
                    'timeout_action_id':'a.timeout'
                }}
            ],
            'canonical_actions':['a.look_sword','a.leave','a.timeout']
        }
        out=normalize_upstream_contract(upstream)
        self.assertEqual(out['node_ids'],['NODE_A01'])
        self.assertEqual(out['action_ids'],['a.leave','a.look_sword','a.timeout'])
        self.assertEqual(out['interaction_windows'][0]['start_sec'],3.2)
        self.assertEqual(out['interaction_windows'][0]['pause_behavior'],'continue')

    def test_strict_upstream_project_rejects_invented_canonical_action(self):
        from scripts.validate_project import validate_project
        project=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        project['upstream_contract']={
            'source_system':'interactive-film-production',
            'strict_actions':True,
            'node_ids':['L1'],
            'action_ids':['game.start','hud.enter']
        }
        project['shots']=project['shots'][:1]
        project['shots'][0]['upstream_node_id']='L1'
        project['shots'][0]['events'][0]['action_id']='invented.action'
        errors=validate_project(project)
        self.assertTrue(any('upstream' in e.lower() and 'action' in e.lower() for e in errors),errors)

    def test_strict_upstream_project_accepts_preserved_ids(self):
        from scripts.validate_project import validate_project
        project=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        project['upstream_contract']={
            'source_system':'interactive-film-production',
            'strict_actions':True,
            'node_ids':['L1'],
            'action_ids':['game.start','hud.enter']
        }
        project['shots']=project['shots'][:1]
        project['shots'][0]['upstream_node_id']='L1'
        errors=validate_project(project)
        self.assertFalse(any('upstream' in e.lower() for e in errors),errors)

if __name__=='__main__': unittest.main()
