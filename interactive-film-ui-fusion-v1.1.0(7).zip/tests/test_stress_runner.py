import json
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class StressRunnerTests(unittest.TestCase):
    def test_golden_project_survives_adversarial_suite(self):
        from scripts.stress_project import stress_project
        project=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        report=stress_project(project)
        self.assertEqual(report['mutation_cases'],16)
        self.assertEqual(report['mutation_missed'],[])
        self.assertEqual(report['mutation_detection_rate'],1.0)
        self.assertTrue(report['runtime']['double_commit_blocked'])
        self.assertTrue(report['runtime']['qte_timeout_once'])
        self.assertTrue(report['runtime']['save_load_preserved'])
        self.assertTrue(report['golden_valid'])

if __name__=='__main__': unittest.main()
