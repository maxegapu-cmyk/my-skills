import json
import unittest
from pathlib import Path
from scripts.compile_overlay import compile_overlay

ROOT=Path(__file__).resolve().parents[1]

class GoldenFixtureTests(unittest.TestCase):
    def test_workbuddy_summary_matches_golden(self):
        project=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        expected=json.loads((ROOT/'fixtures/workbuddy-v5/expected-summary.json').read_text(encoding='utf-8'))
        out=compile_overlay(project)
        actual={
            'shot_count':out['summary']['shot_count'],
            'event_count':out['summary']['event_count'],
            'progress_start':out['summary']['progress_start'],
            'progress_end':out['summary']['progress_end'],
            'duration_sec':out['summary']['duration_sec'],
            'milestones':[e['type'] for e in out['events'] if e['type'] in {'GAME_START','ROUTE_REVEAL','HOTSPOT_HIT','ACHIEVEMENT_UNLOCK','COLLECTION_COMPLETE','SETTLEMENT_OPEN','BRAND_OUTRO'}]
        }
        self.assertEqual(actual, expected)

if __name__=='__main__': unittest.main()
