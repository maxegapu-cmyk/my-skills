import tempfile
import unittest
import xml.etree.ElementTree as ET
from pathlib import Path
from scripts.generate_svg_assets import generate_assets

class SvgAssetTests(unittest.TestCase):
    def test_generates_required_editable_svg_assets(self):
        with tempfile.TemporaryDirectory() as td:
            paths = generate_assets(Path(td))
            names = {p.name for p in paths}
            expected = {'timer.svg','quest-card.svg','tip-bubble.svg','stamp.svg','map-node.svg','collection-slot.svg','settlement.svg','route-map.svg','collection-bar.svg','brand-outro.svg'}
            self.assertTrue(expected.issubset(names), expected - names)
            for p in paths:
                root = ET.parse(p).getroot()
                self.assertTrue(root.tag.endswith('svg'))
                self.assertTrue(root.get('data-component-id'))

if __name__ == '__main__':
    unittest.main()
