import json
import unittest
from pathlib import Path
from scripts.compile_overlay import compile_overlay

ROOT = Path(__file__).resolve().parents[1]

class CompileOverlayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.project = json.loads((ROOT / 'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))

    def test_compile_has_18_shots(self):
        out = compile_overlay(self.project)
        self.assertEqual(out['summary']['shot_count'], 18)

    def test_compile_progress_reaches_8_of_8(self):
        out = compile_overlay(self.project)
        self.assertEqual(out['summary']['progress_start'], '0/8')
        self.assertEqual(out['summary']['progress_end'], '8/8')

    def test_events_are_deterministically_sorted(self):
        out = compile_overlay(self.project)
        keys = [(e['at'], e['id']) for e in out['events']]
        self.assertEqual(keys, sorted(keys))

    def test_key_milestones_exist(self):
        out = compile_overlay(self.project)
        types = {e['type'] for e in out['events']}
        for expected in ['GAME_START','ROUTE_REVEAL','HOTSPOT_HIT','ACHIEVEMENT_UNLOCK','COLLECTION_COMPLETE','SETTLEMENT_OPEN','BRAND_OUTRO']:
            self.assertIn(expected, types)

if __name__ == '__main__':
    unittest.main()
