import json
import tempfile
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class PrevisPromptTests(unittest.TestCase):
    def test_workbuddy_generates_18_clean_bottom_plate_prompts(self):
        from scripts.generate_previs_prompts import generate_previs_prompts
        project=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        text=generate_previs_prompts(project)
        self.assertEqual(text.count('## L'),18)
        self.assertIn('不要把 HUD、文字、按钮、地图、印章直接生成进底图',text)
        self.assertIn('田子坊',text)
        self.assertIn('低角度',text)
        self.assertIn('玻璃反射',text)
        self.assertIn('真实上海',text)

if __name__=='__main__': unittest.main()
