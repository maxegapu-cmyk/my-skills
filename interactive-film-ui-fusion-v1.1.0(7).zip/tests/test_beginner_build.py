import json
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class BeginnerBuildTests(unittest.TestCase):
    def test_one_command_builder_outputs_complete_review_bundle(self):
        from scripts.build_project import build_project
        project = json.loads((ROOT / 'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        with tempfile.TemporaryDirectory() as td:
            output = Path(td) / 'bundle'
            result = build_project(project, output)
            expected = {
                'cet.json', 'preview.html', 'storyboard.html', 'production-report.md', 'readiness.json',
                'runtime-simulation.json', 'stress-report.json', 'media-readiness.json', 'previs-prompts.md', 'BEGINNER-START.md',
                'bridges/web-bridge.json', 'bridges/remotion-bridge.json', 'bridges/unity-bridge.json',
                'assets/timer.svg', 'assets/route-map.svg', 'assets/collection-bar.svg',
                'assets/quest-card.svg', 'assets/stamp.svg', 'assets/settlement.svg', 'assets/brand-outro.svg'
            }
            actual = {str(p.relative_to(output)).replace('\\','/') for p in output.rglob('*') if p.is_file()}
            self.assertTrue(expected.issubset(actual), expected - actual)
            self.assertTrue(result['ready_for_previs'])


if __name__ == '__main__':
    unittest.main()
