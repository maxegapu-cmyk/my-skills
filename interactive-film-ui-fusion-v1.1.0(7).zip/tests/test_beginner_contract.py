import json
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class BeginnerContractTests(unittest.TestCase):
    def test_beginner_workflow_reference_is_actionable(self):
        ref=ROOT/'references/beginner-workflow.md'
        self.assertTrue(ref.exists())
        text=ref.read_text(encoding='utf-8')
        for phrase in ['build_project.py','preview.html','storyboard.html','stress_project.py','真实视频','P0','P1']:
            self.assertIn(phrase,text)

    def test_project_template_uses_current_schema_and_full_ui_states(self):
        data=json.loads((ROOT/'templates/project.json').read_text(encoding='utf-8'))
        self.assertEqual(data['schema_version'],'1.1')
        self.assertIn('production_profile',data)
        self.assertIn('visual_profile',data)
        states=data['ui_registry']['quest-card']['states']
        for state in ['HIDDEN','INTRO','ACTIVE','SUCCESS','EXIT']:
            self.assertIn(state,states)

if __name__=='__main__': unittest.main()
