import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class SkillContractTests(unittest.TestCase):
    def test_skill_has_discoverable_frontmatter_and_core_contracts(self):
        path = ROOT / 'SKILL.md'
        self.assertTrue(path.exists(), 'SKILL.md must exist')
        text = path.read_text(encoding='utf-8')
        self.assertTrue(text.startswith('---\n'))
        name = re.search(r'^name:\s*([a-z0-9-]+)\s*$', text, re.M)
        desc = re.search(r'^description:\s*(.+)$', text, re.M)
        self.assertIsNotNone(name)
        self.assertEqual(name.group(1), 'interactive-film-ui-fusion')
        self.assertIsNotNone(desc)
        self.assertTrue(desc.group(1).startswith('Use when'))
        for phrase in ['Canonical Event Timeline', 'commit', 'QTE', 'fusion', 'adapter']:
            self.assertIn(phrase, text)
        self.assertIn('generate_html_preview.py', text)
        for phrase in ['build_project.py','stress_project.py','run_fusion_probe.py','import_upstream_contract.py','storyboard.html','actual footage']:
            self.assertIn(phrase, text)
        self.assertIsNotNone(re.search(r'^version:\s*1\.1\.0\s*$', text, re.M))

    def test_skill_references_required_heavy_docs(self):
        text = (ROOT / 'SKILL.md').read_text(encoding='utf-8')
        for ref in ['architecture.md','canonical-event-timeline.md','ui-component-contract.md','fusion-contract.md','adapter-contracts.md','qa-gates.md','beginner-workflow.md']:
            self.assertIn(ref, text)
            self.assertTrue((ROOT / 'references' / ref).exists())

if __name__ == '__main__':
    unittest.main()
