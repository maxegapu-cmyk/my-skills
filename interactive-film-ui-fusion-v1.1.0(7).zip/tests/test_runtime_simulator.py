import json
import unittest
from pathlib import Path

from scripts.compile_overlay import compile_overlay

ROOT=Path(__file__).resolve().parents[1]

class RuntimeSimulatorTests(unittest.TestCase):
    def setUp(self):
        self.project=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        self.overlay=compile_overlay(self.project)

    def test_double_commit_is_idempotent(self):
        from scripts.simulate_runtime import RuntimeSimulator
        sim=RuntimeSimulator(self.project)
        event=next(e for e in self.overlay['events'] if e['id']=='e009')
        first=sim.commit_event(event)
        second=sim.commit_event(event)
        self.assertTrue(first['committed'])
        self.assertFalse(second['committed'])
        self.assertEqual(sim.state['quest.tianzifang.found'],1)
        self.assertEqual(sim.commit_count('quest.tianzifang.find1'),1)

    def test_qte_timeout_is_deterministic(self):
        from scripts.simulate_runtime import RuntimeSimulator
        sim=RuntimeSimulator(self.project)
        qte=next(e for e in self.overlay['events'] if e['id']=='e015')
        sim.open_qte(qte)
        result=sim.tick(qte['at']+qte['window_sec']+0.001)
        self.assertIn('quest.nanchang.timeout',result['committed_actions'])
        again=sim.tick(qte['at']+qte['window_sec']+1.0)
        self.assertNotIn('quest.nanchang.timeout',again['committed_actions'])
        self.assertEqual(sim.commit_count('quest.nanchang.timeout'),1)


    def test_qte_success_commits_success_once_and_blocks_timeout(self):
        from scripts.simulate_runtime import RuntimeSimulator
        sim=RuntimeSimulator(self.project)
        qte=next(e for e in self.overlay['events'] if e['id']=='e015')
        opened=sim.open_qte(qte)
        result=sim.resolve_qte(opened['qte_id'])
        self.assertTrue(result['committed'])
        self.assertEqual(result['action_id'],qte['success_action_id'])
        after=sim.tick(qte['at']+qte['window_sec']+1.0)
        self.assertNotIn(qte['timeout_action_id'],after['committed_actions'])
        again=sim.resolve_qte(opened['qte_id'])
        self.assertFalse(again['committed'])
        self.assertEqual(sim.commit_count(qte['success_action_id']),1)

    def test_save_load_restores_canonical_state_and_commit_ledger(self):
        from scripts.simulate_runtime import RuntimeSimulator
        sim=RuntimeSimulator(self.project)
        for event_id in ('e009','e010','e011','e014'):
            sim.commit_event(next(e for e in self.overlay['events'] if e['id']==event_id))
        payload=sim.snapshot()
        restored=RuntimeSimulator.from_snapshot(self.project,payload)
        self.assertEqual(restored.state,sim.state)
        self.assertEqual(restored.progress,{'current':1,'total':8})
        duplicate=restored.commit_event(next(e for e in self.overlay['events'] if e['id']=='e009'))
        self.assertFalse(duplicate['committed'])

    def test_linear_golden_replay_reaches_8_of_8(self):
        from scripts.simulate_runtime import RuntimeSimulator
        sim=RuntimeSimulator(self.project)
        report=sim.replay(self.overlay['events'])
        self.assertEqual(report['progress'],{'current':8,'total':8})
        self.assertIn('settlement.s',report['committed_actions'])
        self.assertEqual(report['duplicate_commits'],0)

if __name__=='__main__': unittest.main()
