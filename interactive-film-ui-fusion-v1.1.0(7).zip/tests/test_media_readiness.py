import copy
import json
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

class MediaReadinessTests(unittest.TestCase):
    def setUp(self):
        self.project=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))

    def test_final_video_mode_requires_real_media(self):
        from scripts.verify_media_assets import verify_media_assets
        p=copy.deepcopy(self.project); p['delivery_mode']='FINAL_VIDEO'
        r=verify_media_assets(p, ROOT/'fixtures/workbuddy-v5/project.json')
        self.assertFalse(r['pass'])
        self.assertTrue(any('master' in x.lower() or 'media' in x.lower() for x in r['p0']),r)

    def test_previs_mode_allows_missing_real_media_but_marks_limit(self):
        from scripts.verify_media_assets import verify_media_assets
        r=verify_media_assets(self.project, ROOT/'fixtures/workbuddy-v5/project.json')
        self.assertTrue(r['pass'])
        self.assertTrue(any('previs' in x.lower() or 'media' in x.lower() for x in r['p1']),r)

if __name__=='__main__': unittest.main()

class BuildMediaGateTests(unittest.TestCase):
    def test_final_video_build_refuses_missing_real_media(self):
        from scripts.build_project import build_project
        p=json.loads((ROOT/'fixtures/workbuddy-v5/project.json').read_text(encoding='utf-8'))
        p['delivery_mode']='FINAL_VIDEO'
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError):
                build_project(p,Path(td)/'out')
