#!/usr/bin/env python3
"""Compile project shots into a deterministic Canonical Event Timeline (CET)."""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any

import sys

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.validate_project import validate_project


DEFAULT_EVENT_LIFETIME = {
    "GAME_START": 1.4,
    "HUD_ENTER": 0.8,
    "QUEST_OPEN": 1.8,
    "QUEST_PROGRESS": 0.7,
    "QUEST_COMPLETE": 1.0,
    "QUEST_FAIL": 1.0,
    "HOTSPOT_OPEN": 1.5,
    "HOTSPOT_HIT": 0.45,
    "CHOICE_OPEN": 2.0,
    "ACTION_COMMIT": 0.55,
    "QTE_OPEN": 2.0,
    "QTE_TIMEOUT": 0.8,
    "RESPONSE_PULSE": 0.8,
    "STAMP_IMPACT": 0.65,
    "ACHIEVEMENT_UNLOCK": 1.2,
    "MAP_UNLOCK": 0.55,
    "COLLECTION_UPDATE": 0.55,
    "COLLECTION_COMPLETE": 0.8,
    "SETTLEMENT_OPEN": 3.4,
    "REWARD_REVEAL": 2.0,
    "ROUTE_REVEAL": 2.2,
    "TIP_OPEN": 1.3,
    "HUD_CLEAR": 0.7,
    "BRAND_OUTRO": 2.7,
}


def compile_overlay(project: dict[str, Any]) -> dict[str, Any]:
    errors = validate_project(project)
    if errors:
        raise ValueError("project validation failed: " + " | ".join(errors))

    events: list[dict[str, Any]] = []
    shot_records: list[dict[str, Any]] = []
    progress_updates: list[dict[str, int]] = []
    for shot in project["shots"]:
        shot_event_ids: list[str] = []
        for event in shot.get("events") or []:
            compiled = copy.deepcopy(event)
            compiled["shot_id"] = shot["id"]
            compiled["shot_start"] = shot["start"]
            compiled["shot_end"] = shot["end"]
            lifetime = float(compiled.get("duration_sec", DEFAULT_EVENT_LIFETIME.get(compiled["type"], 0.6)))
            compiled["duration_sec"] = lifetime
            compiled["end_at"] = min(float(shot["end"]), float(compiled["at"]) + lifetime)
            events.append(compiled)
            shot_event_ids.append(event["id"])
            if event.get("progress"):
                progress_updates.append(copy.deepcopy(event["progress"]))
        shot_records.append({
            "id": shot["id"],
            "start": shot["start"],
            "end": shot["end"],
            "copy": copy.deepcopy(shot.get("copy", {})),
            "audio": copy.deepcopy(shot.get("audio", {})),
            "visual": copy.deepcopy(shot.get("visual", {})),
            "event_ids": shot_event_ids,
        })

    events.sort(key=lambda e: (float(e["at"]), str(e["id"])))
    total = int(project.get("collection", {}).get("total") or (progress_updates[0]["total"] if progress_updates else 0))
    initial = int(project.get("collection", {}).get("initial", 0))
    end_current = progress_updates[-1]["current"] if progress_updates else initial

    return {
        "schema_version": "1.1",
        "timeline_type": "canonical-event-timeline",
        "project_id": project["project_id"],
        "title": project.get("title", project["project_id"]),
        "frame": copy.deepcopy(project["frame"]),
        "delivery_mode": project.get("delivery_mode", "PREVIS"),
        "production_profile": copy.deepcopy(project.get("production_profile", {})),
        "visual_profile": copy.deepcopy(project.get("visual_profile", {})),
        "media": copy.deepcopy(project.get("media", {})),
        "timer": copy.deepcopy(project.get("timer", {})),
        "route": copy.deepcopy(project.get("route", {})),
        "collection": copy.deepcopy(project.get("collection", {})),
        "ui_registry": copy.deepcopy(project.get("ui_registry", {})),
        "anchors": copy.deepcopy(project.get("anchors", {})),
        "shots": shot_records,
        "events": events,
        "summary": {
            "shot_count": len(shot_records),
            "event_count": len(events),
            "progress_start": f"{initial}/{total}",
            "progress_end": f"{end_current}/{total}",
            "duration_sec": max((s["end"] for s in shot_records), default=0),
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    project = json.loads(args.project.read_text(encoding="utf-8"))
    try:
        compiled = compile_overlay(project)
    except ValueError as exc:
        print(f"FAIL: {exc}")
        return 1
    text = json.dumps(compiled, ensure_ascii=False, indent=2, sort_keys=False) + "\n"
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text, encoding="utf-8")
        print(f"PASS: wrote {args.out}")
    else:
        print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
