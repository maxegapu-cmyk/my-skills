#!/usr/bin/env python3
"""One-command beginner build for a complete UI-fusion review bundle."""
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path
from typing import Any

import sys
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.audit_production_readiness import audit_project
from scripts.compile_overlay import compile_overlay
from scripts.export_runtime_bridge import export_bridges
from scripts.generate_html_preview import generate_preview
from scripts.generate_svg_assets import generate_assets
from scripts.generate_storyboard_board import generate_storyboard_board
from scripts.generate_previs_prompts import generate_previs_prompts
from scripts.simulate_runtime import RuntimeSimulator
from scripts.stress_project import stress_project
from scripts.validate_project import validate_project
from scripts.verify_media_assets import verify_media_assets


def _production_report(project: dict[str, Any], readiness: dict[str, Any], overlay: dict[str, Any]) -> str:
    lines = [
        f"# {project.get('title', project['project_id'])} — UI Fusion Production Report",
        "",
        f"- Project: `{project['project_id']}`",
        f"- Delivery mode: `{project.get('delivery_mode', 'PREVIS')}`",
        f"- Readiness score: **{readiness['score']}/100**",
        f"- Previs ready: **{readiness['ready_for_previs']}**",
        f"- Final pixel fusion verified: **{readiness['pixel_fusion_verified']}**",
        f"- Shots: **{overlay['summary']['shot_count']}**",
        f"- CET events: **{overlay['summary']['event_count']}**",
        f"- Progress: **{overlay['summary']['progress_start']} → {overlay['summary']['progress_end']}**",
        "",
        "## Shot UI plan",
        "",
        "| Shot | Time | Headline | UI events | SFX |",
        "|---|---:|---|---|---|",
    ]
    for shot in project["shots"]:
        events = ", ".join(e["type"] for e in shot.get("events") or [])
        headline = (shot.get("copy") or {}).get("headline", "")
        sfx = (shot.get("audio") or {}).get("sfx", "")
        lines.append(f"| {shot['id']} | {shot['start']:.1f}–{shot['end']:.1f} | {headline} | {events} | {sfx} |")
    lines += ["", "## Remaining release limits", ""]
    if readiness["remaining_limits"]:
        lines.extend(f"- {item}" for item in readiness["remaining_limits"])
    else:
        lines.append("- None declared.")
    lines += ["", "## Beginner next step", "", "Open `preview.html`, scrub the 18-shot timeline, then replace PREVIS footage with real video only after the UI/event timing is approved.", ""]
    return "\n".join(lines)


def build_project(project: dict[str, Any], output_dir: Path, project_path: Path | None = None) -> dict[str, Any]:
    errors = validate_project(project)
    if errors:
        raise ValueError("project validation failed: " + " | ".join(errors))
    readiness = audit_project(project)
    if not readiness["ready_for_previs"]:
        raise ValueError("project is not ready for previs: " + " | ".join(readiness["p0"]))
    media_readiness = verify_media_assets(project, project_path or (Path.cwd() / "project.json"))
    if str(project.get("delivery_mode", "PREVIS")).upper() in {"FINAL_VIDEO", "INTERACTIVE", "INTERACTIVE_RUNTIME"} and not media_readiness["pass"]:
        raise ValueError("real media is not production-ready: " + " | ".join(media_readiness["p0"]))

    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "project.json").write_text(json.dumps(project, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    overlay = compile_overlay(project)
    (output_dir / "cet.json").write_text(json.dumps(overlay, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    assets_dir = output_dir / "assets"
    generate_assets(assets_dir)
    generate_preview(project, overlay, output_dir / "preview.html")
    generate_storyboard_board(project, output_dir / "storyboard.html", base_dir=(project_path.resolve().parent if project_path else None))
    (output_dir / "previs-prompts.md").write_text(generate_previs_prompts(project), encoding="utf-8")

    simulator = RuntimeSimulator(project)
    runtime_report = simulator.replay(overlay["events"])
    (output_dir / "runtime-simulation.json").write_text(json.dumps(runtime_report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    stress_report = stress_project(project)
    (output_dir / "stress-report.json").write_text(json.dumps(stress_report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    bridges = export_bridges(project, overlay)
    bridges_dir = output_dir / "bridges"
    bridges_dir.mkdir(parents=True, exist_ok=True)
    for name, payload in bridges.items():
        (bridges_dir / f"{name}-bridge.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    (output_dir / "readiness.json").write_text(json.dumps(readiness, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (output_dir / "media-readiness.json").write_text(json.dumps(media_readiness, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (output_dir / "production-report.md").write_text(_production_report(project, readiness, overlay), encoding="utf-8")
    beginner = f"""# Beginner Start — {project.get('title', project['project_id'])}

1. Open `storyboard.html` first: confirm all shots, copy, HUD density and progress order.
2. Open `preview.html`: scrub the timeline and confirm task cards, TIPS, stamps, achievement, settlement and outro timing.
3. Read `readiness.json`: P0 must be empty before production; P1 should be fixed or explicitly accepted.
4. Read `stress-report.json`: mutation_missed must be empty and all runtime checks must be true.
5. Replace PREVIS placeholders with real footage. Keep UI text/assets outside AI-generated footage unless intentionally diegetic.
6. For moving hotspots, provide/produce a normalized track; for foreground crossings, provide a mask. Use `scripts/run_fusion_probe.py` to verify the fusion path before batch work.
7. Use `bridges/web-bridge.json` for H5/Phaser, `remotion-bridge.json` for client-effect video, or `unity-bridge.json` for the existing interactive-film Unity path.
8. Final release is blocked until actual-footage pixel fusion, audio mix and target-runtime interaction are reviewed.
"""
    (output_dir / "BEGINNER-START.md").write_text(beginner, encoding="utf-8")
    return readiness


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--clean", action="store_true", help="remove an existing output directory first")
    args = parser.parse_args()
    if args.clean and args.output_dir.exists():
        shutil.rmtree(args.output_dir)
    project = json.loads(args.project.read_text(encoding="utf-8"))
    try:
        readiness = build_project(project, args.output_dir, args.project)
    except ValueError as exc:
        print(f"FAIL: {exc}")
        return 1
    print(f"PASS: built {args.output_dir} (readiness {readiness['score']}/100)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
