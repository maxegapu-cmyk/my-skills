#!/usr/bin/env python3
"""Verify real media/track/mask inputs before final-video or runtime production."""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


def _is_remote(value: str) -> bool:
    return urlparse(value).scheme in {"http", "https"}


def _resolve(value: str, base: Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else (base / path).resolve()


def _ffprobe(path: Path) -> dict[str, Any] | None:
    exe = shutil.which("ffprobe")
    if not exe:
        return None
    cp = subprocess.run([
        exe, "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height,r_frame_rate,duration",
        "-of", "json", str(path)
    ], capture_output=True, text=True)
    if cp.returncode != 0:
        return {"error": cp.stderr.strip() or "ffprobe failed"}
    try:
        data = json.loads(cp.stdout)
        streams = data.get("streams") or []
        return streams[0] if streams else {"error": "no video stream"}
    except Exception as exc:
        return {"error": f"ffprobe JSON parse failed: {exc}"}


def verify_media_assets(project: dict[str, Any], project_path: Path) -> dict[str, Any]:
    base = project_path.resolve().parent
    p0: list[str] = []
    p1: list[str] = []
    checked: list[dict[str, Any]] = []
    mode = str(project.get("delivery_mode", "PREVIS")).upper()
    media = project.get("media") or {}
    master = media.get("master_src") if isinstance(media, dict) else None

    if not master:
        if mode in {"FINAL_VIDEO", "INTERACTIVE", "INTERACTIVE_RUNTIME"}:
            p0.append(f"media: delivery mode {mode} requires media.master_src or an explicit shot-media production plan")
        else:
            p1.append("media: PREVIS has no real master media; visual fusion is still placeholder-level")
    elif isinstance(master, str) and _is_remote(master):
        p1.append("media: remote master_src cannot be byte/codec verified by this local audit")
        checked.append({"kind": "master", "ref": master, "status": "REMOTE_UNVERIFIED"})
    elif isinstance(master, str):
        path = _resolve(master, base)
        if not path.exists():
            p0.append(f"media: master_src does not exist: {path}")
        else:
            probe = _ffprobe(path)
            if probe and probe.get("error"):
                p0.append(f"media: master_src decode/probe failed: {probe['error']}")
            checked.append({"kind": "master", "ref": str(path), "status": "PASS" if not (probe and probe.get('error')) else "FAIL", "probe": probe})

    for anchor_id, anchor in (project.get("anchors") or {}).items():
        if not isinstance(anchor, dict):
            continue
        if anchor.get("tracking") == "external-track":
            ref = anchor.get("track_ref")
            if not isinstance(ref, str) or not ref:
                p0.append(f"anchor {anchor_id}: external track has no track_ref")
            elif _is_remote(ref):
                p1.append(f"anchor {anchor_id}: remote track_ref not locally validated")
            else:
                path = _resolve(ref, base)
                if not path.exists():
                    p0.append(f"anchor {anchor_id}: track_ref missing: {path}")
                else:
                    try:
                        data=json.loads(path.read_text(encoding="utf-8"))
                        keyframes=data.get("keyframes") if isinstance(data,dict) else None
                        if not isinstance(keyframes,list) or not keyframes:
                            p0.append(f"anchor {anchor_id}: track_ref has no keyframes")
                        checked.append({"kind":"track","anchor":anchor_id,"ref":str(path),"status":"PASS"})
                    except Exception as exc:
                        p0.append(f"anchor {anchor_id}: track_ref unreadable JSON: {exc}")
        mask_ref = anchor.get("mask_ref")
        if mask_ref:
            if not isinstance(mask_ref,str):
                p0.append(f"anchor {anchor_id}: mask_ref must be a path/string")
            elif _is_remote(mask_ref):
                p1.append(f"anchor {anchor_id}: remote mask_ref not locally validated")
            else:
                path=_resolve(mask_ref,base)
                if not path.exists():
                    p0.append(f"anchor {anchor_id}: mask_ref missing: {path}")
                else:
                    checked.append({"kind":"mask","anchor":anchor_id,"ref":str(path),"status":"PASS"})

    return {
        "schema":"media-readiness-1.0",
        "project_id":project.get("project_id"),
        "delivery_mode":mode,
        "pass":not p0,
        "p0":p0,
        "p1":p1,
        "checked":checked,
    }


def main()->int:
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument("project",type=Path); ap.add_argument("--out",type=Path); a=ap.parse_args()
    project=json.loads(a.project.read_text(encoding="utf-8")); report=verify_media_assets(project,a.project)
    text=json.dumps(report,ensure_ascii=False,indent=2)+"\n"
    if a.out: a.out.write_text(text,encoding="utf-8")
    print(text,end="")
    return 0 if report["pass"] else 1
if __name__=="__main__": raise SystemExit(main())
