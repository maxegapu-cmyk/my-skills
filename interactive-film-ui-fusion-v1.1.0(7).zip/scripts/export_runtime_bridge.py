#!/usr/bin/env python3
"""Export data-only runtime/preview bridges from one Canonical Event Timeline."""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any

import sys

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.compile_overlay import compile_overlay


def _base(project: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    return {
        "bridge_schema": "1.0",
        "project_id": project["project_id"],
        "event_ids": [e["id"] for e in overlay["events"]],
        "canonical_actions": [e["action_id"] for e in overlay["events"]],
        "events": copy.deepcopy(overlay["events"]),
        "anchors": copy.deepcopy(overlay.get("anchors", {})),
        "frame": copy.deepcopy(project["frame"]),
        "ui_registry": copy.deepcopy(project.get("ui_registry", {})),
        "visual_profile": copy.deepcopy(project.get("visual_profile", {})),
        "route": copy.deepcopy(project.get("route", {})),
        "collection": copy.deepcopy(project.get("collection", {})),
        "timer": copy.deepcopy(project.get("timer", {})),
        "shots": copy.deepcopy(overlay.get("shots", [])),
    }


def export_bridges(project: dict[str, Any], overlay: dict[str, Any] | None = None) -> dict[str, dict[str, Any]]:
    overlay = overlay or compile_overlay(project)
    web = _base(project, overlay)
    web.update({
        "adapter": "web",
        "runtime_hint": "phaser-xstate",
        "clock": "video-frame-callback",
        "state_authority": "canonical-action-only",
        "hotspot_coordinates": "normalized",
    })

    remotion = _base(project, overlay)
    remotion.update({
        "adapter": "remotion",
        "runtime_hint": "preview-render",
        "clock": "frame-index",
        "state_authority": "read-only-replay",
        "fps": project["frame"]["fps"],
    })

    unity = _base(project, overlay)
    unity.update({
        "adapter": "unity",
        "runtime_hint": "persistent-single-scene-fmv",
        "clock": "playback-time",
        "state_authority": "canonical-action-only",
        "hotspot_coordinates": "normalized",
        "ui_layer_hint": "runtime-overlay",
    })
    return {"web": web, "remotion": remotion, "unity": unity}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    project = json.loads(args.project.read_text(encoding="utf-8"))
    overlay = compile_overlay(project)
    bridges = export_bridges(project, overlay)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for name, payload in bridges.items():
        path = args.output_dir / f"{name}-bridge.json"
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(path)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
