#!/usr/bin/env python3
"""Build MANIFEST.json for the portable Skill payload."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INCLUDE_ROOT = {"SKILL.md", "VERSION"}
INCLUDE_DIRS = {"references", "templates", "scripts", "fixtures", "tests"}


def payload_files(root: Path = ROOT) -> list[Path]:
    files: list[Path] = []
    for name in INCLUDE_ROOT:
        p = root / name
        if p.is_file():
            files.append(p)
    for dirname in INCLUDE_DIRS:
        base = root / dirname
        if not base.exists():
            continue
        for p in base.rglob("*"):
            if not p.is_file():
                continue
            if "__pycache__" in p.parts or p.suffix == ".pyc":
                continue
            files.append(p)
    return sorted(set(files), key=lambda p: p.relative_to(root).as_posix())


def build_manifest(root: Path = ROOT) -> dict:
    version = (root / "VERSION").read_text(encoding="utf-8").strip()
    entries = []
    for p in payload_files(root):
        entries.append({
            "path": p.relative_to(root).as_posix(),
            "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        })
    return {
        "name": "interactive-film-ui-fusion",
        "version": version,
        "schema_version": "1.0",
        "files": entries,
    }


def main() -> int:
    manifest = build_manifest(ROOT)
    path = ROOT / "MANIFEST.json"
    path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {path} ({len(manifest['files'])} files)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
