#!/usr/bin/env python3
"""Normalize older interactive-film runtime/node contracts into a stable pairing contract."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


def _action_ids(raw: Any) -> set[str]:
    out: set[str] = set()
    if isinstance(raw, list):
        for item in raw:
            if isinstance(item, str):
                out.add(item)
            elif isinstance(item, dict):
                value = item.get("action_id") or item.get("id")
                if value:
                    out.add(str(value))
    elif isinstance(raw, dict):
        for key, item in raw.items():
            if isinstance(item, dict) and item.get("action_id"):
                out.add(str(item["action_id"]))
            else:
                out.add(str(key))
    return out


def normalize_upstream_contract(upstream: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(upstream, dict):
        raise ValueError("upstream contract must be an object")
    nodes = upstream.get("nodes") or upstream.get("node_pack") or []
    if isinstance(nodes, dict):
        nodes = list(nodes.values())
    if not isinstance(nodes, list):
        raise ValueError("upstream nodes must be a list/object")

    node_ids: list[str] = []
    actions = _action_ids(upstream.get("canonical_actions") or upstream.get("actions"))
    windows: list[dict[str, Any]] = []
    for node in nodes:
        if not isinstance(node, dict):
            continue
        node_id = node.get("id") or node.get("node_id")
        if node_id:
            node_ids.append(str(node_id))
        interactions = node.get("interactions")
        if interactions is None and node.get("interaction") is not None:
            interactions = [node.get("interaction")]
        if not isinstance(interactions, list):
            continue
        for interaction in interactions:
            if not isinstance(interaction, dict):
                continue
            for action in interaction.get("actions") or interaction.get("choices") or []:
                if isinstance(action, dict):
                    action_id = action.get("action_id") or action.get("canonical_action")
                    if action_id:
                        actions.add(str(action_id))
            timeout_action = interaction.get("timeout_action_id") or interaction.get("timeout_action")
            if timeout_action:
                actions.add(str(timeout_action))
            start = interaction.get("start_sec", interaction.get("start"))
            end = interaction.get("end_sec", interaction.get("end"))
            if start is not None or end is not None:
                windows.append({
                    "node_id": str(node_id) if node_id else None,
                    "start_sec": start,
                    "end_sec": end,
                    "pause_behavior": interaction.get("pause_behavior", "continue"),
                    "timeout_action_id": timeout_action,
                })
    return {
        "contract_schema": "interactive-film-upstream-1.0",
        "source_system": upstream.get("source_system", "interactive-film-production"),
        "source_project_id": upstream.get("project_id"),
        "strict_actions": True,
        "node_ids": sorted(set(node_ids)),
        "action_ids": sorted(actions),
        "interaction_windows": windows,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    upstream = json.loads(args.input.read_text(encoding="utf-8"))
    normalized = normalize_upstream_contract(upstream)
    args.output.write_text(json.dumps(normalized, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(args.output)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
