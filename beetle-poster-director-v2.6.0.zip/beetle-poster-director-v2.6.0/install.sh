#!/usr/bin/env bash
set -euo pipefail

MODE=""
REPO_PATH=""
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PKG_NAME="beetle-poster-director"
SRC_DIR="$SCRIPT_DIR"

usage() {
  cat <<USAGE
Usage:
  bash install.sh --user
  bash install.sh --repo /absolute/path/to/repo
USAGE
}

if [[ $# -eq 0 ]]; then
  MODE="user"
elif [[ "$1" == "--user" ]]; then
  MODE="user"
elif [[ "$1" == "--repo" ]]; then
  MODE="repo"
  REPO_PATH="${2:-}"
  if [[ -z "$REPO_PATH" ]]; then
    echo "Error: --repo requires an absolute path"
    exit 1
  fi
else
  usage
  exit 1
fi

if [[ "$MODE" == "user" ]]; then
  TARGET_BASE="$HOME/.agents/skills"
else
  TARGET_BASE="$REPO_PATH/.agents/skills"
fi

TARGET_DIR="$TARGET_BASE/$PKG_NAME"
BACKUP_DIR="${TARGET_DIR}.bak.$(date +%Y%m%d-%H%M%S)"
OLD_CODEX_DIR="$HOME/.codex/skills/$PKG_NAME"

mkdir -p "$TARGET_BASE"

if [[ -d "$TARGET_DIR" ]]; then
  mv "$TARGET_DIR" "$BACKUP_DIR"
  echo "Backed up existing install to: $BACKUP_DIR"
fi

mkdir -p "$TARGET_DIR"
cp "$SRC_DIR/SKILL.md" "$TARGET_DIR/SKILL.md"
cp "$SRC_DIR/README.md" "$TARGET_DIR/README.md"
cp "$SRC_DIR/VERSION" "$TARGET_DIR/VERSION"
cp "$SRC_DIR/uninstall.sh" "$TARGET_DIR/uninstall.sh"
chmod +x "$TARGET_DIR/uninstall.sh"

if [[ -d "$OLD_CODEX_DIR" ]]; then
  echo "Detected old Codex-era install at: $OLD_CODEX_DIR"
  echo "You can remove it manually if you no longer need it."
fi

echo "Installed: $TARGET_DIR"
echo -n "Version: "
cat "$TARGET_DIR/VERSION"
