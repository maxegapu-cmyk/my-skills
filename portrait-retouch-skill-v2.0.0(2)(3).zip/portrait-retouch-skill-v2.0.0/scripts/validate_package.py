from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
required = [
    "SKILL.md",
    "README.md",
    "references/REALISM_STACK.md",
    "references/FAILURE_ATLAS.md",
    "references/SCENARIO_MATRIX.md",
    "references/PROMPT_RECIPES.md",
    "references/RESEARCH_NOTES.md",
    "tests/acceptance.md",
]
missing = [p for p in required if not (root / p).is_file()]
if missing:
    print("FAIL missing:", ", ".join(missing))
    sys.exit(1)

skill = (root / "SKILL.md").read_text(encoding="utf-8")
checks = {
    "version": "version: 2.0.0",
    "edit intent": "Existing portrait + user asks to change it = EDIT",
    "identity lock": "HARD LOCKS",
    "human realism": "Human Realism Stack",
    "beauty": "Beauty Lift Without Identity Drift",
    "AI humanize": "AI Humanization",
    "compact compiler": "Quick Mode Compiler",
    "original retry": "retry from ORIGINAL",
    "acceptance": "Acceptance Gates",
    "exclude traditional": "GFPGAN/CodeFormer",
}
failed = [name for name, needle in checks.items() if needle not in skill]
if failed:
    print("FAIL checks:", ", ".join(failed))
    sys.exit(2)

if len(skill.splitlines()) < 200:
    print("FAIL SKILL.md unexpectedly short")
    sys.exit(3)

print("PACKAGE_TEST=PASS")
print("required_files=PASS")
print("core_sections=PASS")
print("skill_lines=", len(skill.splitlines()))
