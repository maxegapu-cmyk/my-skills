# Prompt Recipes

These are compact recipes. Adapt them; do not copy every line mechanically.

## 1. Default — Better + Alive + Real
Edit this existing portrait and keep the same person and same shot. Preserve identity, face proportions, gaze, age, skin tone, expression, pose, hairstyle, wardrobe, camera and background. Improve only visible defects and overall presentation. Selectively clean temporary blemishes/artifacts, balance local skin tone, refine malformed eye/lip/hair details, and improve face-to-scene light continuity. Keep natural regional skin texture, subtle tonal variation, believable highlights, coherent eye moisture/catchlights and realistic hair clustering. Make the subject look healthier, more photogenic and more present, not redesigned. No face slimming, enlarged eyes, smaller nose, inflated lips, de-aging, skin whitening, plastic skin, repeated pores, doll eyes, porcelain teeth, HDR halos or oversharpening. Result: the same person, simply captured/retouched more convincingly.

## 2. AI Humanize
Humanize this AI-generated portrait without changing the designed identity. Keep face geometry, gaze, expression, hairline, hairstyle, skin tone, pose, camera and scene unchanged. Remove synthetic cues: waxy/uniform skin, repeated pore pattern, glassy eyes, over-white sclera/teeth, helmet hair, inconsistent face/neck rendering, excessive clarity or glow. Replace them only with source-consistent material behavior: regional skin variation, restrained fine texture, coherent specular response, natural eye moisture/catchlight, realistic hair masses with selected fine strands, and light/color integration matching the scene. Do not add random acne, scars, wrinkles, freckles or asymmetry just to look real.

## 3. Beauty Lift
Make this portrait noticeably more flattering while preserving the exact identity and facial geometry. Prioritize temporary blemish cleanup, balanced local skin tone, subtle under-eye color cleanup, natural eye clarity, refined lip color/texture, tidy brows/hair and better facial light separation. Keep age, skin tone, expression, gaze, face shape and feature sizes unchanged. Attractive means healthier, cleaner and more photogenic—not slimmer, younger, paler or more symmetrical. Keep real skin texture and natural highlights; no beauty-filter face.

## 4. Plastic Skin Rescue
Repair the synthetic/plastic skin only. Keep every facial feature, expression, gaze, hair, camera and background unchanged. Replace uniform waxy rendering with subtle region-specific skin texture, fine tonal variation and restrained highlights matching the existing light and focus. Do not exaggerate pores, add wrinkles/blemishes or sharpen the whole face. Preserve the source age and stable marks.

## 5. Dead Eyes Rescue
Repair only the artificial eye rendering. Preserve eye shape, size, spacing, iris color, eyelids, gaze direction and expression exactly. Restore natural corneal moisture, restrained iris depth, off-white sclera and catchlights consistent with the existing scene light. No enlarged eyes, brighter irises, extra catchlights, fake lashes or gaze changes.

## 6. Hair Rescue
Repair only artificial hair behavior. Keep haircut, parting, hairline, volume and color unchanged. Break synthetic clumps into believable hair masses and clusters, retain natural edge hairs and a few source-consistent strands, and match the existing focus/light. No new hairstyle, no hairline redesign, no wire-like hyper-detail.

## 7. Low-Quality Rescue
Improve readability and visible defects while preserving identity and avoiding invented detail. Recover broad facial boundaries, local tone and obvious malformed features using only evidence supported by the source. Keep the source's realistic detail ceiling; do not invent pores, iris patterns, lashes or fine hair that cannot be inferred reliably. Preserve camera, crop, pose and scene.

## 8. Editorial Real
Give this portrait a refined editorial finish without making it look retouched. Preserve exact identity, age, expression, skin tone, facial geometry, pose, wardrobe, camera and background. Use restrained local cleanup, nuanced skin tone balance, realistic microtexture, controlled facial highlights, precise hair/edge cleanup and natural eye/lip detail. Keep depth and texture; avoid poreless beauty skin, over-contouring, HDR clarity or generic fashion-face replacement.
