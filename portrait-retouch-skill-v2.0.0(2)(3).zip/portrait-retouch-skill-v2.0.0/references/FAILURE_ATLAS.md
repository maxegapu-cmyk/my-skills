# Failure Atlas — Diagnose Before Retrying

## A. Prettier stranger
**Symptom:** output is attractive but likeness dropped.
**Cause:** generic beauty adjectives / too-large edit budget / repeated edits on edited output.
**Fix:** original source; hard-lock identity; remove shape adjectives; local presentation-only pass.

## B. Plastic / wax skin
**Symptom:** smooth, uniform, shiny, CGI face.
**Cause:** "flawless smooth perfect" wording; global skin replacement.
**Fix:** ask for regional texture + local tone variation + restrained specular response; no global smoothing.

## C. Old / rough / diseased look
**Symptom:** model added deep pores, spots, wrinkles or redness in the name of realism.
**Cause:** over-literal imperfection prompts.
**Fix:** preserve age and existing marks; forbid invented blemishes; reduce microcontrast; use optical/material realism instead.

## D. Dead doll eyes
**Symptom:** glossy eye beads, white sclera, giant catchlights.
**Fix:** preserve gaze/shape; off-white sclera; coherent source-light catchlight; natural moisture only.

## E. "AI pores"
**Symptom:** same-sized dots everywhere, overly sharp pores.
**Fix:** irregular regional texture at source resolution; no pore amplification; respect depth-of-field.

## F. Face pasted on
**Symptom:** face sharpness/color/light differs from neck and scene.
**Fix:** match local exposure, color spill, shadow softness, edge sharpness and focus depth to body/background.

## G. Hair turned into wires
**Symptom:** thousands of sharp individual strands.
**Fix:** hierarchical hair masses with selected strands; preserve source focus level.

## H. Beauty filter drift
**Symptom:** smaller nose, larger eyes, V jaw, pale skin.
**Fix:** explicitly disable structural beauty changes and skin-tone shifts.

## I. Expression drift
**Symptom:** smile/gaze/emotion changed although not requested.
**Fix:** lock expression, mouth tension, eye opening and gaze vector; remove "friendly / warm / confident" unless requested.

## J. Makeup rewritten
**Symptom:** new eyeliner, contour, lipstick, brows.
**Fix:** preserve existing makeup design; only repair smears, artifacts or color discontinuity.

## K. Over-clean hairline / beard
**Symptom:** helmet edge or painted beard.
**Fix:** preserve fine edge hairs and growth irregularity; do not redraw silhouette globally.

## L. Low-res hallucination
**Symptom:** invented skin/iris/hair details contradict source.
**Fix:** broad restoration only; explicitly state "do not invent fine details unsupported by source".

## M. Retry drift accumulation
**Symptom:** pass 3 looks less like source than pass 1.
**Fix:** always retry from original unless the previous pass is explicitly accepted as new authority.
