---
name: cinematic-fight-director
version: 4.0.0-public
description: Director-first prompt compiler for cinematic fight scenes, optimized for Seedance 2.5 and adaptable to other AI video models.
---

# Cinematic Fight Director v4.0 — Public Edition

## Purpose

Turn a fight idea, script beat, character image, storyboard, or motion reference into a production-ready AI video prompt whose action is **fast, readable, physical, continuous, cinematic, and state-consistent**.

This is not a library of adjectives. It is a choreography compiler. It translates intent into visible cause-and-effect: who initiates, what changes, where contact occurs, how bodies and props respond, how the environment records force, and what state makes the next beat possible.

Primary target: Seedance 2.5. The choreography logic is model-agnostic; timing and reference syntax should be adapted for other generators.

## Public-edition boundary

This package is a clean-room public rewrite. It does not contain private workflows, internal project names, personal paths, proprietary prompt text, or full third-party prompts. Examples are newly written for this package. Public sources are listed in `SOURCES.md`.

## Default behavior

When the user asks for a fight prompt:

1. Identify the target model, duration, aspect ratio, input references, fighters, weapons/powers, location, tone, and desired winner/outcome if stated.
2. If non-blocking details are missing, choose conservative defaults and continue instead of interrogating the user.
3. Build a **combat state sheet** before writing prose.
4. Choose a **motion density** and **camera strategy** that fit the duration and model reliability.
5. Compile the fight into linked **Action Packets**.
6. Write a paste-ready prompt using the target model's reference syntax.
7. Run the failure scan in `references/diagnostics.md` and silently fix obvious contradictions.
8. Output the finished prompt first. Add brief notes only when they materially help execution.

## Core model: Action Packet

Every meaningful exchange should form a causal packet:

`INITIATION → DEFENSE/CONTACT → IMPACT RESPONSE → DISPLACEMENT → WORLD RESPONSE → EXIT VECTOR`

An Action Packet is successful only if the viewer can answer:

- Who moved first?
- Toward whom or what?
- Did it hit, miss, parry, jam, redirect, or get interrupted?
- What visibly changed in the target body/weapon/stance?
- Where did each participant end up?
- What environmental trace proves the force?
- What velocity, posture, distance, or opening feeds the next packet?

Do not write isolated move lists. A punch followed by a kick is not choreography unless the first result creates the second opportunity.

## The six locks

Before writing timestamps, lock these six dimensions:

### 1. Identity lock
Face, body scale, costume, silhouette, weapon ownership, injuries and visible damage remain consistent.

### 2. Space lock
Define screen-left/screen-right, facing, distance, exits, obstacles, vertical levels, and a stable action axis. Cuts may change viewpoint; they may not teleport state.

### 3. Physics lock
Every large movement needs a source of force. Every strong hit needs a consequence. Airborne motion needs takeoff momentum and a landing/impact path unless supernatural hovering is explicitly part of the story.

### 4. Tempo lock
Decide whether the clip is measured, kinetic, or hyperdense. Do not ask the model to perform more distinct state changes than the duration can visually carry.

### 5. Camera lock
Every shot has one main job: establish space, follow displacement, expose contact, reveal reversal, emphasize impact, or show result. Camera spectacle must not hide decisive body contact.

### 6. Style lock
Palette, texture, lens feel, lighting source, motion-blur character, grain, contrast, weather and VFX vocabulary remain stable unless a deliberate transition is written.

## Motion density

Use one of three defaults. These are authoring targets, not guaranteed frame-accurate controls.

### MEASURED
One major exchange roughly every 1.5–3 seconds. Best for heavy weapons, realism, duel tension, creature scale, and readable full-body mechanics.

### KINETIC — default
One resolved exchange roughly every 0.9–1.8 seconds, with small connective movements inside each exchange. Best general action-film balance.

### HYPERDENSE
A resolved micro-combination can be designed around roughly 0.6–1.0 seconds when the scene and model support it. Use for elite-vs-mob bursts, stylized assassin speed, or short climax passages. Hyperdense does **not** mean listing ten unrelated moves per second. Compress each burst into one readable directional idea and one clear result.

For Seedance 2.5, top-level timeline blocks should remain simple and contiguous. Sub-second beat labels are optional authoring aids rather than a platform promise. If micro-timing destabilizes generation, fold the microbeats into continuous prose inside a larger time block.

## Momentum continuity rule

During sustained action, avoid dead frames. Each packet must finish with at least one live continuation variable:

- forward/sideways velocity,
- a loaded hip/shoulder,
- an opponent already entering,
- a weapon already rebounding,
- a slide/roll/recovery path,
- a camera whip landing on the next threat,
- debris/door/rail/vehicle motion that becomes the next obstacle.

Do not insert decorative ready poses between packets unless the story requires a reset.

## Impact hierarchy

Not every strike deserves the same cinematic accent. Use three levels:

- **Touch:** light contact; body twitch, guard change, cloth movement, small sound.
- **Beat:** meaningful hit; posture break, short displacement, sharper sound, brief camera response.
- **Hero impact:** decisive hit; visible acceleration into contact, directional body response, environment reaction, optional micro-jolt/punch-in/hit-stop, then aftermath.

Reserve strong camera shake, heavy radial blur, debris bursts and extreme knockback for selected hero impacts. If every hit is maximum, none reads as maximum.

Read `references/impact-physics.md` before writing heavy contact.

## Multi-enemy rule

For one-vs-many scenes, maintain a **Threat Queue** rather than turning the background into idle statues or a simultaneous pile-on.

At any moment identify:

- primary threat currently exchanging with the protagonist,
- secondary threat entering or forcing movement,
- inactive/disabled enemies and their final location,
- next threat vector.

A defeated enemy remains defeated unless the script says otherwise. New attackers enter from known directions. Use overlap: the next enemy may begin entering before the current packet finishes, creating continuous pressure without unreadable body fusion.

Read `references/multi-enemy.md`.

## Airborne motion rule

For grounded realism:

`launch source → acceleration → short ballistic airtime → contact/landing → absorption/secondary collision`

Avoid unexplained vertical lift, stationary jumping, long hovering, or bodies pausing at the top of an arc. If fantasy flight is intended, explicitly define the supernatural force and treat it consistently.

## Camera readability rules

- Show the geometry before the first complex exchange.
- Keep critical contact visible; do not hide every hit behind foreground occlusion or extreme close-ups.
- Preserve the action axis through rapid cuts unless a deliberate axis-crossing shot explains the change.
- During very fast movement, the camera may lag slightly then catch up; this often reads faster than perfectly glued tracking.
- Use whip pans as transitions between known endpoints, not as permanent blur.
- Use impact shake as punctuation, not wallpaper.
- After a major hit, give the result enough screen time to register before the next unrelated cut.

Read `references/camera-and-editing.md`.

## Reference assignment

When media references exist, assign one authority per dimension. Example:

- `@图片1` → character identity and costume only.
- `@图片2` → location and production design only.
- `@视频1` → choreography rhythm and body trajectory only; do not transfer performer identity, location, logo, dialogue, or palette.
- `@视频2` → camera path only.
- `@音频1` → music tempo or authorized voice only.

Do not let two references compete for the same dimension without naming which one wins.

## Prompt compiler

Default Seedance 2.5 output shape:

```text
〖素材职责〗
[Map each @ asset to one or more non-conflicting jobs.]

〖一句话导演意图〗
[Who fights whom, where, outcome, action identity, camera identity.]

〖全局锁定〗
[identity + space + physics + style + sound + exclusions]

〖战斗时间轴〗
0–Xs: [Action Packet(s) with visible causal chain, camera job, sound accents, endpoint]
X–Ys: [...]
...

〖连续性终态〗
[final positions, facing, weapon states, injuries, environment damage, camera endpoint]
```

For a simple 4–8 second single-beat shot, collapse this into one dense paragraph. For complex 15–30 second fights, use 3–7 timeline blocks. More blocks are allowed when each one has a distinct job, but do not fragment every punch into a new camera shot.

## Combat writing grammar

Prefer observable verbs and consequences:

Good:
- shoulder dips under the hook; rear foot skids half a step; guard opens on the left;
- blade glances off the railing, sparks fan backward, rebound exposes the wrist;
- knee drives through the center line, torso folds, momentum carries the target into the table;
- attacker misses, over-rotates, and the protagonist uses that rotation to pass behind.

Weak:
- epic fight;
- extremely powerful punch;
- cinematic martial arts;
- amazing combo;
- the enemy gets hit hard.

Intensity should be expressed through **distance, acceleration, contact, timing, displacement, material response and recovery**, not booster adjectives.

## Choreography construction order

For each fighter define:

1. preferred distance,
2. locomotion signature,
3. attack family,
4. defensive habit,
5. power/weapon constraints,
6. recovery weakness,
7. visual signature.

Then define the scene escalation:

`ENTRY → FIRST PROOF OF SKILL → PRESSURE → REVERSAL → PEAK EXCHANGE → RESULT/EXIT`

Not every clip needs all six. A 6-second clip may only cover ENTRY → FIRST PROOF → RESULT. A 30-second clip can support the full arc.

## Style and spectacle

Use spectacle as a physical layer:

- motion blur follows actual velocity,
- afterimage is brief and directional,
- dust/spray/sparks inherit the contact vector,
- cloth and hair lag behind direction changes,
- practical lights smear during fast pans but geometry remains legible,
- debris persists after impact instead of resetting on the next cut.

If a user wants dark Eastern fantasy, noir, anime, Hong Kong action, modern tactical, superhero, or other aesthetics, keep the choreography engine intact and swap the style layer. Style must not erase physical causality.

## Sound

Use sound to clarify action order:

`movement cue → contact transient → body/material response → tail/room tone`

Examples: shoe scrape before launch; cloth snap during rotation; metal ring at parry; bassy body impact; wall crack after displacement; rain resumes clearly in the brief gap after a hero hit.

Avoid assigning a unique maximal sound to every minor strike.

## Output modes

- `PROMPT_ONLY`: paste-ready prompt, default when user explicitly asks for a prompt.
- `DIRECTOR_PLUS_PROMPT`: short choreography rationale + prompt.
- `SHOTLIST_PLUS_PROMPT`: shot plan + prompt for complex sequences.
- `DIAGNOSE`: inspect a failed prompt/video description and change the smallest variable group likely to fix it.

## Final internal check

Before delivery verify:

- every fighter is distinguishable;
- all major contacts have outcomes;
- no unexplained teleportation;
- no dead-air reset between high-speed packets unless deliberate;
- aerial motion has a force source and endpoint;
- camera does not hide the decisive contact;
- impact accents are hierarchical;
- disabled enemies do not resurrect;
- props do not change hands or geometry without explanation;
- environment damage persists;
- timeline ranges are contiguous and fit target duration;
- style references do not conflict with identity/motion references;
- prompt contains visible actions instead of generic quality adjectives.

Then deliver.
