# Multi-Enemy Choreography — Threat Queue System

## Goal

Create the feeling of overwhelming pressure without producing a fused crowd or enemies who politely wait for turns.

## 1. State table

Track each opponent internally:

```text
E1: screen-left / active / axe / closing
E2: rear-right / secondary / baton / 2m away
E3: foreground / disabled / on floor / no weapon
E4: doorway / entering / uninjured
```

Update after every resolved packet.

## 2. One primary + one pressure source

Default to one opponent in direct contact while another creates incoming pressure. The protagonist should often finish one packet while already reacting to the next vector.

Example structure:

- E1 commits from front-left.
- During E1's displacement, E2 is already entering from right edge.
- Camera/eyeline catches E2 before E1 has fully settled.
- Protagonist's existing rotation becomes the first move against E2.

This produces continuous action without asking the model to solve four overlapping body contacts at once.

## 3. Enemy individuality

Give enemies distinguishable silhouettes, weapons, attack vectors or movement patterns. Do not describe “five identical men swarm him” if identity separation matters.

## 4. Defeat persistence

Once an enemy is disabled:

- keep the body/location consistent,
- do not silently restore their weapon,
- let the environment remember the fall,
- use the fallen body/weapon as an obstacle only if visible and useful.

## 5. Threat rhythm

Three useful patterns:

### Conveyor
Each defeated enemy clears a lane that reveals the next attacker. Very readable and ideal for narrow corridors.

### Crossfire
One close-range threat plus one ranged or lateral threat forces the hero to move. Good for tactical scenes.

### Compression
Enemies push from multiple edges, shrinking safe space; hero breaks one edge to escape. Good for desperation and crowd pressure.

## 6. Hyperdense mob burst

If the user wants a very fast elite-vs-mob sequence, each micro-combination should usually resolve **one dominant enemy state** while the next attacker starts entering. Use a common directional flow so the hero does not reset to a front-facing neutral pose every second.

A useful mental target is roughly 0.6–1.0 seconds per resolved mini-combination in a short burst, but treat this as an authoring rhythm, not guaranteed generator timing.

## 7. Anti-failure constraints

- no fused bodies;
- no duplicate protagonist;
- no enemy teleporting into contact;
- no resurrecting disabled enemies;
- no weapon swapping without a visible transfer;
- no every-enemy-at-once grappling pile unless deliberately staged;
- no background enemy frozen unnaturally: they circle, hesitate, approach, recover, or react.
