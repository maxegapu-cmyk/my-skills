# Action Packets — Causal Choreography Engine

## 1. Why a packet exists

AI video often fails fights because the prompt describes nouns and named moves while omitting causality. The model receives “jab, elbow, kick, spin” but not the spatial reason those actions connect.

An Action Packet is a small closed loop whose ending creates the next opening.

## 2. Packet schema

Use this internal schema:

```text
P#: [initiator]
START: position + facing + velocity + guard/weapon state
TRIGGER: what makes this beat begin
ACTION: one dominant directional action or short combination
DEFENSE: evade / block / parry / jam / counter / no defense
CONTACT: exact readable result
REACTION: local body/weapon response
DISPLACEMENT: where bodies/props move
WORLD: visible environmental consequence
EXIT: final posture + velocity + next opening
CAMERA JOB: what the shot must prove
SOUND: one or two ordered accents
```

The final prompt should read naturally; this schema is for reasoning and consistency.

## 3. Packet chaining

A good chain reuses the previous packet's exit state:

```text
P1 EXIT: opponent folds forward + protagonist outside opponent's right shoulder
P2 TRIGGER: second enemy enters from screen-right while protagonist is already rotated clockwise
P2 ACTION: protagonist continues that rotation into a backfist instead of resetting square
```

Bad chaining silently resets everybody to neutral before every move.

## 4. Combination compression

When speed is high, combine micro-actions by function rather than enumerating every limb:

Weak:
`jab, cross, hook, elbow, knee, sweep, kick`

Better:
`a compact body-head flurry drives the guard high; without resetting his feet he changes level, bumps the hips off-line and scythes the supporting leg, sending the opponent down along the same diagonal.`

The second version gives the model one directional idea, a tactical change, and a result.

## 5. Contact outcomes

Do not default every attack to “hits.” Rotate among:

- clean hit,
- glancing hit,
- blocked but posture-breaking hit,
- parry with weapon deflection,
- jam before full extension,
- slip/duck with attacker over-rotation,
- limb trap,
- collision with environment,
- weapon caught or pinned,
- attack redirected into another obstacle/threat.

Varied outcomes create real choreography instead of target-dummy animation.

## 6. Reversal design

A reversal is strongest when caused by an earlier choice. Examples:

- protagonist chases too aggressively → enters grappling range → opponent clinches;
- heavy weapon hits railing → rebound slows recovery → counter window opens;
- defender retreats into puddle → footing degrades → next dodge shortens;
- fast attacker repeatedly circles left → opponent anticipates and closes that exit.

Do not use arbitrary “suddenly the other fighter wins” switches.

## 7. Endpoint discipline

Every timeline block should end on a visible, stable-enough state the next block can inherit:

- “protagonist lands screen-right, left shoulder toward camera, sword low, opponent sliding screen-left” is useful;
- “they keep fighting intensely” is not.

For extensions, store the endpoint separately in the continuity ledger.
