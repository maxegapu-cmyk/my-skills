# Diagnostics — Fix the Smallest Broken Layer

Change one variable family at a time whenever possible.

## Symptom → likely cause → first fix

### “Fast” fight still looks slow
Cause: prompt lists many moves but gives no continuous momentum or displacement.
Fix: remove move names, chain 2–3 Action Packets by shared exit vectors; start effective movement in the opening frame; shorten decorative close-ups.

### Characters stop after every combo
Cause: each sentence ends at a neutral result.
Fix: rewrite every packet exit with velocity, rotation, loaded posture, or incoming threat that directly triggers the next packet.

### Hits feel weightless
Cause: contact has no local response or displacement.
Fix: add one local body cue + directional displacement + one material/environment cue. Do not solve it with more adjectives.

### Everyone flies unrealistically
Cause: maximum knockback assigned to routine hits.
Fix: restore impact hierarchy. Most hits change posture/distance modestly; reserve launches for hero impacts or supernatural force.

### Camera is exciting but fight unreadable
Cause: camera has more motion complexity than bodies.
Fix: simplify to lateral/3-4 follow; establish axis; keep decisive contact in medium/full framing; reserve whip/orbit for transitions.

### Enemies merge or duplicate
Cause: too many simultaneous primary interactions; weak identity separation.
Fix: threat queue; one dominant contact; distinct clothing/weapon/screen entry; fewer overlapping limb instructions.

### Enemies wait politely
Cause: sequential list with no secondary pressure.
Fix: let next threat enter during current opponent's displacement/recovery; background threats reposition, hesitate, aim or close distance instead of freezing.

### Fighter teleports between cuts
Cause: no endpoint state.
Fix: write exact positions/facing/velocity before cut and inherit them in the next shot.

### Weapon changes length/hand
Cause: ownership/geometry omitted amid dense action.
Fix: add global weapon lock and repeat only at complex transfers/blocks.

### Too much shake / blur
Cause: every contact receives hero-impact treatment.
Fix: use stable base camera; minor hits rely on performance/sound; one or two hero impacts receive strong punctuation.

### Airborne action floats
Cause: jump described without impulse or endpoint.
Fix: add takeoff source, short arc and landing/collision. If true flight is desired, define its supernatural rule instead.

### VFX swallow anatomy
Cause: effects are described as the action rather than consequence.
Fix: make body/weapon trajectory primary; VFX trail behind it and leave one sharp anchor.

### Timeline feels mechanical
Cause: each second contains a disconnected task.
Fix: use fewer top-level blocks and continuous causal prose inside them. Timestamps should organize phases, not micromanage every frame.

## Release checklist

A prompt passes when:

- first effective action happens early enough for intended pace;
- at least 80% of major exchanges include a visible causal result;
- no unexplained state reset exists between adjacent blocks;
- camera can see the key contact or decisive miss;
- one-vs-many state remains countable;
- impact intensity has hierarchy;
- environment remembers major damage;
- final state is explicit enough to extend.
