# Prompt Contracts

## A. Seedance 2.5 — standard fight

```text
〖素材职责〗
@图片1：[identity/costume role]
@图片2：[environment role]
@视频1：[motion/choreography role only; exclusions]

〖一句话导演意图〗
[duration]秒，[aspect ratio]。[fighters]在[location]完成[outcome]。动作风格[grounded/kinetic/stylized]，镜头策略[one-take/multi-shot].

〖全局锁定〗
人物：[identity locks]
空间：[screen direction / axis / landmarks]
物理：[grounded launch, impact hierarchy, no hover, prop rigidity]
视觉：[capture + palette + light + atmosphere + motion texture]
声音：[ambience + impact policy + music policy]
禁止：[fusion / duplicate / teleport / prop morph / unwanted subtitles etc.]

〖战斗时间轴〗
0–Xs：[packet chain; camera job; endpoint]
X–Ys：[packet chain; camera job; endpoint]
...

〖连续性终态〗
[positions, facing, velocity, weapon ownership, injuries, environment damage, camera endpoint]
```

## B. 6–8 second hyperdense burst

Keep one space and one camera grammar. Avoid six separate shots.

```text
[reference assignment]. [style lock]. From the first frame, effective action begins immediately. The protagonist moves through [2–4] connected Action Packets with no neutral reset: [packet 1 result] feeds directly into [packet 2], then [packet 3]. Each decisive hit has directional body response and one matching environmental trace. Incoming threats overlap in timing but only one primary body contact is visually dominant at a time. Camera [lateral/low follow] preserves full-body contact, using brief whip catches between threats and one stronger impact accent at the climax. End on [specific spatial state]. No hovering, teleportation, fused bodies, resurrected enemies, weapon morphing, or continuous maximum shake.
```

## C. 15–30 second duel

Use escalation rather than constant maximum speed:

```text
0–4s: establish geography and first proof of style.
4–10s: distance closes; first exchange reveals different fighter habits.
10–17s: pressure and reversal; environment begins to change.
17–24s: peak exchange; one hero impact/signature move.
24–30s: result, separation or transition to next clip; preserve all damage/state.
```

## D. One-vs-many corridor

```text
Use the corridor as a directional spine. Threats enter from named doors/edges. Maintain a threat queue: current opponent, incoming pressure, disabled opponents. Each mini-combination resolves one dominant opponent while the next begins entering. The protagonist never returns to a presentation stance; existing rotation, slide, recoil or weapon rebound becomes the next attack/defense. Camera tracks along the corridor axis, with short whip catches rather than random 360° orbiting.
```

## E. Weapon duel

Add:

- weapon geometry and ownership lock;
- grip hand;
- contact material behavior;
- recovery path after blocks;
- no blade bending/length change unless weapon is designed to transform;
- cut/spark/damage only when supported by contact.

## F. Creature fight

Add:

- scale reference in frame;
- center-of-mass and reach difference;
- creature gait/attack arc;
- human/creature height layers;
- camera distance that can keep both bodies readable;
- environmental deformation proportional to mass.
