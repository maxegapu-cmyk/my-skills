# Impact Physics and Spectacle

## 1. Force must travel through the image

A convincing impact has a short chain:

`APPROACH VELOCITY → CONTACT → LOCAL REACTION → WHOLE-BODY RESPONSE → DISPLACEMENT → MATERIAL/ENVIRONMENT RESPONSE → SETTLE`

The prompt does not need to spell out all seven words, but the visible result should contain enough of them that the force is legible.

## 2. Local response before huge displacement

Before an enemy flies away, show a local cue: shoulder snaps back, ribs compress, head turns, guard collapses, weapon jerks off-line, shoe loses traction. This brief local response makes later displacement feel caused rather than teleported.

## 3. Directional knockback

Knockback follows the resultant force vector unless another obstacle redirects it. Phrase direction explicitly:

- backward and slightly screen-left,
- folded over the strike then skidding rearward,
- rotating clockwise into the wall,
- launched low across the floor rather than vertically upward.

Avoid generic “flies away.”

## 4. Camera impact accents

Use accents by hierarchy:

### Minor contact
No camera shake. Let performance and sound sell it.

### Strong beat
A very brief handheld jolt, tiny push-in, or focus snap may accompany the contact.

### Hero impact
One strong punctuation device: micro-jolt, snap push, whip landing, one- or two-beat hit-stop feel, or a fast cut to the result. Do not stack every device every time.

## 5. Motion blur and afterimage

Motion blur should follow velocity and shutter/lens logic. Use directional streaking during whip pans or extremely fast limbs, while the contact pose remains readable. If stylized afterimage is desired, keep it short-lived, behind the moving body/weapon, and aligned with the traveled path.

Avoid opaque smears that replace anatomy.

## 6. Radial blur

Radial blur is an emphasis effect, not a default physical law. Use it around selected impacts, crash zooms or extreme forward bursts. Keep the contact point and main silhouette readable.

## 7. Environment as a force witness

Choose effects based on what is actually present:

- dust: directional puff then settling layer;
- shallow water: fan-shaped spray, ripples, wet footprints;
- rain: droplets streak and are displaced by fast surfaces;
- glass: fracture origin at contact, fragments inherit direction;
- wood: splinters from impact point, larger pieces lag;
- metal: sparks at hard scrape/contact, dent only if force supports it;
- loose paper/fabric: delayed air wake;
- snow/ash: plume reveals foot path and landing.

Do not summon dust indoors on a clean wet floor unless there is material to produce it.

## 8. Airborne realism

Grounded jump/launch:

1. visible push, collision, throw, ramp, or explosive force;
2. clear launch vector;
3. short ballistic arc;
4. no stationary pause at apex;
5. landing/collision with knee/hip/shoulder absorption or uncontrolled crash.

For wuxia/superhero flight, replace the ballistic rule with a declared supernatural motion rule and apply it consistently.

## 9. Body safety and visual plausibility

Avoid impossible joint folding, limb duplication, fused bodies, disappearing hands, and weapon penetration unless explicitly intended by the fictional scene. For high-speed grappling, reduce simultaneous limb instructions and favor a readable silhouette plus one dominant contact relationship.
