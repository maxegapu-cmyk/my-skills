from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
required = [
    'SKILL.md','README.md','SOURCES.md',
    'references/action-packets.md','references/impact-physics.md',
    'references/multi-enemy.md','references/camera-and-editing.md',
    'references/style-and-vfx.md','references/prompt-contracts.md',
    'references/diagnostics.md','examples/hyperdense-public-example.md',
    'examples/duel-public-example.md'
]
errors=[]
for f in required:
    p=ROOT/f
    if not p.exists() or p.stat().st_size < 100:
        errors.append(f'missing/too small: {f}')

skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
for token in ['Action Packet','Threat Queue','impact hierarchy','Momentum continuity rule','Seedance 2.5']:
    if token.lower() not in skill.lower():
        errors.append(f'missing core token: {token}')

# External edition hygiene: no local absolute paths, no packaged source binaries, no common secret markers.
all_text='\n'.join((ROOT/f).read_text(encoding='utf-8') for f in required)
for pattern, label in [
    (r'/mnt/data/', 'local path'),
    (r'\\Users\\', 'Windows user path'),
    (r'BEGIN (?:RSA|OPENSSH) PRIVATE KEY', 'private key'),
    (r'sk-[A-Za-z0-9_-]{20,}', 'API key-like token'),
]:
    if re.search(pattern, all_text):
        errors.append(f'hygiene failure: {label}')

if errors:
    print('SELFTEST FAIL')
    for e in errors: print('-', e)
    sys.exit(1)
print('SELFTEST PASS')
print(f'files_checked={len(required)}')
print(f'total_text_chars={len(all_text)}')
