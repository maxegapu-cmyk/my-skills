# Changelog

## 4.0.0-public — 2026-09-27

Major clean-room rewrite of the supplied cinematic-fight prompt package.

### Architecture
- Replaced the long monolithic martial-arts guide with a routed Skill entry point plus focused references.
- Added Action Packet causal choreography: initiation → defense/contact → reaction → displacement → world response → exit vector.
- Added persistent combat state and explicit final-state handoff.

### Action quality
- Added momentum continuity / no-neutral-reset logic for sustained combat.
- Added three motion-density modes: measured, kinetic, hyperdense.
- Added impact hierarchy so routine hits and hero impacts do not share the same VFX/camera intensity.
- Added grounded airborne-motion rules and short ballistic arcs for realistic fights.
- Added environment-as-force-witness behavior for water, dust, glass, metal, cloth, rain and debris.

### One-vs-many
- Added Threat Queue tracking for primary threat, secondary pressure, disabled opponents and next entry vector.
- Added defeat persistence and anti-resurrection rules.
- Added conveyor, crossfire and compression crowd patterns.
- Added overlap timing so the next attacker can enter before the current exchange fully settles without turning the shot into a fused pile.

### Cinematography
- Added shot-job grammar: establish, follow, contact, reversal, impact, result.
- Added screen-direction/action-axis ledger.
- Added lag-and-catch tracking for extreme speed.
- Added impact punctuation rules and shaky-cam limits.

### Prompting and compatibility
- Reworked prompt contracts around current Seedance 2.5 public guidance: explicit reference roles, one-line concept, timeline, global locks, sound and observable endpoint.
- Sub-second choreography is treated as authoring rhythm rather than guaranteed frame-accurate control.
- Added short-burst, duel, corridor, weapon and creature contracts.

### Diagnostics
- Added symptom-driven minimal repair guide for slow action, dead pauses, weightless hits, excessive knockback, fused enemies, teleporting cuts, floating jumps, VFX overload and mechanical timelines.

### Public-release hygiene
- Removed the bundled large video-analysis DOCX and unrelated source-package metadata.
- Rewrote all examples from scratch.
- Added public-source notes and package self-test.
