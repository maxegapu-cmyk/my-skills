# Example — 8s Hyperdense Alley Fight

This example is original to this public package and demonstrates the compiler. It intentionally does not reproduce any third-party or user-supplied prompt.

## Brief

One unarmed protagonist escapes through a rain-soaked service alley while four armed pursuers enter from different directions. Grounded contemporary action, dark cool palette, no supernatural powers.

## Paste-ready Seedance-style prompt

```text
〖素材职责〗
@图片1锁定主角的脸、短发、深灰夹克、体型与鞋；@图片2锁定潮湿狭窄后巷、金属消防梯、垃圾箱和远端暖黄门灯。若提供@视频1，仅参考其快速近身动作节奏，不迁移人物、服装、场景、Logo或色彩。

〖一句话导演意图〗
8秒16:9写实动作短片，主角沿狭窄后巷连续突破四名追击者并从远端门口撤离。动作快而清楚，硬朗近身格斗，攻击与反制都产生明确的身体位移；镜头以低机位侧后跟拍为主，通过短促摇甩捕捉下一威胁，不做持续360度环绕。

〖全局锁定〗
35mm胶片质感，冷青灰低饱和，湿地反光，深阴影中保留中性肤色，远端仅有一处暖黄实景灯；细颗粒、轻微高光晕染。人物比例与衣着全程稳定。真实地面摩擦与惯性；所有腾空必须由冲撞、绊摔或蹬地带来，短弧线后立即落地/撞击，禁止原地上浮与长时间滞空。普通命中只改变姿态和距离，高潮命中才允许明显震机和大幅位移。运动模糊沿真实速度方向出现，接触点始终可辨。无字幕、无多余人物、无肢体融合、无瞬移、无武器凭空换手。

〖战斗时间轴〗
0–2秒：动作从第一帧开始。E1从画面左前方用短棍横扫，主角不后退，压低重心从棍下切入近身，前臂架住E1持棍手腕并用肩撞破其站姿；E1向左侧铁门撞去，棍子敲在门板上发出金属震响。主角借肩撞后的顺时针转体继续向巷子深处移动，镜头低位平行追随，E2已经从右侧垃圾箱后切入。

2–4秒：主角不回正，利用正在进行的转体把E2伸来的手臂带偏，让其前冲擦过自己肩侧；紧接一个短距离躯干打击令E2上身折下，主角推住其背部让他沿原本前冲方向滑向湿地。E3从后方扑近，镜头短促摇甩后立即稳定在双人全身关系，主角踩住墙边低矮箱体借力侧移，避免三人身体叠成一团。

4–6秒：E3追上并抓住夹克后摆，主角被拉停半步而不是瞬移脱身；他顺着拉力回身，用肘部砸开抓握，再用腿部绊阻让E3失去支点。E3横向跌入浅水，水花沿其倒地方向扇开。跌落声尚未结束，E4已从远端门口迎面冲来，主角落脚后仍保持前冲速度，镜头让两人的闭合距离完整可见。

6–8秒：E4迎面重拳，主角向外侧偏头让拳锋擦过，抓住其过度前伸的肩线，把自己的前冲惯性与E4的冲势合在一起将其带向侧墙；撞墙瞬间只使用一次明显的摄影机微震和短促径向动感，墙面旧灰屑与雨水同时飞散。主角不给停顿，松手后继续冲向暖黄门口；镜头略微落后半拍再追上，最终定在主角穿门而出、E4靠墙下滑、前三名追击者仍停留在各自倒地位置的清晰终态。

〖连续性终态〗
主角离开远端门口；E1左侧铁门旁，短棍落在脚边；E2中段湿地俯卧；E3浅水区侧倒；E4远端右墙下滑。后巷积水仍在扩散波纹，铁门轻微振动，远端暖灯不变。
```

## Why it works

- every exchange inherits motion from the previous one;
- each opponent has an entry vector and persistent end state;
- only the final wall impact receives the strongest camera accent;
- secondary threats overlap in time without creating four simultaneous grapples;
- the environment records contact through metal, water and wall debris;
- the final state can be used as the start of an extension.
