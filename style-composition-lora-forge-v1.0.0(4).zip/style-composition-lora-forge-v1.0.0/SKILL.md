---
name: style-composition-lora-forge
version: 1.0.0
summary: Build and validate style-focused LoRA training projects while keeping composition controllable through a separate inference-time structure channel.
---

# Style + Composition LoRA Forge

## Purpose
Use this skill when a user has a set of reference images (for example, oil paintings from one creator or one coherent visual period) and prompt-only attempts cannot reliably reproduce the visual language.

The skill does **not** treat "style" and "composition" as one thing. It uses two coordinated channels:

1. **Style channel — LoRA / adapter training**
   - brushwork / edge behavior
   - palette relationships
   - surface treatment / paint density
   - shape simplification and rendering habits
   - lighting preferences
   - recurring design grammar

2. **Structure channel — inference-time control**
   - exact or near-exact composition
   - pose / silhouette
   - depth / perspective
   - major edge layout
   - spatial arrangement

The structure channel should normally be handled by ComfyUI + ControlNet / reference-image conditioning / IP-Adapter-type tools rather than forcing a style LoRA to memorize layouts.

## Supported training backends
Preferred order:

- **OneTrainer**: best default for users who want a GUI, broad model support, dataset tooling and training-time sampling.
- **SimpleTuner**: best advanced/general backend for modern architectures and reproducible config-driven training.
- **kohya_ss / sd-scripts**: strong choice for classic Stable Diffusion / SDXL workflows and users already invested in its ecosystem.
- **AI Toolkit**: convenient config-driven option for FLUX-family and other supported diffusion models.

Do not vendor third-party trainer code. Generate project plans and config starters that point to the upstream projects.

## Default workflow

### Phase 0 — define the target
Ask or infer:
- base model family
- local GPU / VRAM or cloud GPU
- number of reference images
- whether the user wants **style transfer**, **soft compositional tendencies**, or **specific composition recreation**
- intended inference UI (ComfyUI is preferred)

If exact composition is required, keep it out of the LoRA objective as much as possible and reserve it for the structure channel.

### Phase 1 — curate and audit the dataset
Generate a curation sheet first when practical:

```bash
python scripts/forge.py curate --dataset /path/to/images --out outputs/curation.csv
```

Fill `subject_group`, `composition_group`, `period`, `medium`, `quality_1_5` for the images you can classify confidently. Then audit:

```bash
python scripts/forge.py audit --dataset /path/to/images --curation outputs/curation.csv --out outputs/audit.json
```

Create a leakage-resistant split:

```bash
python scripts/forge.py split --dataset /path/to/images --out outputs/split
```

The split keeps exact and perceptually near-duplicate clusters together so re-encodes/crops do not land on opposite sides of train and holdout.

Hard failures:
- fewer than 8 usable images
- severe exact-duplicate contamination
- mixed unrelated visual periods/mediums with no labels
- low-resolution or heavily compressed majority
- watermarks / frames / gallery-room photos dominating the set

Warnings:
- fewer than 15 images
- one subject dominates more than ~35% of the set
- one composition dominates more than ~30% unless that bias is intentionally desired
- near-duplicate clusters
- missing captions

### Phase 2 — split what should be learned vs controlled
Build four conceptual labels for each image:

- `CONTENT`: subject, action, environment
- `STRUCTURE`: composition, framing, pose, viewpoint, spatial layout
- `STYLE`: brushwork, palette logic, edge behavior, surface, lighting grammar
- `NOISE`: signature, frame, scan artifact, watermark, museum wall, color cast from bad reproduction

Caption **CONTENT** and usually **STRUCTURE**. Do not exhaustively caption every stylistic trait you want the trigger token to absorb.

Why: if the captions repeatedly name every composition and style trait, the adapter can bind those traits to ordinary words instead of the trigger token; if you omit all structure descriptors, the LoRA is more likely to bake specific layouts into the style token. The default therefore captions structure but trains style.

### Phase 3 — captioning
Use one caption text file per image when supported.

Recommended caption shape:

`<trigger>, <subject/content>, <action>, <environment>, <composition/framing>, <viewpoint>, <lighting facts>`

Do not put evaluative filler like "masterpiece, best quality" into training captions.

Optional local caption sources:
- OneTrainer's built-in caption tooling
- JoyCaption batch captioning

Always review machine captions. The model must not be trained on hallucinated content labels.

### Phase 4 — create a pilot, not one giant run
Generate a plan:

```bash
python scripts/forge.py plan --dataset /path/to/images --project examples/project.example.json --out outputs/plan.json
```

Default philosophy:
- start rank 16–32
- keep text encoders frozen unless a model-specific reason exists
- use checkpoint intervals around 200–300 steps for small/medium style sets
- do not select the final LoRA from training loss alone
- save multiple checkpoints and compare on a fixed validation matrix

The plan generator deliberately outputs a **range and checkpoint sweep**, not a false "magic best step".

### Phase 5 — emit backend starter files

```bash
python scripts/forge.py emit --trainer simpletuner --project examples/project.example.json --plan outputs/plan.json --out outputs/simpletuner
python scripts/forge.py emit --trainer aitoolkit   --project examples/project.example.json --plan outputs/plan.json --out outputs/aitoolkit
python scripts/forge.py emit --trainer kohya       --project examples/project.example.json --plan outputs/plan.json --out outputs/kohya
python scripts/forge.py emit --trainer onetrainer  --project examples/project.example.json --plan outputs/plan.json --out outputs/onetrainer
```

Version-sensitive backends change quickly. The emitter writes a starter config plus a `CHECK_BEFORE_RUN.md`; compare generated fields against the upstream example for the exact installed commit before launching an expensive run.

### Phase 6 — validation matrix
Use fixed seeds and fixed prompts for every checkpoint.

The minimum matrix must test:
1. **new subject** not present in training data
2. **new environment** not present in training data
3. **new composition** to test whether the style token is entangled with layout
4. **same content, alternate framing**
5. **style strength sweep** (e.g. 0.55 / 0.75 / 0.95)
6. **composition control on/off**

A good checkpoint:
- carries visual language across unseen subjects
- keeps prompt compliance
- does not collapse onto a few training compositions
- does not reproduce signatures / frames / irrelevant motifs
- still responds to external structure control

Reject a checkpoint if it is merely more similar to a training image.

### Phase 7 — composition channel in ComfyUI
For exact or semi-exact composition:

- silhouette / gesture: OpenPose / DWPose-style preprocessor + compatible ControlNet
- major edges: Canny / line art
- depth / perspective: depth preprocessor + compatible ControlNet
- global image reference: IP-Adapter / other reference conditioning compatible with the model family

Start with the LoRA at moderate strength and one structure condition. Add a second condition only if the first cannot constrain the needed geometry.

Avoid "constraint pile-up": high LoRA strength + strong IP reference + strong edge ControlNet + strong depth ControlNet can fight each other and reduce texture quality.

### Phase 8 — choose the winner
Score each checkpoint using `references/EVAL_RUBRIC.md`.

Never choose by:
- lowest training loss only
- "looks most like one reference" only
- strongest style at 1.0 weight only

Prefer the earliest checkpoint that passes style fidelity **and** generalization gates. Later checkpoints that improve reference similarity but reduce prompt/layout freedom are overfit.

## Non-negotiable rules
- Never promise exact style recreation from prompt engineering alone.
- Never claim one hyperparameter set is universally optimal across model families.
- Never mix train and holdout near-duplicates.
- Never use the training references themselves as the only validation set.
- Never treat composition fidelity as a style-LoRA-only problem when a structure adapter can solve it more reliably.
- Always keep a fixed seed/prompt validation sheet across checkpoints.
- Always record base model, trainer version/commit, dataset hash and config with the LoRA.

## Success standard
A run is accepted only if all are true:
- style transfer works on at least 3 unseen subject categories
- at least 2 substantially different compositions remain controllable
- no obvious training-image copy is produced in the fixed validation matrix
- the same checkpoint behaves coherently at two LoRA strengths
- structure-control on/off produces predictable layout changes while retaining style

