# Backend Matrix

## OneTrainer — default GUI choice
Use when:
- user wants broad model support and less command-line work
- dataset caption/mask tooling is useful
- training-time sampling and backups matter

Strengths:
- LoRA + full fine-tuning + embeddings
- aspect-ratio / multi-resolution support
- dataset caption tooling
- masked training
- training sampling / TensorBoard

## SimpleTuner — default advanced choice
Use when:
- modern architectures are involved
- reproducible config files matter
- VRAM optimization / quantization / distributed options matter
- user may run locally or on rented GPUs

Start from the upstream example for the exact model family, then apply the Forge-generated patch.

## kohya_ss / sd-scripts — classic SD/SDXL path
Use when:
- user already has a kohya setup
- SD1.x / SDXL ecosystem compatibility matters
- a well-known GUI + CLI workflow is preferred

## AI Toolkit — convenient FLUX-oriented path
Use when:
- FLUX-style training is the main need
- a readable YAML job config is attractive
- checkpoint sampling every N steps is desired

## Inference / composition
Use ComfyUI as the preferred assembly layer:
- load base model
- apply selected LoRA
- add one structure condition first (pose OR edge OR depth)
- add reference-image conditioning only when needed
- sweep LoRA and structure strengths separately
