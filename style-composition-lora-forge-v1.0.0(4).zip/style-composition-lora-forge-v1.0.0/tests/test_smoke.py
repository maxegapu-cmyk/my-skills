import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
FORGE = ROOT / "scripts" / "forge.py"
PROJECT = ROOT / "examples" / "project.example.json"


def run(*args):
    cp = subprocess.run([sys.executable, str(FORGE), *map(str, args)], capture_output=True, text=True)
    if cp.returncode != 0:
        raise AssertionError(cp.stdout + "\n" + cp.stderr)
    return cp


def main():
    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        ds = td / "dataset"
        ds.mkdir()
        for i in range(18):
            im = Image.new("RGB", (900 + i * 3, 1024), (20 + i, 40 + i, 60 + i))
            p = ds / f"img_{i:02d}.png"
            im.save(p)
            p.with_suffix(".txt").write_text(f"pntx9, test subject {i}, centered composition", encoding="utf-8")

        curation = td / "curation.csv"
        run("curate", "--dataset", ds, "--out", curation)
        assert curation.exists()

        audit = td / "audit.json"
        plan = td / "plan.json"
        run("audit", "--dataset", ds, "--out", audit, "--curation", curation)
        a = json.loads(audit.read_text(encoding="utf-8"))
        assert a["image_count"] == 18
        assert a["caption_coverage"] == 1.0

        project = td / "project.json"
        obj = json.loads(PROJECT.read_text(encoding="utf-8"))
        obj["dataset_dir"] = str(ds)
        project.write_text(json.dumps(obj), encoding="utf-8")
        split_dir = td / "split"
        run("split", "--dataset", ds, "--out", split_dir)
        assert (split_dir / "train.txt").exists()
        assert (split_dir / "holdout.txt").exists()

        run("plan", "--dataset", ds, "--project", project, "--out", plan)
        p = json.loads(plan.read_text(encoding="utf-8"))
        assert p["training"]["lora_rank_start"] in {16, 24, 32}
        assert len(p["training"]["step_window"]) == 2

        for trainer in ["simpletuner", "aitoolkit", "kohya", "onetrainer"]:
            out = td / trainer
            run("emit", "--trainer", trainer, "--project", project, "--plan", plan, "--out", out)
            assert (out / "CHECK_BEFORE_RUN.md").exists()

    print("SMOKE TEST PASS")


if __name__ == "__main__":
    main()
