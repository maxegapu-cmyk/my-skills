# BOOT

Run this once after unpacking:

```bash
python tests/test_smoke.py
```

Expected output:

```text
SMOKE TEST PASS
```

Then open `README.md` for the short workflow or `SKILL.md` for the complete operating protocol.
