#!/usr/bin/env python3
"""提示词逆向：从一条或多条提示词反推“母版指令”。

多条样本：对齐短语，找出所有样本共有的骨架（常量）和每条不同的部分（变量槽），
生成带 {{槽位}} 的母版模板，并验证模板能否还原每条原始提示词。
单条样本：拆成成分（主体/场景/风格/光线/镜头……），给出建议的母版结构。

用法：
  prompt_reverse.py prompts.txt                  # 每行一条，或用 --- 分隔多行提示词
  prompt_reverse.py a.txt b.txt c.txt            # 每个文件一条
  echo "..." | prompt_reverse.py -               # 从标准输入读
  prompt_reverse.py prompts.txt --threshold 0.6  # 出现率 ≥ 60% 视为常量
  prompt_reverse.py prompts.txt --json           # 输出 JSON
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter, OrderedDict
from difflib import SequenceMatcher
from pathlib import Path

# ---------------------------------------------------------------- 成分词库
CATEGORIES = OrderedDict([
    ("参数", []),  # 由正则识别
    ("画质", ["8k", "4k", "hd", "uhd", "masterpiece", "best quality", "high quality", "ultra detailed",
             "highly detailed", "sharp focus", "photorealistic", "hyperrealistic", "award winning", "raw photo",
             "高清", "超清", "高画质", "细节丰富", "超写实", "写实", "杰作", "最佳质量", "精细"]),
    ("镜头", ["shot", "close-up", "closeup", "close up", "wide angle", "wide-angle", "lens", "mm", "macro",
             "bokeh", "depth of field", "dof", "aerial", "drone", "pov", "dolly", "pan", "tilt", "zoom",
             "tracking", "handheld", "low angle", "high angle", "bird's eye", "eye level", "telephoto",
             "f/", "aperture", "focus", "镜头", "特写", "近景", "中景", "远景", "全景", "俯拍", "仰拍", "航拍",
             "推镜", "拉镜", "摇镜", "跟拍", "运镜", "景深", "虚化", "广角", "长焦", "微距", "视角", "机位", "平视"]),
    ("构图", ["composition", "centered", "symmetr", "rule of thirds", "full body", "half body", "portrait",
             "landscape orientation", "framing", "negative space", "构图", "居中", "对称", "三分法", "全身",
             "半身", "留白", "画面", "比例"]),
    ("光线", ["light", "lighting", "sunlight", "golden hour", "blue hour", "backlight", "rim light", "neon",
             "glow", "shadow", "volumetric", "cinematic lighting", "studio lighting", "soft light", "hard light",
             "光", "光线", "逆光", "侧光", "顶光", "柔光", "硬光", "霓虹", "黄金时刻", "阴影", "体积光", "丁达尔",
             "暖光", "冷光", "布光", "日落", "夕阳", "晨光"]),
    ("色彩", ["color", "colour", "palette", "monochrome", "pastel", "vibrant", "muted", "teal and orange",
             "black and white", "saturated", "desaturated", "hue", "tone", "色", "色调", "配色", "饱和",
             "黑白", "莫兰迪", "马卡龙", "暖色", "冷色", "胶片色"]),
    ("风格", ["style", "in the style of", "art", "aesthetic", "anime", "cinematic", "film", "illustration",
             "painting", "watercolor", "oil", "3d", "render", "octane", "unreal engine", "pixar", "ghibli",
             "cyberpunk", "vaporwave", "minimalist", "surreal", "vintage", "retro", "photography", "editorial",
             "风格", "画风", "插画", "水彩", "油画", "国风", "二次元", "动漫", "赛博朋克", "电影感", "胶片",
             "极简", "复古", "超现实", "渲染", "摄影", "国潮", "水墨", "像素"]),
    ("情绪", ["mood", "atmosphere", "dreamy", "moody", "serene", "dramatic", "melancholic", "cozy", "epic",
             "mysterious", "氛围", "梦幻", "忧郁", "宁静", "温馨", "史诗", "神秘", "治愈", "压抑", "浪漫", "情绪"]),
    ("运动", ["moving", "motion", "slow motion", "timelapse", "time-lapse", "walks", "walking", "running",
             "turns", "flying", "camera moves", "transition", "seconds", "fps", "loop",
             "运动", "慢动作", "延时", "转身", "奔跑", "行走", "飞", "转场", "秒", "帧", "循环", "动作", "缓缓"]),
    ("场景", ["background", "in a", "in the", "at the", "street", "city", "forest", "room", "studio", "beach",
             "mountain", "sky", "ocean", "rain", "snow", "fog", "sunset", "park", "sofa", "desk", "window", "interior", "exterior", "indoor", "outdoor", "night", "day",
             "背景", "场景", "街道", "城市", "森林", "室内", "室外", "海边", "山", "天空", "夜晚", "白天", "雨", "雪", "雾"]),
])
PARAM_PATTERNS = [
    (r"--[a-zA-Z]+(?:\s+[^\s,，-][^\s,，]*)?", "Midjourney 参数"),
    (r"\([^()]+:\s*[0-9.]+\)", "权重语法"),
    (r"<lora:[^>]+>", "LoRA"),
    (r"\b(?:seed|steps|cfg|sampler|ar|aspect ratio)\s*[:=]\s*[\w.:]+", "生成参数"),
]
NEG_RE = re.compile(r"(?im)^\s*(negative prompt|负面提示词|反向提示词|negative)\s*[:：]\s*(.+)$")
SPLIT_RE = re.compile(r"[,，;；、\n]+|(?<=[。.!！?？])\s+")


def classify(phrase: str) -> str:
    low = phrase.lower()
    for name, pat in PARAM_PATTERNS:
        if re.fullmatch(pat, phrase.strip(), flags=re.I):
            return "参数"
    best, score = "主体", 0
    for cat, words in CATEGORIES.items():
        hits = sum(1 for w in words if w in low)
        if hits > score:
            best, score = cat, hits
    return best


def normalize(p: str) -> str:
    return re.sub(r"\s+", " ", p.strip().strip("。.").lower())


def split_prompt(text: str) -> dict:
    neg = None
    m = NEG_RE.search(text)
    if m:
        neg = m.group(2).strip()
        text = text[:m.start()] + text[m.end():]
    params = []
    for pat, label in PARAM_PATTERNS:
        for hit in re.findall(pat, text, flags=re.I):
            params.append(hit.strip())
        text = re.sub(pat, " ", text, flags=re.I)
    phrases = [p.strip() for p in SPLIT_RE.split(text) if p and p.strip(" .。")]
    return {"phrases": phrases, "params": params, "negative": neg}


# ---------------------------------------------------------------- 读取
def read_samples(paths: list, sep: str | None) -> list:
    samples = []
    for p in paths:
        raw = sys.stdin.read() if p == "-" else Path(p).read_text(encoding="utf-8")
        raw = raw.strip()
        if not raw:
            continue
        if len(paths) > 1 and p != "-":
            samples.append(raw)
            continue
        if sep:
            parts = raw.split(sep)
        elif re.search(r"(?m)^\s*-{3,}\s*$", raw):
            parts = re.split(r"(?m)^\s*-{3,}\s*$", raw)
        else:
            parts = raw.splitlines()
        samples += [x.strip() for x in parts if x.strip()]
    return samples


# ---------------------------------------------------------------- 母版提取
def extract_template(samples: list, threshold: float) -> dict:
    parsed = [split_prompt(s) for s in samples]
    seqs = [[normalize(p) for p in x["phrases"]] for x in parsed]
    n = len(samples)
    # 以最长的一条为骨架，避免漏掉结构
    base_i = max(range(n), key=lambda i: len(seqs[i]))
    base = seqs[base_i]
    present = [1] * len(base)  # 每个骨架短语在多少条样本中对齐出现
    aligned = [[None] * len(base) for _ in range(n)]
    for j in range(len(base)):
        aligned[base_i][j] = parsed[base_i]["phrases"][j]
    for i in range(n):
        if i == base_i:
            continue
        sm = SequenceMatcher(a=base, b=seqs[i], autojunk=False)
        for blk in sm.get_matching_blocks():
            for k in range(blk.size):
                present[blk.a + k] += 1
                aligned[i][blk.a + k] = parsed[i]["phrases"][blk.b + k]
    const = [present[j] / n >= threshold for j in range(len(base))]

    # 变量槽：骨架中连续的非常量区段 + 其他样本中对应的未匹配区段
    slots, template_parts, slot_ranges = [], [], []
    j = 0
    while j < len(base):
        if const[j]:
            template_parts.append(parsed[base_i]["phrases"][j])
            j += 1
            continue
        k = j
        while k < len(base) and not const[k]:
            k += 1
        slot_ranges.append((j, k))
        j = k

    # 为每个槽位收集每条样本的取值：两侧常量锚点之间的原文短语
    def values_for(i, a, b):
        seq, phr = seqs[i], parsed[i]["phrases"]
        left = base[a - 1] if a > 0 else None
        right = base[b] if b < len(base) else None
        li = seq.index(left) + 1 if left in seq else (0 if a == 0 else None)
        ri = seq.index(right) if right in seq else (len(seq) if b == len(base) else None)
        if li is None or ri is None or ri < li:
            return None
        return phr[li:ri]

    used = Counter()
    template, cursor = [], 0
    def add_slot(cat_src, vals):
        cats = Counter(classify(x) for x in cat_src if x)
        cat = cats.most_common(1)[0][0] if cats else "主体"
        if not slots and not template and cat == "场景":
            cat = "主体"  # 开头的变量段通常是主体描述（如 a cat on a sofa）
        used[cat] += 1
        name = cat if used[cat] == 1 else f"{cat}{used[cat]}"
        optional = any(not v for v in vals)
        slots.append({"name": name, "category": cat, "values": vals, "optional": optional,
                      "distinct": len({v for v in vals if v})})
        template.append(("[可选：{{" + name + "}}]") if optional else "{{" + name + "}}")

    for (a, b) in slot_ranges:
        template += [parsed[base_i]["phrases"][x] for x in range(cursor, a) if const[x]]
        per = [values_for(i, a, b) for i in range(n)]
        width = b - a
        if width > 1 and all(v is not None and len(v) == width for v in per):
            # 每条样本在这一段的短语数相同 → 逐位置拆成独立槽位（如主体、场景分开）
            for k in range(width):
                add_slot([v[k] for v in per], [v[k] for v in per])
        else:
            add_slot([parsed[base_i]["phrases"][x] for x in range(a, b)],
                     ["，".join(v) if v else None for v in per])
        cursor = b
    template += [parsed[base_i]["phrases"][x] for x in range(cursor, len(base)) if const[x]]

    # 参数与负面词：全体共有的视为常量
    param_sets = [set(x["params"]) for x in parsed]
    common_params = sorted(set.intersection(*param_sets)) if param_sets else []
    var_params = sorted(set.union(*param_sets) - set(common_params)) if param_sets else []
    negs = [x["negative"] for x in parsed]
    neg_common = negs[0] if negs and all(v == negs[0] for v in negs) else None

    # 还原验证：模板代入每条样本的槽值，比较短语集合覆盖率
    coverage = []
    for i in range(n):
        filled = "，".join(template)
        for s in slots:
            v = s["values"][i] or ""
            filled = filled.replace("[可选：{{" + s["name"] + "}}]", v).replace("{{" + s["name"] + "}}", v)
        got = {normalize(p) for p in SPLIT_RE.split(filled) if p.strip()}
        want = set(seqs[i])
        coverage.append(round(len(got & want) / max(1, len(want)), 2))

    constants = [parsed[base_i]["phrases"][j] for j in range(len(base)) if const[j]]
    return {
        "samples": n, "threshold": threshold, "base_sample": base_i + 1,
        "template": "，".join(template) + ("".join(" " + p for p in common_params)),
        "constants": [{"text": c, "category": classify(c)} for c in constants],
        "slots": slots, "common_params": common_params, "variable_params": var_params,
        "negative_common": neg_common, "coverage": coverage,
    }


def anatomy(sample: str) -> dict:
    x = split_prompt(sample)
    comp = OrderedDict()
    for p in x["phrases"]:
        comp.setdefault(classify(p), []).append(p)
    return {"components": comp, "params": x["params"], "negative": x["negative"]}


# ---------------------------------------------------------------- 输出
SLOT_HINT = {"主体": "换主体", "场景": "换场景", "运动": "换动作", "情绪": "换氛围"}
STABLE = ("风格", "画质", "光线", "色彩", "镜头", "构图", "参数")


def md_single(a: dict) -> str:
    out = ["# 提示词成分拆解（单条样本）", ""]
    out += ["| 成分 | 内容 |", "| --- | --- |"]
    for cat, items in a["components"].items():
        out.append(f"| {cat} | {'；'.join(items)} |")
    if a["params"]:
        out.append(f"| 参数 | {' '.join(a['params'])} |")
    if a["negative"]:
        out.append(f"| 负面词 | {a['negative']} |")
    slots = [c for c in a["components"] if c not in STABLE]
    keep = [c for c in a["components"] if c in STABLE]
    out += ["", "## 建议的母版结构", "",
            "单条样本无法区分常量和变量，以下按成分类型推断：",
            f"- 很可能是变量槽：{'、'.join(slots) or '（无）'}",
            f"- 很可能是风格常量：{'、'.join(keep) or '（无）'}", "",
            "```", "，".join("{{" + c + "}}" if c in slots else "；".join(a["components"][c])
                            for c in a["components"]) + ("".join(" " + p for p in a["params"])), "```", "",
            "再提供 2 条以上同系列提示词，可以把推断换成实证。"]
    return "\n".join(out)


def md_multi(r: dict) -> str:
    out = [f"# 母版指令逆向（{r['samples']} 条样本，常量阈值 {int(r['threshold'] * 100)}%）", "",
           "## 母版模板", "", "```", r["template"], "```", ""]
    if r["negative_common"]:
        out += [f"负面词（全部样本一致）：`{r['negative_common']}`", ""]
    out += ["## 常量（风格锚点）", "", "所有或大部分样本都出现，决定这个系列的统一观感：", ""]
    out += [f"- [{c['category']}] {c['text']}" for c in r["constants"]] or ["- （无）"]
    out += ["", "## 变量槽", "", "| 槽位 | 类型 | 不同取值数 | 各样本取值 |", "| --- | --- | --- | --- |"]
    for s in r["slots"]:
        vals = " / ".join(f"#{i + 1}:{v}" for i, v in enumerate(s["values"]) if v) or "（未对齐）"
        tag = "（可选）" if s.get("optional") else ""
        out.append(f"| {{{{{s['name']}}}}}{tag} | {s['category']} | {s['distinct']} | {vals} |")
    if r["common_params"] or r["variable_params"]:
        out += ["", f"参数常量：{' '.join(r['common_params']) or '无'}；参数变量：{' '.join(r['variable_params']) or '无'}"]
    avg = sum(r["coverage"]) / len(r["coverage"])
    out += ["", "## 还原验证", "",
            f"把每条样本的槽值代回模板，短语覆盖率：{', '.join(f'#{i + 1} {c:.0%}' for i, c in enumerate(r['coverage']))}（平均 {avg:.0%}）。",
            "覆盖率 ≥ 90% 说明模板基本解释了全部样本；偏低时，多半是样本里有可选成分或顺序被打乱，"
            "可降低 --threshold 或人工合并相近槽位。"]
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description="提示词逆向：反推母版指令")
    ap.add_argument("inputs", nargs="+", help="文件路径，或 - 表示标准输入")
    ap.add_argument("--sep", help="自定义样本分隔符")
    ap.add_argument("--threshold", type=float, default=1.0, help="常量出现率阈值（默认 1.0 = 全部样本都有）")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    samples = read_samples(a.inputs, a.sep)
    if not samples:
        sys.exit("没有读到提示词")
    if len(samples) == 1:
        res = anatomy(samples[0])
        print(json.dumps(res, ensure_ascii=False, indent=2) if a.json else md_single(res))
    else:
        res = extract_template(samples, a.threshold)
        print(json.dumps(res, ensure_ascii=False, indent=2) if a.json else md_multi(res))


if __name__ == "__main__":
    main()
