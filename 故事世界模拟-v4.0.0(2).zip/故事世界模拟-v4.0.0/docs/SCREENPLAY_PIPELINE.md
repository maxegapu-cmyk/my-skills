# Screenplay Pipeline

## Hierarchy

`logline -> character engines -> ending pressure -> act/sequence map -> scene functions -> beat sheets -> dialogue/action -> Fountain`

This hierarchy is guidance, not a mandatory creative order. Writers may enter at any layer.

## Sequence design

Each sequence should have:
- local objective;
- escalation mechanism;
- reversal/turn;
- consequence that changes the next sequence.

## Scene design

Every scene declares:
- dramatic owner;
- objective;
- opposition;
- first tactic;
- tactic change;
- turn;
- exit value;
- visual evidence of interior change.

## Screenplay memory

Carry forward:
- injuries;
- clothing/props when story-relevant;
- location geography;
- who knows what;
- relationship tension;
- unfinished actions;
- object possession;
- time of day.

## Fountain

The package's exporter produces readable Fountain-like text. Production-specific locked pages/revision colors are outside v2 scope.
