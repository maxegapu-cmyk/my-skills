# Scene Engine

## Scene state vector

At entry:
- place/time;
- participants;
- objective situation;
- each participant's goal;
- knowledge/belief;
- relationship pressure;
- physical resources;
- emotional residue from previous scene.

## Beat mechanics

A useful beat usually contains:
`attempt -> feedback -> interpretation -> tactic adjustment`

A scene becomes dramatic when tactics change under pressure.

## Exit delta

Record what changed in:
- information;
- power;
- relationship;
- decision;
- risk;
- resource;
- emotional direction;
- audience expectation.

If none changed, identify a deliberate function (tone, suspense, misdirection, recovery) or flag redundancy.

## Dialogue

Dialogue lines are actions. Tag intent such as:
- test;
- pressure;
- seduce;
- conceal;
- bargain;
- rescue face;
- recruit;
- reject;
- stall;
- provoke;
- verify;
- shift blame.

Subtext is the active social move, not merely the opposite of literal words.
