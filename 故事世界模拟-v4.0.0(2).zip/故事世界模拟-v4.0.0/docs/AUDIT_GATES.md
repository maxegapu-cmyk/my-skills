# Audit Gates

## Gate 1 — Facts
No contradiction with accepted source/canon.

## Gate 2 — Time/space
Events can physically and chronologically occur.

## Gate 3 — Knowledge
No character acts on unavailable information.

## Gate 4 — Character causality
Major choices have a valid desire/fear/belief/memory/threshold chain.

## Gate 5 — Relationship continuity
Large relationship deltas have event causes.

## Gate 6 — Causal chain
Major turns have prerequisites and consequences.

## Gate 7 — Promise/payoff
Important setups are tracked; payoffs correspond to established promises.

## Gate 8 — Scene value
Scenes create a meaningful delta or a deliberate non-delta function.

## Gate 9 — Arc coherence
Character change is progressive, regressive, cyclical, steadfast, or deliberately unresolved—not accidental drift.

## Gate 10 — Format fidelity
Novel POV or screenplay filmability rules are satisfied.
