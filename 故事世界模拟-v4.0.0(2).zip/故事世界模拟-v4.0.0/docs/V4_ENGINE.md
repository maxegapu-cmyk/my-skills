# 4.0 Engine Notes

## 时间
核心时间字段统一为数字 `story_time`。人类友好的“第十二天傍晚”放 `time_label`。所有排序只看数值时间，再看 `sequence`。

## 知识
每条知识不是一句“他知道了”，而是：`subject_id + fact_id + learned_at + source_event_id + confidence + status`。查询某角色在时刻 t 的知识只返回 `learned_at <= t` 且未在 `forgotten_at <= t` 的记录。

## 模拟
4.0 采用“确定性外壳 + 语义输入”而非假装做通用物理模拟。Intent 的 effects 只有受控类型：`fact_set`、`fact_delete`、`entity_patch`、`resource_delta`、`move`、`knowledge_grant`、`promise_update`。未知 effect 直接拒绝。

## 自动指标的边界
指标是“可追踪信号”，不是文学质量真值。它们用于发现跑偏和比较同一项目的分支，不应用作跨作品评分。
