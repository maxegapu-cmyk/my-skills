# Event Replay and Branching

The accepted world is reconstructed from accepted events. Snapshots are optimization, not truth.

Advantages:
- rewind to any supported time;
- inspect what a character knew then;
- branch from a stable past state;
- compare controlled and uncontrolled futures;
- diagnose the first event where two runs diverged;
- preserve an audit trail.

Same-time events require deterministic ordering using sequence IDs or explicit causal precedence.
