# Memory and Belief Model

## 1. Why memory matters

Plot decisions are often triggered by what a character remembers *now*, not by the full objective history.

## 2. Episode fields

A memory episode stores:
- event reference;
- character;
- age/period;
- objective summary;
- perceived summary;
- emotional valence;
- arousal/intensity;
- importance;
- reliability;
- accessibility;
- avoidance;
- trigger cues;
- belief impact;
- learned strategy;
- later reinterpretations.

## 3. Retrieval heuristic

For a scene, candidate memories may be ranked by:

`hard relevance > trigger match > causal relevance > importance > recency > semantic similarity`

Do not retrieve a dramatic memory merely because it is dramatic.

## 4. Memory distortion

A memory may diverge from objective history through:
- incomplete perception;
- later misinformation;
- selective attention;
- defensive reinterpretation;
- emotional reframing;
- ordinary forgetting.

The engine stores both objective event and remembered version.

## 5. Belief lifecycle

Beliefs have:
- proposition;
- confidence;
- evidence known to character;
- origin memory/event;
- reinforcing events;
- contradicting evidence;
- status: active / weakened / replaced / unresolved.

A belief changes only when the character encounters evidence they actually receive and process.

## 6. Reinterpretation

Later events can change the meaning of an old memory. Record a new interpretation event rather than altering the historical source episode.
