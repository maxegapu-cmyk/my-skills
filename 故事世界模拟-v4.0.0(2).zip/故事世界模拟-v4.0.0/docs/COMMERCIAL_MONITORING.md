# Project / Commercial Monitoring

This layer is configurable because different products value different outcomes.

Possible goals for episodic or platform-oriented fiction:
- early hook without false promises;
- controlled unanswered-question load;
- periodic payoff;
- escalating stakes;
- protagonist agency;
- relationship motion;
- scene efficiency;
- production feasibility;
- episode-end propulsion;
- long-term franchise/character value.

Never collapse these into one universal “good story score.” A project may explicitly choose its priorities and trade-offs.

Monitoring is descriptive. Steering is intervention. Keep them separate so a writer can inspect natural evolution before deciding to influence it.
