import json,tempfile,unittest,sys,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import storyworld, simulate, audit, steering, context_compile, knowledge, ingest, render

class V4Fast(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory(); self.p=Path(self.t.name)/'p'; storyworld.init(self.p,'T')
    def tearDown(self): self.t.cleanup()
    def seed(self):
        shutil.rmtree(self.p); shutil.copytree(ROOT/'examples'/'harbor',self.p)
    def test_init_validate(self): self.assertEqual(storyworld.validate(self.p)[0],[])
    def test_numeric_time_schema_rejects_string(self):
        (self.p/'state'/'canon_events.jsonl').write_text(json.dumps({'id':'e','status':'CANON','story_time':'Day 1','summary':'x','state_deltas':[]})+'\n')
        self.assertTrue(storyworld.validate(self.p)[0])
    def test_schema_actually_used(self):
        pj=json.loads((self.p/'project.json').read_text()); del pj['canon_version']; (self.p/'project.json').write_text(json.dumps(pj)); self.assertTrue(storyworld.validate(self.p)[0])
    def test_knowledge_leak_rejected_in_sim(self):
        self.seed(); r,_=simulate.run_sim(self.p,json.loads((self.p/'run_plan.json').read_text())); self.assertEqual(len(r['events']),1); self.assertEqual(r['rejected'][0]['reasons'][0]['code'],'KNOWLEDGE_MISSING')
    def test_sim_metrics_derived(self):
        self.seed(); r,_=simulate.run_sim(self.p,json.loads((self.p/'run_plan.json').read_text())); self.assertGreater(r['metrics']['tension'],0); self.assertGreater(r['metrics']['agency'],0)
    def test_context_alias_and_time_cutoff(self):
        self.seed(); r=context_compile.compile_context(self.p,'mira',20,['停电'],6); self.assertEqual(r['relevant_memories'][0]['id'],'mem_mira_01')
        with (self.p/'state'/'canon_events.jsonl').open('a',encoding='utf-8') as f: f.write(json.dumps({'id':'future','status':'CANON','story_time':99,'sequence':1,'summary':'future','state_deltas':[]})+'\n')
        r=context_compile.compile_context(self.p,'mira',20,[],6); self.assertNotIn('future',[x['id'] for x in r['recent_events']])
    def test_stale_branch_blocked(self):
        b=self.p/'branches'/'b.json'; b.write_text(json.dumps({'id':'b','status':'ACCEPTED','base_canon_version':999,'events':[]}));
        with self.assertRaises(SystemExit): storyworld.commit(self.p,b)
    def test_duplicate_event_blocked(self):
        self.seed(); ev=json.loads((self.p/'state'/'canon_events.jsonl').read_text().splitlines()[0]); b=self.p/'branches'/'b.json'; b.write_text(json.dumps({'id':'b','status':'ACCEPTED','base_canon_version':1,'events':[ev]}));
        with self.assertRaises(SystemExit): storyworld.commit(self.p,b)
    def test_valid_commit_increments_version(self):
        self.seed(); ev={'id':'ev_new','status':'CANDIDATE','story_time':21,'sequence':1,'summary':'x','state_deltas':[{'kind':'fact_set','target':'x','value':1}]}; b=self.p/'branches'/'b.json'; b.write_text(json.dumps({'id':'b','status':'ACCEPTED','base_canon_version':1,'events':[ev]})); storyworld.commit(self.p,b); self.assertEqual(json.loads((self.p/'project.json').read_text())['canon_version'],2)
    def test_budget_really_decrements(self):
        self.seed(); r,_=simulate.run_sim(self.p,json.loads((self.p/'run_plan.json').read_text())); c=json.loads((self.p/'monitors'/'default.json').read_text()); ledger=self.p/'interventions'/'ledger.jsonl'; a=steering.suggest(r,c,ledger)
        from common import append_jsonl
        for x in a['suggestions']: append_jsonl(ledger,x)
        b=steering.suggest(r,c,ledger); self.assertGreaterEqual(b['budget_used'],sum(x['cost'] for x in a['suggestions']))
    def test_audit_ten_gates_and_budget(self):
        self.seed(); r=audit.audit(self.p); self.assertEqual(len(r['gates']),10)
        (self.p/'interventions'/'ledger.jsonl').write_text(json.dumps({'id':'i','monitor_id':'default','run_id':'r','cost':99,'status':'APPLIED'})+'\n'); r=audit.audit(self.p); self.assertFalse(r['ok']); self.assertTrue(any(x['kind']=='budget_exceeded' for x in r['findings']))
    def test_knowledge_query(self):
        self.seed(); rows=knowledge.read_jsonl(self.p/'state'/'knowledge.jsonl'); self.assertEqual(knowledge.missing(rows,'mira',20,['storm_warning']),[])
    def test_ingest_logic_stages_only(self):
        f=Path(self.t.name)/'n.md'; f.write_text('第一段\n\n第二段',encoding='utf-8')
        # CLI smoke because ingest exposes only main
        cp=subprocess.run([sys.executable,str(ROOT/'tools'/'ingest.py'),str(self.p),str(f)],capture_output=True,text=True,check=True)
        self.assertEqual(json.loads(cp.stdout)['status'],'REVIEW_REQUIRED'); self.assertEqual((self.p/'state'/'canon_events.jsonl').read_text(),'')
    def test_render_functions(self):
        self.seed(); r,_=simulate.run_sim(self.p,json.loads((self.p/'run_plan.json').read_text())); self.assertIn('米拉',render.novel(r)); self.assertIn('MIRA',render.fountain(r))
    def test_snapshot_rollback(self):
        storyworld.snapshot(self.p,'s'); pj=json.loads((self.p/'project.json').read_text()); pj['title']='bad'; (self.p/'project.json').write_text(json.dumps(pj)); storyworld.rollback(self.p,'s'); self.assertEqual(json.loads((self.p/'project.json').read_text())['title'],'T')
    def test_exclusive_resource_conflict(self):
        self.seed(); plan=json.loads((self.p/'run_plan.json').read_text()); a=plan['intents'][0]; a['exclusive_resources']=['only_hammer']; b=json.loads(json.dumps(a)); b['id']='ask2'; b['event_id']='ev2'; plan['intents']=[a,b]; r,_=simulate.run_sim(self.p,plan); self.assertEqual(len(r['events']),1); self.assertEqual(r['rejected'][0]['reasons'][0]['code'],'RESOURCE_CONFLICT')
    def test_cli_smoke(self):
        cp=subprocess.run([sys.executable,str(ROOT/'tools'/'storyworld.py'),'validate',str(self.p)],capture_output=True,text=True,check=True); self.assertIn('"ok": true',cp.stdout.lower())

if __name__=='__main__': unittest.main()
