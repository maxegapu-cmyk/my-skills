#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from common import load_json,read_jsonl,schema_validate
from knowledge import active_knowledge
from storyworld import validate as validate_project
GATES=['schema','time','identity_refs','causality','knowledge','space','branch_version','budget','promises','render_consistency']
def add(findings,gate,severity,kind,**kw): findings.append({'gate':gate,'severity':severity,'kind':kind,**kw})
def audit(project,branch=None):
    root=Path(project); findings=[]; pj=load_json(root/'project.json'); events=read_jsonl(root/'state'/'canon_events.jsonl'); knowledge=read_jsonl(root/'state'/'knowledge.jsonl'); promises=read_jsonl(root/'state'/'promises.jsonl')
    e,_=validate_project(root)
    for x in e: add(findings,'schema','error','schema_error',detail=x)
    # time
    last=None
    for ev in sorted(events,key=lambda x:(float(x.get('story_time',0)),int(x.get('sequence',0)))):
        if not isinstance(ev.get('story_time'),(int,float)): add(findings,'time','error','non_numeric_time',event=ev.get('id'))
        if last is not None and float(ev.get('story_time',0))<last: add(findings,'time','error','time_regression',event=ev.get('id'))
        last=float(ev.get('story_time',0))
    # identity refs
    ids=[x.get('id') for x in events]
    if len(ids)!=len(set(ids)): add(findings,'identity_refs','error','duplicate_event_id')
    chars={p.stem for p in (root/'characters').glob('*.json')}
    for ev in events:
        for x in ev.get('participants',[]):
            if chars and x not in chars: add(findings,'identity_refs','warning','unknown_participant',event=ev.get('id'),detail=x)
    # causality
    idset=set(ids)
    for ev in events:
        for c in ev.get('causes',[]):
            if isinstance(c,str) and c.startswith('ev_') and c not in idset: add(findings,'causality','warning','dangling_cause',event=ev.get('id'),detail=c)
            if c in idset:
                ce=next(x for x in events if x.get('id')==c)
                if float(ce.get('story_time',0))>float(ev.get('story_time',0)): add(findings,'causality','error','future_cause',event=ev.get('id'),detail=c)
    # knowledge leakage based on optional event required_knowledge
    for ev in events:
        actor=ev.get('actor_id'); req=ev.get('required_knowledge',[])
        if actor and req:
            have=active_knowledge(knowledge,actor,float(ev['story_time']))
            miss=[x for x in req if x not in have]
            if miss: add(findings,'knowledge','error','knowledge_leak',event=ev.get('id'),detail=miss)
    # space: moves must name place; colocation proof fields if present
    places=load_json(root/'world'/'places.json') if (root/'world'/'places.json').exists() else {'places':[]}; pids={p.get('id') for p in places.get('places',[])}
    for ev in events:
        for d in ev.get('state_deltas',[]):
            if d.get('kind')=='move':
                pid=(d.get('value') or {}).get('place_id')
                if pids and pid not in pids: add(findings,'space','error','unknown_place',event=ev.get('id'),detail=pid)
    # branch version
    if branch:
        b=load_json(branch)
        if b.get('base_canon_version')!=pj.get('canon_version'): add(findings,'branch_version','error','stale_branch',detail={'base':b.get('base_canon_version'),'current':pj.get('canon_version')})
    # budget
    ledger=read_jsonl(root/'interventions'/'ledger.jsonl')
    monitors={p.stem:load_json(p) for p in (root/'monitors').glob('*.json')}
    totals={}
    for x in ledger:
        if x.get('status') not in ('PROPOSED','APPLIED'): continue
        key=(x.get('monitor_id'),x.get('run_id')); totals[key]=totals.get(key,0)+float(x.get('cost',0))
    for (mid,rid),cost in totals.items():
        cap=float((monitors.get(mid) or {}).get('intervention_budget',0))
        if cost>cap: add(findings,'budget','error','budget_exceeded',detail={'monitor':mid,'run':rid,'used':cost,'cap':cap})
    # promises
    for p in promises:
        if p.get('status')=='PAID' and p.get('payoff_event_id') and p['payoff_event_id'] not in idset: add(findings,'promises','error','missing_payoff_event',detail=p.get('id'))
        if p.get('status') in ('OPEN','ADVANCED') and float(p.get('progress',0))>=1: add(findings,'promises','warning','progress_status_mismatch',detail=p.get('id'))
    # render consistency: no render fact claims outside optional declared_facts
    facts=load_json(root/'state'/'facts.json') if (root/'state'/'facts.json').exists() else {}
    for ev in events:
        for fid in (ev.get('rendering') or {}).get('declared_facts',[]):
            if fid not in facts and not any(d.get('kind')=='fact_set' and d.get('target')==fid for d in ev.get('state_deltas',[])): add(findings,'render_consistency','warning','render_undeclared_fact',event=ev.get('id'),detail=fid)
    covered={f['gate'] for f in findings}; summary={g:{'findings':sum(1 for f in findings if f['gate']==g),'status':'FAIL' if any(f['gate']==g and f['severity']=='error' for f in findings) else 'PASS'} for g in GATES}
    return {'ok':not any(f['severity']=='error' for f in findings),'gates':summary,'findings':findings}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('project'); ap.add_argument('--branch'); ap.add_argument('--json',action='store_true'); a=ap.parse_args(); r=audit(a.project,a.branch); print(json.dumps(r,ensure_ascii=False,indent=2)); raise SystemExit(1 if not r['ok'] else 0)
if __name__=='__main__': main()
