#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,shutil,re,hashlib
from pathlib import Path
from common import dump_json,now
# This importer deliberately stages candidates instead of silently inventing canon.
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('project'); ap.add_argument('source'); ap.add_argument('--kind',default='source'); a=ap.parse_args(); root=Path(a.project); src=Path(a.source)
    if not src.exists(): raise SystemExit('source not found')
    raw=src.read_text(encoding='utf-8',errors='replace'); digest=hashlib.sha256(raw.encode()).hexdigest(); dst=root/'sources'/src.name; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
    chunks=[x.strip() for x in re.split(r'\n\s*\n',raw) if x.strip()]
    packet={'id':f'import_{digest[:12]}','kind':a.kind,'source_file':src.name,'sha256':digest,'created_at':now(),'status':'REVIEW_REQUIRED','chunks':[{'id':f'chunk_{i+1:04d}','text':x,'candidate_type':'UNCLASSIFIED'} for i,x in enumerate(chunks)]}
    out=root/'imports'/f'{packet["id"]}.json'; dump_json(out,packet); print(json.dumps({'ok':True,'import':str(out),'chunks':len(chunks),'status':'REVIEW_REQUIRED'},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
