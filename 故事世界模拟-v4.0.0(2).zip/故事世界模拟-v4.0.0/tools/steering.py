#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from common import load_json,read_jsonl,append_jsonl
from monitor import evaluate
FORBIDDEN={'force_choice','rewrite_personality','retcon_canon','knowledge_injection','teleport_without_rule'}
MAP={
 ('METRIC_BELOW_MIN','tension'):('timing',1,'Advance an already established deadline or consequence window.','existing deadline/consequence'),
 ('METRIC_BELOW_MIN','agency'):('opportunity',1,'Expose an existing meaningful option the protagonist may accept or reject.','existing relationship/resource'),
 ('METRIC_BELOW_MIN','payoff_progress'):('information',1,'Make an already seeded clue or promise reachable earlier.','existing evidence/witness'),
 ('METRIC_ABOVE_MAX','reveal_rate'):('timing',1,'Delay one noncritical reveal while preserving its setup.','existing reveal path'),
}
def used_budget(ledger,monitor_id,run_id):
    return sum(float(x.get('cost',0)) for x in read_jsonl(ledger) if x.get('monitor_id')==monitor_id and x.get('run_id')==run_id and x.get('status') in ('PROPOSED','APPLIED'))
def suggest(run,contract,ledger=None):
    ev=evaluate(run,contract); total=float(contract.get('intervention_budget',0)); used=used_budget(ledger,contract.get('id'),run.get('id')) if ledger else 0.; remain=max(0.,total-used); out=[]
    banned=set(contract.get('forbidden_interventions',[]))|FORBIDDEN
    for v in ev['violations']:
        spec=MAP.get((v.get('code'),v.get('metric')))
        if not spec: continue
        fam,cost,mechanism,channel=spec
        if cost>remain: continue
        item={'id':f'int_{run.get("id","run")}_{len(out)+1}','run_id':run.get('id'),'monitor_id':contract.get('id'),'family':fam,'cost':cost,'target_metric':v.get('metric'),'mechanism':mechanism,'delivery_channel':channel,'status':'PROPOSED'}
        out.append(item); remain-=cost
    return {'baseline':ev,'budget_total':total,'budget_used':used,'budget_remaining_after_suggestions':remain,'forbidden':sorted(banned),'suggestions':out}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('run'); ap.add_argument('contract'); ap.add_argument('--ledger'); ap.add_argument('--record',action='store_true'); a=ap.parse_args(); r=load_json(a.run); c=load_json(a.contract); out=suggest(r,c,a.ledger)
    if a.record:
        if not a.ledger: raise SystemExit('--record requires --ledger')
        for x in out['suggestions']: append_jsonl(a.ledger,x)
    print(json.dumps(out,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
