from __future__ import annotations
import json, hashlib, shutil
from pathlib import Path
from datetime import datetime, timezone
try:
    import jsonschema
except Exception:
    jsonschema=None

ROOT=Path(__file__).resolve().parents[1]
SCHEMAS=ROOT/'schemas'

def load_json(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def dump_json(path,obj):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def read_jsonl(path):
    p=Path(path)
    if not p.exists(): return []
    out=[]
    for n,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
        if line.strip():
            try: out.append(json.loads(line))
            except Exception as e: raise ValueError(f'{p}:{n}: {e}')
    return out
def write_jsonl(path,items):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in items),encoding='utf-8')
def append_jsonl(path,obj):
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('a',encoding='utf-8') as f: f.write(json.dumps(obj,ensure_ascii=False)+'\n')
def schema_validate(obj,name):
    if jsonschema is None: return [f'jsonschema dependency unavailable; cannot validate {name}']
    schema=load_json(SCHEMAS/name)
    v=jsonschema.Draft202012Validator(schema)
    return [f'{"/".join(map(str,e.path)) or "$"}: {e.message}' for e in sorted(v.iter_errors(obj),key=lambda x:list(x.path))]
def sha_tree(root,exclude=('snapshots',)):
    root=Path(root); h=hashlib.sha256()
    for p in sorted(x for x in root.rglob('*') if x.is_file() and not any(q in x.parts for q in exclude)):
        h.update(str(p.relative_to(root)).encode()); h.update(b'\0'); h.update(p.read_bytes()); h.update(b'\0')
    return h.hexdigest()
def now(): return datetime.now(timezone.utc).isoformat()
def deep_merge(base,patch):
    if not isinstance(base,dict) or not isinstance(patch,dict): return patch
    out=dict(base)
    for k,v in patch.items(): out[k]=deep_merge(out.get(k),v) if k in out else v
    return out
