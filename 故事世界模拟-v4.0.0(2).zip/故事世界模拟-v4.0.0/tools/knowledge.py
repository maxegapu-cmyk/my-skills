#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from common import read_jsonl, schema_validate

def active_knowledge(records,subject,t):
    out={}
    for k in records:
        if k.get('subject_id')!=subject: continue
        if float(k.get('learned_at',10**30))>t: continue
        fa=k.get('forgotten_at')
        if fa is not None and float(fa)<=t: continue
        if k.get('status') in ('KNOWN','BELIEVED','DOUBTED'): out[k['fact_id']]=k
    return out

def missing(records,subject,t,fact_ids):
    have=active_knowledge(records,subject,t)
    return [f for f in fact_ids if f not in have]

def validate_ledger(path):
    rows=read_jsonl(path); errs=[]; ids=set()
    for i,r in enumerate(rows,1):
        for e in schema_validate(r,'knowledge.schema.json'): errs.append(f'line {i}: {e}')
        if r.get('id') in ids: errs.append(f'line {i}: duplicate id {r.get("id")}')
        ids.add(r.get('id'))
    return errs

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    x=sub.add_parser('show'); x.add_argument('ledger'); x.add_argument('subject'); x.add_argument('--at',type=float,required=True)
    x=sub.add_parser('check'); x.add_argument('ledger'); x.add_argument('subject'); x.add_argument('--at',type=float,required=True); x.add_argument('--fact',action='append',default=[])
    x=sub.add_parser('validate'); x.add_argument('ledger')
    a=ap.parse_args()
    if a.cmd=='validate':
        e=validate_ledger(a.ledger); print(json.dumps({'ok':not e,'errors':e},ensure_ascii=False,indent=2)); raise SystemExit(1 if e else 0)
    rows=read_jsonl(a.ledger)
    if a.cmd=='show': print(json.dumps(active_knowledge(rows,a.subject,a.at),ensure_ascii=False,indent=2))
    else:
        m=missing(rows,a.subject,a.at,a.fact); print(json.dumps({'ok':not m,'missing':m},ensure_ascii=False,indent=2)); raise SystemExit(1 if m else 0)
if __name__=='__main__': main()
