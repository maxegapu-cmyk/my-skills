# Public references and lessons used in v3

This file records public projects consulted for generic engineering ideas. No private system is documented here.

## Google DeepMind — Concordia
https://github.com/google-deepmind/concordia

Useful public idea:
- generative agents act as entities;
- a Game Master/environment resolves natural-language intentions against physical/social/digital context;
- modular components separate memory/reasoning/environment behavior.

Applied independently here as separation between actor intention and world resolution/control.

## Mesa
https://github.com/mesa/mesa

Useful public idea:
- agent-based models combine multiple actors, schedules, spatial environments and analysis;
- macro behavior can emerge from many local actor rules.

Applied independently here as multi-scale agent/world stepping and LOD simulation.

## Microsoft TinyTroupe
https://github.com/microsoft/TinyTroupe

Useful public idea:
- detailed persona-based simulated people;
- environment stimuli, mental state, episodic/semantic memory and action correction;
- simulation as an analytical object rather than a chat transcript.

Applied independently to strengthen character-local state and simulation discipline.

## Graphiti
https://github.com/getzep/graphiti

Useful public idea:
- temporal knowledge graphs preserve changing facts, provenance and historical queries.

Applied independently to temporal validity and time-slice reconstruction.

## pyeventsourcing/eventsourcing
https://github.com/pyeventsourcing/eventsourcing

Useful public idea:
- application state can be reconstructed from a sequence of events.

Applied independently to accepted-world replay, branching and auditability.

## AI Town
https://github.com/a16z-infra/ai-town

Useful public idea:
- shared global state, transactions and a persistent simulation engine for many AI characters.

Applied independently to world persistence and branch isolation.

## MyGameMaster
https://github.com/tibs245/mygamemaster

Useful public idea:
- public living-world design with monotone story time, spatial graph, actor trajectories, LOD ticks and causal propagation;
- model intentions are checked by deterministic state/rule mechanisms.

This strongly supports using a 4D story-time model plus rule-bound reconciliation. No source code or project-specific mechanics are copied.

## SimPy (public mirrors/documentation)
https://gitlab.com/team-simpy/simpy

Useful public idea:
- discrete-event simulation advances a monotone clock through scheduled events;
- deterministic ordering is important when events share a timestamp.

Applied independently to event-queue and replay semantics.
