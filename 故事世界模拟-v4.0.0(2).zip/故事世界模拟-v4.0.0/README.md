# 故事世界模拟 4.0

**故事世界模拟（Story World Simulator）v4.0.0** 是一个面向中文长篇、剧本、系列故事和复杂原创世界的本地工作台。它把“故事”拆成可回放的正史、角色有限知识、时空状态、意图、规则、后果、监控指标与渲染层，并把最容易失真的部分交给确定性代码检查。

核心原则：

- **世界先于文本**：正文和剧本都是同一条事件路径的不同渲染结果。
- **角色只能凭自己当时知道的东西行动**：知识是带来源、获得时间、可信度的账本，不再只靠提示词提醒。
- **AI 负责语义，人类与代码负责边界**：AI 可以提出角色意图、解释和语言；代码检查时序、知识、版本、预算、重复 ID、规则前置条件和提交安全。
- **未来可分支，正史不可偷改**：任何模拟结果默认都是候选分支；只有显式 `ACCEPTED`、基于当前 `canon_version` 且通过审计的分支才可提交。
- **监控指标尽量由事件证据推导**：不再要求人工随手填写一组看起来漂亮的分数。

## 4.0 的真正变化

1. 统一故事时间为数值 `story_time`，旧式描述放在 `time_label`，避免字符串/数字混用。
2. 所有核心 JSON / JSONL 都接入 JSON Schema 校验。
3. 新增知识账本 `state/knowledge.jsonl` 与泄露检查器。
4. 新增确定性单步模拟器：AI/用户只提交“意图”，引擎检查知识、位置、前置条件、资源与规则，再产生候选事件和状态变化。
5. 新增事件遥测与自动指标：张力、主角能动性、伏笔推进、揭秘密度、因果密度。
6. 调控预算真实扣减，同一轮不会无限建议；干预是结构化对象，不靠匹配报错句子。
7. 正史提交加入 `canon_version` 乐观锁、重复 ID、分支来源和审计门禁。
8. 审计扩为 10 道门：Schema、时间、ID/引用、因果、知识、空间、分支版本、预算、承诺、渲染一致性。
9. 上下文编译支持时间截断、中文别名词典和知识过滤。
10. 新增资料导入草稿区、章节账本、文风圣经、人物口吻、长篇节奏合同、小说 Markdown / Fountain 渲染入口。

## 快速开始

```bash
python tools/storyworld.py init my_story --title "我的故事"
python tools/storyworld.py validate my_story
python tools/ingest.py my_story notes.md --kind source
python tools/simulate.py my_story examples/harbor/run_plan.json --out my_story/runs/run_001.json
python tools/monitor.py my_story/runs/run_001.json my_story/monitors/default.json
python tools/steering.py my_story/runs/run_001.json my_story/monitors/default.json --ledger my_story/interventions/ledger.jsonl
python tools/audit.py my_story --json
python -m unittest discover -s tests -v
```

## 文件分层

- `state/canon_events.jsonl`：唯一正史事件流。
- `state/facts.json`：当前可机器判定的世界事实。
- `state/knowledge.jsonl`：谁在什么时候、通过什么来源知道什么。
- `world/places.json` / `world/spacetime.json` / `world/rules.json`：空间、轨迹与世界规则。
- `characters/` / `memories/` / `relationships.json`：角色与关系。
- `branches/`：所有未提交未来。
- `runs/`：模拟运行记录。
- `monitors/`：目标区间与干预预算。
- `interventions/ledger.jsonl`：真实预算账本。
- `chapters/ledger.jsonl`：章节/集数账本。
- `style/style_bible.json`：文风圣经。
- `style/voices/`：人物口吻约束。
- `sources/`：导入的原始资料；`imports/`：待人工确认的结构化候选。

详见 `PLAYBOOK.md`、`ARCHITECTURE.md` 与 `docs/V4_ENGINE.md`。
