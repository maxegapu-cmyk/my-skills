# UX Rules

## Default mental model

The canvas is a workspace, not a poster.

A user should be able to answer three questions quickly:

1. What are we trying to accomplish?
2. What are the major functional areas?
3. What blocks or depends on what?

## Navigation

Minimum navigation:

- pan on blank space
- zoom around pointer
- fit content
- reset view
- search and focus

Recommended:

- minimap for huge canvases
- breadcrumb / cluster focus mode
- type filters
- “show only dependency path” mode

## Selection

Selected node should visibly differ from hover.

Selected state may reveal:

- full summary
- status / priority
- inputs and outputs
- acceptance
- assumptions
- dependency list
- warnings

## Search

Search should consider:

- title
- aliases
- summary
- tags

Selecting a result should center or fit the node, not merely highlight it off-screen.

## Filters

Do not create a checkbox for every metadata field. Default useful filters:

- node type
- module
- priority
- status
- warnings / unresolved

## Semantic edge visibility

When edge density grows, allow hiding secondary relations.

Example priority:

1. `requires`
2. `next`
3. data read/write
4. measurement / serves
5. contextual relations

## Layout preservation

If a user drags nodes into a meaningful arrangement, do not overwrite that layout on next load.

Auto-layout should be explicit or limited to new/unplaced nodes.
