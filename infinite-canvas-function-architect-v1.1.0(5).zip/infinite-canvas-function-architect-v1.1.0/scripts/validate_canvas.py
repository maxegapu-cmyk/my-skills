#!/usr/bin/env python3
"""Dependency-free structural validator for Infinite Canvas Function Architect.

Design goals:
- never traceback on malformed user JSON
- reject non-finite numbers and duplicate JSON keys
- validate large graphs without recursive DFS
- distinguish hard structural errors from semantic warnings
"""
from __future__ import annotations

import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

ALLOWED_NODE_TYPES = {
    "goal", "actor", "module", "feature", "flow", "data", "integration",
    "constraint", "decision", "risk", "metric", "note"
}
ALLOWED_EDGE_TYPES = {
    "contains", "requires", "triggers", "reads", "writes", "produces",
    "blocks", "conflicts", "alternative_to", "measured_by", "serves",
    "derives_from", "next"
}
ID_RE = re.compile(r"^[A-Za-z0-9_.-]+$")
MAX_REPORTED_CYCLES = 100


class DuplicateKeyError(ValueError):
    pass


def _object_no_duplicate_keys(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise DuplicateKeyError(f"duplicate JSON object key: {key!r}")
        out[key] = value
    return out


def _reject_constant(value):
    raise ValueError(f"non-finite JSON number is not allowed: {value}")


def load(path: Path):
    text = path.read_text(encoding="utf-8")
    return json.loads(
        text,
        object_pairs_hook=_object_no_duplicate_keys,
        parse_constant=_reject_constant,
    )


def _is_finite_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _valid_id(value: Any) -> bool:
    return isinstance(value, str) and bool(value) and bool(ID_RE.fullmatch(value))


def requires_cycles(node_ids, edges):
    """Return representative requires-cycles without recursive DFS.

    This is intentionally iterative so a long dependency chain cannot hit Python's
    recursion limit. Invalid edges are ignored here; the main validator reports them.
    """
    graph = {nid: [] for nid in node_ids}
    for e in edges:
        if not isinstance(e, dict) or e.get("type") != "requires":
            continue
        s, t = e.get("source"), e.get("target")
        if s in graph and t in graph:
            graph[s].append(t)

    state = {nid: 0 for nid in graph}  # 0 unseen, 1 active, 2 done
    cycles = []
    seen_cycle_keys = set()

    for start in graph:
        if state[start] != 0:
            continue
        state[start] = 1
        path = [start]
        index_in_path = {start: 0}
        stack = [(start, 0)]

        while stack:
            u, next_index = stack[-1]
            neighbors = graph[u]
            if next_index >= len(neighbors):
                state[u] = 2
                stack.pop()
                index_in_path.pop(u, None)
                if path and path[-1] == u:
                    path.pop()
                continue

            v = neighbors[next_index]
            stack[-1] = (u, next_index + 1)
            if state[v] == 0:
                state[v] = 1
                index_in_path[v] = len(path)
                path.append(v)
                stack.append((v, 0))
            elif state[v] == 1 and v in index_in_path:
                cycle = path[index_in_path[v]:] + [v]
                core = cycle[:-1]
                if core:
                    rotations = [tuple(core[i:] + core[:i]) for i in range(len(core))]
                    key = min(rotations)
                    if key not in seen_cycle_keys:
                        seen_cycle_keys.add(key)
                        cycles.append(cycle)
                        if len(cycles) >= MAX_REPORTED_CYCLES:
                            return cycles
    return cycles


def validate(data):
    errors = []
    warnings = []

    if not isinstance(data, dict):
        return ["root must be a JSON object"], warnings

    required_top = ["schema_version", "title", "nodes", "edges", "groups", "camera", "meta"]
    for key in required_top:
        if key not in data:
            errors.append(f"missing top-level field: {key}")

    if data.get("schema_version") != "1.0":
        errors.append("schema_version must be '1.0'")
    if not isinstance(data.get("title"), str) or not data.get("title", "").strip():
        errors.append("title must be a non-empty string")

    nodes_raw = data.get("nodes", [])
    edges_raw = data.get("edges", [])
    groups_raw = data.get("groups", [])
    if not isinstance(nodes_raw, list):
        errors.append("nodes must be an array")
        nodes = []
    else:
        nodes = nodes_raw
    if not isinstance(edges_raw, list):
        errors.append("edges must be an array")
        edges = []
    else:
        edges = edges_raw
    if not isinstance(groups_raw, list):
        errors.append("groups must be an array")
        groups = []
    else:
        groups = groups_raw

    camera = data.get("camera")
    if not isinstance(camera, dict):
        errors.append("camera must be an object")
    else:
        for key in ("x", "y", "scale"):
            if key not in camera:
                errors.append(f"camera missing {key}")
            elif not _is_finite_number(camera[key]):
                errors.append(f"camera.{key} must be a finite number")
        if _is_finite_number(camera.get("scale")) and camera["scale"] <= 0:
            errors.append("camera.scale must be > 0")

    meta = data.get("meta")
    if not isinstance(meta, dict):
        errors.append("meta must be an object")
    else:
        for key in ("created_at", "updated_at"):
            if key not in meta:
                errors.append(f"meta missing {key}")
            elif not isinstance(meta[key], str):
                errors.append(f"meta.{key} must be a string")

    node_by_id = {}
    feature_title_keys = defaultdict(list)
    for i, node in enumerate(nodes):
        if not isinstance(node, dict):
            errors.append(f"node[{i}] must be an object")
            continue
        nid = node.get("id")
        if not _valid_id(nid):
            errors.append(f"node[{i}] id must match {ID_RE.pattern}")
            continue
        if nid in node_by_id:
            errors.append(f"duplicate node id: {nid}")
            continue
        node_by_id[nid] = node

        ntype = node.get("type")
        if ntype not in ALLOWED_NODE_TYPES:
            errors.append(f"node {nid}: invalid type {ntype!r}")
        title = node.get("title")
        if not isinstance(title, str) or not title.strip():
            errors.append(f"node {nid}: title must be a non-empty string")
        if "summary" not in node or not isinstance(node.get("summary"), str):
            errors.append(f"node {nid}: summary must be a string")

        pos = node.get("position")
        if not isinstance(pos, dict):
            errors.append(f"node {nid}: position must be an object")
        else:
            for key in ("x", "y"):
                if key not in pos or not _is_finite_number(pos.get(key)):
                    errors.append(f"node {nid}: position.{key} must be a finite number")

        size = node.get("size")
        if size is not None:
            if not isinstance(size, dict):
                errors.append(f"node {nid}: size must be an object")
            else:
                for key, minimum in (("w", 80), ("h", 40)):
                    if key in size:
                        if not _is_finite_number(size[key]) or size[key] < minimum:
                            errors.append(f"node {nid}: size.{key} must be a finite number >= {minimum}")

        if ntype == "feature" and isinstance(title, str):
            normalized = " ".join(title.casefold().split())
            feature_title_keys[(node.get("module_id"), normalized)].append(nid)

    edge_ids = set()
    semantic_edges = set()
    valid_edges = []
    degree = defaultdict(int)
    neighbors = defaultdict(set)
    for i, edge in enumerate(edges):
        if not isinstance(edge, dict):
            errors.append(f"edge[{i}] must be an object")
            continue
        eid = edge.get("id")
        if not _valid_id(eid):
            errors.append(f"edge[{i}] id must match {ID_RE.pattern}")
            eid_label = f"edge[{i}]"
        else:
            eid_label = f"edge {eid}"
            if eid in edge_ids:
                errors.append(f"duplicate edge id: {eid}")
            edge_ids.add(eid)

        etype, source, target = edge.get("type"), edge.get("source"), edge.get("target")
        if etype not in ALLOWED_EDGE_TYPES:
            errors.append(f"{eid_label}: invalid type {etype!r}")
        if source not in node_by_id:
            errors.append(f"{eid_label}: missing source node {source!r}")
        if target not in node_by_id:
            errors.append(f"{eid_label}: missing target node {target!r}")
        if source == target and source is not None:
            warnings.append(f"{eid_label}: self-edge {source} -> {target}")

        key = (etype, source, target)
        if key in semantic_edges:
            warnings.append(f"duplicate semantic edge: {etype} {source} -> {target}")
        semantic_edges.add(key)

        if source in node_by_id and target in node_by_id:
            valid_edges.append(edge)
            degree[source] += 1
            degree[target] += 1
            neighbors[source].add(target)
            neighbors[target].add(source)

    valid_module_ids = {nid for nid, n in node_by_id.items() if n.get("type") == "module"}
    for nid, node in node_by_id.items():
        if node.get("type") != "feature":
            continue
        module_id = node.get("module_id")
        if not module_id:
            warnings.append(f"feature {nid}: no module_id")
        elif module_id not in node_by_id:
            errors.append(f"feature {nid}: module_id {module_id!r} does not exist")
        elif module_id not in valid_module_ids:
            warnings.append(f"feature {nid}: module_id {module_id!r} does not point to a module")

        acceptance = node.get("acceptance")
        if acceptance is None or acceptance == []:
            warnings.append(f"feature {nid}: no acceptance criteria")
        elif not isinstance(acceptance, list) or not all(isinstance(x, str) for x in acceptance):
            errors.append(f"feature {nid}: acceptance must be an array of strings")

        actors = node.get("actors")
        if actors is not None and (not isinstance(actors, list) or not all(isinstance(x, str) for x in actors)):
            errors.append(f"feature {nid}: actors must be an array of strings")

        owned = module_id in valid_module_ids
        meaningful_neighbor = any(
            node_by_id[other].get("type") in {"actor", "goal", "module", "flow", "data", "integration"}
            for other in neighbors.get(nid, ())
        )
        if not owned and not meaningful_neighbor:
            warnings.append(f"orphan feature candidate: {nid}")

    for (_, normalized), ids in feature_title_keys.items():
        if normalized and len(ids) > 1:
            warnings.append("possible duplicate feature title: " + ", ".join(ids))

    group_ids = set()
    for i, group in enumerate(groups):
        if not isinstance(group, dict):
            errors.append(f"group[{i}] must be an object")
            continue
        gid = group.get("id")
        if not _valid_id(gid):
            errors.append(f"group[{i}] id must match {ID_RE.pattern}")
            continue
        if gid in group_ids:
            errors.append(f"duplicate group id: {gid}")
        group_ids.add(gid)
        if not isinstance(group.get("title"), str) or not group.get("title", "").strip():
            errors.append(f"group {gid}: title must be a non-empty string")
        node_ids = group.get("node_ids")
        if not isinstance(node_ids, list):
            errors.append(f"group {gid}: node_ids must be an array")
            continue
        seen = set()
        for member in node_ids:
            if not isinstance(member, str):
                errors.append(f"group {gid}: node id must be a string")
                continue
            if member in seen:
                warnings.append(f"group {gid}: duplicate node reference {member!r}")
            seen.add(member)
            if member not in node_by_id:
                errors.append(f"group {gid}: missing node {member!r}")

    for nid, node in node_by_id.items():
        if node.get("type") not in {"note", "module", "feature"} and degree[nid] == 0:
            warnings.append(f"orphan node: {nid} ({node.get('type')})")

    cycles = requires_cycles(node_by_id.keys(), valid_edges)
    for cycle in cycles:
        warnings.append("requires cycle: " + " -> ".join(cycle))
    if len(cycles) >= MAX_REPORTED_CYCLES:
        warnings.append(f"requires cycle reporting capped at {MAX_REPORTED_CYCLES}")

    for nid, node in node_by_id.items():
        if node.get("type") != "goal":
            continue
        covered = any(
            edge.get("type") == "serves"
            and edge.get("target") == nid
            and node_by_id.get(edge.get("source"), {}).get("type") in {"feature", "flow", "module"}
            for edge in valid_edges
        )
        if not covered:
            warnings.append(f"goal gap candidate: {nid} has no feature/flow/module serving it")

    module_features = defaultdict(list)
    for nid, node in node_by_id.items():
        if node.get("type") == "feature" and node.get("module_id") in valid_module_ids:
            module_features[node["module_id"]].append(nid)
    for mid, features in module_features.items():
        if len(features) > 20:
            warnings.append(f"large module candidate: {mid} owns {len(features)} features; inspect for split/collapse")

    return errors, warnings


def main(argv):
    args = list(argv[1:])
    strict = False
    if "--strict" in args:
        strict = True
        args.remove("--strict")
    if len(args) != 1:
        print("usage: validate_canvas.py [--strict] <canvas-model.json>")
        return 2

    path = Path(args[0])
    try:
        data = load(path)
    except (OSError, UnicodeError, json.JSONDecodeError, ValueError, RecursionError) as exc:
        print(f"ERROR: could not read strict JSON: {exc}")
        return 2

    try:
        errors, warnings = validate(data)
    except Exception as exc:  # last-resort guard: malformed data must not dump a traceback
        print(f"ERROR: validator internal failure: {type(exc).__name__}: {exc}")
        return 2

    for item in errors:
        print("ERROR:", item)
    for item in warnings:
        print("WARN :", item)

    if errors:
        print(f"FAIL: {len(errors)} error(s), {len(warnings)} warning(s)")
        return 1
    if strict and warnings:
        print(f"FAIL-STRICT: 0 errors, {len(warnings)} warning(s)")
        return 1
    print(f"PASS: 0 errors, {len(warnings)} warning(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
