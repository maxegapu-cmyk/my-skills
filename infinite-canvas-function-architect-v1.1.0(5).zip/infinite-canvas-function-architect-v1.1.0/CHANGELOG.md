# Changelog

## 1.1.0 — 2026-10-02

Release-hardening update driven by destructive and real-browser testing.

- Fixed validator tracebacks on non-object roots, wrong collection types, malformed nodes, and missing feature IDs.
- Replaced recursive `requires` cycle traversal with an iterative implementation; long chains no longer hit Python recursion limits.
- Added strict JSON loading that rejects duplicate object keys and non-finite values.
- Added stronger camera, node, edge, group, feature and metadata validation.
- Added optional `--strict` gate so warnings can fail CI/release checks.
- Removed an O(features × edges) validation path; a 10,000-feature/9,999-edge chain validates in under one second in the release environment.
- Fixed a real browser drag bug caused by calling `setPointerCapture()` on a DOM node that had just been replaced.
- Dragging no longer re-renders the whole node tree; selection is patched in place.
- Dragging a node now updates only its incident edges rather than rebuilding every edge.
- Replaced linear node lookup during edge work with indexed Maps.
- Replaced the finite 100,000px grid/SVG coordinate trick with an unbounded camera-relative grid and SVG geometry in world coordinates.
- Added viewport culling, semantic zoom/LOD, pointer-move RAF coalescing, touch-safe pointer handling, pointer-cancel recovery, and resize handling.
- Import is transactional: malformed models are rejected without destroying the current canvas.
- Added node-type filtering and search-to-focus on Enter.
- Added real-browser Playwright smoke/stress test and expanded validator regression suite.

## 1.0.0 — 2026-10-02

- Initial clean-room release.
- Added typed functional graph model.
- Added requirement normalization and diagnostics protocol.
- Added rendering-lane selector.
- Added standalone infinite-canvas reference implementation.
- Added React Flow starter.
- Added JSON Schema and no-dependency validator.
- Added regression tests and example model.
- Added public open-source research notes and license cautions.
