# Open-source research notes

Research date: 2026-10-02

This package is clean-room original work. The projects below were inspected for public architectural patterns and product capabilities. Their source code is not copied into this Skill.

## tldraw

Repository: https://github.com/tldraw/tldraw

Useful ideas observed:

- infinite-canvas engine as a reusable application substrate
- extensible shapes, tools, bindings, UI, event hooks
- runtime/editor API
- AI-oriented canvas primitives
- multiplayer option

Important license note at time of research: current tldraw SDK production use requires a license key under the tldraw license. Treat it as an optional implementation lane, not the default dependency for a freely distributable Skill.

## Excalidraw

Repository: https://github.com/excalidraw/excalidraw

Useful ideas observed:

- infinite canvas interaction model
- open drawing JSON format
- zoom/pan, arrows, undo/redo
- export and local-first behavior
- practical whiteboard ergonomics

Best suited here when freeform whiteboarding matters more than typed functional graph semantics.

## xyflow / React Flow

Repository: https://github.com/xyflow/xyflow

Useful ideas observed:

- node/edge model with custom components
- selection, zoom, pan, minimap, controls
- handles and interactive connections
- strong fit for product feature graphs and workflow editors

The repository states React Flow / Svelte Flow are MIT licensed at the time of research.

## Rete.js

Repository: https://github.com/retejs/rete

Useful ideas observed:

- dataflow/control-flow-oriented graph semantics
- visual programming rather than generic diagramming
- typed processing nodes as a first-class concept

Use only when nodes represent executable/processing behavior.

## Dagre

Repository: https://github.com/dagrejs/dagre

Useful ideas observed:

- client-side directed graph layout
- good fit for deterministic layered dependency maps

Research surfaced a 2026 changelog indicating per-cluster direction and dynamic-layout support. Treat version-specific behavior as something to verify against the installed package before relying on it.

## AFFiNE

Repository: https://github.com/toeverything/AFFiNE

Useful product idea:

- knowledge/document structure and canvas/edgeless thinking can coexist rather than forcing all information into one mode

This Skill adopts the broader principle that the infinite canvas should be one view over structured knowledge, not the only place where meaning lives.

## 2026 performance follow-up

Additional public research during v1.1.0 hardening reinforced several implementation choices:

- React Flow's current performance guidance recommends memoizing custom node/edge components and callbacks, avoiding broad subscriptions to frequently changing node arrays, collapsing large trees, and simplifying heavy visual styles on large graphs: https://reactflow.dev/learn/advanced-use/performance
- tldraw's 2026 performance documentation describes viewport culling backed by a spatial index and notes that a scene can contain thousands of shapes while only the visible subset renders: https://github.com/tldraw/tldraw/blob/main/apps/docs/content/sdk-features/performance.mdx
- Public Excalidraw performance discussions likewise identify viewport checking, spatial indexing, dirty-region work, and large element counts as the actual scaling problem rather than merely “having an infinite coordinate system”: https://github.com/excalidraw/excalidraw/issues/10063

The v1.1.0 standalone reference therefore adds culling, LOD, indexed node lookup, RAF coalescing and incident-edge updates instead of pretending a giant DOM surface alone is sufficient.
