// Keep layout as a separate adapter so the canonical model does not depend on React Flow.
// For simple directed graphs, integrate Dagre here. For compound/nested graphs,
// consider ELK only when the complexity justifies the extra dependency.

export type Positioned = { id: string; position: { x: number; y: number } };

export function keepManualPositions<T extends Positioned>(nodes: T[]): T[] {
  return nodes;
}
