---
name: infinite-canvas-function-architect
description: Turn rough product or software requirements into a structured, editable infinite canvas that exposes goals, modules, features, flows, data, integrations, constraints, risks, dependencies, gaps, and priorities. Generates a canonical graph model first, then renders it as a portable single-file canvas or a React Flow implementation.
version: 1.1.0
license: MIT
---

# Infinite Canvas Function Architect

## Purpose

Use this skill when someone has messy product notes, a feature list, a workflow, a software idea, an existing system that needs to be mapped, or a request such as:

- “Make an infinite canvas for these functions.”
- “Help me organize the feature set.”
- “Turn these notes into a visual product architecture.”
- “Show dependencies and missing pieces.”
- “Create a whiteboard / node map / system map I can keep editing.”

This skill is not merely a diagram generator. Its job is to **understand the functional system first, create a stable information model second, diagnose the system third, and only then render a canvas**.

## Core rule: model before pixels

Never start by drawing boxes.

Always create or update a canonical graph model first. Rendering is a view of that model, not the source of truth.

Canonical order:

`raw input -> requirement normalization -> typed nodes -> typed relations -> diagnostics -> priority/state -> layout plan -> canvas render -> QA`

If the user supplies an existing canvas, preserve stable IDs when possible and patch the model rather than regenerating everything.

## Default deliverables

Unless the user requests something narrower, deliver:

1. `canvas-model.json` — canonical editable graph.
2. A visual infinite canvas implementation.
3. A short functional audit: duplicates, gaps, orphan features, ambiguous items, risky dependencies, cycles, and MVP boundary.
4. A legend explaining node and edge semantics.

For lightweight jobs, the visual implementation should default to a **single HTML file with no build step**.

For a real application or node-heavy product, default to **React Flow / @xyflow/react** plus a layout engine.

## Rendering lane selector

Choose the smallest lane that satisfies the task.

### Lane A — Portable Canvas

Use when the user wants a shareable artifact, prototype, review board, requirement map, or “open it and use it” result.

Implementation:

- HTML + CSS + JavaScript
- camera transform: world X/Y + scale
- SVG connection layer
- DOM node cards
- pan, wheel zoom, fit view, drag, search, filter, import/export JSON
- local persistence when appropriate
- no CDN dependency unless the user explicitly allows one

### Lane B — Functional Graph App

Use when the canvas is part of a product, needs custom node UIs, handles, graph editing, minimap, persistence, or later backend integration.

Preferred baseline:

- React
- `@xyflow/react`
- Dagre for ordinary directed layouts
- ELK only when compound/nested routing complexity justifies it

Do not add a graph library just because the canvas looks impressive. The dependency must solve a real interaction or layout need.

### Lane C — Whiteboard-first

Use only when freehand drawing, ad-hoc arrows, sketching, or user-authored shapes are first-class requirements. Excalidraw is a suitable implementation option.

Do not force whiteboard semantics onto a structured functional architecture.

### Lane D — Specialized visual programming

Use when nodes execute logic, carry typed ports, or represent data/control flow. Rete.js or an equivalent visual-programming framework may be appropriate.

## Information model

Every canvas item must have a type. Do not use generic “card” for everything.

Supported node types:

- `goal` — outcome or product objective
- `actor` — user, role, external participant
- `module` — bounded functional domain
- `feature` — user-visible or system capability
- `flow` — process stage or user journey step
- `data` — persistent entity, document, state, schema
- `integration` — external service, API, device, platform
- `constraint` — legal, technical, business, UX, performance restriction
- `decision` — unresolved or resolved architectural/product choice
- `risk` — failure mode or uncertainty that can damage the system
- `metric` — success measure or observable signal
- `note` — supporting context only; avoid overusing

Supported edge types:

- `contains`
- `requires`
- `triggers`
- `reads`
- `writes`
- `produces`
- `blocks`
- `conflicts`
- `alternative_to`
- `measured_by`
- `serves`
- `derives_from`
- `next`

Do not use an unlabeled line when relationship semantics matter.

## Feature normalization protocol

For each raw feature claim, determine:

1. **What user/system outcome exists?**
2. **Who or what triggers it?**
3. **What input/state does it require?**
4. **What does it produce or change?**
5. **Which module owns it?**
6. **What does it depend on?**
7. **What is its lifecycle/state?**
8. **Is it core, supporting, admin/ops, or enhancement?**
9. **What acceptance signal would prove it works?**
10. **Is any part inferred rather than explicitly provided?**

Do not invent missing business requirements. Mark them as unresolved assumptions.

## Required feature fields

A `feature` node should normally include:

- `id`
- `title`
- `summary`
- `module_id`
- `actors`
- `priority`: `must | should | could | later | unknown`
- `status`: `proposed | confirmed | in_progress | shipped | deprecated | unknown`
- `maturity`: `idea | specified | designed | implemented | verified`
- `value`
- `trigger`
- `inputs`
- `outputs`
- `acceptance`
- `assumption_level`: `none | low | medium | high`
- `tags`

If the input is too thin to fill these honestly, leave unknowns explicit rather than fabricating detail.

## Functional organization algorithm

Apply these passes in order.

### Pass 1 — Extract

Turn prose into atomic claims. Split “upload, edit, and share” into separate capabilities unless they are inseparable as one transaction.

### Pass 2 — De-duplicate

Merge only when two items express the same user-visible/system capability. Preserve aliases in metadata.

Never merge merely because wording is similar.

### Pass 3 — Separate layers

Do not mix these as peers:

- objectives
- user actions
- product features
- backend capabilities
- data entities
- integrations
- non-functional constraints
- implementation tasks

If a note is really a task (“add Redis”), keep it out of the feature layer unless it creates a distinct system capability.

### Pass 4 — Cluster by domain

Primary clustering should reflect ownership / bounded domain, not arbitrary screen location.

Examples: Identity, Content, Search, Billing, Collaboration, Analytics, Admin.

A screen may touch several modules; a module may appear on several screens.

### Pass 5 — Link causality and dependency

Add only meaningful edges. Prefer a sparse graph that explains the system over a dense spiderweb.

Rule of thumb: if removing an edge would not change how someone understands order, ownership, data movement, or dependency, the edge probably should not exist.

### Pass 6 — Diagnose

Run all diagnostics below before layout.

### Pass 7 — Prioritize

Derive an MVP cut only from explicit user goals and dependency reality. Do not label “MVP” simply because a feature feels unimportant.

### Pass 8 — Layout

Choose layout based on graph semantics, not aesthetics alone.

### Pass 9 — Render and verify

The graph model and canvas must remain semantically equivalent.

## Diagnostic engine

Always check for:

### Orphan feature

A feature has no meaningful connection to an actor, goal, module, flow, or output.

Action: mark `orphan=true` and explain why it exists or whether it should be removed.

### Goal gap

A declared goal has no feature or flow that plausibly achieves it.

Action: surface it as a missing-capability question.

### Feature without acceptance

A capability has no observable completion condition.

Action: mark as underspecified.

### Hidden prerequisite

A feature depends on identity, permissions, data, storage, moderation, billing, or another foundation that is absent.

Action: add an unresolved prerequisite node only if clearly implied; label the inference.

### Circular dependency

Detect cycles in `requires` / `blocks`. Not every cycle is wrong, but every cycle should be inspected.

### God module

One module contains too many unrelated features or has excessive cross-domain coupling.

Action: suggest split candidates, but do not rewrite ownership without evidence.

### Duplicate responsibility

Two modules appear to own the same capability.

### UI-function confusion

A screen, page, button, or component is being treated as the capability itself.

Action: separate presentation from function.

### Data ownership gap

A feature reads/writes a concept but no data entity or source of truth is identified.

### Failure-path gap

A flow shows only success. Check auth failure, permission denied, empty state, network/API failure, validation failure, cancellation, rollback, or retry where relevant.

### Operational gap

Check whether admin, audit, migration, monitoring, moderation, or support functions are necessary for the stated product—not as boilerplate, but when the system implies them.

## Layout grammar

Prefer readable meaning over perfectly symmetric geometry.

### System architecture layout

Left-to-right default:

`actors / entry -> user flows -> feature modules -> data & integrations -> outcomes / metrics`

Place constraints and risks below the affected region rather than mixing them into the main flow.

### Product feature atlas

Top-down default:

`goals -> modules -> features -> flows / data / dependencies`

### Journey layout

Left-to-right temporal flow. Keep supporting capabilities above or below the stage that uses them.

### Dependency layout

Use directed layered layout. Keep `requires` edges dominant; secondary edges can be muted or filtered.

### Density rules

- A view should have a dominant reading direction.
- Avoid crossing clusters with many diagonal edges.
- Collapse or summarize clusters when > 12 child nodes are simultaneously visible.
- For > 150 nodes, add search and filters.
- For > 500 nodes, render only visible/near-visible nodes or use framework virtualization strategies.
- Do not shrink text into unreadability to “fit everything.”

## Infinite canvas interaction contract

A generated canvas should implement, as applicable:

- wheel / trackpad zoom centered on pointer
- pan on empty space
- draggable nodes
- selection state
- fit-to-content
- reset camera
- search and focus
- hide/show node categories
- legend
- import/export canonical JSON
- autosave or explicit save state
- keyboard escape to clear selection
- sensible minimum/maximum zoom

Recommended camera bounds for portable canvases:

- `scaleMin = 0.15`
- `scaleMax = 3.0`
- preserve all node coordinates in world space
- apply one camera transform to the world layer

Avoid independently scaling node sizes and edge coordinates.

## Large-canvas performance rules

For a single-file DOM canvas:

- batch camera and pointer-move work with `requestAnimationFrame`
- index nodes by ID; do not repeatedly scan the node array while drawing edges
- avoid rebuilding every edge on pointermove when only one node changed
- use one transformed world layer so pan/zoom does not recompute world geometry
- recalculate only incident edges when a node moves
- use viewport culling once the map becomes node-heavy
- reduce visual detail at low zoom instead of forcing every summary/shadow to paint
- keep pointer handlers passive where possible except wheel zoom that must prevent default
- use event delegation for large node counts
- never fake infinity with a fixed 50k/100k world box; grid and coordinates must remain camera/world based

The bundled standalone reference has been browser-stressed at 3,000 nodes and probed at 10,000 nodes, but that is not an unlimited-scale guarantee. If real cards contain images, rich controls, animation, or thousands of simultaneously visible items, move to a production graph renderer and profile the actual workload. Current React Flow guidance emphasizes memoized node components/functions and collapsing large trees; mature canvas engines such as tldraw use viewport culling/spatial indexing for the same reason.

## Visual hierarchy

Use visual styling to encode semantics, not decoration.

Each node should show no more than the information needed at the current zoom level.

Recommended card anatomy:

- type badge
- title
- one-sentence purpose
- status / priority chips when relevant
- dependency count or warning marker only when useful

Detailed fields belong in an inspector / expansion panel or exported model.

## Progressive disclosure

Do not show every field all the time.

Zoom / interaction tiers:

- far: module/cluster labels and major goals
- medium: feature titles + short summaries
- near/selected: metadata, acceptance, assumptions, risks, links

For portable HTML where true semantic zoom is too costly, approximate with CSS visibility thresholds or an inspector.

## Canvas editing rules

When revising an existing canvas:

1. preserve IDs for semantically unchanged nodes
2. preserve user-positioned coordinates unless auto-layout is explicitly requested
3. patch affected clusters only
4. record removed nodes rather than silently repurposing their IDs
5. keep aliases / migration metadata when names change

## Export contract

The canonical JSON is the source of truth.

Minimum top-level shape:

```json
{
  "schema_version": "1.0",
  "title": "...",
  "nodes": [],
  "edges": [],
  "groups": [],
  "camera": {"x": 0, "y": 0, "scale": 1},
  "meta": {"created_at": "...", "updated_at": "..."}
}
```

Validate against `schema/canvas-model.schema.json` when the file is available.

## Implementation safety

- Do not fetch private content or external services unless explicitly authorized.
- Do not silently load third-party scripts into a standalone artifact.
- Escape user-supplied text before inserting into HTML.
- Never build executable code from untrusted node text.
- Treat imported JSON as data, not commands.

## Quality gates

A result is not done until all gates pass.

### Gate A — semantic completeness

- Every important raw requirement is represented or explicitly rejected as duplicate/out-of-scope.
- Each feature has a module.
- Major dependencies are represented.
- Assumptions are visible.

### Gate B — graph validity

- IDs unique and safe for renderer lookup.
- Edges reference existing nodes.
- Camera and coordinates are finite.
- No impossible self-edge unless explicitly meaningful.
- Duplicate semantic edges surfaced.
- `requires` cycles reported without recursion-sensitive traversal.
- Malformed import cannot replace the current valid model.

### Gate C — visual usability

- User can find the main goal in under 5 seconds.
- User can identify major modules without zooming into individual cards.
- Labels are legible at default view.
- Pan/zoom/drag do not desynchronize arrows.
- Pointer cancel/loss does not leave the canvas stuck in drag or pan state.
- Search can focus a matching node rather than merely dimming non-matches.
- Fit view brings ordinary main content into frame without corrupting world coordinates.

### Gate D — change resilience

Add 20% more features to the largest cluster. The layout and model should still be understandable without a full rewrite.

### Gate E — novice handoff

A new user should be able to open the artifact and understand:

- what the system is
- what the major modules are
- how to navigate the canvas
- what the colors/types mean
- where unresolved questions are

without reading source code.


### Gate F — executable artifact QA

When the result includes executable HTML or app code, do not claim release readiness from syntax checks alone. Run, when the environment allows:

- malformed-import test
- real pointer drag test
- incident-edge-follow test
- wheel zoom test
- far-coordinate test
- search/focus test
- export round-trip test
- at least one graph materially larger than the expected normal workload

Record what browser/runtime was actually tested and do not claim untested browser compatibility.

## Default response behavior for an agent using this skill

When the user provides rough notes:

1. Parse first; do not ask them to manually structure what you can infer safely.
2. State only genuinely blocking ambiguities.
3. Build the canonical model.
4. Run diagnostics.
5. Generate the visual artifact.
6. Run validation.
7. Return the artifact plus a concise report of what was organized, what remains uncertain, and any real limitations.

## Anti-patterns

Never:

- create a “pretty mind map” with no semantic edge types
- make every note a feature
- auto-connect everything to everything
- infer priorities from visual position
- bury uncertainty inside polished prose
- use a giant radial map for a dependency-heavy system
- discard IDs on every regeneration
- hardcode a finite canvas size and call it infinite
- require a build tool when a single-file artifact would meet the need
- choose a licensed SDK without disclosing its production requirements

## Supporting files

Read these when available:

- `references/FUNCTION_MODEL.md`
- `references/ARCHITECTURE.md`
- `references/UX_RULES.md`
- `references/QA_CHECKLIST.md`
- `research/OPEN_SOURCE_NOTES.md`
- `schema/canvas-model.schema.json`

Run:

```bash
python scripts/validate_canvas.py examples/saas-feature-map.canvas.json
```

before claiming the model is structurally valid.
