"""离线地名 → 经纬度 / 时区（玄枢 2.0）。

新手最常说的是「我是湖南邵阳人」「出生在上海」，而不是「27n14 / 111e28」。真太阳时、宫位、
上升点都取决于出生地经纬度（经度差 1° = 真太阳时差 4 分钟），所以 2.0 自带一份离线地名库：

* 中国大陆与港澳台：约 5400 个县城 / 城镇（GeoNames 人口 ≥ 1000）；
* 全球：约 13000 个有中文名或人口 ≥ 10 万的城市；
* 每条带 IANA 时区（Asia/Shanghai、America/New_York……），起盘时自动折算历史夏令时。

匹配策略（越具体越优先）：「湖南邵阳隆回」先找隆回，找不到退到邵阳，再退到湖南省会，并在结果里
写明精度等级与可能造成的真太阳时误差，让 AI 主动追问更具体的地名。

数据：GeoNames（https://www.geonames.org/），CC BY 4.0。
"""
from __future__ import annotations

import gzip
import json
import re
from dataclasses import asdict, dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any

_DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "places.json.gz"

# GeoNames CN 一级行政区代码 → (全称, 常用简称/别称, 省会英文名)
CN_PROVINCES: dict[str, tuple[str, tuple[str, ...], str]] = {
    "01": ("安徽省", ("安徽", "皖"), "Hefei"),
    "02": ("浙江省", ("浙江", "浙"), "Hangzhou"),
    "03": ("江西省", ("江西", "赣"), "Nanchang"),
    "04": ("江苏省", ("江苏", "苏"), "Nanjing"),
    "05": ("吉林省", ("吉林",), "Changchun"),
    "06": ("青海省", ("青海",), "Xining"),
    "07": ("福建省", ("福建", "闽"), "Fuzhou"),
    "08": ("黑龙江省", ("黑龙江",), "Harbin"),
    "09": ("河南省", ("河南", "豫"), "Zhengzhou"),
    "10": ("河北省", ("河北", "冀"), "Shijiazhuang"),
    "11": ("湖南省", ("湖南", "湘"), "Changsha"),
    "12": ("湖北省", ("湖北", "鄂"), "Wuhan"),
    "13": ("新疆维吾尔自治区", ("新疆",), "Ürümqi"),
    "14": ("西藏自治区", ("西藏",), "Lhasa"),
    "15": ("甘肃省", ("甘肃",), "Lanzhou"),
    "16": ("广西壮族自治区", ("广西",), "Nanning"),
    "18": ("贵州省", ("贵州",), "Guiyang"),
    "19": ("辽宁省", ("辽宁",), "Shenyang"),
    "20": ("内蒙古自治区", ("内蒙古", "内蒙"), "Hohhot"),
    "21": ("宁夏回族自治区", ("宁夏",), "Yinchuan"),
    "22": ("北京市", ("北京",), "Beijing"),
    "23": ("上海市", ("上海", "沪"), "Shanghai"),
    "24": ("山西省", ("山西", "晋"), "Taiyuan"),
    "25": ("山东省", ("山东", "鲁"), "Jinan"),
    "26": ("陕西省", ("陕西", "陕"), "Xi’an"),
    "28": ("天津市", ("天津",), "Tianjin"),
    "29": ("云南省", ("云南", "滇"), "Kunming"),
    "30": ("广东省", ("广东", "粤"), "Guangzhou"),
    "31": ("海南省", ("海南", "琼"), "Haikou"),
    "32": ("四川省", ("四川", "川", "蜀"), "Chengdu"),
    "33": ("重庆市", ("重庆", "渝"), "Chongqing"),
}
# 省级别名里过短、极易误命中的单字简称只在「X省」形态下使用
_MUNICIPALITIES = {"22", "23", "28", "33"}
_SINGLE_CHAR_ALIASES = {alias for _, aliases, _ in CN_PROVINCES.values() for alias in aliases if len(alias) == 1}

_ADMIN_SUFFIXES = (
    "特别行政区", "自治县", "自治州", "自治旗", "街道办事处", "街道", "地区", "新区",
    "市", "县", "区", "镇", "乡", "盟", "旗", "村",
)
_NOISE = ("中华人民共和国", "中国", "大陆", "出生", "生于", "老家", "人", "附近", "一带")

_COUNTRY_ZH = {
    "美国": "US", "英国": "GB", "加拿大": "CA", "澳大利亚": "AU", "新西兰": "NZ", "日本": "JP",
    "韩国": "KR", "新加坡": "SG", "马来西亚": "MY", "泰国": "TH", "德国": "DE", "法国": "FR",
    "意大利": "IT", "西班牙": "ES", "俄罗斯": "RU", "印度": "IN", "越南": "VN", "印度尼西亚": "ID",
    "菲律宾": "PH", "荷兰": "NL", "瑞士": "CH", "瑞典": "SE", "巴西": "BR", "阿联酋": "AE",
}

_DECIMAL_PAIR_RE = re.compile(
    r"(?P<a>[+-]?\d{1,3}(?:\.\d+)?)\s*[,，/\s]\s*(?P<b>[+-]?\d{1,3}(?:\.\d+)?)"
)


@dataclass
class PlaceMatch:
    name: str
    name_zh: str
    lat: float
    lon: float
    timezone: str
    country: str
    province: str | None
    population: int
    precision: str  # coordinates | town | city | province
    matched_text: str
    longitude_uncertainty_deg: float
    true_solar_uncertainty_minutes: float
    notes: list[str] = field(default_factory=list)

    def as_payload_fields(self) -> dict[str, Any]:
        """可直接并入起盘载荷的字段（lat/lon 用十进制，入口会自动归一成 31n13 形式）。"""
        return {"lat": round(self.lat, 4), "lon": round(self.lon, 4), "zone": self.timezone, "pos": self.name_zh or self.name}


@lru_cache(maxsize=1)
def _dataset() -> dict[str, Any]:
    raw = gzip.decompress(_DATA_PATH.read_bytes())
    data = json.loads(raw.decode("utf-8"))
    t2s_pairs = data.get("t2s", "")
    data["_t2s"] = {t2s_pairs[i]: t2s_pairs[i + 1] for i in range(0, len(t2s_pairs) - 1, 2)}
    index: dict[str, list[int]] = {}
    en_index: dict[str, list[int]] = {}
    for i, row in enumerate(data["places"]):
        for zh in row[7]:
            for key in _name_keys(zh):
                index.setdefault(key, []).append(i)
        en_index.setdefault(_ascii_key(row[0]), []).append(i)
    data["_index"] = index
    data["_en_index"] = en_index
    return data


def _ascii_key(text: str) -> str:
    return re.sub(r"[^a-z]", "", text.lower().replace("’", "").replace("'", ""))


def _name_keys(zh: str) -> set[str]:
    keys = {zh}
    for suffix in _ADMIN_SUFFIXES:
        if zh.endswith(suffix) and len(zh) - len(suffix) >= 2:
            keys.add(zh[: -len(suffix)])
    return keys


def _to_simplified(text: str) -> str:
    table = _dataset()["_t2s"]
    return "".join(table.get(ch, ch) for ch in text)


def _row_to_match(row: list[Any], *, precision: str, matched: str) -> PlaceMatch:
    data = _dataset()
    cc = row[4]
    province = CN_PROVINCES.get(row[5], (None,))[0] if cc == "CN" else None
    names = [n for n in row[7] if not n.endswith(("街道", "村"))] or list(row[7])
    containing = sorted((n for n in names if matched and matched in n), key=len)
    zh = containing[0] if containing else (names[0] if names else "")
    lon_unc = {"coordinates": 0.0, "town": 0.1, "city": 0.3, "province": 4.0}[precision]
    return PlaceMatch(
        name=row[0],
        name_zh=zh,
        lat=float(row[1]),
        lon=float(row[2]),
        timezone=data["timezones"][row[3]],
        country=cc,
        province=province,
        population=int(row[6]),
        precision=precision,
        matched_text=matched,
        longitude_uncertainty_deg=lon_unc,
        true_solar_uncertainty_minutes=round(lon_unc * 4, 1),
    )


def _detect_province(text: str) -> tuple[str | None, str | None]:
    best: tuple[int, str, str] | None = None
    for code, (full, aliases, _) in CN_PROVINCES.items():
        for name in (full, *aliases):
            if name in _SINGLE_CHAR_ALIASES:
                if f"{name}省" not in text:
                    continue
            pos = text.find(name)
            if pos >= 0 and (best is None or len(name) > len(best[2])):
                best = (pos, code, name)
    return (best[1], best[2]) if best else (None, None)


def _parse_coordinates(text: str) -> tuple[float, float] | None:
    match = _DECIMAL_PAIR_RE.search(text)
    if not match or "." not in match.group(0):
        return None
    a, b = float(match.group("a")), float(match.group("b"))
    if abs(a) <= 90 and abs(b) <= 180:
        return a, b
    if abs(b) <= 90 and abs(a) <= 180:
        return b, a
    return None


def lookup_place(text: str, *, limit: int = 5) -> dict[str, Any]:
    """把自然语言地名解析成经纬度 + 时区。返回 {ok, best, candidates, notes, ask_user}。"""
    query = (text or "").strip()
    if not query:
        return {"ok": False, "reason": "empty", "ask_user": "请告诉我出生在哪个城市（最好具体到区县）。"}

    coords = _parse_coordinates(query)
    if coords is not None:
        lat, lon = coords
        nearest = nearest_place(lat, lon)
        tz = nearest.timezone if nearest else "UTC"
        match = PlaceMatch(
            name=f"{lat:.4f},{lon:.4f}", name_zh="", lat=lat, lon=lon, timezone=tz,
            country=nearest.country if nearest else "", province=nearest.province if nearest else None,
            population=0, precision="coordinates", matched_text=query,
            longitude_uncertainty_deg=0.0, true_solar_uncertainty_minutes=0.0,
            notes=[f"按坐标直接取用；时区取最近城市 {nearest.name_zh or nearest.name} 的 {tz}。" if nearest else "时区未知，按 UTC。"],
        )
        return {"ok": True, "best": asdict(match), "payload_fields": match.as_payload_fields(), "candidates": [asdict(match)], "notes": match.notes}

    data = _dataset()
    simplified = _to_simplified(query)
    cleaned = simplified
    for noise in _NOISE:
        cleaned = cleaned.replace(noise, " ")
    province_code, province_name = _detect_province(cleaned)
    country_filter = next((cc for zh, cc in _COUNTRY_ZH.items() if zh in cleaned), None)

    # 1) 中文名：枚举所有子串查索引（地名一般 2–8 字）
    hits: dict[int, tuple[int, int, str]] = {}
    compact = re.sub(r"\s+", "", cleaned)
    index = data["_index"]
    for size in range(min(8, len(compact)), 1, -1):
        for start in range(0, len(compact) - size + 1):
            sub = compact[start : start + size]
            if (
                province_name
                and province_code not in _MUNICIPALITIES
                and sub in (province_name, CN_PROVINCES[province_code][0])
            ):
                continue
            for i in index.get(sub, ()):
                prev = hits.get(i)
                cand = (size, start, sub)
                if prev is None or cand[:2] > prev[:2]:
                    hits[i] = cand

    # 2) 英文 / 拼音
    if not hits:
        tokens = [t for t in re.split(r"[,，\s]+", query) if t]
        en_index = data["_en_index"]
        joined = _ascii_key(query)
        first = _ascii_key(tokens[0]) if tokens else ""
        for key in (joined, _ascii_key(" ".join(tokens[:2])), first):
            if len(key) >= 3 and key in en_index:
                for i in en_index[key]:
                    hits.setdefault(i, (len(key), 0, key))
                break
            if len(key) >= 5:
                # 「New York」→ New York City：前缀命中只认大城市，免得把小镇顶上来
                prefixed = [
                    i for name_key, ids in en_index.items() if name_key.startswith(key)
                    for i in ids if data["places"][i][6] >= 100000
                ]
                if prefixed:
                    for i in prefixed:
                        hits.setdefault(i, (len(key), 0, key))
                    break

    places = data["places"]
    scored: list[tuple[tuple[Any, ...], int]] = []
    for i, (size, start, sub) in hits.items():
        row = places[i]
        if country_filter and row[4] != country_filter:
            continue
        province_bonus = 1 if (province_code and row[4] == "CN" and row[5] == province_code) else 0
        province_penalty = -1 if (province_code and row[4] == "CN" and row[5] != province_code) else 0
        exact = 1 if sub in row[7] else 0
        # 越靠后的地名越具体（「湖南邵阳隆回」里隆回最具体）；同位置取更长、同省、人口更大
        key = (province_bonus + province_penalty, start + size, size, exact, row[6])
        scored.append((key, i))
    scored.sort(reverse=True)

    notes: list[str] = []
    candidates: list[PlaceMatch] = []
    for _, i in scored[: max(1, limit)]:
        row = places[i]
        precision = "city" if row[6] >= 300000 else "town"
        candidates.append(_row_to_match(row, precision=precision, matched=hits[i][2]))

    if not candidates and province_code:
        capital_en = CN_PROVINCES[province_code][2]
        for row in places:
            if row[4] == "CN" and row[0] == capital_en:
                match = _row_to_match(row, precision="province", matched=province_name or "")
                match.notes.append(
                    f"只识别到省级（{CN_PROVINCES[province_code][0]}），暂按省会{match.name_zh}定位；"
                    "省内东西跨度大，真太阳时可能偏差十几分钟，建议补充具体城市或区县。"
                )
                candidates = [match]
                break

    if not candidates:
        return {
            "ok": False,
            "reason": "not_found",
            "query": query,
            "ask_user": "没有在离线地名库里找到这个地方。请换一个更常见的写法（例如「湖南长沙」「广东佛山顺德」），"
                        "或直接提供经纬度（例如 28.2, 112.97）。",
        }

    best = candidates[0]
    if province_code and best.country == "CN" and best.province and best.province != CN_PROVINCES[province_code][0]:
        best.notes.append(f"注意：你提到了{province_name}，但最匹配的是{best.province}的{best.name_zh}，请确认。")
    province_settled = bool(province_code and best.country == "CN" and best.province == CN_PROVINCES[province_code][0])
    if (
        not province_settled
        and len(candidates) > 1
        and candidates[1].matched_text == best.matched_text
        and candidates[1].province != best.province
    ):
        others = "、".join(f"{c.province or c.country}{c.name_zh or c.name}" for c in candidates[1:4] if c.matched_text == best.matched_text)
        notes.append(f"同名地点不止一个（{others}），默认取了{best.province or best.country}{best.name_zh}；如不对请说明省份。")
    best_hit = next((hits[i] for _, i in scored if places[i][0] == best.name), None)
    if best_hit is not None and best.precision != "province":
        tail = compact[best_hit[1] + best_hit[0]:]
        for suffix in _ADMIN_SUFFIXES:
            tail = tail.replace(suffix, "")
        han_tail = "".join(ch for ch in tail if "\u4e00" <= ch <= "\u9fff")
        if len(han_tail) >= 2:
            best.longitude_uncertainty_deg = max(best.longitude_uncertainty_deg, 0.6)
            best.true_solar_uncertainty_minutes = round(best.longitude_uncertainty_deg * 4, 1)
            notes.append(
                f"离线库里没有更细的「{han_tail}」，已按上一级「{best.name_zh}」定位，"
                f"真太阳时误差约 ±{best.true_solar_uncertainty_minutes:g} 分钟；出生时间接近时辰交界时，建议提供经纬度。"
            )
    if best.precision == "town" and best.population == 0:
        notes.append("命中的是小镇或街道级地点，坐标精确，但请确认它就是出生地。")
    notes.extend(best.notes)

    return {
        "ok": True,
        "query": query,
        "best": asdict(best),
        "payload_fields": best.as_payload_fields(),
        "candidates": [asdict(c) for c in candidates],
        "notes": notes,
        "source": data["source"],
    }


def nearest_place(lat: float, lon: float) -> PlaceMatch | None:
    """最近的已知城市（用于给裸坐标配时区）。"""
    import math

    best_row = None
    best_d = 1e18
    for row in _dataset()["places"]:
        dlat = row[1] - lat
        dlon = (row[2] - lon) * math.cos(math.radians(lat))
        d = dlat * dlat + dlon * dlon
        if d < best_d:
            best_d, best_row = d, row
    return _row_to_match(best_row, precision="city", matched="") if best_row else None


__all__ = ["CN_PROVINCES", "PlaceMatch", "lookup_place", "nearest_place"]
