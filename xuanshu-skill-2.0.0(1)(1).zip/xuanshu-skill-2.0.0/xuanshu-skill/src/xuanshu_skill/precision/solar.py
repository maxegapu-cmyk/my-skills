"""真太阳时（玄枢 2.0）。

真太阳时 = 世界时 + 经度/15 小时（得地方平太阳时）+ 均时差（地球椭圆轨道 + 黄赤交角造成的日晷与钟表之差，
全年在 −14.2 ～ +16.4 分钟之间摆动）。

均时差用 Meeus《Astronomical Algorithms》式 28.3（Smart 公式）配低精度太阳根数（第 25 章），
与天文年历的差在 ±3 秒以内，足够判定时辰（每个时辰 120 分钟）与时辰交界。
"""
from __future__ import annotations

import math
from datetime import UTC, datetime, timedelta


def julian_day(moment: datetime) -> float:
    """UTC datetime → 儒略日。"""
    if moment.tzinfo is None:
        raise ValueError("julian_day 需要带时区的时间 / julian_day needs an aware datetime")
    utc = moment.astimezone(UTC)
    year, month = utc.year, utc.month
    day = utc.day + (utc.hour + (utc.minute + (utc.second + utc.microsecond / 1e6) / 60) / 60) / 24
    if month <= 2:
        year -= 1
        month += 12
    a = year // 100
    b = 2 - a + a // 4
    if (utc.year, utc.month, utc.day) < (1582, 10, 15):
        b = 0
    return int(365.25 * (year + 4716)) + int(30.6001 * (month + 1)) + day + b - 1524.5


def equation_of_time_minutes(moment: datetime) -> float:
    """均时差（分钟）：真太阳时 − 平太阳时。正值 = 日晷比钟表快。"""
    t = (julian_day(moment) - 2451545.0) / 36525.0
    l0 = math.radians((280.46646 + 36000.76983 * t + 0.0003032 * t * t) % 360.0)
    m = math.radians((357.52911 + 35999.05029 * t - 0.0001537 * t * t) % 360.0)
    e = 0.016708634 - 0.000042037 * t - 0.0000001267 * t * t
    omega = math.radians(125.04 - 1934.136 * t)
    eps0 = 23.0 + (26.0 + (21.448 - t * (46.815 + t * (0.00059 - t * 0.001813))) / 60.0) / 60.0
    eps = math.radians(eps0 + 0.00256 * math.cos(omega))
    y = math.tan(eps / 2.0) ** 2
    eot = (
        y * math.sin(2 * l0)
        - 2 * e * math.sin(m)
        + 4 * e * y * math.sin(m) * math.cos(2 * l0)
        - 0.5 * y * y * math.sin(4 * l0)
        - 1.25 * e * e * math.sin(2 * m)
    )
    return math.degrees(eot) * 4.0


def true_solar_time(moment: datetime, longitude_deg: float) -> dict[str, object]:
    """返回地方平太阳时、均时差与真太阳时（均为「墙钟」naive datetime，方便直接取时辰）。"""
    utc = moment.astimezone(UTC)
    lmt = utc + timedelta(minutes=longitude_deg * 4.0)
    eot = equation_of_time_minutes(utc)
    tst = lmt + timedelta(minutes=eot)
    civil = moment.replace(tzinfo=None)
    return {
        "local_mean_time": lmt.replace(tzinfo=None),
        "equation_of_time_minutes": round(eot, 2),
        "true_solar_time": tst.replace(tzinfo=None),
        "longitude_correction_minutes": round((lmt.replace(tzinfo=None) - civil).total_seconds() / 60.0, 2),
        "total_correction_minutes": round((tst.replace(tzinfo=None) - civil).total_seconds() / 60.0, 2),
    }


__all__ = ["equation_of_time_minutes", "julian_day", "true_solar_time"]
