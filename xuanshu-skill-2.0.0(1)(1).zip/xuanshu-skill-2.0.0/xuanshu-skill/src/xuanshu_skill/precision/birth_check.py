"""出生时间体检（玄枢 2.0）。

命盘准不准，一半看算法，一半看输入。新手最容易在这几处吃亏，而且自己完全察觉不到：

1. **出生地**：只说「湖南」不说「邵阳」，经度差几度，真太阳时就差十几分钟。
2. **夏令时**：中国 1986–1991 年每年夏天钟表拨快 1 小时；出生证上的时间是当时的钟表时间，
   直接按 +08:00 起盘会整整差一个小时（常常差一个时辰）。海外出生同理。
3. **时辰交界**：真太阳时离时辰分界只有几分钟时，时柱可能是两个之一，紫微命宫、六壬占时随之全变。
4. **节气交界**：出生在「节」（立春、惊蛰……）前后，月柱会变；立春前后连年柱、生肖都会变。
5. **晚子时**：23:00–24:00 出生，日柱按当天还是次日有两派口径。

本模块把这些风险一次查清，给出：精度等级（A/B/C）、白话体检报告、可直接用于起盘的载荷字段，
以及在有交界风险时应当「双盘对照」的两套候选四柱。

四柱口径（本模块的参考四柱）：年柱 / 月柱按**出生的绝对时刻**与节气交接时刻比较；日柱 / 时柱按
**真太阳时**。正式命盘以八字工具（bazi_birth）的输出为准，本体检用于提前发现风险。
"""
from __future__ import annotations

import re
from datetime import UTC, datetime, timedelta, timezone
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from xuanshu_skill.precision.places import lookup_place, nearest_place
from xuanshu_skill.precision.solar import true_solar_time

BRANCHES = "子丑寅卯辰巳午未申酉戌亥"
SHICHEN_NAMES = [f"{b}时" for b in BRANCHES]
SHICHEN_RANGES = [
    "23:00–00:59", "01:00–02:59", "03:00–04:59", "05:00–06:59", "07:00–08:59", "09:00–10:59",
    "11:00–12:59", "13:00–14:59", "15:00–16:59", "17:00–18:59", "19:00–20:59", "21:00–22:59",
]
# 只有「节」换月柱；「气」不换。
JIE_NAMES = ("立春", "惊蛰", "清明", "立夏", "芒种", "小暑", "立秋", "白露", "寒露", "立冬", "大雪", "小寒")
BEIJING = timezone(timedelta(hours=8))

_OFFSET_RE = re.compile(r"^(?:UTC|GMT)?\s*(?P<sign>[+-])(?P<h>\d{1,2})(?::?(?P<m>\d{2}))?$", re.I)


# ── 基础换算 ────────────────────────────────────────────────────────────────────
def shichen_index(hour: int, minute: int) -> int:
    return ((hour + 1) // 2) % 12


def minutes_to_shichen_boundary(moment: datetime) -> tuple[float, str]:
    """距最近时辰分界（奇数整点）的分钟数，以及那条分界是哪两个时辰之间。"""
    minutes = moment.hour * 60 + moment.minute + moment.second / 60
    best = None
    for odd in range(-1, 26, 2):
        boundary = odd * 60
        diff = minutes - boundary
        if best is None or abs(diff) < abs(best):
            best = diff
    assert best is not None
    boundary_minutes = minutes - best
    before = SHICHEN_NAMES[shichen_index(int((boundary_minutes - 1) // 60) % 24, 59)]
    after = SHICHEN_NAMES[shichen_index(int(boundary_minutes // 60) % 24, 0)]
    return round(abs(best), 1), f"{before}/{after}"


def _parse_offset(text: str) -> timezone | None:
    match = _OFFSET_RE.match(text.strip())
    if not match:
        return None
    sign = -1 if match.group("sign") == "-" else 1
    hours, minutes = int(match.group("h")), int(match.group("m") or 0)
    if hours > 14 or minutes >= 60:
        return None
    return timezone(sign * timedelta(hours=hours, minutes=minutes))


def _fmt_offset(delta: timedelta | None) -> str:
    if delta is None:
        return "?"
    total = int(delta.total_seconds() // 60)
    sign = "+" if total >= 0 else "-"
    total = abs(total)
    return f"{sign}{total // 60:02d}:{total % 60:02d}"


def _coerce_coordinate(value: Any, *, axis: str) -> float | None:
    from xuanshu_skill.input_normalization import _coerce_coordinate_decimal

    decimal = _coerce_coordinate_decimal(value)
    if decimal is None:
        return None
    limit = 90 if axis == "lat" else 180
    return decimal if -limit <= decimal <= limit else None


# ── 四柱参考（lunar_python）─────────────────────────────────────────────────────
def _solar(dt: datetime):
    from lunar_python import Solar

    return Solar.fromYmdHms(dt.year, dt.month, dt.day, dt.hour, dt.minute, dt.second)


def reference_pillars(instant: datetime, tst: datetime, *, late_zi_next_day: bool = True) -> dict[str, Any]:
    """年月柱按绝对时刻（折北京时间对节气表），日时柱按真太阳时。"""
    bj = instant.astimezone(BEIJING).replace(tzinfo=None)
    lunar_bj = _solar(bj).getLunar()
    ec_bj = lunar_bj.getEightChar()
    lunar_tst = _solar(tst).getLunar()
    ec_tst = lunar_tst.getEightChar()
    ec_tst.setSect(1 if late_zi_next_day else 2)
    return {
        "year": ec_bj.getYear(),
        "month": ec_bj.getMonth(),
        "day": ec_tst.getDay(),
        "time": ec_tst.getTime(),
        "zodiac_by_lichun": lunar_bj.getYearShengXiaoExact(),
        "zodiac_by_lunar_new_year": lunar_bj.getYearShengXiao(),
        "lunar_date": lunar_tst.toString(),
    }


def _nearest_jie(instant: datetime) -> dict[str, Any]:
    """出生前后最近的「节」（换月柱的那 12 个），返回名字、北京时间与相距小时。"""
    bj = instant.astimezone(BEIJING).replace(tzinfo=None)
    lunar = _solar(bj).getLunar()
    found: list[dict[str, Any]] = []
    for jq in (lunar.getPrevJie(), lunar.getNextJie()):
        solar = jq.getSolar()
        at = datetime(solar.getYear(), solar.getMonth(), solar.getDay(), solar.getHour(), solar.getMinute(), solar.getSecond())
        hours = (at - bj).total_seconds() / 3600.0
        found.append({"name": jq.getName(), "beijing_time": at.strftime("%Y-%m-%d %H:%M:%S"), "hours_from_birth": round(hours, 2)})
    found.sort(key=lambda item: abs(item["hours_from_birth"]))
    return {"nearest": found[0], "bracket": sorted(found, key=lambda item: item["hours_from_birth"])}


# ── 主入口 ──────────────────────────────────────────────────────────────────────
def birth_check(
    *,
    date: str,
    time: str,
    zone: str | None = None,
    place: str | None = None,
    lat: Any = None,
    lon: Any = None,
    boundary_minutes: float = 15.0,
    time_uncertainty_minutes: float | None = None,
    late_zi_next_day: bool = True,
    prefer_fixed_zone: bool = False,
) -> dict[str, Any]:
    findings: list[dict[str, str]] = []
    ask_user: list[str] = []

    def add(level: str, code: str, text: str) -> None:
        findings.append({"level": level, "code": code, "text": text})

    # 1) 日期时间
    try:
        y, mo, d = (int(x) for x in re.split(r"[-/.]", date.strip())[:3])
        parts = [int(x) for x in re.split(r"[:：]", time.strip())]
        hh, mm, ss = (parts + [0, 0, 0])[:3]
        civil = datetime(y, mo, d, hh, mm, ss)
    except (ValueError, TypeError):
        return {
            "ok": False,
            "reason": "invalid_datetime",
            "ask_user": "出生日期或时间格式没看懂。请用「1990-05-15 14:30」这种公历写法；如果只知道农历，请说明是农历。",
        }

    # 2) 地点
    place_info: dict[str, Any] | None = None
    lat_v = _coerce_coordinate(lat, axis="lat") if lat is not None else None
    lon_v = _coerce_coordinate(lon, axis="lon") if lon is not None else None
    if place and (lat_v is None or lon_v is None):
        place_info = lookup_place(place)
        if place_info.get("ok"):
            best = place_info["best"]
            lat_v, lon_v = best["lat"], best["lon"]
            for note in place_info.get("notes", []):
                add("info", "place.note", note)
        else:
            ask_user.append(place_info.get("ask_user") or "请补充出生地。")
    geo_tz_name: str | None = None
    if lat_v is not None and lon_v is not None:
        if place_info and place_info.get("ok"):
            geo_tz_name = place_info["best"]["timezone"]
        else:
            near = nearest_place(lat_v, lon_v)
            geo_tz_name = near.timezone if near else None
    else:
        ask_user.append("出生地在哪里？（城市即可，最好具体到区县；海外请写国家+城市）")

    # 3) 时区 / 夏令时
    zone_text = (zone or "").strip()
    fixed = _parse_offset(zone_text) if zone_text else None
    iana_name = zone_text if "/" in zone_text else None
    if iana_name is None and fixed is None:
        iana_name = geo_tz_name
    if iana_name == "Asia/Urumqi" and (y, mo, d) >= (1949, 10, 1):
        iana_name = "Asia/Shanghai"
        add("info", "zone.cn_unified", "新疆出生按北京时间口径（出生证明、户籍都用北京时间）。如果记录的是当地「新疆时间」，请说明。")

    instant: datetime | None = None
    resolved_offset: timedelta | None = None
    if iana_name:
        try:
            tz = ZoneInfo(iana_name)
        except (ZoneInfoNotFoundError, ValueError):
            tz = None
            add("warn", "zone.unknown", f"时区「{iana_name}」无法识别。")
        if tz is not None:
            first = civil.replace(tzinfo=tz, fold=0)
            second = civil.replace(tzinfo=tz, fold=1)
            roundtrip = first.astimezone(UTC).astimezone(tz).replace(tzinfo=None)
            if roundtrip != civil:
                add("risk", "dst.gap",
                    f"{civil:%Y-%m-%d %H:%M} 在当地正好处于夏令时开始时被跳过的那一小时，钟表上不存在这个时刻。"
                    "多半是记录时间有误，或记录的是标准时间，请与家人核对。")
            elif first.utcoffset() != second.utcoffset():
                add("risk", "dst.ambiguous",
                    f"{civil:%Y-%m-%d %H:%M} 在当地是夏令时结束时重复的一小时，这个钟表时间出现了两次"
                    f"（{_fmt_offset(first.utcoffset())} 与 {_fmt_offset(second.utcoffset())}），相差一小时。请确认是哪一个。")
            instant = first
            resolved_offset = first.utcoffset()
            dst = first.dst()
            if dst and dst.total_seconds() > 0:
                where = "中国" if iana_name == "Asia/Shanghai" else "当地"
                add("info", "dst.active",
                    f"出生时{where}正在实行夏令时，钟表比标准时间快 {int(dst.total_seconds() // 60)} 分钟，"
                    f"实际时区是 {_fmt_offset(resolved_offset)}。只要出生证上写的是当时的钟表时间，玄枢会自动按夏令时换算，无需手动减一小时。")
    if fixed is not None and resolved_offset is None and geo_tz_name:
        # 用户给了固定偏移：仍按出生地的 IANA 时区算一遍当日法定偏移（含历史夏令时）做对照
        geo_name = "Asia/Shanghai" if geo_tz_name == "Asia/Urumqi" and (y, mo, d) >= (1949, 10, 1) else geo_tz_name
        try:
            geo_local = civil.replace(tzinfo=ZoneInfo(geo_name))
            if fixed.utcoffset(None) not in {geo_local.utcoffset(), civil.replace(tzinfo=ZoneInfo(geo_name), fold=1).utcoffset()}:
                iana_name = geo_name
                resolved_offset = geo_local.utcoffset()
                dst = geo_local.dst()
                if dst and dst.total_seconds() > 0:
                    add("info", "dst.active",
                        f"出生时当地正在实行夏令时（{geo_name}），钟表比标准时间快 {int(dst.total_seconds() // 60)} 分钟。")
        except (ZoneInfoNotFoundError, ValueError):
            pass
    if fixed is not None:
        fold_offsets = set()
        if iana_name:
            try:
                fold_offsets = {civil.replace(tzinfo=ZoneInfo(iana_name), fold=f).utcoffset() for f in (0, 1)}
            except (ZoneInfoNotFoundError, ValueError):
                fold_offsets = set()
        if resolved_offset is not None and fixed.utcoffset(None) != resolved_offset and fixed.utcoffset(None) not in fold_offsets:
            diff = abs((fixed.utcoffset(None) - resolved_offset).total_seconds()) / 60
            if prefer_fixed_zone:
                add("risk", "zone.mismatch",
                    f"你指定按固定时区 {zone_text} 计算，但出生地当天的法定时间是 {_fmt_offset(resolved_offset)}（{iana_name}），"
                    f"差 {diff:.0f} 分钟。已按你指定的 {zone_text} 计算。")
                instant, resolved_offset, iana_name = civil.replace(tzinfo=fixed), fixed.utcoffset(None), None
            else:
                add("risk", "zone.mismatch",
                    f"传入的时区是 {zone_text}，但出生地在那一天的法定时间是 {_fmt_offset(resolved_offset)}（{iana_name}），"
                    f"差 {diff:.0f} 分钟。出生证、医院记录写的都是当时的钟表时间，所以已改按 {iana_name} 计算；"
                    "只有确认记录的是标准时间（例如家人已自行减过一小时）时，才应坚持固定时区。")
                instant = civil.replace(tzinfo=ZoneInfo(iana_name))  # type: ignore[arg-type]
        else:
            instant = civil.replace(tzinfo=fixed)
            resolved_offset = fixed.utcoffset(None)
    if instant is None:
        instant = civil.replace(tzinfo=BEIJING)
        resolved_offset = timedelta(hours=8)
        add("warn", "zone.assumed", "没有时区也没有出生地，暂按北京时间（+08:00）估算。")

    # 4) 真太阳时
    report: dict[str, Any] = {
        "ok": True,
        "input": {"date": date, "time": time, "zone": zone, "place": place},
        "civil_time": civil.strftime("%Y-%m-%d %H:%M:%S"),
        "utc_offset": _fmt_offset(resolved_offset),
        "timezone_name": iana_name,
        "location": None,
    }
    if place_info and place_info.get("ok"):
        report["location"] = place_info["best"]
    elif lat_v is not None and lon_v is not None:
        report["location"] = {"lat": lat_v, "lon": lon_v, "timezone": geo_tz_name, "precision": "coordinates"}

    tst_dt: datetime
    if lon_v is not None:
        tst = true_solar_time(instant, lon_v)
        tst_dt = tst["true_solar_time"]  # type: ignore[assignment]
        report["true_solar"] = {
            "true_solar_time": tst_dt.strftime("%Y-%m-%d %H:%M:%S"),
            "local_mean_time": tst["local_mean_time"].strftime("%Y-%m-%d %H:%M:%S"),  # type: ignore[union-attr]
            "longitude_correction_minutes": tst["longitude_correction_minutes"],
            "equation_of_time_minutes": tst["equation_of_time_minutes"],
            "total_correction_minutes": tst["total_correction_minutes"],
        }
        total = float(tst["total_correction_minutes"])  # type: ignore[arg-type]
        dst_delta = instant.dst() if instant.tzinfo is not None else None
        dst_minutes = (dst_delta.total_seconds() / 60.0) if dst_delta else 0.0
        eot = float(tst["equation_of_time_minutes"])  # type: ignore[arg-type]
        lon_part = total - eot + dst_minutes
        report["true_solar"]["breakdown"] = {
            "longitude_vs_standard_meridian_minutes": round(lon_part, 1),
            "daylight_saving_minutes": round(-dst_minutes, 1),
            "equation_of_time_minutes": round(eot, 1),
        }
        if abs(total) >= 30:
            parts = [f"经度 {lon_part:+.0f} 分"]
            if dst_minutes:
                parts.append(f"夏令时 {-dst_minutes:+.0f} 分")
            parts.append(f"均时差 {eot:+.1f} 分")
            add("warn", "tst.large",
                f"真太阳时与钟表时间相差 {total:+.0f} 分钟（{' + '.join(parts)}）。八字、紫微默认按真太阳时取时辰。")
    else:
        tst_dt = civil
        report["true_solar"] = None

    # 5) 时辰与交界
    clock_idx = shichen_index(civil.hour, civil.minute)
    tst_idx = shichen_index(tst_dt.hour, tst_dt.minute)
    gap, boundary_label = minutes_to_shichen_boundary(tst_dt)
    location_unc = float((report.get("location") or {}).get("true_solar_uncertainty_minutes") or 0.0)
    effective_window = boundary_minutes + location_unc + float(time_uncertainty_minutes or 0)
    report["shichen"] = {
        "by_clock": SHICHEN_NAMES[clock_idx],
        "by_true_solar": SHICHEN_NAMES[tst_idx],
        "true_solar_range": SHICHEN_RANGES[tst_idx],
        "minutes_to_boundary": gap,
        "nearest_boundary": boundary_label,
    }
    if clock_idx != tst_idx and lon_v is not None:
        add("risk", "shichen.clock_vs_tst",
            f"按钟表时间是{SHICHEN_NAMES[clock_idx]}，按真太阳时是{SHICHEN_NAMES[tst_idx]}。"
            "八字、紫微通常用真太阳时；不同软件口径不同会排出两张盘，这是最常见的「为什么和别处算的不一样」。")
    boundary_risk = gap <= effective_window
    if boundary_risk:
        add("risk", "shichen.boundary",
            f"真太阳时离{boundary_label}分界只有 {gap:.0f} 分钟（考虑地点与记录误差后的安全边际是 {effective_window:.0f} 分钟），"
            "时柱可能落在相邻时辰。建议两个时辰都排一遍对照，或用人生大事校时。")
        ask_user.append("出生时间是怎么记录的？（出生证明/医院记录/家人回忆）大概准确到几分钟？")

    # 6) 晚子时
    if tst_dt.hour == 23:
        add("info", "zi.late",
            "出生在晚子时（23:00–24:00）。日柱有两派口径：晚子时算次日（玄枢缺省）或仍算当天。"
            "两派日柱不同，命理解读差别很大，下面同时给出两种结果。")

    # 7) 节气交界
    jie = _nearest_jie(instant)
    report["solar_term"] = jie
    nearest = jie["nearest"]
    hours = abs(nearest["hours_from_birth"])
    jie_window_hours = max(2.0, effective_window / 60.0 * 2)
    if nearest["name"] in JIE_NAMES and hours <= 24:
        level = "risk" if hours <= jie_window_hours else "info"
        side = "之后" if nearest["hours_from_birth"] < 0 else "之前"
        extra = "（立春还决定年柱与生肖）" if nearest["name"] == "立春" else ""
        add(level, "jieqi.boundary",
            f"出生在{nearest['name']}{side}约 {hours:.1f} 小时（交节时刻北京时间 {nearest['beijing_time']}）。"
            f"月柱以交节时刻为界{extra}。" + ("时间稍有误差就可能换月柱，请务必核实出生时间。" if level == "risk" else ""))

    # 8) 参考四柱（含交界候选）
    pillars = reference_pillars(instant, tst_dt, late_zi_next_day=late_zi_next_day)
    report["reference_pillars"] = pillars
    alternatives: list[dict[str, Any]] = []
    if boundary_risk:
        shift = gap + 1
        direction = -1 if (tst_dt.hour * 60 + tst_dt.minute) % 120 >= 60 else 1
        other = tst_dt + timedelta(minutes=direction * shift)
        alt = reference_pillars(instant + timedelta(minutes=direction * shift), other, late_zi_next_day=late_zi_next_day)
        alternatives.append({"why": "时辰交界另一侧", "true_solar_time": other.strftime("%H:%M"), "pillars": alt})
    if tst_dt.hour == 23:
        alt = reference_pillars(instant, tst_dt, late_zi_next_day=not late_zi_next_day)
        alternatives.append({"why": "晚子时另一派口径（日柱" + ("算当天" if late_zi_next_day else "算次日") + "）", "pillars": alt})
    if nearest["name"] in JIE_NAMES and hours <= jie_window_hours:
        delta = timedelta(hours=nearest["hours_from_birth"]) + timedelta(minutes=1 if nearest["hours_from_birth"] > 0 else -1)
        alt = reference_pillars(instant + delta, tst_dt, late_zi_next_day=late_zi_next_day)
        alternatives.append({"why": f"{nearest['name']}交节另一侧", "pillars": alt})
    report["alternatives"] = alternatives
    if pillars["zodiac_by_lichun"] != pillars["zodiac_by_lunar_new_year"]:
        add("info", "zodiac.split",
            f"生肖有两种说法：按立春算属{pillars['zodiac_by_lichun']}（命理用这个），"
            f"按农历正月初一算属{pillars['zodiac_by_lunar_new_year']}（民俗常用）。")

    # 9) 评级与载荷
    levels = [f["level"] for f in findings]
    grade = "C" if "risk" in levels else ("B" if "warn" in levels or not report["location"] else "A")
    report["grade"] = grade
    report["grade_text"] = {
        "A": "出生信息完整，时辰与月柱都不在交界附近，可以放心起盘。",
        "B": "可以起盘，但有需要留意的地方（见体检项），解读时请把这些口径说清楚。",
        "C": "存在交界或时区风险，单张盘的结论可能整体偏掉。建议先核实出生时间，或对候选盘双盘对照。",
    }[grade]
    report["findings"] = findings
    report["ask_user"] = ask_user
    payload_fields: dict[str, Any] = {"date": civil.strftime("%Y-%m-%d"), "time": civil.strftime("%H:%M:%S")}
    payload_fields["zone"] = iana_name or _fmt_offset(resolved_offset)
    if lat_v is not None and lon_v is not None:
        payload_fields["lat"] = round(lat_v, 4)
        payload_fields["lon"] = round(lon_v, 4)
    if report["location"] and report["location"].get("name_zh"):
        payload_fields["pos"] = report["location"]["name_zh"]
    report["payload_fields"] = payload_fields
    report["plain_summary"] = _plain_summary(report)
    return report


def _plain_summary(report: dict[str, Any]) -> str:
    lines = [f"【出生时间体检：{report['grade']} 级】{report['grade_text']}"]
    loc = report.get("location") or {}
    if loc:
        name = loc.get("name_zh") or loc.get("name") or f"{loc.get('lat')},{loc.get('lon')}"
        lon_v, lat_v = float(loc.get("lon") or 0), float(loc.get("lat") or 0)
        ew = f"东经 {lon_v:.2f}°" if lon_v >= 0 else f"西经 {-lon_v:.2f}°"
        ns = f"北纬 {lat_v:.2f}°" if lat_v >= 0 else f"南纬 {-lat_v:.2f}°"
        province = loc.get("province") or ""
        if province and name and province.startswith(name):
            province = ""
        lines.append(f"出生地：{province}{name}（{ew}，{ns}），时区 {report.get('timezone_name') or report['utc_offset']}。")
    lines.append(f"钟表时间：{report['civil_time']}（UTC{report['utc_offset']}）。")
    tst = report.get("true_solar")
    if tst:
        lines.append(f"真太阳时：{tst['true_solar_time']}（校正 {tst['total_correction_minutes']:+.1f} 分钟）。")
    sc = report["shichen"]
    lines.append(f"时辰：{sc['by_true_solar']}（{sc['true_solar_range']}），距{sc['nearest_boundary']}分界 {sc['minutes_to_boundary']:.0f} 分钟。")
    p = report["reference_pillars"]
    lines.append(f"参考四柱：{p['year']} {p['month']} {p['day']} {p['time']}；农历 {p['lunar_date']}；生肖 {p['zodiac_by_lichun']}。")
    for item in report["findings"]:
        tag = {"risk": "⚠ 风险", "warn": "注意", "info": "说明"}[item["level"]]
        lines.append(f"{tag}：{item['text']}")
    for alt in report.get("alternatives", []):
        ap = alt["pillars"]
        lines.append(f"候选盘（{alt['why']}）：{ap['year']} {ap['month']} {ap['day']} {ap['time']}。")
    return "\n".join(lines)


__all__ = ["birth_check", "minutes_to_shichen_boundary", "reference_pillars", "shichen_index"]
