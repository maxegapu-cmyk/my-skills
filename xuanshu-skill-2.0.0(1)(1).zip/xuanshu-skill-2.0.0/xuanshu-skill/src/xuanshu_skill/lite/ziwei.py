"""轻量引擎 · 紫微斗数（iztro-py，MIT；通用·飞星四化口径）。

起盘时辰按真太阳时取（与完整引擎缺省 timeAlg=0 一致）；23 点后为晚子时。
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from xuanshu_skill.lite.common import build_snapshot, gender_of, resolve_moment, table

_STEM_KEYS = {"jia": "甲", "yi": "乙", "bing": "丙", "ding": "丁", "wu": "戊", "ji": "己", "geng": "庚", "xin": "辛", "ren": "壬", "gui": "癸"}
_BRANCH_KEYS = {"zi": "子", "chou": "丑", "yin": "寅", "mao": "卯", "chen": "辰", "si": "巳", "wu": "午", "wei": "未",
                "shen": "申", "you": "酉", "xu": "戌", "hai": "亥"}
MUTAGENS = ["化禄", "化权", "化科", "化忌"]


def _stem(key: str) -> str:
    return _STEM_KEYS.get(key.replace("Heavenly", ""), key)


def _branch(key: str) -> str:
    return _BRANCH_KEYS.get(key.replace("Earthly", ""), key)


def _time_index(local: datetime) -> int:
    h = local.hour
    if h == 23:
        return 12
    return (h + 1) // 2


def run(inp: dict[str, Any]) -> dict[str, Any]:
    import iztro_py

    m = resolve_moment(inp)
    gender = gender_of(inp)
    if gender is None:
        return build_snapshot("ziwei_birth", "紫微斗数", [("起盘信息", "紫微斗数需要性别，请补充性别后重新起盘。")])
    local = m["local"]
    idx = _time_index(local)
    astro = iztro_py.by_solar(f"{local.year}-{local.month}-{local.day}", idx, "男" if gender == 1 else "女", True, "zh-CN")
    raw = astro.model_dump()
    zh = astro.to_iztro_dict()

    star_name: dict[str, str] = {}
    palace_name: dict[str, str] = {}
    for rp, zp in zip(raw["palaces"], zh["palaces"]):
        palace_name[rp["name"]] = zp["name"]
        for kind in ("major_stars", "minor_stars", "adjective_stars"):
            zkind = {"major_stars": "majorStars", "minor_stars": "minorStars", "adjective_stars": "adjectiveStars"}[kind]
            for rs, zs in zip(rp[kind], zp[zkind]):
                star_name[rs["name"]] = zs["name"]

    sections: list[tuple[str, str]] = []
    sections.append(("起盘信息", "\n".join([
        f"公历（钟表）：{m['civil']:%Y-%m-%d %H:%M}　起盘时间：{local:%Y-%m-%d %H:%M}（{m['basis']}）",
        f"农历：{zh['lunarDate']}　干支：{zh['chineseDate']}　时辰：{zh['time']}（{zh['timeRange']}）",
        f"性别：{zh['gender']}　生肖：{zh['zodiac']}　五行局：{zh['fiveElementsClass']}",
        f"命宫在{zh['earthlyBranchOfSoulPalace']}，身宫在{zh['earthlyBranchOfBodyPalace']}；命主 {zh['soul']}，身主 {zh['body']}",
        "四化口径：通用（飞星）；闰月按 iztro 默认（前半月算本月、后半月算下月）。",
    ])))

    def star_text(stars: list[dict[str, Any]], *, brightness: bool = True, empty_note: bool = False) -> str:
        parts = []
        for s in stars:
            label = s["name"]
            if brightness and s.get("brightness"):
                label += f"({s['brightness']})"
            if s.get("mutagen"):
                label += f"[化{s['mutagen']}]"
            parts.append(label)
        return "、".join(parts) or ("—（空宫，借对宫主星）" if empty_note else "—")

    rows = []
    sihua_lines = []
    for p in zh["palaces"]:
        name = p["name"] + ("（身宫）" if p.get("isBodyPalace") else "")
        dec = p.get("decadal") or {}
        rng = dec.get("range") if isinstance(dec, dict) else None
        rows.append([
            name, f"{p['heavenlyStem']}{p['earthlyBranch']}",
            star_text(p["majorStars"], empty_note=True), star_text(p["minorStars"]),
            "、".join(s["name"] for s in p["adjectiveStars"][:6]) or "—",
            p.get("changsheng12") or "", f"{rng[0]}–{rng[1]}" if rng else "",
        ])
        for s in p["majorStars"] + p["minorStars"]:
            if s.get("mutagen"):
                sihua_lines.append(f"{s['name']}化{s['mutagen']} → 落{p['name']}")
    # 大限区间从 raw 取（to_iztro_dict 不带）
    for row, rp in zip(rows, raw["palaces"]):
        rng = (rp.get("decadal") or {}).get("range")
        if rng:
            row[-1] = f"{rng[0]}–{rng[1]} 岁"
    sections.append(("十二宫", table(["宫位", "干支", "主星（亮度/四化）", "辅星", "杂曜", "长生", "大限"], rows)))
    sections.append(("生年四化", "\n".join(sihua_lines) or "—"))

    target = str(inp.get("horoscopeDate") or inp.get("transitDate") or datetime.now().strftime("%Y-%m-%d"))
    try:
        h = astro.horoscope(target, idx).model_dump()
        idx_to_palace = {i: (zh["palaces"][i]["name"], zh["palaces"][i]["earthlyBranch"]) for i in range(12)}
        lines = [f"参照日期：{target}"]
        for key, label in (("decadal", "大限"), ("age", "小限"), ("yearly", "流年")):
            item = h.get(key) or {}
            if not item:
                continue
            pi = item.get("index")
            pname, pbranch = idx_to_palace.get(pi, ("?", "?"))
            muts = [star_name.get(s, s) for s in (item.get("mutagen") or [])]
            mut_text = "、".join(f"{s}{MUTAGENS[i]}" for i, s in enumerate(muts) if i < 4)
            lines.append(
                f"{label}：{_stem(item.get('heavenly_stem', ''))}{_branch(item.get('earthly_branch', ''))}，"
                f"{label}命宫落本命{pname}（{pbranch}）；{label}四化：{mut_text}"
            )
            if key in {"decadal", "yearly"}:
                where = []
                for i, s in enumerate(muts[:4]):
                    for p in zh["palaces"]:
                        if any(st["name"] == s for st in p["majorStars"] + p["minorStars"]):
                            where.append(f"{s}{MUTAGENS[i]}入本命{p['name']}")
                if where:
                    lines.append(f"  {label}四化落宫：" + "；".join(where))
        sections.append(("大限流年", "\n".join(lines)))
    except Exception as exc:  # noqa: BLE001 — 运限是附加段，失败不影响本命盘
        sections.append(("大限流年", f"运限计算未完成：{exc}"))

    data = {"soul_palace_branch": zh["earthlyBranchOfSoulPalace"], "five_elements_class": zh["fiveElementsClass"],
            "time_index": idx, "chinese_date": zh["chineseDate"]}
    return build_snapshot("ziwei_birth", "紫微斗数", sections, data)


__all__ = ["run"]
