"""轻量引擎公共件：出生时刻解析（含真太阳时）、导出快照构造。"""
from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from typing import Any

from xuanshu_skill.input_normalization import _coerce_coordinate_decimal
from xuanshu_skill.precision.solar import true_solar_time

LITE_ENGINE_NOTE = (
    "本次由玄枢轻量引擎（纯 Python，无需下载离线 runtime）计算；结果的核心盘面与完整引擎一致，"
    "细节段落较少。需要全部段落时可安装完整引擎：uv run xuanshu install。"
)

_ZONE_RE = re.compile(r"^(?P<sign>[+-])(?P<h>\d{1,2}):?(?P<m>\d{2})?$")
STEMS = "甲乙丙丁戊己庚辛壬癸"
BRANCHES = "子丑寅卯辰巳午未申酉戌亥"


def parse_zone(value: Any) -> timezone:
    text = str(value or "+08:00").strip().upper().replace("UTC", "").replace("GMT", "") or "+00:00"
    if text in {"Z", "+00", "0"}:
        return timezone.utc
    m = _ZONE_RE.match(text)
    if not m:
        try:
            hours = float(text)
            return timezone(timedelta(hours=hours))
        except ValueError:
            return timezone(timedelta(hours=8))
    sign = -1 if m.group("sign") == "-" else 1
    return timezone(sign * timedelta(hours=int(m.group("h")), minutes=int(m.group("m") or 0)))


def parse_local(date: Any, time: Any) -> datetime:
    d = [int(x) for x in re.split(r"[-/.]", str(date).strip())[:3]]
    t = [int(x) for x in re.split(r"[:：]", str(time or "12:00").strip()) if x != ""]
    t = (t + [0, 0, 0])[:3]
    return datetime(d[0], d[1], d[2], t[0], t[1], t[2])


def coord(inp: dict[str, Any], axis: str) -> float | None:
    gps = inp.get("gpsLat" if axis == "lat" else "gpsLon")
    if isinstance(gps, (int, float)):
        return float(gps)
    return _coerce_coordinate_decimal(inp.get(axis))


def resolve_moment(inp: dict[str, Any], *, use_true_solar: bool = True) -> dict[str, Any]:
    """出生/起卦时刻：钟表时间、绝对时刻、真太阳时（缺经度则退回钟表时间）。"""
    civil = parse_local(inp.get("date"), inp.get("time"))
    tz = parse_zone(inp.get("zone"))
    instant = civil.replace(tzinfo=tz)
    lat, lon = coord(inp, "lat"), coord(inp, "lon")
    time_alg = str(inp.get("timeAlg", 0))
    if lon is not None and use_true_solar and time_alg != "1":
        tst = true_solar_time(instant, lon)
        local = tst["true_solar_time"]
        basis = f"真太阳时（经度 {lon:.2f}°，校正 {tst['total_correction_minutes']:+.1f} 分钟）"
    else:
        local = civil
        basis = "钟表时间（未做真太阳时校正）"
    return {"civil": civil, "instant": instant, "local": local, "lat": lat, "lon": lon, "basis": basis, "zone": tz}


def gender_of(inp: dict[str, Any]) -> int | None:
    g = inp.get("gender", inp.get("sex"))
    if g in (1, "1", "男", "male", "m", "M"):
        return 1
    if g in (0, "0", "女", "female", "f", "F"):
        return 0
    return None


def build_snapshot(tool: str, label: str, sections: list[tuple[str, str]], data: dict[str, Any] | None = None) -> dict[str, Any]:
    """组装与完整引擎同形的 export_snapshot（[段名] + 正文），供合参 / 报告 / 记忆直接复用。"""
    sections = [(title, body.strip()) for title, body in sections if body and body.strip()]
    text = "\n\n".join(f"[{title}]\n{body}" for title, body in sections)
    export = {
        "technique": {"key": f"lite_{tool}", "label": f"{label}（轻量引擎）"},
        "section_titles_detected": [t for t, _ in sections],
        "selected_sections": [t for t, _ in sections],
        "missing_selected_sections": [],
        "unknown_detected_sections": [],
        "sections": [
            {"index": i + 1, "raw_title": t, "title": t, "included": True, "body": b} for i, (t, b) in enumerate(sections)
        ],
        "export_text": text,
        "format_source": "xuanshu_lite",
        "provenance": {"source_domain": "xuanshu_lite_engine", "technique": tool},
        "citation": f"Xuanshu lite engine · {label}",
    }
    return {"snapshot_text": text, "export_snapshot": export, "lite": data or {}, "_warnings": [LITE_ENGINE_NOTE]}


def table(headers: list[str], rows: list[list[Any]]) -> str:
    out = ["| " + " | ".join(headers) + " |", "| " + " | ".join("---" for _ in headers) + " |"]
    out += ["| " + " | ".join(str(c) for c in row) + " |" for row in rows]
    return "\n".join(out)


__all__ = [
    "BRANCHES", "LITE_ENGINE_NOTE", "STEMS", "build_snapshot", "coord", "gender_of", "parse_local", "parse_zone",
    "resolve_moment", "table",
]
