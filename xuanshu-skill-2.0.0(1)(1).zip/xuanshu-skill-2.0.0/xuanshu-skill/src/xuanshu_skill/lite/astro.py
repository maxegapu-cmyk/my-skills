"""轻量引擎 · 西洋占星：本命盘 / 太阳返照 / 小限（astronomy-engine，MIT，纯 Python）。

星体位置：几何视位置（含光行差），真黄道与真春分点（of date），与 Swiss Ephemeris 差在角分级以内。
宫制：0 整宫、1 Alcabitus（缺省）、3 Placidus、9 Porphyry、11 等宫；其余宫制回退 Alcabitus 并注明。
"""
from __future__ import annotations

import math
from datetime import datetime, timedelta, timezone
from typing import Any

import astronomy as A

from xuanshu_skill.lite.common import build_snapshot, coord, parse_local, parse_zone, resolve_moment, table

SIGNS = ["白羊座", "金牛座", "双子座", "巨蟹座", "狮子座", "处女座", "天秤座", "天蝎座", "射手座", "摩羯座", "水瓶座", "双鱼座"]
SIGN_ELEMENT = ["火", "土", "风", "水"] * 3
SIGN_MODE = ["启动", "固定", "变动"] * 4
BODIES = [
    ("太阳", A.Body.Sun), ("月亮", A.Body.Moon), ("水星", A.Body.Mercury), ("金星", A.Body.Venus), ("火星", A.Body.Mars),
    ("木星", A.Body.Jupiter), ("土星", A.Body.Saturn), ("天王星", A.Body.Uranus), ("海王星", A.Body.Neptune), ("冥王星", A.Body.Pluto),
]
RULER = {0: "火星", 1: "金星", 2: "水星", 3: "月亮", 4: "太阳", 5: "水星", 6: "金星", 7: "火星", 8: "木星", 9: "土星", 10: "土星", 11: "木星"}
DOMICILE = {"太阳": [4], "月亮": [3], "水星": [2, 5], "金星": [1, 6], "火星": [0, 7], "木星": [8, 11], "土星": [9, 10]}
EXALT = {"太阳": 0, "月亮": 1, "水星": 5, "金星": 11, "火星": 9, "木星": 3, "土星": 6}
ASPECTS = [("合相", 0, 8), ("六分相", 60, 5), ("四分相", 90, 7), ("三分相", 120, 7), ("对分相", 180, 8)]
HOUSE_MEANING = {1: "自我、外貌、人生起点", 2: "金钱、资源、价值观", 3: "沟通、学习、兄弟姐妹", 4: "家庭、根基、父母",
                 5: "恋爱、创造、子女", 6: "工作日常、健康", 7: "伴侣、合作、对手", 8: "共有财产、深度关系、转化",
                 9: "高等教育、远行、信仰", 10: "事业、社会地位", 11: "朋友、团体、愿望", 12: "潜意识、隐退、幕后"}
HOUSE_NAMES = {0: "整宫制", 1: "Alcabitus", 3: "Placidus", 9: "Porphyry", 11: "等宫制"}


def norm(x: float) -> float:
    return x % 360.0


def fmt(lon: float) -> str:
    lon = norm(lon)
    sign = int(lon // 30)
    deg = lon - sign * 30
    d = int(deg)
    m = int(round((deg - d) * 60))
    if m == 60:
        d, m = d + 1, 0
    return f"{SIGNS[sign]} {d}°{m:02d}′"


def _time(instant: datetime) -> A.Time:
    u = instant.astimezone(timezone.utc)
    return A.Time.Make(u.year, u.month, u.day, u.hour, u.minute, u.second + u.microsecond / 1e6)


def obliquity(t: A.Time) -> float:
    T = t.tt / 36525.0
    eps0 = 23.0 + (26.0 + (21.448 - T * (46.815 + T * (0.00059 - T * 0.001813))) / 60.0) / 60.0
    omega = math.radians(125.04 - 1934.136 * T)
    return eps0 + 0.00256 * math.cos(omega)


def body_longitude(body: A.Body, t: A.Time) -> float:
    if body == A.Body.Sun:
        return A.SunPosition(t).elon
    if body == A.Body.Moon:
        return A.EclipticGeoMoon(t).lon
    vec = A.GeoVector(body, t, True)
    return A.SphereFromVector(A.RotateVector(A.Rotation_EQJ_ECT(t), vec)).lon


def mean_node(t: A.Time) -> float:
    T = t.tt / 36525.0
    return norm(125.04452 - 1934.136261 * T + 0.0020708 * T * T + T ** 3 / 450000)


def _lam_from_ra(ra: float, eps: float) -> float:
    r, e = math.radians(ra), math.radians(eps)
    return norm(math.degrees(math.atan2(math.sin(r), math.cos(r) * math.cos(e))))


def _decl(lam: float, eps: float) -> float:
    return math.degrees(math.asin(math.sin(math.radians(eps)) * math.sin(math.radians(lam))))


def _dsa(decl: float, lat: float) -> float:
    x = -math.tan(math.radians(lat)) * math.tan(math.radians(decl))
    x = max(-1.0, min(1.0, x))
    return math.degrees(math.acos(x))


def angles(t: A.Time, lat: float, lon: float) -> tuple[float, float, float, float]:
    eps = obliquity(t)
    ramc = norm(A.SiderealTime(t) * 15.0 + lon)
    r, e, f = math.radians(ramc), math.radians(eps), math.radians(lat)
    mc = norm(math.degrees(math.atan2(math.sin(r), math.cos(r) * math.cos(e))))
    asc = norm(math.degrees(math.atan2(math.cos(r), -(math.sin(r) * math.cos(e) + math.tan(f) * math.sin(e)))))
    return asc, mc, ramc, eps


def houses(t: A.Time, lat: float, lon: float, hsys: int) -> tuple[list[float], str]:
    asc, mc, ramc, eps = angles(t, lat, lon)
    note = ""
    if hsys == 3 and abs(lat) >= 66:
        hsys, note = 9, "高纬度下 Placidus 无解，已改用 Porphyry。"
    if hsys not in HOUSE_NAMES:
        note = f"轻量引擎暂不支持该宫制（{hsys}），已改用 Alcabitus。"
        hsys = 1
    cusps = [0.0] * 12
    if hsys == 0:
        start = math.floor(asc / 30) * 30
        cusps = [norm(start + 30 * i) for i in range(12)]
    elif hsys == 11:
        cusps = [norm(asc + 30 * i) for i in range(12)]
    elif hsys == 9:
        q1 = (mc - asc) % 360  # ASC→MC 逆向距离用于 10-1 象限
        span_a = (asc - mc) % 360
        cusps[0], cusps[9] = asc, mc
        cusps[10] = norm(mc + span_a / 3)
        cusps[11] = norm(mc + 2 * span_a / 3)
        ic = norm(mc + 180)
        span_b = (ic - asc) % 360
        cusps[1] = norm(asc + span_b / 3)
        cusps[2] = norm(asc + 2 * span_b / 3)
        del q1
        for i in (0, 1, 2, 9, 10, 11):
            cusps[(i + 6) % 12] = norm(cusps[i] + 180)
    else:
        ramc_ic = norm(ramc + 180)
        if hsys == 1:
            d = _decl(asc, eps)
            dsa = _dsa(d, lat)
            nsa = 180 - dsa
            ra = {11: ramc + dsa / 3, 12: ramc + 2 * dsa / 3, 2: ramc_ic - 2 * nsa / 3, 3: ramc_ic - nsa / 3}
            for h, val in ra.items():
                cusps[h - 1] = _lam_from_ra(val, eps)
        else:  # Placidus
            for h, frac, above in ((11, 1 / 3, True), (12, 2 / 3, True), (2, 2 / 3, False), (3, 1 / 3, False)):
                lam = norm(mc + (30 * (h - 10) if above else 180 + 30 * (h - 4)))
                for _ in range(30):
                    d = _decl(lam, eps)
                    dsa = _dsa(d, lat)
                    ra = ramc + frac * dsa if above else ramc_ic - frac * (180 - dsa)
                    new = _lam_from_ra(ra, eps)
                    if abs((new - lam + 180) % 360 - 180) < 1e-7:
                        lam = new
                        break
                    lam = new
                cusps[h - 1] = lam
        cusps[0], cusps[9] = asc, mc
        for h in (11, 12, 2, 3, 1, 10):
            cusps[(h + 5) % 12] = norm(cusps[h - 1] + 180)
    return cusps, (HOUSE_NAMES[hsys] + (f"（{note}）" if note else ""))


def house_of(lon: float, cusps: list[float]) -> int:
    for i in range(12):
        a, b = cusps[i], cusps[(i + 1) % 12]
        span = (b - a) % 360
        if (lon - a) % 360 < span:
            return i + 1
    return 12


def dignity(name: str, lon: float) -> str:
    if name not in DOMICILE:
        return ""
    sign = int(norm(lon) // 30)
    if sign in DOMICILE[name]:
        return "入庙"
    if EXALT.get(name) == sign:
        return "入旺"
    if (sign + 6) % 12 in DOMICILE[name]:
        return "落陷"
    if EXALT.get(name) is not None and (EXALT[name] + 6) % 12 == sign:
        return "入弱"
    return ""


def compute_chart(instant: datetime, lat: float, lon: float, hsys: int = 1) -> dict[str, Any]:
    t = _time(instant)
    t_next = t.AddDays(0.5)
    t_prev = t.AddDays(-0.5)
    points = []
    for name, body in BODIES:
        lo = body_longitude(body, t)
        speed = ((body_longitude(body, t_next) - body_longitude(body, t_prev) + 540) % 360) - 180
        points.append({"name": name, "lon": lo, "retro": speed < 0 and name not in ("太阳", "月亮"), "speed": speed})
    node = mean_node(t)
    points.append({"name": "北交点", "lon": node, "retro": True, "speed": -0.053})
    cusps, hname = houses(t, lat, lon, hsys)
    asc, mc = cusps[0], cusps[9]
    for p in points:
        p["house"] = house_of(p["lon"], cusps)
        p["dignity"] = dignity(p["name"], p["lon"])
    sun = next(p for p in points if p["name"] == "太阳")
    moon = next(p for p in points if p["name"] == "月亮")
    day_chart = sun["house"] >= 7
    fortune = norm(asc + moon["lon"] - sun["lon"]) if day_chart else norm(asc + sun["lon"] - moon["lon"])
    aspects = []
    for i in range(len(points)):
        for j in range(i + 1, len(points)):
            a, b = points[i], points[j]
            if "北交点" in (a["name"], b["name"]):
                continue
            sep = abs((a["lon"] - b["lon"] + 180) % 360 - 180)
            for asp, angle, orb in ASPECTS:
                extra = 2 if {"太阳", "月亮"} & {a["name"], b["name"]} else 0
                if abs(sep - angle) <= orb + extra:
                    aspects.append({"a": a["name"], "b": b["name"], "aspect": asp, "orb": round(abs(sep - angle), 2)})
    return {"points": points, "cusps": cusps, "asc": asc, "mc": mc, "house_system": hname, "day_chart": day_chart,
            "fortune": fortune, "aspects": aspects}


def _hsys(inp: dict[str, Any]) -> int:
    try:
        return int(inp.get("hsys", 1))
    except (TypeError, ValueError):
        return 1


def _chart_sections(chart: dict[str, Any], *, title_prefix: str = "") -> list[tuple[str, str]]:
    rows = [[p["name"], fmt(p["lon"]), f"第{p['house']}宫", "逆行" if p["retro"] else "", p["dignity"]] for p in chart["points"]]
    rows.append(["上升点 ASC", fmt(chart["asc"]), "第1宫宫头", "", ""])
    rows.append(["天顶 MC", fmt(chart["mc"]), "第10宫宫头", "", ""])
    rows.append(["福点", fmt(chart["fortune"]), f"第{house_of(chart['fortune'], chart['cusps'])}宫", "", ""])
    cusp_rows = [[f"第{i + 1}宫", fmt(c), HOUSE_MEANING[i + 1]] for i, c in enumerate(chart["cusps"])]
    asp_rows = [[a["a"], a["aspect"], a["b"], f"{a['orb']}°"] for a in sorted(chart["aspects"], key=lambda x: x["orb"])]
    elem = {"火": 0, "土": 0, "风": 0, "水": 0}
    mode = {"启动": 0, "固定": 0, "变动": 0}
    for p in chart["points"][:10]:
        s = int(norm(p["lon"]) // 30)
        elem[SIGN_ELEMENT[s]] += 1
        mode[SIGN_MODE[s]] += 1
    sun = chart["points"][0]
    moon = chart["points"][1]
    big3 = (f"太阳{SIGNS[int(sun['lon'] // 30)]}（核心自我，第{sun['house']}宫）　"
            f"月亮{SIGNS[int(moon['lon'] // 30)]}（情绪需求，第{moon['house']}宫）　"
            f"上升{SIGNS[int(chart['asc'] // 30)]}（外在气质）")
    asc_ruler = RULER[int(chart["asc"] // 30)]
    ruler_pt = next(p for p in chart["points"] if p["name"] == asc_ruler)
    return [
        (f"{title_prefix}三巨头", big3 + f"\n命主星（上升守护星）：{asc_ruler}，落{fmt(ruler_pt['lon'])}、第{ruler_pt['house']}宫"
         + f"\n{'昼生盘（太阳在地平线上）' if chart['day_chart'] else '夜生盘（太阳在地平线下）'}；宫制：{chart['house_system']}"),
        (f"{title_prefix}星体位置", table(["星体", "星座度数", "宫位", "逆行", "庙旺"], rows)),
        (f"{title_prefix}宫头", table(["宫位", "宫头", "主管领域"], cusp_rows)),
        (f"{title_prefix}主要相位", table(["星体", "相位", "星体", "容许度"], asp_rows) if asp_rows else "无主要相位"),
        (f"{title_prefix}元素与模式", "元素：" + "　".join(f"{k}{v}" for k, v in elem.items())
         + "\n模式：" + "　".join(f"{k}{v}" for k, v in mode.items())),
    ]


def _need_coords(inp: dict[str, Any]) -> tuple[float, float] | None:
    lat, lon = coord(inp, "lat"), coord(inp, "lon")
    if lat is None or lon is None:
        return None
    return lat, lon


def run_chart(inp: dict[str, Any]) -> dict[str, Any]:
    ll = _need_coords(inp)
    m = resolve_moment(inp, use_true_solar=False)
    if ll is None:
        return build_snapshot("chart", "西洋本命盘", [("起盘信息", "缺少出生地经纬度，无法计算上升点与宫位。请补充出生地（place）。")])
    chart = compute_chart(m["instant"], ll[0], ll[1], _hsys(inp))
    info = (f"出生时间：{m['civil']:%Y-%m-%d %H:%M}（UTC{inp.get('zone') or '+08:00'}）\n"
            f"出生地：{inp.get('pos') or ''} 纬度 {ll[0]:.4f}，经度 {ll[1]:.4f}\n黄道：回归黄道（真春分点）")
    data = {"asc": round(chart["asc"], 4), "mc": round(chart["mc"], 4),
            "points": [{k: (round(v, 4) if isinstance(v, float) else v) for k, v in p.items()} for p in chart["points"]]}
    return build_snapshot("chart", "西洋本命盘", [("起盘信息", info), *_chart_sections(chart)], data)


def run_solarreturn(inp: dict[str, Any]) -> dict[str, Any]:
    ll = _need_coords(inp)
    m = resolve_moment(inp, use_true_solar=False)
    if ll is None:
        return build_snapshot("solarreturn", "太阳返照盘", [("起盘信息", "缺少经纬度，无法起返照盘。")])
    natal_sun = A.SunPosition(_time(m["instant"])).elon
    target = inp.get("datetime") or inp.get("returnDate") or inp.get("year")
    year = int(str(target)[:4]) if target else datetime.now().year
    if year == m["civil"].year:
        year += 0
    start = A.Time.Make(year, m["civil"].month, max(1, m["civil"].day), 0, 0, 0).AddDays(-4)
    hit = A.SearchSunLongitude(natal_sun, start, 10)
    if hit is None:
        return build_snapshot("solarreturn", "太阳返照盘", [("起盘信息", "未找到返照时刻。")])
    utc = hit.Utc()
    instant = utc.replace(tzinfo=timezone.utc) if utc.tzinfo is None else utc
    rlat = coord({"lat": inp.get("dirLat"), "lon": inp.get("dirLon")}, "lat") or ll[0]
    rlon = coord({"lat": inp.get("dirLat"), "lon": inp.get("dirLon")}, "lon") or ll[1]
    chart = compute_chart(instant, rlat, rlon, _hsys(inp))
    tz = parse_zone(inp.get("dirZone") or inp.get("zone"))
    sun = chart["points"][0]
    moon = chart["points"][1]
    natal = compute_chart(m["instant"], ll[0], ll[1], _hsys(inp))
    angular = [f"本命{p['name']}落返照第{house_of(p['lon'], chart['cusps'])}宫" for p in natal["points"][:7]
               if house_of(p["lon"], chart["cusps"]) in (1, 4, 7, 10)]
    focus = "\n".join([
        f"返照年度：{year} 年生日起的一年",
        f"返照上升：{fmt(chart['asc'])} → 今年整体状态与外在表现",
        f"太阳落返照第{sun['house']}宫（{HOUSE_MEANING[sun['house']]}）→ 今年最用力的领域",
        f"月亮落返照第{moon['house']}宫（{HOUSE_MEANING[moon['house']]}）→ 今年情绪与生活重心",
        "本命行星落返照角宫：" + ("；".join(angular) if angular else "无"),
    ])
    info = (f"返照时刻：{instant.astimezone(tz):%Y-%m-%d %H:%M:%S}（UTC{inp.get('dirZone') or inp.get('zone') or '+08:00'}）\n"
            f"返照地点：纬度 {rlat:.4f}，经度 {rlon:.4f}（缺省用出生地）\n本命太阳：{fmt(natal_sun)}")
    return build_snapshot("solarreturn", "太阳返照盘", [("起盘信息", info), ("年度重点", focus), *_chart_sections(chart, title_prefix="返照")],
                          {"return_time_utc": instant.isoformat()})


def run_profection(inp: dict[str, Any]) -> dict[str, Any]:
    ll = _need_coords(inp)
    m = resolve_moment(inp, use_true_solar=False)
    if ll is None:
        return build_snapshot("profection", "小限法", [("起盘信息", "缺少经纬度，无法确定上升星座。")])
    chart = compute_chart(m["instant"], ll[0], ll[1], 0)
    asc_sign = int(chart["asc"] // 30)
    target_text = inp.get("datetime") or inp.get("year")
    target = parse_local(str(target_text)[:10], "12:00") if target_text and len(str(target_text)) >= 8 else datetime.now()
    birth = m["civil"]
    age = target.year - birth.year - ((target.month, target.day) < (birth.month, birth.day))
    rows = []
    for a in range(max(0, age - 1), age + 5):
        house = a % 12 + 1
        sign = (asc_sign + a) % 12
        lord = RULER[sign]
        lp = next(p for p in chart["points"] if p["name"] == lord)
        rows.append([f"{birth.year + a}–{birth.year + a + 1}", f"{a} 岁", f"第{house}宫（{HOUSE_MEANING[house]}）", SIGNS[sign],
                     f"{lord}（本命{fmt(lp['lon'])}，第{lp['house']}宫）"])
    house_now = age % 12 + 1
    lord_now = RULER[(asc_sign + age) % 12]
    summary = (f"当前 {age} 岁，小限走到第{house_now}宫（{HOUSE_MEANING[house_now]}），这是今年的主题领域；"
               f"年主星是{lord_now}，今年它在本命盘与行运中的状态特别关键。")
    return build_snapshot("profection", "小限法", [
        ("起盘信息", f"出生时间：{birth:%Y-%m-%d %H:%M}　上升：{fmt(chart['asc'])}（整宫制起限）"),
        ("当前小限", summary),
        ("小限时间表", table(["生日年度", "年龄", "小限宫", "星座", "年主星"], rows)),
    ], {"age": age, "house": house_now, "year_lord": lord_now})


__all__ = ["compute_chart", "fmt", "run_chart", "run_profection", "run_solarreturn"]
