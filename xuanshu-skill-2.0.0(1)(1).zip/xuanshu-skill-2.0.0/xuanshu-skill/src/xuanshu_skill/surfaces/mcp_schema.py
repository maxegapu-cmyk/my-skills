"""tools/list 广告层瘦身（v0.36.0 B1）：两层 schema —— 广告的是「域核心 + 工具自有字段」，校验的仍是全模型。

为什么不能直接瘦 `__signature__`：FastMCP 按签名生成的 arg model 是 `extra="ignore"`，签名里没有的顶层键
会被静默丢掉（A6 那一类病）。所以签名保持全字段（校验层），注册后只重写 `Tool.parameters`（广告层）。
效果：默认全量 tools/list 1186 KB → ≤256 KB；精简面 93 KB → ≤30 KB（`scripts/verify_mcp_list_budget.py` 棘轮）。

广告层规则：
- BirthInput 族：域核心（西占/推运/chart：date/time/zone/lat/lon/ad/hsys/zodiacal/siderealAyanamsa；中式/神数：
  去掉宫制/黄道/岁差，加 gender/timeAlg）+ 推运目标字段（PREDICTIVE_INPUT_CONTRACTS）+ 工具自有字段（模型上
  非 BirthInput 继承的字段）+ 闸门三键 + `request` 逃生舱（注明还有 N 个高级旋钮按名接受，全表见
  xuanshu_agent_guidance）；`additionalProperties: true`。
- 非 BirthInput 的小模型：全部字段照广告（本来就小）。
- 枚举只进广告层：hsys（西占用 ASTRO_HOUSE_SYSTEM_TEXT，印占用 INDIA_HOUSE_SYSTEM_LABELS）、zodiacal、ad、
  response_view、siderealAyanamsa（47 制）。
- dispatch/hecan：5 路 union 内联两次（各 24 KB）→ 单一宽松对象。
- 描述：去掉每工具重复的澄清闸段（server instructions 已讲），只留技法双语一句 + 指引一行。
"""
from __future__ import annotations

from typing import Any

from xuanshu_skill.agent_guidance import PREDICTIVE_INPUT_CONTRACTS
from xuanshu_skill.astro_sidereal import INDIA_HOUSE_SYSTEM_LABELS, SIDEREAL_AYANAMSA_LABELS
from xuanshu_skill.engine.registry import TOOL_DEFINITIONS
from xuanshu_skill.engine.synonyms import aka_line
from xuanshu_skill.schemas.tools import BirthInput

GATE_KEYS: tuple[str, ...] = ("agent_confirmed_settings", "defaults_accepted", "clarification_notes")
# name/pos（显示名）已声明、顶层照收，但不进广告层：两字段 × 80 工具 ≈ 10 KB，只是盘头文字。
ASTRO_CORE: tuple[str, ...] = (
    "date", "time", "zone", "lat", "lon", "ad", "hsys", "zodiacal", "siderealAyanamsa", "response_view",
)
CN_CORE: tuple[str, ...] = ("date", "time", "zone", "lat", "lon", "ad", "gender", "timeAlg", "response_view")
DOMAIN_CORE: dict[str, tuple[str, ...]] = {
    "astro": ASTRO_CORE,
    "predict": ASTRO_CORE,
    "chart": ASTRO_CORE,
    "cn": CN_CORE,
    "shenshu": CN_CORE,
}
# 域核心字段的短描述（广告层专用；校验层的长描述仍在模型上，guidance 可查）。
CORE_DOC: dict[str, str] = {
    "date": "公历日期 YYYY-MM-DD",
    "time": "HH:mm:ss",
    "zone": "时区偏移，如 +08:00",
    "lat": "纬度 31n13 / 31.22",
    "lon": "经度 121e28 / 121.47",
    "ad": "1=公元（默认） -1=公元前",
    "hsys": "宫制索引（见 enum；1=Alcabitus，3=Placidus）",
    "zodiacal": "0=回归（默认） 1=恒星",
    "siderealAyanamsa": "恒星黄道岁差制（zodiacal=1 时）",
    "name": "当事人姓名（透传盘头）",
    "pos": "地点显示名",
    "gender": "性别 1/男 0/女",
    "timeAlg": "0=真太阳时 1=钟表时",
    "response_view": "响应裁剪（完整结果已存档）",
    "agent_confirmed_settings": "用户已确认设置→true",
    "defaults_accepted": "用户接受默认→true",
    "clarification_notes": "确认摘要",
}
CORE_TYPE: dict[str, Any] = {
    "date": "string", "time": "string", "zone": "string", "lat": ["string", "number"], "lon": ["string", "number"],
    "ad": "integer", "hsys": "integer", "zodiacal": "integer", "siderealAyanamsa": "string", "name": "string",
    "pos": "string", "gender": ["integer", "string"], "timeAlg": "integer", "response_view": "string",
    "agent_confirmed_settings": "boolean", "defaults_accepted": "boolean", "clarification_notes": "string",
}
OWN_FIELD_DOC_LIMIT = 72  # 字符；工具自有字段描述超长截断（全文见 xuanshu_agent_guidance）
DESCRIPTION_CHAR_LIMIT = 200  # 字符；技法双语描述超长截断（全文在 guidance / 技法目录资源）


def _enum_for(field: str, tool_name: str) -> dict[str, Any]:
    if field == "hsys":
        table = INDIA_HOUSE_SYSTEM_LABELS if tool_name.startswith("india") else {int(k): v for k, v in _astro_house_table().items()}
        short = {"整宫制": "整宫", "Vehlow Equal": "Vehlow", "Polich Page": "PolichPage", "天顶为10宫中点等宫制": "MC10宫等宫"}
        legend = " ".join(f"{k}={short.get(table[k], table[k])}" for k in sorted(table))
        return {"enum": sorted(table), "description": legend}
    if field == "zodiacal":
        return {"enum": [0, 1]}
    if field == "ad":
        return {"enum": [1, -1]}
    if field == "response_view":
        return {"enum": ["full", "sections", "titles"]}
    if field == "siderealAyanamsa":
        # 47 制的 enum 每工具 600 B × 80 工具 = 48 KB，超预算；只给常用键，全表见 guidance。
        common = [k for k in ("lahiri", "raman", "krishnamurti", "fagan_bradley", "yukteshwar") if k in SIDEREAL_AYANAMSA_LABELS]
        return {"description": f"岁差制（zodiacal=1）：{'/'.join(common)}…共 {len(SIDEREAL_AYANAMSA_LABELS)} 制见 guidance"}
    return {}


def _astro_house_table() -> dict[str, str]:
    # 延迟导入：service 模块很重，且 mcp_schema 不能反向让 service 依赖它。
    from xuanshu_skill.service import ASTRO_HOUSE_SYSTEM_TEXT

    return ASTRO_HOUSE_SYSTEM_TEXT


def _core_property(field: str, tool_name: str, required: bool) -> dict[str, Any]:
    prop: dict[str, Any] = {"type": CORE_TYPE.get(field, "string"), "description": CORE_DOC.get(field, field)}
    prop.update(_enum_for(field, tool_name))  # enum 源自带 description 时覆盖短描述（hsys 全表 / 岁差制）
    if required:
        prop["description"] = f"[required] {prop['description']}"
    return prop


def _own_property(field: str, full_prop: dict[str, Any], required: bool) -> dict[str, Any]:
    prop = {k: v for k, v in full_prop.items() if k in {"type", "enum", "items", "anyOf", "description"}}
    desc = str(prop.get("description") or "").strip()
    if len(desc) > OWN_FIELD_DOC_LIMIT:
        prop["description"] = desc[: OWN_FIELD_DOC_LIMIT - 1] + "…"
    if "anyOf" in prop and "type" not in prop:
        types = sorted({str(a.get("type")) for a in prop["anyOf"] if isinstance(a, dict) and a.get("type")})
        prop.pop("anyOf", None)
        prop["type"] = types if len(types) > 1 else (types[0] if types else "string")
    if "items" in prop and isinstance(prop["items"], dict):
        prop["items"] = {k: v for k, v in prop["items"].items() if k in {"type", "enum"}} or {}
    if required and not str(prop.get("description", "")).startswith("[required]"):
        prop["description"] = f"[required] {prop.get('description', '')}".strip()
    return prop


def _request_property(hidden: list[str], tool_name: str) -> dict[str, Any]:
    text = "整包载荷"
    if hidden:
        text += f"；另 {len(hidden)} 个高级旋钮顶层按名可传（全表见 guidance）"
    return {"type": ["object", "string"], "description": text}


def advertise_hidden_fields(model: type[Any]) -> frozenset[str]:
    """输入模型可声明 `ADVERTISE_HIDDEN: ClassVar[frozenset[str]]`：这些字段**照常声明**（校验层照收、MCP 扁平签名
    照收顶层键——未声明的键会被 FastMCP 的 arg model 静默丢掉，见 test_mcp_flat_surface_keys），只是不进广告层，
    计入 `request` 描述里的「另 N 个高级旋钮」、全表与词表见 xuanshu_agent_guidance。
    为什么（v0.40.0 tools/list 预算）：长尾口径旋钮每个广告出去 ~100 B，一个技法补齐上游几十个就是几 KB，
    而全量面硬顶 256 KB 已近满；声明而不广告 = 零字节、功能与类型校验全保留。"""
    hidden: set[str] = set()
    for cls in getattr(model, "__mro__", ()):
        hidden |= set(vars(cls).get("ADVERTISE_HIDDEN", ()) or ())
    return frozenset(hidden)


def advertised_technique_schema(tool_name: str, full_schema: dict[str, Any]) -> dict[str, Any]:
    """技法工具的广告层 inputSchema（校验层不动）。"""
    definition = TOOL_DEFINITIONS[tool_name]
    model = definition.input_model
    props = dict(full_schema.get("properties") or {})
    required = {k for k, v in props.items() if isinstance(v, dict) and v.get("x-xuanshu-required")}
    keep: list[str] = []
    # 「已声明、不广告」两种声明法取并集：模型级 `ADVERTISE_HIDDEN`（西占长尾旋钮）与字段级 `x-xuanshu-hidden`
    # （v0.40 mingli：紫微 22 传本键 / 八字盘法键等长词表）。校验层照收（MCP 顶层按名可传），只从广告层剔除、
    # 计入隐藏旋钮数；键表与取值进 xuanshu_agent_guidance。🔴 曾合并成后者覆盖前者 → 西占旋钮全部回到广告层，
    # tools/list 一次 +8 KB 逼近 256 KB 硬顶（verify_mcp_list_budget 抓到）。
    unadvertised = set(advertise_hidden_fields(model)) | {
        k for k, v in props.items() if isinstance(v, dict) and v.get("x-xuanshu-hidden")
    }
    if issubclass(model, BirthInput):
        core = DOMAIN_CORE.get(definition.domain, ASTRO_CORE)
        targets = list(PREDICTIVE_INPUT_CONTRACTS.get(tool_name, {}).get("required_fields") or [])
        own = [f for f in model.model_fields if f not in BirthInput.model_fields and f not in unadvertised]
        for key in (*core, *targets, *own, *GATE_KEYS):
            if key in props and key not in keep:
                keep.append(key)
    else:
        keep = [f for f in model.model_fields if f in props and f not in unadvertised]
    hidden = sorted(set(props) - set(keep) - {"request"})
    out: dict[str, Any] = {}
    for key in keep:
        if key in CORE_DOC:
            out[key] = _core_property(key, tool_name, key in required)
        else:
            out[key] = _own_property(key, props[key], key in required)
    out["request"] = _request_property(hidden, tool_name)
    return {"type": "object", "properties": out, "additionalProperties": True, "x-xuanshu-hidden-knobs": len(hidden)}


def advertised_dispatch_schema(*, hecan: bool) -> dict[str, Any]:
    props: dict[str, Any] = {
        "query": {"type": "string", "description": "[required] 用户原话（选盘依据）", "x-xuanshu-required": True},
        "birth": {
            "type": "object",
            "description": "出生/起课信息：date/time/zone/lat/lon（+ gender 等技法字段），按所选技法校验",
            "additionalProperties": True,
        },
        "subject": {"type": "object", "description": "当事人：name/year 等（可选）", "additionalProperties": True},
        "context": {"type": "object", "description": "补充上下文：time/zone/lat/lon 等", "additionalProperties": True},
        "preferences": {"type": "object", "description": "偏好/流派设置", "additionalProperties": True},
        "save_result": {"type": "boolean", "description": "默认 true：写入记忆"},
        "agent_confirmed_settings": {"type": "boolean", "description": CORE_DOC["agent_confirmed_settings"]},
        "defaults_accepted": {"type": "boolean", "description": CORE_DOC["defaults_accepted"]},
        "clarification_notes": {"type": "string", "description": CORE_DOC["clarification_notes"]},
        "request": {"type": ["object", "string"], "description": "整包载荷（对象或 JSON 串）"},
    }
    if hecan:
        props["tools"] = {"type": "array", "items": {"type": "string"}, "description": "显式指定技法（缺省由路由选盘）"}
        props["max_tools"] = {"type": "integer", "description": "合参技法上限（默认 5）"}
    return {"type": "object", "properties": props, "additionalProperties": True}


def advertised_description(tool_name: str) -> str:
    definition = TOOL_DEFINITIONS[tool_name]
    aka = aka_line(tool_name, limit=4)
    tail = f"口径/输出段/全部旋钮：xuanshu_agent_guidance(tool_name=\"{tool_name}\")"
    desc = definition.description.strip()
    if len(desc) > DESCRIPTION_CHAR_LIMIT:
        desc = desc[: DESCRIPTION_CHAR_LIMIT - 1] + "…"
    return f"{desc}\n{aka + '；' if aka else ''}{tail}"



# ---------------------------------------------------------------------------
# 可移植广告层（v0.37.0）
#
# 广告层与校验层是分开的：校验走 `_signature_for_input_model` 的 `Annotated[Any, …]`（一律宽松），
# 广告层只影响客户端**看到**什么。所以把广告层收窄到「最低公分母客户端也能吃」是**零功能损失**的：
# 服务器照样接受 request 传 JSON 字符串、lat/lon 传数字、顶层塞隐藏旋钮。
#
# 各客户端的硬约束（2026-09 实测/官方文档）：
#   · Gemini CLI / Vertex FunctionDeclaration：每个属性必须有**单个** type；数组必须有 items；
#     拒 $ref/$defs；严格按 JSON Schema 2020-12 校验 —— 违反时拒的是**整张工具表**。
#   · OpenAI strict function calling：不接受 type 数组、不接受 additionalProperties: true。
#   · 私有 x-* 键：部分客户端按未知关键字直接报错。
# ---------------------------------------------------------------------------

# 允许在属性里出现的键；其余（default/title/format/x-*/$…）一律剔除。
_PORTABLE_PROP_KEYS = frozenset({"type", "enum", "items", "description"})


def _portable_type(prop: dict[str, Any], name: str) -> str:
    """把 anyOf / type 数组收敛成**恰一个**标量 type。"""
    candidates: list[str] = []
    declared = prop.get("type")
    if isinstance(declared, str):
        candidates = [declared]
    elif isinstance(declared, list):
        candidates = [str(x) for x in declared if x and x != "null"]
    if not candidates:
        for entry in prop.get("anyOf") or []:
            if isinstance(entry, dict) and entry.get("type") and entry.get("type") != "null":
                candidates.append(str(entry["type"]))
    if not candidates:
        return "string"
    if len(candidates) == 1:
        return candidates[0]
    # 多类型：字符串永远是安全的收窄口径 —— 服务端的 normalize 层本来就吃字符串
    # （"31.22" → "31n13"、"1" → 1），而 object 联合体（request）另有专门处理。
    return "object" if "object" in candidates else "string"


def portable_property(name: str, prop: dict[str, Any]) -> dict[str, Any]:
    """单个属性的可移植化：恰一个 type、数组有 items、无私有键、绝不返回 {}。"""
    out = {k: v for k, v in prop.items() if k in _PORTABLE_PROP_KEYS}
    out["type"] = _portable_type(prop, name)
    if out["type"] == "array":
        items = out.get("items")
        if not isinstance(items, dict) or not items.get("type"):
            # Gemini 会因为「array 没有 items」直接 400 INVALID_ARGUMENT。
            out["items"] = {"type": "string"}
        else:
            out["items"] = {k: v for k, v in items.items() if k in {"type", "enum"}}
    else:
        out.pop("items", None)
    if not str(out.get("description") or "").strip():
        out.pop("description", None)
    return out


def portable_schema(schema: dict[str, Any]) -> dict[str, Any]:
    """整张 inputSchema 的可移植化。幂等。"""
    if not isinstance(schema, dict):
        return {"type": "object", "properties": {}}
    out: dict[str, Any] = {"type": "object"}
    props = schema.get("properties")
    out["properties"] = {
        str(name): portable_property(str(name), prop if isinstance(prop, dict) else {})
        for name, prop in (props or {}).items()
    }
    # additionalProperties: true 在 2020-12 里等于「缺省」，但 OpenAI strict 见到 true 会拒；
    # 隐藏旋钮走顶层透传的能力不受影响（服务端不校验广告层）。
    if schema.get("additionalProperties") is False:
        out["additionalProperties"] = False
    if isinstance(schema.get("required"), list) and schema["required"]:
        out["required"] = [str(x) for x in schema["required"]]
    return out


def apply_advertised_schemas(mcp: Any) -> dict[str, int]:
    """注册完成后重写各工具的广告层 schema/描述；返回 {mcp_name: 隐藏旋钮数}（测试/棘轮用）。"""
    manager = getattr(mcp, "_tool_manager", None)
    if manager is None:
        return {}
    by_mcp_name = {definition.mcp_name: name for name, definition in TOOL_DEFINITIONS.items()}
    hidden: dict[str, int] = {}
    for tool in manager.list_tools():
        tool_name = by_mcp_name.get(tool.name)
        if tool_name is not None:
            slim = advertised_technique_schema(tool_name, tool.parameters or {})
            tool.parameters = slim
            tool.description = advertised_description(tool_name)
            hidden[tool.name] = int(slim.get("x-xuanshu-hidden-knobs", 0))
        elif tool.name in {"xuanshu_dispatch", "xuanshu_hecan"}:
            tool.parameters = advertised_dispatch_schema(hecan=tool.name == "xuanshu_hecan")
    # 🔴 最后对**全部**工具跑一遍可移植化 —— 包括 8 个门面与 xuanshu_tool_run。
    # 此前只有技法 + dispatch/hecan 被重写，门面直接把 pydantic 的原始 schema
    # （anyOf:[…,{null}] / default:null / title / $ref）发上线；而在精简面下门面**就是**全部工具。
    for tool in manager.list_tools():
        tool.parameters = portable_schema(tool.parameters or {})
    return hidden
