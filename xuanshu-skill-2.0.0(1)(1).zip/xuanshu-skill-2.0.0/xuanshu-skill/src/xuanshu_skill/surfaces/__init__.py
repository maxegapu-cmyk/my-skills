"""CLI and MCP surfaces."""
