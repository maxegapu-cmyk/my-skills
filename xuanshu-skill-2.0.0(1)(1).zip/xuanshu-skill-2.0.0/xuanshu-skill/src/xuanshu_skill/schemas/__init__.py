"""Pydantic schemas for Xuanshu skill inputs and outputs."""

