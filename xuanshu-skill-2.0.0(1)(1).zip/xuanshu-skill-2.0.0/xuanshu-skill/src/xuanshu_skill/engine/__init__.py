"""Engine layer for Xuanshu skill routing and API adapters."""

