from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any

from xuanshu_skill.config import Settings
from xuanshu_skill.errors import ToolTransportError
from xuanshu_skill.runtime import XuanshuRuntimeManager


class XuanshuJsEngineClient:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.runtime_manager = XuanshuRuntimeManager(settings)

    def run(self, tool_name: str, payload: dict[str, Any]) -> dict[str, Any]:
        node_bin = self._resolve_node_binary()
        errors: list[dict[str, Any]] = []
        for engine_root in self._candidate_engine_roots():
            try:
                return self._run_with_engine_root(node_bin=node_bin, engine_root=engine_root, tool_name=tool_name, payload=payload)
            except ToolTransportError as exc:
                errors.append({"code": exc.code, "message": str(exc), "details": exc.details})
                error_obj = exc.details.get("error") if isinstance(exc.details, dict) else None
                message = error_obj.get("message") if isinstance(error_obj, dict) else ""
                if "Unsupported xuanshu-core-js tool" not in str(message):
                    raise
        raise ToolTransportError(
            "xuanshu-core-js execution failed.",
            code="js_engine.execution_failed",
            details={"tool": tool_name, "attempts": errors},
        )

    def _run_with_engine_root(
        self,
        *,
        node_bin: Path,
        engine_root: Path,
        tool_name: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        cli_path = engine_root / "bin" / "cli.mjs"
        if not cli_path.is_file():
            raise ToolTransportError(
                "xuanshu-core-js CLI entry is missing.",
                code="js_engine.cli_missing",
                details={"path": str(cli_path)},
            )

        try:
            completed = subprocess.run(
                [str(node_bin), str(cli_path), "run", tool_name],
                input=json.dumps(payload, ensure_ascii=False),
                text=True,
                encoding="utf-8",
                errors="replace",
                capture_output=True,
                cwd=str(engine_root),
                timeout=self.settings.js_engine_timeout_seconds,
            )
        except subprocess.TimeoutExpired as exc:
            raise ToolTransportError(
                "本地 JS 引擎执行超时（xuanshu-core-js timed out）。",
                code="js_engine.timeout",
                details={
                    "tool": tool_name,
                    "timeout_seconds": self.settings.js_engine_timeout_seconds,
                    "node_bin": str(node_bin),
                },
            ) from exc
        except OSError as exc:
            # FileNotFoundError (Node not installed / unresolved), PermissionError, etc. — keep the
            # "every failure is a ToolTransportError" contract so the surface returns a clean error.
            raise ToolTransportError(
                "本地 JS 引擎无法启动：未找到可执行的 Node（可装离线 runtime 自带 node，或设 XUANSHU_NODE_BIN）。",
                code="js_engine.node_unavailable",
                details={"tool": tool_name, "node_bin": str(node_bin), "error": str(exc)},
            ) from exc
        try:
            parsed = json.loads(completed.stdout or "{}")
        except ValueError as exc:
            raise ToolTransportError(
                "本地 JS 引擎返回了无效 JSON。",
                code="js_engine.invalid_json",
                details={
                    "tool": tool_name,
                    # 原始输出属调试信息：降级进 debug 并短截断，避免大段堆栈直冲 agent 上下文。
                    "debug": {
                        "stdout": (completed.stdout or "")[-500:],
                        "stderr": (completed.stderr or "")[-500:],
                    },
                },
            ) from exc

        if completed.returncode != 0 or parsed.get("ok") is not True:
            error_obj = parsed.get("error") if isinstance(parsed, dict) else None
            raise ToolTransportError(
                "本地 JS 引擎执行失败。",
                code="js_engine.execution_failed",
                details={
                    "tool": tool_name,
                    "returncode": completed.returncode,
                    "error": error_obj or {},
                    # 原始输出属调试信息：降级进 debug 并短截断。
                    "debug": {
                        "stdout": (completed.stdout or "")[-500:],
                        "stderr": (completed.stderr or "")[-500:],
                    },
                },
            )

        if not isinstance(parsed, dict):
            raise ToolTransportError(
                "xuanshu-core-js returned an invalid result shape.",
                code="js_engine.invalid_shape",
                details={"tool": tool_name},
            )
        parsed.pop("ok", None)
        return parsed

    def _resolve_node_binary(self) -> Path:
        env_override = os.environ.get("XUANSHU_NODE_BIN")
        if env_override:
            candidate = Path(env_override).expanduser().resolve()
            if candidate.is_file():
                return candidate

        manifest = self.runtime_manager.load_installed_manifest()
        if manifest and isinstance(manifest.get("runtimes"), dict):
            node_relative = manifest["runtimes"].get("node")
            if isinstance(node_relative, str) and node_relative.strip():
                candidate = self.settings.runtime_current_dir / node_relative
                if candidate.is_file():
                    return candidate

        return Path("node")

    def _resolve_engine_root(self) -> Path:
        return self._candidate_engine_roots()[0]

    def _candidate_engine_roots(self) -> list[Path]:
        candidates: list[Path] = []

        env_override = os.environ.get("XUANSHU_CORE_JS_ROOT")
        if env_override:
            candidate = Path(env_override).expanduser().resolve()
            if candidate.is_dir():
                candidates.append(candidate)

        manifest = self.runtime_manager.load_installed_manifest()
        if manifest and isinstance(manifest.get("artifacts"), dict):
            relative = manifest["artifacts"].get("xuanshu_core_js_root")
            if isinstance(relative, str) and relative.strip():
                candidate = self.settings.runtime_current_dir / relative
                if candidate.is_dir():
                    candidates.append(candidate)

        source_candidate = Path(__file__).resolve().parents[3] / "xuanshu-core-js"
        if source_candidate.is_dir():
            candidates.append(source_candidate)

        unique: list[Path] = []
        seen: set[str] = set()
        for candidate in candidates:
            key = str(candidate.resolve())
            if key not in seen:
                seen.add(key)
                unique.append(candidate)
        return unique or [source_candidate]
