"""玄枢 2.0 小白模式：问事向导、白话解释、术语词典、一键全面解读的骨架。"""
from xuanshu_skill.beginner.guide import (
    READING_STYLE_RULES,
    annotate_terms,
    beginner_guide,
    explain,
    report_skeleton,
    technique_card,
)
from xuanshu_skill.beginner.matters import MATTERS, classify_matter, list_matters

__all__ = [
    "MATTERS",
    "READING_STYLE_RULES",
    "annotate_terms",
    "beginner_guide",
    "classify_matter",
    "explain",
    "list_matters",
    "report_skeleton",
    "technique_card",
]
