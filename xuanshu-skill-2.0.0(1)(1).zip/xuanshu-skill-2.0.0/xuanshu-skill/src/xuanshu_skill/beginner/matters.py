"""问事分类（玄枢 2.0 小白模式）。

新手不会说「请用六爻占官鬼爻」，只会说「我这次面试能过吗」「我今年财运怎么样」。这里把常见问题
分成 16 类事项，每类给出：

* 识别关键词；
* 两种看法：**命盘**（看长期格局与运程，需要出生信息）和**占卜**（问一件具体的事，用问事时刻起卦）；
* 各自推荐的技法组合（主看 + 辅看），以及每个技法看这类事时**具体看盘上哪里**；
* 需要向用户补问的信息（白话）；
* 解读时的注意事项（健康、官司等必须提示寻求专业帮助）。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Matter:
    key: str
    label: str
    keywords: tuple[str, ...]
    natal_tools: tuple[str, ...]
    event_tools: tuple[str, ...]
    focus: dict[str, tuple[str, ...]]
    ask: tuple[str, ...] = ()
    cautions: tuple[str, ...] = ()
    default_mode: str = "both"  # natal | event | both | date
    sixyao_ask_type: str | None = None
    tarot_spread: str = "three"
    extra: dict[str, Any] = field(default_factory=dict)


_COMMON_NATAL_FOCUS = {
    "bazi_birth": ("先定日主强弱和用神，再看与本事项相关的十神", "看当前大运与今明两年流年对相关十神的引动"),
    "ziwei_birth": ("看与本事项对应的宫位及其三方四正", "看当前大限与流年四化落点"),
    "chart": ("看与本事项对应的宫位、宫主星及相位", "近期配合行运或日返盘"),
}

MATTERS: dict[str, Matter] = {
    "career": Matter(
        key="career", label="事业工作",
        keywords=("工作", "事业", "职业", "升职", "晋升", "跳槽", "换工作", "面试", "offer", "录用", "老板", "上司", "领导",
                  "同事", "创业", "辞职", "裁员", "岗位", "公司", "求职", "找工作", "转行", "考公", "编制", "仕途"),
        natal_tools=("bazi_birth", "ziwei_birth", "chart"),
        event_tools=("sixyao", "liureng_gods", "qimen"),
        focus={
            "bazi_birth": ("官杀（正官、七杀）：职位、规则与压力；有印星相生则利于在体制或大平台发展",
                           "食神伤官：技术、才华、表达，旺而有财则适合技术型、创意型或创业",
                           "财星：收入来源；看身强弱判断能否担得起财",
                           "当前大运与流年是否走到用神，是否冲动月柱（工作环境变动）"),
            "ziwei_birth": ("官禄宫主星：适合的工作性质（如紫微、天府适合管理，天机适合策划，武曲适合财务）",
                            "命宫、官禄、财帛、迁移的三方四正格局",
                            "大限官禄宫是否有化禄、化权；流年化忌是否冲官禄"),
            "chart": ("第十宫与天顶（MC）星座：社会角色与职业形象", "第十宫主星落宫与相位",
                      "第六宫（日常工作）、第二宫（收入）", "土星、木星行运经过天顶或十宫"),
            "sixyao": ("求职、升迁、考公以官鬼爻为用神；签合同、拿文书以父母爻为用神",
                       "世爻（自己）旺衰与用神的生克", "动爻与变爻是回头生还是回头克", "用神空亡、月破则多有落空"),
            "liureng_gods": ("看日干（自己）与官星的关系", "三传是否见官星、贵人，末传吉凶",
                             "天将：贵人、青龙、太常多为吉，白虎、勾陈多主压力或纠纷"),
            "qimen": ("以开门为事业用神，看开门落宫的门星神与生克", "日干（自己）宫与开门宫的关系", "值符为领导上司，看其对自己宫的生克"),
        },
        ask=("你想看的是长期适合做什么、什么时候有发展（看命盘），还是眼前某个具体机会能不能成（起卦）？",
             "现在大概是什么情况？比如在职想跳槽、等面试结果、准备创业。"),
    ),
    "wealth": Matter(
        key="wealth", label="财运投资",
        keywords=("财运", "钱", "赚钱", "收入", "工资", "投资", "理财", "股票", "基金", "炒股", "生意", "发财", "偏财",
                  "彩票", "借钱", "欠款", "回款", "收账", "负债", "买卖", "加薪"),
        natal_tools=("bazi_birth", "ziwei_birth", "chart"),
        event_tools=("sixyao", "liureng_gods", "qimen"),
        focus={
            "bazi_birth": ("正财：稳定收入；偏财：投资、经营、外快", "身强能担财，身弱财多反为负担", "比劫（兄弟朋友）旺的人容易破财或合伙分财",
                           "食伤生财：靠技术和才华赚钱", "大运流年是否走财运、是否有比劫夺财"),
            "ziwei_birth": ("财帛宫主星与四化", "田宅宫（资产积累）", "福德宫（花钱习惯与对钱的态度）", "大限、流年财帛宫是否见化禄或化忌"),
            "chart": ("第二宫（自己赚的钱）与第八宫（他人的钱、投资、贷款）", "金星、木星的状态", "福点（Part of Fortune）的位置"),
            "sixyao": ("以妻财爻为用神", "兄弟爻动多主破财、竞争", "子孙爻为财源，动而生财为吉", "世爻持财或财来生合世爻为得财之象"),
            "liureng_gods": ("看日干所克之神（财星）", "三传见财且旺相为吉", "玄武主失财、盗损，见之需防"),
            "qimen": ("以生门、戊（资本）为财的用神", "生门落宫的旺衰与门星神", "戊与日干宫的生克"),
        },
        ask=("是想看自己一生的财运格局，还是某一笔投资、某一桩生意能不能做？",),
        cautions=("投资理财有真实风险，术数结论只能作为参考，不能代替专业的财务意见和风险评估。",),
    ),
    "love": Matter(
        key="love", label="感情婚姻",
        keywords=("感情", "爱情", "恋爱", "桃花", "对象", "男朋友", "女朋友", "暗恋", "表白", "脱单", "婚姻", "结婚", "离婚",
                  "复合", "分手", "前任", "老公", "老婆", "丈夫", "妻子", "姻缘", "正缘", "出轨", "相亲", "喜欢"),
        natal_tools=("bazi_birth", "ziwei_birth", "chart"),
        event_tools=("sixyao", "liureng_gods", "tarot"),
        focus={
            "bazi_birth": ("男命看财星为妻，女命看官杀为夫", "日支为夫妻宫：被冲多主变动，被合多主牵绊",
                           "桃花（咸池）、红鸾天喜", "大运流年引动夫妻宫或配偶星的年份，常是恋爱结婚的时机"),
            "ziwei_birth": ("夫妻宫主星：伴侣的类型和相处模式", "夫妻宫与官禄宫互为对宫，事业与婚姻互相影响",
                            "流年化禄、化忌入夫妻宫的年份", "红鸾、天喜、咸池等桃花星"),
            "chart": ("金星（爱的方式）与火星（欲望与追求）", "第五宫（恋爱）与第七宫（婚姻、伴侣）", "月亮（情感需求）",
                      "行运触发第七宫或金星"),
            "sixyao": ("男问女以妻财爻为用神，女问男以官鬼爻为用神", "世爻（自己）与应爻（对方）的生克合冲",
                       "世应相生相合为有缘，相冲相克多有阻隔", "兄弟爻动男方多有竞争者，子孙爻动女方不利于问男"),
            "liureng_gods": ("看日干（自己）与日支（对方）的生克", "天后、六合、青龙等天将主喜事",
                             "三传的发展趋势"),
            "tarot": ("看代表对方心意和关系现状的位置", "圣杯牌多主情感交流，宝剑多主沟通冲突",
                      "恋人、圣杯二等关系牌的出现"),
        },
        ask=("是想看自己的婚恋模式和姻缘时机（看命盘），还是问和某个具体的人会怎样（起卦）？",
             "如果是两个人的关系，有对方的出生日期时间吗？（可以做合盘）"),
        cautions=("感情的结果最终取决于两个人的选择，解读时多给建设性的建议，不要用「注定」「克夫克妻」这类说法。",),
        tarot_spread="relation",
    ),
    "match": Matter(
        key="match", label="两人合婚 / 关系",
        keywords=("合婚", "合盘", "配不配", "合不合", "我们合", "俩合", "朋友合不合", "对象合不合", "老公合不合", "老婆合不合", "八字合", "两个人", "我们俩", "般配", "相处", "合伙人"),
        natal_tools=("relative", "bazi_birth", "ziwei_birth"),
        event_tools=("sixyao", "tarot"),
        focus={
            "relative": ("太阳、月亮、金星、火星之间的相位：吸引与情感共鸣", "对方行星落入自己的第七宫、第五宫",
                         "土星接触：承诺与压力", "组合中点盘的整体主题"),
            "bazi_birth": ("双方日柱的天干合、地支六合三合为有缘", "双方用神是否互补", "日支是否相冲"),
            "ziwei_birth": ("双方命宫主星性格是否互补", "各自夫妻宫描述的伴侣类型是否对得上对方"),
        },
        ask=("请提供两个人各自的出生日期、时间和出生地。",),
        cautions=("合盘只描述互动方式，没有绝对的「合」与「不合」，请用于增进理解而不是下判决。",),
        tarot_spread="relation",
    ),
    "health": Matter(
        key="health", label="健康身体",
        keywords=("健康", "身体", "生病", "疾病", "病情", "手术", "住院", "怀孕后", "康复", "体检", "医院", "治疗", "失眠", "病", "的病", "病能好", "病会好", "活多久", "寿命", "自杀", "不想活"),
        natal_tools=("bazi_birth", "ziwei_birth", "chart"),
        event_tools=("sixyao", "liureng_gods"),
        focus={
            "bazi_birth": ("五行过旺过弱对应的身体系统（木肝胆、火心血、土脾胃、金肺、水肾）", "流年冲克日主或用神的年份宜多保养"),
            "ziwei_birth": ("疾厄宫主星与煞星", "流年化忌入疾厄宫的年份"),
            "chart": ("第六宫（日常健康）与第一宫（体质）", "火星、土星对上升或第六宫的相位"),
            "sixyao": ("问病以子孙爻为医药与康复之神，官鬼爻为病", "官鬼旺动病势重，子孙旺动利于康复"),
            "liureng_gods": ("看病神（官鬼）与救神（子孙）在三传中的力量",),
        },
        ask=("是想了解体质上需要注意的方面，还是关于一次具体的病情或手术？",),
        cautions=("任何健康问题请以医生的诊断和治疗为准。术数只能提供保养方向上的参考，绝不能代替就医，也不能据此停药或拒绝治疗。",
                  "不对寿命、死期做任何推断。若用户流露轻生念头，先关心对方并建议立即联系身边信任的人或当地心理援助热线 / 急救电话，不做占算。"),
    ),
    "study": Matter(
        key="study", label="学业考试",
        keywords=("考试", "高考", "中考", "考研", "考博", "考证", "成绩", "录取", "学业", "读书", "留学", "申请", "上岸", "考上", "论文"),
        natal_tools=("bazi_birth", "ziwei_birth", "chart"),
        event_tools=("sixyao", "liureng_gods", "qimen"),
        focus={
            "bazi_birth": ("印星：学习能力、文凭证书", "食伤：理解力与表达", "官星：考试名次、录取与功名", "当年流年是否生扶印星"),
            "ziwei_birth": ("文昌、文曲、化科", "官禄宫与父母宫（文书）", "流年化科所在"),
            "chart": ("水星（思维与学习）", "第三宫（基础学习）与第九宫（高等教育、留学）"),
            "sixyao": ("以父母爻为用神（试卷、文书、录取通知）", "官鬼爻为功名，父母与官鬼相生为吉", "财爻动克父母多主考试受阻"),
            "liureng_gods": ("朱雀主文书考试", "看三传是否见父母（印）与官星"),
            "qimen": ("以景门、丁奇为考试文书的用神", "天辅星主文化学业"),
        },
        ask=("是什么考试、大概什么时候考？",),
    ),
    "travel": Matter(
        key="travel", label="出行搬迁",
        keywords=("出行", "出差", "旅行", "旅游", "出国", "移民", "搬家", "搬迁", "迁居", "远行", "外地", "回国", "签证"),
        natal_tools=("bazi_birth", "chart"),
        event_tools=("qimen", "sixyao", "liureng_gods"),
        focus={
            "bazi_birth": ("驿马星与流年冲动", "用神所在方位（五行方位：木东、火南、金西、水北、土中）"),
            "chart": ("第三宫（短途）与第九宫（远行、出国）", "可用占星地图（ACG）看哪个城市对自己有利"),
            "qimen": ("择方：看哪个方位的宫有吉门吉星", "日干宫与目的地方位宫的生克"),
            "sixyao": ("以世爻为自己，看出行是否安顺", "官鬼、兄弟动多主阻滞破财"),
            "liureng_gods": ("看三传是否见驿马、天马", "白虎、玄武主路途风险"),
        },
        ask=("计划去哪里、大概什么时候？",),
    ),
    "lawsuit": Matter(
        key="lawsuit", label="官司纠纷",
        keywords=("官司", "诉讼", "起诉", "仲裁", "纠纷", "打官司", "律师", "判决", "被告", "原告", "赔偿", "合同纠纷"),
        natal_tools=("bazi_birth",),
        event_tools=("liureng_gods", "sixyao", "qimen"),
        focus={
            "liureng_gods": ("日干为我方，日支为对方，看彼此生克", "勾陈主争讼，朱雀主文书", "末传定结局"),
            "sixyao": ("世爻为我方，应爻为对方", "官鬼爻为法官、官府，生世则有利", "子孙爻可制官鬼，为解忧之神"),
            "qimen": ("惊门、伤门主官非争执", "开门为法官法院", "比较我方宫与对方宫的旺衰"),
            "bazi_birth": ("流年官杀攻身、刑冲多主是非",),
        },
        ask=("纠纷大概是什么性质、现在进行到哪一步了？",),
        cautions=("涉及法律的问题请以律师和法律程序为准，术数结论仅供心理参考，不能作为诉讼决策的依据。",),
    ),
    "lost": Matter(
        key="lost", label="寻物寻人",
        keywords=("丢了", "丢失", "找不到", "失物", "遗失", "寻物", "寻人", "走失", "宠物", "钱包", "手机丢", "被偷", "失窃"),
        natal_tools=(),
        event_tools=("sixyao", "liureng_gods", "qimen", "horary"),
        focus={
            "sixyao": ("按失物类别取用神（钱财看妻财、证件文书看父母、人看对应六亲）", "用神旺而不空能找回，空亡、入墓多难寻", "用神所临五行与卦宫提示方位"),
            "liureng_gods": ("玄武为盗神，看玄武所临之地", "三传指示失物的去向与方位"),
            "qimen": ("以失物类神落宫定方位", "杜门主隐藏，景门主显露"),
            "horary": ("以第二宫主星代表失物", "看失物征象星所在的宫与星座判断位置与距离"),
        },
        ask=("丢的是什么、大概什么时候发现不见的、最后一次在哪里看到？",),
        default_mode="event",
    ),
    "date": Matter(
        key="date", label="择日选时",
        keywords=("择日", "选日子", "挑日子", "吉日", "好日子", "黄道吉日", "开业", "开张", "结婚日子", "领证", "搬家日子",
                  "入宅", "动土", "装修", "签约日", "吉时", "什么时候适合", "适合签", "适合搬", "适合开", "适合结婚", "今天适合", "明天适合", "哪天", "选哪天", "哪一天", "哪天好", "什么日子", "几号"),
        natal_tools=("huanglizeri", "huangli"),
        event_tools=("huangli", "election", "qimenzeri"),
        focus={
            "huangli": ("看「宜」里是否有所办之事，「忌」里是否没有", "看冲煞是否冲当事人生肖", "选当天的吉时"),
            "huanglizeri": ("按事项和日期范围筛选", "排除冲当事人生肖的日子", "优先选黄道日、吉神多的日子"),
            "election": ("排除月空、月亮受克等红线", "比较多个候选时刻的评分"),
            "qimenzeri": ("按条件在时间窗内扫出吉时", "看所选时辰的门星神是否有利于所办之事"),
        },
        ask=("要办什么事？", "大概在哪段日期里选？", "当事人的生肖或出生日期（用来避开冲日）？"),
        default_mode="date",
    ),
    "personality": Matter(
        key="personality", label="性格天赋",
        keywords=("性格", "天赋", "优点", "缺点", "适合", "什么样的人", "命格", "命盘", "本命", "人生方向", "潜力"),
        natal_tools=("bazi_birth", "ziwei_birth", "chart"),
        event_tools=(),
        focus={
            "bazi_birth": ("日主五行与强弱：基本性格底色", "月令格局：做事方式", "十神组合：思维模式与天赋"),
            "ziwei_birth": ("命宫主星：核心性格", "身宫：后天努力方向", "福德宫：精神世界与价值观"),
            "chart": ("太阳、月亮、上升三巨头", "行星最集中的星座和宫位", "元素与模式的分布（火土风水、启动固定变动）"),
        },
        default_mode="natal",
    ),
    "yearly": Matter(
        key="yearly", label="流年运势",
        keywords=("今年", "明年", "流年", "运势", "运气", "这一年", "年运", "本命年", "犯太岁", "下半年", "上半年"),
        natal_tools=("bazi_birth", "ziwei_birth", "solarreturn", "profection"),
        event_tools=("tarot",),
        focus={
            "bazi_birth": ("当年流年干支与命局、大运的生克冲合", "流年是否为用神", "是否冲日支（夫妻宫）、月柱（工作环境）、年柱（家庭长辈）"),
            "ziwei_birth": ("流年命宫落在哪个宫", "流年四化：化禄在哪里得、化忌在哪里要用心"),
            "solarreturn": ("返照盘上升与第一宫：今年整体状态", "太阳落宫：今年最用力的领域"),
            "profection": ("今年走到的宫：年度主题", "年主星的状态与行运"),
        },
        ask=("想看哪一年？",),
        default_mode="natal",
    ),
    "children": Matter(
        key="children", label="子女生育",
        keywords=("孩子", "子女", "生孩子", "怀孕", "备孕", "生育", "儿子", "女儿", "宝宝", "生男生女"),
        natal_tools=("bazi_birth", "ziwei_birth", "chart"),
        event_tools=("sixyao",),
        focus={
            "bazi_birth": ("时柱为子女宫", "男命官杀为子女，女命食伤为子女", "流年引动子女星的年份"),
            "ziwei_birth": ("子女宫主星与四化",),
            "chart": ("第五宫与宫主星",),
            "sixyao": ("以子孙爻为用神",),
        },
        cautions=("生育健康请以医生的检查和建议为准；不对胎儿性别做判断。",),
    ),
    "family": Matter(
        key="family", label="家宅父母",
        keywords=("父母", "爸爸", "妈妈", "家里", "家宅", "家人", "房子", "买房", "卖房", "风水", "长辈", "兄弟姐妹"),
        natal_tools=("bazi_birth", "ziwei_birth"),
        event_tools=("sixyao", "qimen"),
        focus={
            "bazi_birth": ("年柱为祖上长辈，月柱为父母兄弟", "印星为母，偏财为父（常见口径）"),
            "ziwei_birth": ("父母宫、兄弟宫、田宅宫",),
            "sixyao": ("问房屋以父母爻为用神", "问家人按六亲取用神"),
            "qimen": ("看宅向与九宫吉凶",),
        },
    ),
    "decision": Matter(
        key="decision", label="选择抉择",
        keywords=("选哪个", "还是", "要不要", "该不该", "值不值得", "怎么选", "选择", "决定", "犹豫", "该去", "去哪", "选哪"),
        natal_tools=(),
        event_tools=("qimen", "sixyao", "tarot"),
        focus={
            "qimen": ("分别为每个选项看对应宫的门星神", "看哪个选项的宫生扶自己（日干宫）"),
            "sixyao": ("可以每个选项各占一卦，比较用神旺衰", "或一卦问「选 A 是否有利」"),
            "tarot": ("为每个选项抽一组牌比较", "最后一张作为行动建议"),
        },
        ask=("几个选项分别是什么？", "你最看重的是什么（收入、稳定、成长、家人）？"),
        default_mode="event",
    ),
    "general": Matter(
        key="general", label="综合看看",
        keywords=(),
        natal_tools=("bazi_birth", "ziwei_birth", "chart"),
        event_tools=("tarot", "sixyao"),
        focus=dict(_COMMON_NATAL_FOCUS),
        ask=("最想了解的是哪一方面？事业、财运、感情、健康、学业，还是整体性格和今年运势？",),
    ),
}

# 识别具体事件的语气（偏向占卜）
_EVENT_HINTS = ("能不能", "会不会", "能否", "是否", "吗", "成不成", "这次", "这个", "那个", "这件", "这份", "这家", "这单",
                "下周", "下个月", "最近", "结果", "什么时候", "多久", "还能", "有没有戏")
# 长期 / 格局语气（偏向命盘）
_NATAL_HINTS = ("一生", "一辈子", "命", "适合什么", "适合做", "适合干", "做什么", "哪一行", "哪个行业", "性格", "天赋", "大运", "流年", "今年", "明年", "这几年", "运势", "格局", "八字", "紫微", "星盘")


def classify_matter(text: str | None, matter: str | None = None) -> Matter:
    if matter and matter in MATTERS:
        return MATTERS[matter]
    if matter:
        for item in MATTERS.values():
            if matter in (item.label, *item.label.split(" / ")):
                return item
    query = (text or "").lower()
    best: tuple[int, Matter] | None = None
    for item in MATTERS.values():
        score = sum(len(k) for k in item.keywords if k.lower() in query)
        if score and (best is None or score > best[0]):
            best = (score, item)
    return best[1] if best else MATTERS["general"]


def suggest_mode(text: str | None, item: Matter, has_birth: bool) -> str:
    """natal（命盘）/ event（占卜）/ date（择日）。"""
    if item.default_mode == "date":
        return "date"
    if not item.natal_tools:
        return "event"
    if not item.event_tools:
        return "natal"
    event_score = _score(text, _EVENT_HINTS)
    natal_score = _score(text, _NATAL_HINTS)
    if event_score > natal_score:
        return "event"
    if natal_score > event_score:
        return "natal"
    if item.default_mode in {"natal", "event"}:
        return item.default_mode
    return "natal" if has_birth else "event"


def _score(text: str | None, hints: tuple[str, ...]) -> int:
    query = text or ""
    return sum(1 for h in hints if h in query)


def tools_for(item: Matter, mode: str, *, max_tools: int = 3) -> list[str]:
    if mode == "event":
        tools = list(item.event_tools) or list(item.natal_tools)
    elif mode == "date":
        tools = list(item.natal_tools if item.key == "date" else item.event_tools) or list(item.event_tools)
    else:
        tools = list(item.natal_tools) or list(item.event_tools)
    return tools[: max(1, max_tools)]


def focus_points(item: Matter, tool: str) -> list[str]:
    points = item.focus.get(tool) or _COMMON_NATAL_FOCUS.get(tool) or ()
    return list(points)


_SIXYAO_ASK = {"career": "career", "wealth": "wealth", "love": None, "health": "illness", "study": "study",
               "travel": "travel", "lawsuit": "lawsuit", "lost": "lost", "family": "home", "children": "children"}


def sixyao_ask_type(item: Matter, gender: Any = None) -> str | None:
    if item.key == "love":
        if gender in (0, "0", "女", "female", "f"):
            return "marriage_f"
        if gender in (1, "1", "男", "male", "m"):
            return "marriage_m"
        return None
    return _SIXYAO_ASK.get(item.key)


def list_matters() -> list[dict[str, Any]]:
    return [
        {"key": m.key, "label": m.label, "natal_tools": list(m.natal_tools), "event_tools": list(m.event_tools)}
        for m in MATTERS.values()
    ]


__all__ = ["MATTERS", "Matter", "classify_matter", "focus_points", "list_matters", "sixyao_ask_type", "suggest_mode", "tools_for"]
