#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
SKILL_ROOT="${ROOT}/xuanshu-skill"
DIST_ROOT="${SKILL_ROOT}/dist/runtime"
export XUANSHU_SKILL_PYPROJECT="${SKILL_ROOT}/pyproject.toml"
VERSION="$(python3 - <<'PY'
import tomllib
from pathlib import Path
data = tomllib.loads(Path(__import__('os').environ['XUANSHU_SKILL_PYPROJECT']).read_text(encoding='utf-8'))
print(data['project']['version'])
PY
)"
RELEASE_REPO="${XUANSHU_RUNTIME_RELEASE_REPO:-xuanshu-project/xuanshu-skill}"
RELEASE_BASE_URL="${XUANSHU_RUNTIME_RELEASE_BASE_URL:-https://github.com/${RELEASE_REPO}/releases/latest/download}"

"${ROOT}/xuanshu-skill/scripts/package_runtime_payload.sh"
python3 "${ROOT}/xuanshu-skill/scripts/build_runtime_release_windows.py"
mkdir -p "${DIST_ROOT}"
python3 "${ROOT}/xuanshu-skill/scripts/generate_release_manifest.py" \
  --version "${VERSION}" \
  --darwin-archive "${DIST_ROOT}/xuanshu-runtime-darwin-arm64-v${VERSION}.tar.gz" \
  --darwin-url "${RELEASE_BASE_URL}/xuanshu-runtime-darwin-arm64-v${VERSION}.tar.gz" \
  --windows-archive "${DIST_ROOT}/xuanshu-runtime-win32-x64-v${VERSION}.zip" \
  --windows-url "${RELEASE_BASE_URL}/xuanshu-runtime-win32-x64-v${VERSION}.zip" \
  --output "${DIST_ROOT}/runtime-manifest.json"

(
  cd "${DIST_ROOT}"
  shasum -a 256 "xuanshu-runtime-darwin-arm64-v${VERSION}.tar.gz" "xuanshu-runtime-win32-x64-v${VERSION}.zip" > SHA256SUMS.txt
)

python3 "${ROOT}/xuanshu-skill/scripts/verify_runtime_release.py" \
  --darwin-archive "${DIST_ROOT}/xuanshu-runtime-darwin-arm64-v${VERSION}.tar.gz" \
  --windows-archive "${DIST_ROOT}/xuanshu-runtime-win32-x64-v${VERSION}.zip" \
  --manifest "${DIST_ROOT}/runtime-manifest.json"
