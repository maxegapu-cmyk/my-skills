"""生成离线地名库 src/xuanshu_skill/data/places.json.gz（出生地 → 经纬度 + IANA 时区）。

数据源：GeoNames（https://www.geonames.org/，CC BY 4.0），经 `geonamescache` 包取得。
  * 中国大陆 / 港澳台：人口 ≥ 1000 的全部聚落（覆盖到绝大多数县城与镇）；
  * 其余国家：人口 ≥ 15000 且有中文名，或人口 ≥ 10 万的城市。
中文名统一转成简体（opencc t2s）建索引，繁体查询在运行时按同一张字表转换。

只有维护者重建数据时才需要运行；运行时零依赖：

    uv run --with geonamescache --with opencc-python-reimplemented \
        python scripts/build_places_data.py
"""
from __future__ import annotations

import gzip
import json
import sys
from pathlib import Path

import geonamescache  # type: ignore[import-not-found]
from opencc import OpenCC  # type: ignore[import-not-found]

OUT = Path(__file__).resolve().parents[1] / "src" / "xuanshu_skill" / "data" / "places.json.gz"
GREATER_CHINA = {"CN", "TW", "HK", "MO"}


def _has_han(text: str) -> bool:
    return any("一" <= ch <= "鿿" for ch in text)


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[union-attr]
    data_dir = Path(geonamescache.__file__).parent / "data"
    c1000 = json.loads((data_dir / "cities1000.json").read_text(encoding="utf-8"))
    c15000 = json.loads((data_dir / "cities15000.json").read_text(encoding="utf-8"))
    t2s = OpenCC("t2s")

    rows: dict[int, dict] = {}
    for v in c1000.values():
        if v["countrycode"] in GREATER_CHINA:
            rows[v["geonameid"]] = v
    for v in c15000.values():
        rows.setdefault(v["geonameid"], v)

    timezones = sorted({v["timezone"] for v in rows.values()})
    tz_index = {tz: i for i, tz in enumerate(timezones)}
    trad_chars: dict[str, str] = {}
    places = []
    for v in rows.values():
        han = set()
        for alt in v.get("alternatenames", []):
            if _has_han(alt) and len(alt) <= 12 and not any("぀" <= ch <= "ヿ" for ch in alt):
                simp = t2s.convert(alt)
                han.add(simp)
                for a, b in zip(alt, simp):
                    if a != b:
                        trad_chars[a] = b
        if v["countrycode"] not in GREATER_CHINA and not han and v["population"] < 100000:
            continue
        places.append([
            v["name"], round(v["latitude"], 4), round(v["longitude"], 4), tz_index[v["timezone"]],
            v["countrycode"], v.get("admin1code") or "", int(v["population"] or 0), sorted(han),
        ])
    places.sort(key=lambda row: -row[6])
    payload = {
        "source": "GeoNames (https://www.geonames.org/), CC BY 4.0",
        "fields": ["name", "lat", "lon", "tz", "cc", "admin1", "pop", "zh"],
        "timezones": timezones,
        "t2s": "".join(f"{a}{b}" for a, b in sorted(trad_chars.items())),
        "places": places,
    }
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    OUT.write_bytes(gzip.compress(raw, compresslevel=9, mtime=0))
    print(f"wrote {OUT} ({len(places)} places, {OUT.stat().st_size} bytes)")


if __name__ == "__main__":
    main()
