// Node golden self-check for the vendored 玄枢 JS engines (no jest): runs horary / election /
// progextra(balbillus) on a fixed traditional-chart fixture and asserts the snapshot shape. This is
// the only test that exercises the ~40-file divination/ tree + balbillus.js at the JS layer; the
// Python @requires_chart tests only reach them via a live chart service. Exit non-zero on any failure
// so `npm test` / CI fails loudly.
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { runHoraryTool } from '../src/tools/horary.js';
import { runElectionTool } from '../src/tools/election.js';
import { runProgExtra } from '../src/tools/progextra.js';
import { runAstroExtra } from '../src/tools/astroextra.js';
import { runLiureng, normalizeChart } from '../src/tools/liureng.js';
import { buildLiuRengReferenceContext } from '../src/vendor/liureng/liurengRefContext.js';
import { matchBiFa } from '../src/vendor/liureng/LRBiFaDoc.js';
import { ZiLiuQin } from '../src/vendor/liureng/LRConst.js';
import { runGuolaoMoira } from '../src/tools/guolaoMoira.js';
import { runXiaoLiuRen } from '../src/tools/xiaoliuren.js';
import { runFeiGong } from '../src/tools/feigong.js';
import { runXiaoChengTu } from '../src/tools/xiaochengtu.js';
import { runGuice } from '../src/tools/guice.js';
import { runZhengChuan } from '../src/tools/zhengchuan.js';
import { runLingqi } from '../src/tools/lingqi.js';
import { runTianxing } from '../src/tools/tianxing.js';
import { runQizhengElection } from '../src/tools/qizhengElection.js';
import { runBaziGeju } from '../src/tools/baziGeju.js';
import { runTiebanFramework } from '../src/tools/tiebanFramework.js';
import { buildTiebanFramework } from '../src/vendor/tieban/tiebanFrameworkLocal.js';
import { computeQimenScanPan, buildQimenScanSeeds } from '../src/vendor/divination/zeri/qimenScanEngine.js';
import { buildLocalBaziResult } from '../src/vendor/bazi/baziLunarLocal.js';
import { runCanping } from '../src/tools/canping.js';
import { runHeluo } from '../src/tools/heluo.js';
import { runYizhangjing } from '../src/tools/yizhangjing.js';
import { runTongSheFa } from '../src/tools/tongshefa.js';
import { runTarot } from '../src/tools/tarot.js';
import { runYanqinYanfa } from '../src/tools/yanqinYanfa.js';
import { runHuangli } from '../src/tools/huangli.js';
import { runLiuyao } from '../src/tools/liuyao.js';
import { personBazi } from '../src/vendor/calendar/riziEngine.js';
import { runZeriScan, ZERI_TECHNIQUES } from '../src/tools/zeriScan.js';
import { runMundaneCards } from '../src/tools/mundaneCards.js';
import { zeriRowOpts, withLeafKind } from '../src/tools/zeriSnapshotOpts.js';
import { runAcgSection } from '../src/tools/acgSection.js';
import { runBaziLocal } from '../src/tools/baziLocal.js';
import { runZiweiBirth } from '../src/tools/ziweiBirth.js';
import { runSuzhan } from '../src/tools/suzhan.js';
import { runSanshiUnited } from '../src/tools/sanshiUnited.js';
import { calcDunJia } from '../src/vendor/dunjia/DunJiaCalc.js';
import { buildLocalJieqiYearSeed } from '../src/shared/localNongliAdapter.js';
import { makeFields } from '../src/shared/fields.js';
import { buildLiuRengLayout as lrmLayout, buildKeData as lrmKe, buildSanChuanData as lrmSanChuan } from '../src/vendor/liureng/LiuRengMain.js';

const HERE = dirname(fileURLToPath(import.meta.url));
const chart = JSON.parse(readFileSync(join(HERE, 'fixtures', 'chart_traditional.json'), 'utf8'));
const liurengFix = JSON.parse(readFileSync(join(HERE, 'fixtures', 'chart_liureng.json'), 'utf8'));
const guolaoFix = JSON.parse(readFileSync(join(HERE, 'fixtures', 'chart_guolao.json'), 'utf8'));

let failures = 0;
// 🔴 check() 必须认异步：早先它只 `fn()` 不看返回值，async 断言体的失败会变成
// unhandled rejection —— 打印 `ok`、退出码 0、CI 全绿，而断言其实根本没验。这与本轮清剿的
// 「presence 级绿灯掩盖值级错误」是同一形状，只不过发生在 harness 自己身上。
const pending = [];
process.on('unhandledRejection', (err) => {
  failures += 1;
  console.error(`  FAIL <unhandled rejection>: ${err && err.message ? err.message : err}`);
});
function check(name, fn) {
  try {
    const out = fn();
    if (out && typeof out.then === 'function') {
      pending.push(out.then(
        () => console.log(`  ok   ${name}`),
        (err) => { failures += 1; console.error(`  FAIL ${name}: ${err.message}`); },
      ));
      return;
    }
    console.log(`  ok   ${name}`);
  } catch (err) {
    failures += 1;
    console.error(`  FAIL ${name}: ${err.message}`);
  }
}
function assert(cond, msg) {
  if (!cond) throw new Error(msg);
}

check('horary(marriage) emits a verdict snapshot', () => {
  const r = runHoraryTool({ chart, category: 'marriage' });
  assert(r.data.ok === true, 'data.ok should be true');
  const s = r.snapshot_text || '';
  for (const sec of ['[起卦信息]', '[根本性]', '[征象星指派]', '[裁决]']) {
    assert(s.includes(sec), `missing section ${sec}`);
  }
  assert(s.split('\n').length >= 10, 'snapshot too short');
  assert(typeof r.data.verdict === 'string' && r.data.verdict.length > 0, 'missing verdict');
});

check('horary unknown category falls back to general', () => {
  const r = runHoraryTool({ chart, category: 'no_such_category' });
  assert(r.category === 'general', `expected general, got ${r.category}`);
  assert((r.snapshot_text || '').includes('[起卦信息]'), 'missing 起卦信息');
});

check('election(surgery) emits a scored snapshot', () => {
  const r = runElectionTool({ chart, topicId: 'surgery' });
  assert(r.data.ok === true, 'data.ok should be true');
  const s = r.snapshot_text || '';
  for (const sec of ['[起盘信息]', '[总评]', '[红线]', '[建议]']) {
    assert(s.includes(sec), `missing section ${sec}`);
  }
  assert(r.data.overall && typeof r.data.overall.score === 'number', 'missing overall.score');
});

check('election unknown topic falls back to marriage', () => {
  const r = runElectionTool({ chart, topicId: 'no_such_topic' });
  assert(r.topicId === 'marriage', `expected marriage, got ${r.topicId}`);
});

check('progextra(balbillus) emits the 旺距削减 table', () => {
  const r = runProgExtra({ technique: 'balbillus', chart });
  const s = r.snapshot_text || '';
  assert(s.includes('[Balbillus]'), 'missing [Balbillus]');
  assert(s.includes('旺距削减'), 'missing 旺距削减 description');
  assert(s.includes('| 主限 | 子限 |'), 'missing period table header');
  assert(s.split('\n').filter((l) => l.startsWith('|')).length >= 5, 'too few table rows');
});

// v3.11 同步（F7）：上游挂载齿轮 → builder opts（aiAnalysisContext.js:2998-3013）必须真的到达 vendored builder。
// 权威：balbillus.js / keypoints120.js / triplicityRulers.js 是上游 utils/*.js 的 verbatim vendor（manifest 校验），
// 这里钉的是「选项改变结果」的具体值：起始星名、年制/口径标签、释放点标签、两分段年龄段。
check('progextra options reach the vendored builders (balbillus/keypoints/triplicityrulers)', () => {
  const dflt = runProgExtra({ technique: 'balbillus', chart }).snapshot_text;
  // 上游 AstroText.AstroTxtMsg 行星为单字（日/月…）：progConst shim 曾写成「太阳」，与上游逐字不符。
  assert(dflt.includes('七星按本命黄经序从 日 起铺开'), 'balbillus default must start from 日 (upstream AstroTxtMsg)');
  assert(!dflt.includes('太阳'), 'balbillus must print upstream single-char planet names');
  const moon = runProgExtra({ technique: 'balbillus', chart, options: { startPlanet: 'Moon', yearType: 'hellenistic', mode: 'forward' } }).snapshot_text;
  assert(moon.includes('七星按本命黄经序从 月 起铺开'), 'startPlanet=Moon must start from 月');
  assert(moon.includes('年制=Egyptian/Hellenistic（360 日）、距离口径=顺黄道距（forward）'), 'yearType/mode must reach builder');
  assert(moon.split('\n').some((l) => l.startsWith('| 月(')), 'first main period must be 月');
  const body = runProgExtra({ technique: 'keypoints', chart, options: { mode: 'body' } }).snapshot_text;
  assert(body.includes('释放点=命（上升起）'), 'keypoints mode=body must release from Asc');
  const halves = runProgExtra({ technique: 'triplicityrulers', chart, options: { division: 'halves', lifespan: 90 } }).snapshot_text;
  assert(halves.includes('两分（上半生 / 下半生 + 协作贯穿）'), 'division=halves must reach builder');
  assert(halves.includes('| 次三分主星（下半生） | 水 | 45–90岁 |'), 'lifespan=90 must split at 45');
});

// 上游 buildCurrentMomentLines(chartObj, extraLines)：builder 自算的 [当前时点] 定位行经 stub 回传（不产段）。
// fixture 出生 2026-06-02 → 此后 15 年内都处在首个主限「日」、三分主星首段「土」（0–25 岁）。
check('progextra returns the builders\' current-moment locator lines', () => {
  const bal = runProgExtra({ technique: 'balbillus', chart });
  assert(bal.moment_lines.some((l) => l.startsWith('当前主限：日（起 2026-06-02，时长 15.35 年）')), `balbillus moment ${JSON.stringify(bal.moment_lines)}`);
  assert(!bal.snapshot_text.includes('[当前时点]'), 'stub must not emit the section itself (Python owns it)');
  const tri = runProgExtra({ technique: 'triplicityrulers', chart });
  assert(tri.moment_lines[0] === '当前所处阶段：主三分主星·土（0–25岁）', `triplicity moment ${JSON.stringify(tri.moment_lines)}`);
  assert(runProgExtra({ technique: 'keypoints', chart }).moment_lines.length === 0, 'keypoints passes no locator line upstream');
});

// F15：[寿命格局] 取主法 + 太阳三态阈值随调用方/本盘回显（上游 astroAiSnapshot.js:1123-1136）。
check('astroextra lifespan honours method option and params solar orbs', () => {
  const ptolemy = runAstroExtra({ chart }).data.lifespan;
  const doro = runAstroExtra({ chart, options: { lifespanMethod: 'dorotheus' } }).data.lifespan;
  assert(ptolemy.method === 'ptolemy' && doro.method === 'dorotheus', 'method must echo the requested 取主法');
  // 同一盘：托勒密取日为生命主，多罗修斯取上升（引擎 = 上游 lifespanEngine.js verbatim）。
  assert(ptolemy.hyleg.key === 'sun' && doro.hyleg.key === 'asc', `hyleg must differ by method (got ${ptolemy.hyleg.key}/${doro.hyleg.key})`);
  const merc = (ls) => (ls.states.rows.find((r) => r.planet === 'mercury') || {}).sunState;
  assert(merc(ptolemy) === null, 'mercury 19.5° from Sun is free under the 17° default');
  const wide = JSON.parse(JSON.stringify(chart));
  wide.params = { ...(wide.params || {}), underBeamsOrb: 20 };
  assert(merc(runAstroExtra({ chart: wide }).data.lifespan) === 'under_beams', 'params.underBeamsOrb must reach buildFacts');
});

check('progextra unknown technique returns empty, not a crash', () => {
  const r = runProgExtra({ technique: 'no_such', chart });
  assert(r.data.ok === false, 'unknown technique should be ok=false');
  assert(r.snapshot_text === '', 'unknown technique should have empty snapshot');
});

// 六壬毕法 (玄枢 v2.5.x Phase4)：buildLiuRengReferenceContext + matchBiFa verbatim 抽取，
// 在固定盘上应组装出有效 ~75 字段 context 并机械命中若干毕法。
check('liureng refContext builds + matchBiFa hits', () => {
  const chartObj = normalizeChart(liurengFix);  // unwrap raw /chart response → nongli/objects at top
  const ctx = buildLiuRengReferenceContext(liurengFix.liureng, chartObj, 2, null, null);
  assert(ctx && ctx.dayGanZi && ctx.dayGanZi.length === 2, 'context missing dayGanZi');
  assert(Array.isArray(ctx.sanChuanBranches) && ctx.sanChuanBranches.length === 3, 'sanChuan should have 3 branches');
  assert(Array.isArray(ctx.keUpBranches) && ctx.keUpBranches.length >= 1, 'keUp branches missing');
  const hits = matchBiFa(ctx);
  assert(Array.isArray(hits) && hits.length >= 1, 'matchBiFa should hit ≥1 毕法 on this 盘');
  assert(hits.every((h) => h.no && h.name && h.verse), 'each 毕法 hit needs no/name/verse');
});

check('liureng 三传六亲走 vendor ZiLiuQin（消费点金标——手抄表时代 vendor 金标看不见它）', () => {
  const r = runLiureng({ ...liurengFix });
  const chartObj = normalizeChart(liurengFix);
  const daygan = `${chartObj.nongli.dayGanZi}`.charAt(0);
  const find = (o) => {
    if (!o || typeof o !== 'object') return null;
    if (Array.isArray(o.cuang) && Array.isArray(o.liuQin)) return o;
    for (const v of Object.values(o)) { const hit = find(v); if (hit) return hit; }
    return null;
  };
  const sanchuan = find(r.data);
  assert(sanchuan && sanchuan.liuQin.length === 3, 'sanchuan object with cuang/liuQin not found in data');
  sanchuan.cuang.forEach((gz, i) => {
    const zi = `${gz}`.slice(-1);
    const want = (ZiLiuQin[zi] || {})[daygan] || '无';
    assert(sanchuan.liuQin[i] === want, `三传 ${gz} 六亲 ${sanchuan.liuQin[i]} ≠ vendor ${want}（日干 ${daygan}）`);
  });
});

check('liureng snapshot carries 毕法 + 占断向导 sections', () => {
  const r = runLiureng({ ...liurengFix, zhanCategory: 'hunyin' });
  const s = r.snapshot_text || '';
  assert(s.includes('[常用神煞]'), 'missing 常用神煞');
  assert(s.includes('[毕法（已命中）]'), 'missing 毕法 section');
  assert(/\n\d+\.\s/.test(s), 'no numbered 毕法 entries');
  assert(s.includes('[占断向导]') && s.includes('占事：婚姻'), 'missing 占断向导 for hunyin');
});

// 🔴 v0.35.0 值级金标：六亲表 ≡ 五行生克公式，120 格逐格对拍（上游 v3.9.4 真值校准同法）。
// LRConst.js 是 curated 手工件，`--from-manifest` 不碰它：乙日巳/午两格「父母」（应为「子孙」：
// 乙木生巳午火＝我生者）在四轮同步里静默滞留。负向对照：把任一格改回去，本检查必红。
check('liureng ZiLiuQin 六亲表与五行生克公式 120 格逐格一致', () => {
  const WX_GAN = { 甲: '木', 乙: '木', 丙: '火', 丁: '火', 戊: '土', 己: '土', 庚: '金', 辛: '金', 壬: '水', 癸: '水' };
  const WX_ZHI = { 子: '水', 亥: '水', 寅: '木', 卯: '木', 巳: '火', 午: '火', 申: '金', 酉: '金', 辰: '土', 戌: '土', 丑: '土', 未: '土' };
  const SHENG = { 木: '火', 火: '土', 土: '金', 金: '水', 水: '木' };  // 我生
  const KE = { 木: '土', 土: '水', 水: '火', 火: '金', 金: '木' };     // 我克
  const expect = (gan, zhi) => {
    const me = WX_GAN[gan], it = WX_ZHI[zhi];
    if (me === it) return '兄弟';
    if (SHENG[me] === it) return '子孙';
    if (SHENG[it] === me) return '父母';
    if (KE[me] === it) return '妻财';
    return '官鬼';
  };
  const bad = [];
  let cells = 0;
  for (const zhi of Object.keys(WX_ZHI)) {
    for (const gan of Object.keys(WX_GAN)) {
      cells += 1;
      const got = ZiLiuQin[zhi] && ZiLiuQin[zhi][gan];
      if (got !== expect(gan, zhi)) bad.push(`${zhi}.${gan}=${got}(应${expect(gan, zhi)})`);
    }
  }
  assert(cells === 120, `expected 120 cells, walked ${cells}`);
  assert(bad.length === 0, `六亲表与公式不符: ${bad.join(' ')}`);
  assert(ZiLiuQin['巳']['乙'] === '子孙' && ZiLiuQin['午']['乙'] === '子孙', '乙日巳/午 must be 子孙 (upstream v3.9.4)');
});

// 七政四余 政余格局 (玄枢 v2.6.x Moira DSL)：buildLocalMoiraPatterns verbatim 抽取。固定盘
// 1985-03-21 应命中喜格「金水相涵」+ 忌格「孛犯太阳」(盘面物象格局，不依赖 七政神煞)。
check('guolaoMoira evaluates 政余格局 patterns', () => {
  const r = runGuolaoMoira(guolaoFix);
  const names = (r.data.patterns || []).map((p) => p.name);
  assert(!r.data.error, `should not error: ${r.data.error}`);
  assert(names.includes('金水相涵'), `expected 金水相涵, got ${names.join(',')}`);
  assert(names.includes('孛犯太阳'), `expected 孛犯太阳, got ${names.join(',')}`);
  const s = r.snapshot_text || '';
  assert(s.includes('喜格：') && s.includes('忌格：'), 'snapshot missing 喜格/忌格 lines');
});

// 🔴 v0.33.1 值级金标：params 必须是**起盘时刻**，不是 /chart 信封。
// 引擎读 params.time 判昼夜（:390）、params.date 判冬令（:397）；信封里两者都没有
// （只有 birth），于是 isDay 恒真、isWinter 恒假 —— 夜生盘拿天贵而非玉贵、孤月独明永不触发、
// 冬令排除永不生效。段照出、格局照列，只有判据是错的。
// 负向对照：把 params 换回整个信封，「12月 冬令」这条即红（金水相涵 会重新出现）。
check('guolaoMoira params 是起盘时刻：冬令排除真的生效', () => {
  const names = (params) => (runGuolaoMoira({ ...guolaoFix, params }).data.patterns || []).map((p) => p.name);
  const spring = names({ date: '1985-03-21', time: '10:00:00' });
  const winter = names({ date: '1985-12-21', time: '10:00:00' });
  assert(spring.includes('金水相涵'), `非冬令应命中金水相涵，实得 ${spring.join(',')}`);
  assert(!winter.includes('金水相涵'), `冬令须排除金水相涵（引擎 :203 的 !isWinter），实得 ${winter.join(',')}`);
  // 传整个信封 = 修复前的形状：date 取不到 → 恒非冬 → 冬令盘也会误报金水相涵
  const envelope = names(guolaoFix.chart || guolaoFix);
  assert(envelope.includes('金水相涵'), '信封形状应复现旧行为（此断言记录 bug 形状，勿删）');
});

// 🔴 v0.33.1 值级金标：起局三开关（timeAlg / after23NewDay / lateZiHourUseNextDay）是 QimenInput
// 继承来的**顶层**字段，扫描引擎却只从 options 读（qimenScanEngine.js:124-126）。Python 侧此前只传
// payload["options"] → 顶层写法静默丢弃，命中区间用默认起局算，而同一次调用的展示盘（走
// _run_qimen_tool）是 honor 顶层的 → 两者不同局，配置段还打出一个没用上的设置标签。
// ⚠️ 真太阳时校正需要 `lon`（不是只有 gpsLon）——测本条时 geo 必须带 lon，否则 timeAlg 看不出差异。
// 负向对照：Python 侧改回只读 options 并用顶层 timeAlg 调用，命中集即与 timeAlg=0 相同。
check('qimenzeri 起局口径真的生效：timeAlg 改变时柱', () => {
  const seeds = buildQimenScanSeeds(2028, 2028, 8);
  const geo = { zone: 8, lon: '119e18', lat: '26n05', gpsLon: 119.3, gpsLat: 26.08 };
  const at = (timeAlg) => computeQimenScanPan(geo, { timeAlg }, seeds, '2028-04-01', '19:02:00').ganzhi.time;
  assert(at(0) === '丁酉', `timeAlg=0 应为平太阳时 丁酉，实得 ${at(0)}`);
  assert(at(1) === '戊戌', `timeAlg=1 应为真太阳时 戊戌，实得 ${at(1)}`);
});

// 🔴 v0.33.1 值级金标：cfg 必须带黄道口径。[征象搜索配置] 的「搜索盘面」行读 cfg.zodiacal
// （tianxingSnapshot.js:76），Python 此前没往 ctx.cfg 里送 → 恒星盘搜索也恒打「回归黄道」，
// 而同一份输出里 [起盘信息] 的「黄道：」行读 fields（已正确填充）→ 一份交付物两行自相矛盾。
// 负向对照：从 cfg 里拿掉 zodiacal，本条即红。
check('tianxing 搜索盘面口径与实际搜索一致（恒星黄道不再被打成回归）', () => {
  const fields = { date: { value: '2029-03-01' }, time: { value: '00:00:00' }, zone: { value: 8 },
    zodiacal: { value: 1 }, siderealAyanamsa: { value: 'fagan_bradley' } };
  const line = (cfg) => (runTianxing({ action: 'snapshot', fields,
    ctx: { cfg, tree: { kind: 'group', joiner: 'all', children: [] }, results: [], truncated: false } }).snapshot_text || '')
    .split('\n').find((l) => l.startsWith('搜索盘面')) || '';
  const withZod = line({ startDate: '2029-03-01', endDate: '2029-03-10', hsys: 3, zodiacal: 1, siderealAyanamsa: 'fagan_bradley' });
  assert(withZod.includes('恒星黄道(fagan_bradley)'), `恒星盘应打恒星黄道，实得 ${withZod}`);
  // 缺 zodiacal = 修复前形状：恒打回归（此断言记录 bug 形状，勿删）
  assert(line({ startDate: '2029-03-01', endDate: '2029-03-10', hsys: 3 }).includes('回归黄道'), 'bug 形状复现失败');
});

// 🔴 v0.33.1 值级金标：铁板「考刻」。引擎读 opts.ke（tiebanFrameworkLocal.js:253）。
// sync311 F8 改口径：考刻是占者按六亲佐证「考」定后手填的刻位，上游无头挂载 ke = ov.tiebanKe（空=1 初刻），
// 刻制/流派读 tiebanKeSystem / tiebanSchool（KinAstroMain.buildKinAstroSnapshotForFields :329-346）——
// 钟点不参与考刻。v0.33.1 那版「按时分折算清八刻」是 skill 自创口径（且十二刻·斗宫 9–12 刻永远到不了），
// 原断言「同时辰不同分钟须落不同刻」随之作废，改钉上游口径。
// 负向对照：把工具改回 keFromClock(hour, minute)，下面「20:47 仍初刻」即红；改回读 school/keSystem，dou12 那条即红。
check('tiebanFramework 考刻取 tiebanKe（上游缺省初刻），刻制上限随 tiebanKeSystem', () => {
  const fp = { year: '己巳', month: '壬申', day: '丁卯', hour: '庚子' };
  const ju = (ke) => buildTiebanFramework(fp, { birthYear: 1989, gender: 1, ke }).ju;
  assert(ju(1).label === '子时初刻＝全日第1刻', `ke=1 → ${ju(1).label}`);
  assert(ju(8).label === '子时八刻＝全日第8刻', `ke=8 → ${ju(8).label}`);
  const run = (extra) => runTiebanFramework({ pillars: [
    { key: 'year', ganzhi: '己巳' }, { key: 'month', ganzhi: '壬申' },
    { key: 'day', ganzhi: '丁卯' }, { key: 'hour', ganzhi: '庚子' }], birthYear: 1989, gender: 1, ...extra });
  const keOf = (extra) => { const m = /全日第(\d+)刻/.exec(run(extra).text || ''); return m && m[1]; };
  assert(keOf({ hour: 20, minute: 47 }) === '1', `未给 tiebanKe 应为初刻（钟点不参与），实得 ${keOf({ hour: 20, minute: 47 })}`);
  assert(keOf({ tiebanKe: 8 }) === '8', `tiebanKe=8 → ${keOf({ tiebanKe: 8 })}`);
  // 十二刻·斗宫收 1–12（清八刻超 8 按初刻）：刻位上限随 tiebanKeSystem。
  const dou = run({ tiebanKeSystem: 'dou12', tiebanKe: 11 });
  assert(dou.data && dou.data.keSystem === 'dou12' && dou.data.ke === 11, `dou12/11 → ${JSON.stringify(dou.data)}`);
  assert(run({ tiebanKe: 11 }).data.ke === 1, 'qing8 下 11 刻应按初刻');
  assert(/北派/.test(run({ tiebanSchool: 'north' }).text || ''), 'tiebanSchool=north 应出北派');
  assert(run({ school: 'north', keSystem: 'dou12' }).data.keSystem === 'qing8', '旧键 school/keSystem 不该生效（上游名 tiebanSchool/tiebanKeSystem）');
});

check('calendarExtras 当事人时辰真的进盘（time 只喂时刻）', () => {
  // 值级：同日不同时辰的当事人，喜忌必须不同。修复前 calendarExtras 把
  // `YYYY-MM-DD HH:MM:SS` 整串塞给 time，parseDateTime 做 `time.split(':')` 后
  // Number('1990-05-15 03') = NaN → hour 恒 0 → 每个当事人都按子时起盘。
  const xi = (clock) => JSON.stringify(personBazi({ date: '1990-05-15', time: clock, gender: 1 }).xi);
  assert(xi('03:00:00') === '["水","木","火"]', `03:00 喜用实得 ${xi('03:00:00')}`);
  assert(xi('21:00:00') === '["水"]', `21:00 喜用实得 ${xi('21:00:00')}`);
  // 负向对照：把旧的整串形状喂回去，两个时辰会重新塌成同一盘（bug 复现）。
  const old = (clock) => JSON.stringify(personBazi({ date: '1990-05-15', time: `1990-05-15 ${clock}`, gender: 1 }).xi);
  assert(old('03:00:00') === old('21:00:00'), '旧整串形状本应塌盘，负向对照失效说明引擎已改口径');
});

// ---- v0.36.0 A4 半成品收官：三个「引擎已就绪、旋钮未接」的工具各加**能翻转**的值金标（改参数结果必变 + 负向对照）----
check('heluo liunianStep2/ziShuMode 走到引擎：2 岁流年 应爻法≠逐爻上行；写错键名不得翻转；立春前生者干支年基准', () => {
  const base = { date: '2026-02-17', time: '21:50:07', zone: '+08:00', lon: '120e00', gender: 1, timeAlg: 1 };
  const ying = runHeluo(base);
  const seq = runHeluo({ ...base, liunianStep2: 'sequential' });
  assert(ying.input_normalized.liunianStep2 === 'ying' && seq.input_normalized.liunianStep2 === 'sequential', 'liunianStep2 must be echoed');
  const row = (r) => r.snapshot_text.split('\n').find((l) => l.startsWith('| 2岁 |')) || '';
  // 权威：vendored heluoLocal.js liuNian() —— 'ying' 应爻法★（opts.step2 默认，line 244）/ 'sequential' 逐爻上行
  // （line 262），与桌面 HeLuoMain 同一引擎；先天火風鼎的 2 岁流年：应爻法落 雷風恆·上六，逐爻上行落 山風蠱·六四。
  assert(row(ying).includes('雷風恆') && row(ying).includes('上六'), `ying 2岁 row: ${row(ying)}`);
  assert(row(seq).includes('山風蠱') && row(seq).includes('六四'), `sequential 2岁 row: ${row(seq)}`);
  // 负向对照：旋钮名写成 step2（v0.35 的死键）必须**不**翻转——死键就是这样溜过去的。
  const dead = runHeluo({ ...base, step2: 'sequential' });
  assert(row(dead) === row(ying), 'unknown knob name must not change the result');
  // ziShuMode 'single'（heluoLocal.js line 146 每支阴阳取一数）改取数 → 天地数/先天卦必变：pair 火風鼎 19/44 → single 山風蠱 18/24
  const single = runHeluo({ ...base, ziShuMode: 'single' });
  assert(ying.data.chart.xian.name === '火風鼎' && ying.data.chart.tian === 19 && ying.data.chart.di === 44, 'pair baseline');
  assert(single.data.chart.xian.name === '山風蠱' && single.data.chart.tian === 18 && single.data.chart.di === 24, `single: ${single.data.chart.xian.name} ${single.data.chart.tian}/${single.data.chart.di}`);
  // 流年年基准 = 干支年（vendor/utils/ganzhiYearBase.js）：2026-02-03 在立春（2026-02-04）前，年柱乙巳 → 基准 2025
  const pre = runHeluo({ ...base, date: '2026-02-03' });
  assert(pre.data.fourPillars.year === '乙巳' && pre.data.birthYear === 2025 && ying.data.birthYear === 2026, `birthYear: ${pre.data.birthYear}/${ying.data.birthYear}`);
});

check('yizhangjing gradeSet/leapRule 走到引擎：天驛 中品→下品；闰二月十五 00:xx 夜半折半作下月；23:xx 不作', () => {
  const base = { date: '1998-02-20', time: '20:48:00', zone: '+08:00', lat: '31n13', lon: '121e28', gender: 1 };
  const std = runYizhangjing(base);
  const variant = runYizhangjing({ ...base, gradeSet: 'variant' });
  const cell = (r) => r.data.renshi.find((row) => row.palace === '迁移');
  // 权威：vendored yizhangjingReport.js gradeOf(star, gradeSet) 两套品级表（标准表 天驛=中品，变体表 天驛=下品）
  assert(cell(std).star === '天驛' && cell(std).grade === '中品', `standard: ${JSON.stringify(cell(std))}`);
  assert(cell(variant).star === '天驛' && cell(variant).grade === '下品', `variant: ${JSON.stringify(cell(variant))}`);
  assert(std.data.opts.gradeSet === 'standard' && variant.data.opts.gradeSet === 'variant', 'gradeSet must be echoed in opts');
  // 权威：yizhangjingReport.js 闰月归属分支——leapRule='midnight' && 十五 && 生时子且 00:xx → 作下月。
  // 2023-04-05 = 闰二月十五；十五折半★作本月（month 2），夜半折半作下月（month 3）。
  const leap = { ...base, date: '2023-04-05', time: '00:30:00' };
  const half = runYizhangjing(leap);
  const midnight = runYizhangjing({ ...leap, leapRule: 'midnight' });
  assert(half.data.input.leap === true && half.data.input.day === 15 && half.data.input.month === 2, `half: ${JSON.stringify(half.data.input)}`);
  // 上游 v3.11.0 [Q-265/SO-20⑧ 术语校正]：钟面 00:xx 是夜半后的「早子」，全局「晚子时」专指 23 时档 → 注记改「(早子)」，判定不变。
  assert(midnight.data.input.month === 3 && midnight.data.input.monthNote === '闰月·十五夜半(早子)作下月', `midnight: ${JSON.stringify(midnight.data.input)}`);
  // 负向对照：23:30 不满足引擎的 00:xx 条件，夜半折半不得作下月。
  // 显式 after23NewDay:0 —— 一掌经日界缺省已随上游改为 1（23 点算次日，YiZhangJingMain.js:127），
  // 那样 23:30 的农历日先进位成十六、按「十五后作下月」走的是另一条分支；本对照只考 00:xx 条件本身。
  const notLate = runYizhangjing({ ...leap, time: '23:30:00', leapRule: 'midnight', after23NewDay: 0 });
  assert(notLate.data.input.month === 2, `23:30 must stay month 2: ${JSON.stringify(notLate.data.input)}`);
});

check('tongshefa 纳甲逐爻/世应/左右爻变入 data：风雷益 子寅辰未巳卯、世三应六、益→晋 变在 1/4/5 爻', () => {
  const r = runTongSheFa({ taiyin: '巽', taiyang: '离', shaoyang: '震', shaoyin: '坤' });
  assert(r.data.baseLeft.name === '风雷益' && r.data.baseRight.name === '火地晋', 'fixture pair');
  // 权威：京房纳甲（震内卦 子寅辰、巽外卦 未巳卯）+ 巽宫木六亲生克（水父母/木兄弟/土妻财/火子孙）+ 益为巽宫三世卦（世三应六）
  const branches = r.data.leftLines.map((l) => l.branch).join('');
  const kin = r.data.leftLines.map((l) => l.kin).join('/');
  assert(branches === '子寅辰未巳卯', `branches: ${branches}`);
  assert(kin === '父母/兄弟/妻财/妻财/子孙/兄弟', `kin: ${kin}`);
  assert(r.data.leftLines[2].shiYing === '世' && r.data.leftLines[5].shiYing === '应', 'shi/ying');
  assert(r.data.main_relation === '实克思' && r.data.main_relation_label === '实践改造思想', `label: ${r.data.main_relation_label}`);
  // 益 (自下 1,0,0,0,1,1) vs 晋 (0,0,0,1,0,1) → 变在 1/4/5 爻
  const changed = r.data.yaoChanges.filter((y) => y.changed).map((y) => y.line).sort((a, b) => a - b).join(',');
  assert(changed === '1,4,5', `changed lines: ${changed}`);
});

check('guolao moira rules_sections：[虚实]/[本命化曜]/[流年流曜] 三段与上游 jest 夹具逐行一致', () => {
  // 权威：上游 astrostudyui/src/components/guolao/__tests__/guolaoWeakSolidBirthStars.test.js（v44 硬缺修）
  // 的夹具与断言；transit 侧同一 builder 形状（GuoLaoChartMain.buildGuolaoTransitStarsSection）。
  const rules = {
    weakSolid: { houses: [
      { house: '命宫', label: '实', solid: true, weakPillars: [], solidPillars: ['年', '日'] },
      { house: '财帛', label: '虚', weak: true, weakPillars: ['月'], solidPillars: [] },
    ] },
    yearStars: {
      birth: { yearPole: '丙午', planetRows: [{ star: '木', changeTo: '天贵', items: ['岁星'] }, { star: '火', changeTo: '天刑', items: [] }] },
      transit: { yearPole: '', planetRows: [{ star: '火', changeTo: '天刑', items: [] }] },
    },
    transitYearStars: [{ name: '岁星', star: '木', shortName: '岁', quality: '旺', zi: '寅', signName: '析木' }],
  };
  const { sections } = runGuolaoMoira({ action: 'rules_sections', moiraRules: rules, transitYearGz: '丙午' });
  const ws = sections.weakSolid.split('\n');
  assert(ws[0] === '| 宫位 | 虚实 | 虚柱 | 实柱 |' && ws[1] === '| --- | --- | --- | --- |', 'weakSolid header');
  assert(ws[2] === '| 命宫 | 实 | 无 | 年、日 |', `row1: ${ws[2]}`);
  assert(ws[3] === '| 财帛 | 虚 | 月 | 无 |', `row2: ${ws[3]}`);
  assert(ws[4] === '口径：虚宫按四柱旬空推虚；实宫按年、月、日、时四柱地支定实。', 'weakSolid footer');
  const bs = sections.birthStars.split('\n');
  assert(bs[0] === '本命年柱：丙午' && bs[1] === '◆ 本命化曜', 'birthStars head');
  assert(bs[2] === '木：化天贵（同归：岁星）' && bs[3] === '火：化天刑', `birthStars rows: ${bs[2]} / ${bs[3]}`);
  assert(bs[4] === '◆ 十神序（参考）' && bs[5].startsWith('原十神序：天禄、') && bs[6].startsWith('替代十神序：比肩、'), 'ten-god seq');
  assert(bs[7] === '◆ 天禄至天权（年曜主项）' && bs[8] === '天禄：科名、天马、生官' && bs[bs.length - 1] === '天权：爵星、产星、伤官', 'year info groups');
  const ts = sections.transitStars.split('\n');
  assert(ts[0] === '流年干支：丙午' && ts[1] === '◆ 流年化曜' && ts[2] === '火：化天刑', `transit head: ${ts.slice(0, 3)}`);
  assert(ts[3] === '◆ 流曜落宫' && ts[4] === '岁星：木（岁；旺 · 寅 · 析木）', `transit sign row: ${ts[4]}`);
  // 无数据 → 空串不产段（上游「零字节变化」契约）
  const empty = runGuolaoMoira({ action: 'rules_sections', moiraRules: {} }).sections;
  assert(empty.weakSolid === '' && empty.birthStars === '' && empty.transitStars === '', 'empty rules → empty sections');
  // 缺省入口（patterns）不受影响
  assert(typeof runGuolaoMoira({ chart: { chart: {} } }).snapshot_text === 'string', 'patterns entry still works');
});

// ---- v0.36.0 C3：三个本地 JS 引擎的值金标（此前只有存在性断言）----
check('huangli 2000-01-01：干支/农历/生肖 = 万年历公开事实', () => {
  // 权威：公开万年历——2000-01-01 为 己卯年 丙子月 戊午日，农历一九九九年冬月廿五，生肖兔（lunar-javascript 与万年历一致）。
  const text = runHuangli({ year: 2000, month: 1, day: 1, hour: 12 }).text;
  assert(text.includes('干支：己卯年 丙子月 戊午日'), `ganzhi line: ${text.split('\n').find((l) => l.startsWith('干支'))}`);
  assert(text.includes('农历：一九九九年冬月廿五'), 'lunar date');
  assert(text.includes('生肖：兔'), 'zodiac');
  // 负向对照：换一天，日柱必变（1999-12-31 = 丁巳日）
  const prev = runHuangli({ year: 1999, month: 12, day: 31, hour: 12 }).text;
  assert(prev.includes('丁巳日') && !prev.includes('戊午日'), 'previous day must be 丁巳');
});

check('liuyao 乾为天静卦：乾宫本宫世六应三、六冲、纳甲六亲六神 = 京房纳甲/六亲生克/六神起例', async () => {
  // 权威：京房纳甲（乾内卦 子寅辰）+ 六亲生克（乾宫属金：水=子孙、木=妻财、土=父母、火=官鬼、金=兄弟）
  // + 六神起例（甲乙日青龙起初爻）+ 八宫卦序（乾为天=乾宫本宫卦，世六应三，六冲）。
  // wave 3：[断卦结构] = vendored 上游 liuyaoStructLines，逐爻为 GFM 表（GuaZhanMain.js:168-181）。
  const nongli = { dayGanZi: '甲子', monthGanZi: '丙寅', yearGanZi: '甲辰' };
  const text = (await runLiuyao({ lines: [1, 1, 1, 1, 1, 1].map((v) => ({ value: v, change: false })), nongli })).snapshot_text;
  assert(text.includes('卦序：乾宫·本宫(世6应3)'), 'palace / shi-ying');
  assert(text.includes('卦象：六冲卦'), 'liuchong');
  const row = (n) => text.split('\n').find((l) => l.startsWith(`| 第${n}爻 |`)) || '';
  assert(row(1).startsWith('| 第1爻 | 青龙 | 子 | 水 | 子孙 |'), `row1: ${row(1)}`);
  assert(row(2).startsWith('| 第2爻 | 朱雀 | 寅 | 木 | 妻财 |'), `row2: ${row(2)}`);
  assert(row(3).startsWith('| 第3爻 | 勾陈 | 辰 | 土 | 父母 | 应 |'), `row3: ${row(3)}`);
  assert(row(4).startsWith('| 第4爻 | 螣蛇 | 午 | 火 | 官鬼 |'), `row4: ${row(4)}`);
  assert(row(5).startsWith('| 第5爻 | 白虎 | 申 | 金 | 兄弟 |'), `row5: ${row(5)}`);
  // 负向对照：初爻动 → 成局/动变段出现（静卦没有）
  const moving = (await runLiuyao({ lines: [1, 1, 1, 1, 1, 1].map((v, i) => ({ value: v, change: i === 0 })), nongli })).snapshot_text;
  assert(moving.includes('成局：') && !text.includes('成局：'), 'moving line changes the structure section');
});

// sync311 wave 3 值级金标：以时起卦 = vendored 上游 buildTimeGua（GuaZhanMain.js:74-98：上卦 (年支序+农历月数+农历日数)%8、
// 下卦 +时柱支序、动爻 %6，Gua8 先天序）。权威：把上游文件里 buildTimeGua 的源码原样切出在 Node 里跑（2026-09-24）：
// 丙午年 八月(8) 十四(14) 甲午时 → 风雷益、上爻动；同日癸巳时 → 风火家人、五爻动。负向对照：旧 Python 手写式
// 取月/日**地支序** + 钟表时辰（年午7+月酉10+日丑2=19、巳6）→ 火天大有、初爻动。
check('liuyao 以时起卦 = 上游 buildTimeGua（农历月日数 + 时柱支序）', async () => {
  const base = { year: '丙午', yearJieqi: '丙午', monthGanZi: '丁酉', dayGanZi: '辛丑', monthInt: 8, dayInt: 14 };
  const cast = async (time) => runLiuyao({ nongli: { ...base, time } });
  const a = await cast('甲午');
  assert(a.time_cast === true && a.current_gua.name === '风雷益', `甲午时: ${JSON.stringify(a.current_gua)}`);
  assert(JSON.stringify(a.lines.map((y) => `${y.value}${y.change ? '*' : ''}`)) === JSON.stringify(['1', '0', '0', '0', '1', '1*']), `甲午 lines: ${JSON.stringify(a.lines)}`);
  assert(a.lines[2].name === '辰土妻财世' && a.lines[0].god === null, '爻名取 Gua64.yaoname、无六神（上游无头卦无 god）');
  const b = await cast('癸巳');
  assert(b.current_gua.name === '风火家人' && b.lines.findIndex((y) => y.change) === 4, `癸巳时: ${JSON.stringify(b.current_gua)}`);
});

// [断诀命中]/[占类断语] = vendored liuyaoSnapshotEx（buildGuaSnapshotText:381-388）；[占类断语] 的「断语·占类门」行
// 证明断语库先载入（ensureLiuyaoDoctrineLoaded :1735-1737）。权威：vendored 上游引擎对同一卦的输出（段首行逐字）。
// 负向对照：旧 liuyao.js 不产这两段；不 await loadDoctrine 则断语行缺席。
// （wave 3b：两段随整份 buildGuaSnapshotText 快照回在 snapshot_text，不再另出 duanjue_text/zhanlei_text 键。）
check('liuyao [断诀命中]/[占类断语] 由上游 liuyaoSnapshotEx 产出、断语库已载入', async () => {
  const nongli = { year: '丙午', yearJieqi: '丙午', monthGanZi: '丁酉', dayGanZi: '辛丑', monthInt: 8, dayInt: 14, time: '甲午' };
  const block = (text, title) => {
    const all = (text || '').split('\n');
    const at = all.indexOf(`[${title}]`);
    if (at < 0) { return []; }
    const end = all.findIndex((l, i) => i > at && /^\[.+\]$/.test(l));
    return all.slice(at, end < 0 ? all.length : end).filter((l, i, arr) => !(i === arr.length - 1 && l === ''));
  };
  const r = await runLiuyao({ nongli });
  const dj = block(r.snapshot_text, '断诀命中');
  assert(dj[0] === '[断诀命中]' && dj[1] === '三层环境：太岁午(岁破子)　月建酉(月破卯)　日建丑(日破未)', `断诀首行: ${dj.slice(0, 2)}`);
  assert(dj.includes('世应关系：世3(妻财辰)应克世应6(兄弟卯)·彼制我、受制难谋'), '世应关系行');
  const zl = block(r.snapshot_text, '占类断语');
  assert(zl[0] === '[占类断语]' && zl[1] === '历史占例：冉伯牛有疾卜得,乃知谩师之过也', `占类首行: ${zl.slice(0, 2)}`);
  assert(zl.includes('断语·总断门第一·孙膑：孙膑总断歌') && r.data.doctrine_loaded === true, '断语库未载入');
  // 六键（旧版回执为 unsurfaced 死键）现改输出：世身 / 古法十六变。
  const tuned = await runLiuyao({ nongli, liuyaoSettings: { shishen: 'standard', gufa: 1 } });
  assert(block(tuned.snapshot_text, '断诀命中').some((l) => l.startsWith('世身：第')) && !dj.some((l) => l.startsWith('世身：')), 'shishen 未生效');
  assert(block(tuned.snapshot_text, '占类断语').some((l) => l.startsWith('十六变：第')), 'gufa 未生效');
});

// sync311 wave 3b 值级金标：整份快照 = 上游 buildGuaSnapshotText(buildCaseSnapshotFields(record), st)（GuaZhanMain.js:201-391，
// regenerateSixyaoSnapshot:1756）。权威：旬空按六十甲子旬手核（丁酉/辛丑同属甲午旬 → 辰巳）；互/错/综按爻值变换手核
// （风雷益 100011 → 互 000001 山地剥、错 011100 雷风恒、综 110001 山泽损）；伏神卦 = 本宫首卦巽为风（初爻丑土妻财）；
// 求测人性别缺省 = buildCaseSnapshotFields gender ?? 1（aiAnalysisContext.js:791）。
// 负向对照：旧 liuyao.js 的 snapshot_text 只有 [断卦结构] 一段（其余段由 Python 自写）→ 以下各行全缺。
check('liuyao 整份快照 = 上游 buildGuaSnapshotText：旬空 / X时 / 互错综 / 关联卦逐爻 / 求测人性别', async () => {
  const nongli = { birth: '2026-09-24 11:09:58', year: '丙午', yearJieqi: '丙午', monthGanZi: '丁酉', dayGanZi: '辛丑', monthInt: 8, dayInt: 14, time: '甲午' };
  const record = { date: '2026-09-24', time: '10:58:00', zone: '+08:00', lon: '121e28', lat: '31n13' };
  const t = (await runLiuyao({ nongli, record })).snapshot_text.split('\n');
  assert(t[0] === '[起盘信息]' && t.includes('日期：2026-09-24 10:58:00') && t.includes('求测人性别：男'), `起盘信息: ${t.slice(0, 8)}`);
  assert(t.includes('起卦时间：2026-09-24 11:09:58 甲午时') && t.includes('旬空：月空辰巳 日空辰巳'), '起卦时间「X时」/ 旬空');
  assert(t.includes('互卦：山地剥  乾宫金') && t.includes('错卦(阴阳全变)：雷风恒  震宫木') && t.includes('综卦(上下颠倒)：山泽损  艮宫土'), '互错综');
  const fu = t.indexOf('伏神卦(本宫首卦)逐爻（初→上）：');
  assert(fu > 0 && t[fu + 1] === '第1爻：阴爻，爻名:丑土妻财', `伏神卦: ${t[fu + 1]}`);
  assert(t.indexOf('[卦辞与断语]') + 1 === t.indexOf('[判语库·参考诀表]'), '无头卦无 guaDesc：[卦辞与断语] 只有段头');
  const female = (await runLiuyao({ nongli, record: { ...record, gender: 0 } })).snapshot_text;
  assert(female.includes('求测人性别：女'), 'gender=0 → 女');
});

check('tarot 种子洗牌确定性：同种子同牌阵逐牌相同、换种子必变', () => {
  // 权威：vendored 上游塔罗引擎的种子洗牌（同 seed 同 reading 是设计契约）；三牌值为本 vendor sha 下的回归钉。
  const rows = (seed) => runTarot({ spread: 'three', deck: 'rws', seed, question: '测试', usesReversals: true })
    .snapshot_text.split('\n').filter((l) => /^\| 位置\d/.test(l));
  const a = rows('xuanshu-golden-1');
  assert(a.length === 3, `three rows: ${a.length}`);
  assert(a[0].includes('太阳') && a[0].includes('| 逆位 |'), `pos1: ${a[0]}`);
  assert(a[1].includes('战车') && a[1].includes('| 正位 |'), `pos2: ${a[1]}`);
  assert(a[2].includes('钱币七') && a[2].includes('| 逆位 |'), `pos3: ${a[2]}`);
  assert(JSON.stringify(rows('xuanshu-golden-1')) === JSON.stringify(a), 'same seed → identical reading');
  assert(JSON.stringify(rows('xuanshu-golden-2')) !== JSON.stringify(a), 'different seed → different reading');
});

// sync311 F9/F11 值级金标：引擎设置经 options 送达（键集锚 resolveSettings），verdictMode 八法全开，
// 牌阵/牌组锚引擎词表（SPREADS / deck caps.spreads）。权威：vendored 上游 engine/reading.js resolveSettings、
// verdict.js YESNO_MODES、timingMethods.js TIMING_METHODS、deckRegistry.js caps。
// 负向对照：把 tarot.js 退回只透传 5 键的旧形状，「计时(大牌数字)」与「答案锚位」两条即红；退回静默回落，报错三条即红。
check('tarot 引擎设置/定局八法/牌阵词表经 runTarot 送达引擎', () => {
  const base = { spread: 'three', deck: 'rws', seed: 'xuanshu-golden-1', question: '测试' };
  const text = (extra) => runTarot({ ...base, ...extra }).snapshot_text || '';
  const timingLine = (t) => t.split('\n').find((l) => l.startsWith('计时(')) || '';
  assert(timingLine(text({})).startsWith('计时(花色单位)'), `缺省计时法：${timingLine(text({}))}`);
  const major = timingLine(text({ options: { timingMethod: 'major_number', timingUnit: '月' } }));
  assert(major.startsWith('计时(大牌数字)') && major.includes('个月'), `timingMethod/timingUnit 未达引擎：${major}`);
  assert(text({ verdictMode: 'anchor' }).includes('答案锚位'), 'verdictMode=anchor 应走 YESNO_MODES 第七法');
  const err = (extra) => ((runTarot({ ...base, ...extra }).data || {}).error || {}).code;
  assert(err({ options: { timingUnit: '年' } }) === 'invalid_setting', '引擎不认的值须报错，不许回落');
  assert(err({ spread: 'one' }) === 'unknown_spread', '不存在的牌阵须报错（旧形状静默换 three）');
  assert(err({ deck: 'lenormand', spread: 'celtic' }) === 'unsupported_spread_for_deck', '牌组允许表外的牌阵须报错');
  assert(runTarot({ ...base, deck: 'lenormand', spread: undefined }).spread === 'single', '缺省牌阵不开放 → 允许表首项');
  assert(JSON.stringify(runTarot({ ...base, options: { nope: 1 } }).data.params_ignored) === '["nope"]', '未识别键回执 params_ignored');
});

// sync311 F7 值级金标：演法流派/六开关逐次传入（上游 yanqinSchools YANQIN_PRESETS / YANQIN_OPTION_META），
// 快照首段按上游 yanqinSnapshot 口径出流派名与我彼口诀。负向对照：退回不调 setYanqinSchool，fenghuang 那条即红。
check('yanqinYanfa 流派/开关经 payload 送达引擎（headless 无 localStorage）', () => {
  const run = (extra) => runYanqinYanfa({ year: 1998, month: 2, day: 20, hour: 20, ...extra });
  const school = (extra) => ((run(extra).text || '').split('\n')[1] || '');
  assert(school({}).startsWith('池本理《禽星易见》;翻禽=我/倒将=彼'), `缺省流派：${school({})}`);
  assert(school({ school: 'fenghuang' }).startsWith('凤凰演禽(现代占课);时禽=我/翻禽=彼'), `fenghuang：${school({ school: 'fenghuang' })}`);
  const custom = school({ woBi: 'shi', monthVerse: 'B' });
  assert(custom.startsWith('custom;时禽=我') && custom.includes('月禽口诀B版'), `偏离预设应标 custom：${custom}`);
  // 同一进程再跑缺省：前一调用的开关不许串味（每次先 applyPreset）。
  assert(school({}).startsWith('池本理《禽星易见》'), '开关串味：缺省调用须回到池本理');
  const bad = run({ huoYaoVariant: 'nope' }).data;
  assert(bad.ok === false && bad.error.code === 'invalid_setting', '词表外取值须报错');
});

check('canping 起运岁走农历真源，不再恒 1 岁', async () => {
  // 值级锚定：baziStyle 档的起运岁必须等于八字盘 direction[0].age（同源判据，
  // 不是自证）；默认《参评诀》档由农历月日推算，同盘得 3 岁。修复前 lunarMonth/
  // lunarDay 没转发 → 引擎守卫判非法 → 起运岁恒回落 1，九个大运区间整体平移。
  const birth = { date: '1998-02-20', time: '20:48:00', zone: 8, lon: '121e28', gender: '男' };
  const firstDayunAge = buildLocalBaziResult({ ...birth, gender: 1, timeAlg: 1 }).bazi.direction[0].age;
  assert(firstDayunAge === 5, `八字盘首运虚岁应为 5，实得 ${firstDayunAge}`);
  const qiyunOf = async (dayunRule) => (await runCanping({ ...birth, dayunRule })).data.qiyunAge;
  assert(await qiyunOf(undefined) === 3, `默认档起运岁应为 3，实得 ${await qiyunOf(undefined)}`);
  assert(await qiyunOf('baziStyle') === firstDayunAge,
    `baziStyle 档须与八字盘同源（${firstDayunAge}），实得 ${await qiyunOf('baziStyle')}`);
});

// sync311 wave 3b 值级金标：数算三技法 timeAlg 缺省 0（真太阳时）、参评/河洛日界缺省 1 —— 上游 AI 挂载无头 buildFieldObject
// timeAlg ?? 0 / after23NewDay ?? 出厂 1（aiAnalysisContext.js:603,606），页面全局字段出厂种子同值。权威（独立源）：live 9977
// /nongli/time 1998-02-20 上海 —— 11:05 真太阳时 10:55:19 时柱丁巳、钟表戊午；23:30 钟表 日柱己亥（23 点换日）/戊戌（24 点）。
// 负向对照：旧缺省 timeAlg=1 → 缺省即午时；旧 canping/heluo 不传日界 → undefined 当 24 点换日 → 戊戌。
check('数算 timeAlg 缺省真太阳时 / 日界缺省 23 点换日（参评·河洛·一掌经随上游无头挂载）', async () => {
  const base = { date: '1998-02-20', time: '11:05:00', zone: '+08:00', lon: '121e28', gender: 1 };
  const cp = await runCanping(base);
  assert(cp.input_normalized.timeAlg === 0 && cp.input_normalized.fourPillars.hourBranch === '巳', `canping: ${JSON.stringify(cp.input_normalized.fourPillars)}`);
  assert(runHeluo(base).data.fourPillars.hour === '丁巳', 'heluo 缺省时柱应为丁巳');
  assert(runYizhangjing(base).data.input.hourBranch === '巳', 'yizhangjing 缺省生时支应为巳');
  assert((await runCanping({ ...base, timeAlg: 1 })).input_normalized.fourPillars.hourBranch === '午', '钟表时对照应为午');
  assert(runHeluo({ ...base, timeAlg: 1 }).data.fourPillars.hour === '戊午', 'heluo 钟表时对照应为戊午');
  const late = { ...base, time: '23:30:00', timeAlg: 1 };
  assert((await runCanping(late)).input_normalized.fourPillars.dayBranch === '亥', 'canping 23:30 缺省日支应为亥');
  assert(runHeluo(late).data.fourPillars.day === '己亥' && runHeluo({ ...late, after23NewDay: 0 }).data.fourPillars.day === '戊戌', 'heluo 日界');
});

check('zhengchuan 大定男女分行，性别不再被 NaN 吃掉', async () => {
  // 值级：同盘男女的 大运／小运／岁君 必须不同。修复前传的是裸 gender，
  // 而 baziLunarLocal 做 `Number(params.gender) === 0 ? 0 : 1` —— Number('女') = NaN
  // ≠ 0 → 一律判男顺行 → 女命的大定死限年整体错位，且照常自信输出。
  const base = { school: 'dading', pillars: ['戊寅', '甲寅', '壬戌', '庚戌'], date: '1998-02-20',
    time: '20:48:00', zone: 8, lon: '121e28', lunarMonth: 1, lunarDay: 24, dadingYear: 2030 };
  const textOf = async (gender) => (await runZhengChuan({ ...base, gender })).snapshot_text || '';
  const male = await textOf('男');
  const female = await textOf('女');
  const yunLine = (s) => (s.split('\n').find((l) => l.includes('大运／小运／岁君')) || '').trim();
  assert(yunLine(male) && yunLine(female), '大定快照应含 大运／小运／岁君 行');
  assert(yunLine(male) !== yunLine(female),
    `男女须分行，实得同一行：${yunLine(male)}`);
  // 数字形式与中文形式必须等价（'女' 与 0 同盘）。
  assert(yunLine(await textOf(0)) === yunLine(female), '性别 0 应与 “女” 同盘');
});

// sync311 wave 3：大定推运表与四柱同一时间算法。上游一次 buildLocalBaziResult 同出四柱与推运表
// （aiAnalysisContext.buildChartShusuanBazi:1948-1979；无头 timeAlg = record.timeAlg ?? 0，buildFieldObject:603）。
// 1998-02-20 11:05 +08:00 121e28：真太阳时 10:57 → 时柱丁巳（后端 /nongli/time 缺省同为丁巳），2030 小运庚寅；
// 钟表时 → 戊午、小运辛卯。负向对照：旧缺省 timeAlg=1 → 四柱丁巳而小运按戊午推 = 辛卯。
check('zhengchuan 大定推运表缺省按真太阳时，与四柱同口径', async () => {
  const base = { school: 'dading', pillars: ['戊寅', '甲寅', '戊戌', '丁巳'], date: '1998-02-20', time: '11:05:00',
    zone: '+08:00', lon: '121e28', gender: 1, lunarMonth: 1, lunarDay: 24, dadingYear: 2030 };
  const yun = async (extra) => ((await runZhengChuan({ ...base, ...extra })).snapshot_text || '').split('\n').find((l) => l.includes('大运／小运／岁君')) || '';
  assert(await yun({}) === '| 大运／小运／岁君 | 丁巳 ／ 庚寅 ／ 庚戌 |', `缺省: ${await yun({})}`);
  assert(await yun({ timeAlg: 1 }) === '| 大运／小运／岁君 | 丁巳 ／ 辛卯 ／ 庚戌 |', `钟表时: ${await yun({ timeAlg: 1 })}`);
});

check('baziGeju 分野口径真的进五行力量 + 缺柱不再无声', async () => {
  // 值级：cangVersion='fenye' 必须改变百分比分布（修复前 fy 在 st 之后才算，
  // 分野档结构上不可达 —— [月令司令（分野）] 报着司令干，[五行力量] 却按通行版加权）。
  const birth = { date: '1989-08-15', time: '23:30:00', zone: 8, lon: '121e28', gender: 1, timeAlg: 1 };
  const fc = buildLocalBaziResult(birth).bazi.fourColumns;
  const distOf = async (cangVersion) => {
    const s = (await runBaziGeju({ fourColumns: fc, birth, cangVersion })).snapshot_text || '';
    return (s.split('\n').find((l) => l.startsWith('分布：')) || '').trim();
  };
  const common = await distOf(undefined);
  const fenye = await distOf('fenye');
  assert(common === '分布：木2.6%　火22.3%　土23.6%　金18%　水33.5%', `通行档实得 ${common}`);
  assert(fenye === '分布：木2.7%　火23.6%　土23.6%　金14.5%　水35.5%', `分野档实得 ${fenye}`);
  assert(common !== fenye, '分野档必须改变加权，相同即说明 siLingGan 没接上');
  // 说明行须与实算口径一致（两段自相矛盾正是修复前的症状）。
  const fenyeText = (await runBaziGeju({ fourColumns: fc, birth, cangVersion: 'fenye' })).snapshot_text;
  assert(fenyeText.includes('（分野加权：'), '分野档说明行未切换');
  // 守卫查的是引擎真读的字段：柱在、stemInBranch 缺时必须结构化报错，而不是无声空段。
  const noCang = await runBaziGeju({ fourColumns: { ...fc, time: { stem: fc.time.stem } } });
  assert(noCang.data && noCang.data.ok === false && noCang.data.reason === 'incomplete_four_pillars',
    `藏干缺应结构化报错，实得 ${JSON.stringify(noCang.data)}`);
  assert(noCang.data.message.includes('time'), '错误须点名缺哪一柱');
});

check('horary/election 判读层旋钮真的接进引擎（锚定引擎自带词表）', () => {
  // 值级：覆写判读层参数必须改变快照。修复前 horary 只喂 horaryJudgeOpts 第 1 层、
  // election 干脆 runElection(chart, topicId) 两参调用 —— 46+13 个真参数结构上不可达，
  // 而 schema 上挂着一排旋钮（其中 receptionMode/almutenScheme/dignityScheme 等
  // 在引擎词表里根本不存在，是发明的名字）。
  const base = runHoraryTool({ chart, category: 'marriage' });
  const over = runHoraryTool({ chart, category: 'marriage', considerationsMode: 'ignore', lotsSet: 'core15' });
  assert(JSON.stringify(over.data.params_applied) === '["considerationsMode","lotsSet"]',
    `覆写未被采纳：${JSON.stringify(over.data.params_applied)}`);
  assert(base.snapshot_text !== over.snapshot_text, 'horary 判读层覆写必须改变快照');
  // 认不出的键要**回执**，不能像整包 opts 那样无声吞掉。
  const bogus = runHoraryTool({ chart, category: 'marriage', options: { notARealKnob: 1 } });
  assert(JSON.stringify(bogus.data.params_ignored) === '["notARealKnob"]',
    `未知键须回执，实得 ${JSON.stringify(bogus.data.params_ignored)}`);
  const e1 = runElectionTool({ chart, topicId: 'marriage' });
  const e2 = runElectionTool({ chart, topicId: 'marriage', school: 'hellenistic', options: { orbProfile: 'classic' } });
  assert(e1.data.school === 'modern_main' && e2.data.school === 'hellenistic',
    `流派档未生效：${e1.data.school} / ${e2.data.school}`);
  assert(e1.snapshot_text !== e2.snapshot_text, 'election 流派/参数覆写必须改变快照');
});

check('zeriScan 择日六技法：命中区间锚定到独立算出的真值', async () => {
  // 值级锚定：八字择时搜「甲子日」，61 天窗内必须恰好命中一次，且那一天由**另一条链**
  // （buildLocalBaziResult）独立确认确实是甲子日。这不是自证 —— 扫描引擎与八字排盘是两套代码。
  const geo = { zone: 8, lon: '121e28', lat: '31n14' };
  const jiazi = await runZeriScan({
    technique: 'bazizeri', action: 'scan',
    cfg: { startDate: '2026-03-01', startTime: '00:00', endDate: '2026-04-30', endTime: '23:59' },
    geo, options: { timeAlg: 1 },
    tree: { kind: 'group', joiner: 'all', negate: false, children: [
      { kind: 'leaf', type: 'day_ganzhi', negate: false, joiner: 'all', params: { values: ['甲子'] } }] },
  });
  assert(jiazi.data.ok === true, `扫描失败：${JSON.stringify(jiazi.data.error)}`);
  assert(jiazi.data.hit_count === 1, `61 天窗内甲子日应恰好 1 次，实得 ${jiazi.data.hit_count}`);
  const hit = jiazi.data.intervals[0];
  assert(hit.start === '2026-04-19 23:00' && hit.end === '2026-04-20 23:00',
    `命中区间应是子时为界的甲子日，实得 ${hit.start} ~ ${hit.end}`);
  // 独立锚：那一天的日柱由八字引擎自己算，必须是甲子。
  const dayGz = (d) => buildLocalBaziResult({ date: d, time: '12:00:00', zone: 8, lon: '121e28', gender: 1, timeAlg: 1 })
    .bazi.fourColumns.day.ganZhi;
  assert(dayGz('2026-04-20') === '甲子', `锚定日应为甲子，实得 ${dayGz('2026-04-20')}`);
  assert(dayGz('2026-04-19') === '癸亥' && dayGz('2026-04-21') === '乙丑', '前后日应为癸亥/乙丑');

  // 六个成员都必须能跑通并给出**结构化**结果（零命中也是合法结果，但错误绝不能降级成零命中）。
  // 叶参数取**引擎自带的 defaults**（newXLeaf 的产物），不是手编 —— 手编的参数会被 validate 拒掉，
  // 而「拒掉」在这条金标里恰好也会红，于是很难分清是接线坏了还是我参数写错了。
  const probes = {
    huanglizeri: { type: 'yi_has', params: { values: ['嫁娶'], matchMode: 'any' } },
    taiyizeri: { type: 'yinyang_ju', params: { value: '阳' } },
    ziweizeri: { type: 'wuxing_ju', params: { values: ['3'] } },
    liurengzeri: { type: 'ke_name', params: { values: ['元首课'] } },
    sanshizeri: { type: 'lr_ke_name', params: { values: ['元首课'] } },
  };
  for (const [technique, leaf] of Object.entries(probes)) {
    const r = await runZeriScan({
      technique, action: 'scan',
      cfg: { startDate: '2026-03-01', startTime: '00:00', endDate: '2026-03-08', endTime: '23:59' },
      geo, options: { timeAlg: 1 },
      tree: { kind: 'group', joiner: 'all', negate: false, children: [{ kind: 'leaf', negate: false, joiner: 'all', ...leaf }] },
    });
    assert(r.data.ok === true, `${technique} 扫描失败：${JSON.stringify(r.data.error)}`);
    assert(Number.isFinite(r.data.hit_count), `${technique} 未给出 hit_count`);
  }
  // 认不出的条件类必须**报错**，不能静默零命中（那读起来是一个有效的空结果）。
  const bogus = await runZeriScan({
    technique: 'bazizeri', action: 'scan',
    cfg: { startDate: '2026-03-01', startTime: '00:00', endDate: '2026-03-02', endTime: '23:59' },
    geo, tree: { kind: 'group', joiner: 'all', children: [{ kind: 'leaf', type: 'notARealConditionType', params: {} }] },
  });
  assert(bogus.data.ok === false && bogus.data.error.code === 'invalid_conditions',
    `未知条件类应结构化报错，实得 ${JSON.stringify(bogus.data)}`);
  assert(Object.keys(ZERI_TECHNIQUES).length === 6, '本地扫描成员应为 6 个');
});

check('liurengzeri 六壬择时真的起课：三传引擎 ChuangChart 接线 + 贵人流派改命中集', async () => {
  // 回归锚：vendored LiuRengMain.js 曾把 ChuangChart（三传引擎类）当 React 元素桩掉 → buildSanChuanData 抛
  // ReferenceError 被吞成 null → 每个时刻都「起盘失败」→ 六壬择时恒零命中（上面那条探针只断言 hit_count 有限，看不见）。
  // 真值：2028-04-01 福州，贵人流派 2（玄枢默认）贵人临寅于 01:07–03:07、05:55–07:07；流派 0 只在 05:07–05:55。
  // 权威：同刻 live 后端 liureng_gods（guirengType 2，01:02 起盘）二课「地盘寅→天盘亥→贵神贵人」= 贵人临寅
  // （2026-09-24 vendored v3.11.1+ 实例实测）；两流派贵人歌诀不同故命中集不同。
  const geo = { zone: '+08:00', lon: '119e18', lat: '26n05', gpsLon: 119.3, gpsLat: 26.08 };
  const cfg = { startDate: '2028-04-01', startTime: '00:00', endDate: '2028-04-01', endTime: '23:59' };
  const tree = { kind: 'group', joiner: 'all', children: [{ kind: 'leaf', type: 'guiren_pos', params: { values: ['寅'], dir: 'any' } }] };
  const rows = async (guirengType) => (await runZeriScan({ technique: 'liurengzeri', action: 'scan', cfg, geo, options: { guirengType }, tree }))
    .data.intervals.map((r) => `${r.start}~${r.end}`);
  assert(JSON.stringify(await rows(2)) === JSON.stringify(['2028-04-01 01:07~2028-04-01 03:07', '2028-04-01 05:55~2028-04-01 07:07']),
    `流派 2 应在两段临寅，实得 ${JSON.stringify(await rows(2))}`);
  assert(JSON.stringify(await rows(0)) === JSON.stringify(['2028-04-01 05:07~2028-04-01 05:55']),
    `流派 0 应只在一段临寅，实得 ${JSON.stringify(await rows(0))}`);
});

check('zeriSnapshotOpts 命中清单两旋钮 + 前 N 行判读树（紫微择时木三局）', async () => {
  // 权威：vendored utils/zeriSnapshotPrefs.js（上游 [Q-452 裁决 A / Q-453]）：maxRows 夹到 10–500（缺省 60），
  // explainRows 0–20（缺省 3）；判读树 = 工作台「详情▼」同源 explainAt，设定文本按 UI 叶 DFS 配对（zeriExplainText）。
  assert(JSON.stringify(zeriRowOpts({ maxRows: 1 })) === JSON.stringify({ maxRows: 10, explainRows: 3 }), 'maxRows 下限 10、判读缺省 3');
  assert(withLeafKind({ kind: 'group', children: [{ type: 'x' }] }).children[0].kind === 'leaf', '裸叶补 kind:leaf');
  const geo = { zone: '+08:00', lon: '119e18', lat: '26n05', gpsLon: 119.3, gpsLat: 26.08 };
  const cfg = { startDate: '2028-04-01', startTime: '00:00', endDate: '2028-04-02', endTime: '23:59' };
  const tree = { kind: 'group', joiner: 'all', children: [{ kind: 'leaf', type: 'wuxing_ju', params: { values: ['3'] } }] };
  const scan = await runZeriScan({ technique: 'ziweizeri', action: 'scan', cfg, geo, options: {}, tree });
  assert(scan.data.hit_count === 4, `两天窗木三局应 4 段，实得 ${scan.data.hit_count}`);
  const snap = await runZeriScan({ technique: 'ziweizeri', action: 'snapshot', cfg, geo, options: {}, tree, results: scan.data.intervals });
  const text = snap.snapshot_text;
  assert(text.split('   判读:').length - 1 === 3, `缺省前 3 行附判读树，实得 ${text.split('   判读:').length - 1}`);
  assert(text.includes('1. 2028-04-01 13:00 ~ 2028-04-01 15:00(120分) 命宫酉·空宫·木三局\n   判读:\n     · 设定 五行局·五行局:3 → 实际 木三局 ✓'),
    '首行判读树：设定配到 UI 叶、实际来自同源求值');
  const none = await runZeriScan({ technique: 'ziweizeri', action: 'snapshot', cfg, geo, options: {}, tree, results: scan.data.intervals, explainRows: 0 });
  assert(none.snapshot_text.split('判读:').length - 1 === 0, 'explainRows=0 不附判读树');
});

check('xiaoliuren(dao) 三数起三传 + 生克/化解，determinism', () => {
  const p = { nums: [5, 20, 7], school: 'dao', askEvent: '求财' };
  const r = runXiaoLiuRen(p);
  assert(r.snapshot_text, 'should emit a snapshot');
  ['[问事]', '[起课]', '[三传]', '[生克]', '[九神]', '[化解]'].forEach((h) => assert(r.snapshot_text.includes(h), `missing ${h}`));
  assert(JSON.stringify(r.data.chuan) === JSON.stringify(['小吉', '空亡', '速喜']), `unexpected 三传: ${r.data.chuan}`);
  assert(r.snapshot_text.includes('拜'), 'dao school should carry 拜解');
  const again = runXiaoLiuRen(p);
  assert(again.snapshot_text === r.snapshot_text, '同三数须同盘（冻结起课）');
  // 主流六宫无五行生克，段如实标注。
  const main = runXiaoLiuRen({ nums: [5, 20, 7], school: 'main', askEvent: '求财' });
  assert(main.snapshot_text.includes('主流六宫不调取五行生克'), 'main school should note no 生克');
});

check('feigong 时上起青龙飞九宫，7 段 + determinism', () => {
  const p = { qiMode: 'manualZhi', zhi: '午', dayGan: '甲', dayZhi: '子', mingAge: 35, mingGender: 'male', liuYueMonth: 1, askEvent: '求财' };
  const r = runFeiGong(p);
  assert(r.snapshot_text, 'should emit a snapshot');
  ['[问事]', '[起局]', '[干支]', '[命宫]', '[宫位]', '[运气]', '[应期]'].forEach((h) => assert(r.snapshot_text.includes(h), `missing ${h}`));
  assert(r.data.qiZhi === '午', `unexpected 起支: ${r.data.qiZhi}`);
  assert(r.snapshot_text.includes('甲乘龙飞九宫'), 'missing 甲乘龙飞九宫');
  const again = runFeiGong(p);
  assert(again.snapshot_text === r.snapshot_text, '同起支须同盘（冻结局）');
});

check('xiaochengtu 洛书九宫 + 股市段条件 + 大衍 seed 确定性', () => {
  const manual = runXiaoChengTu({ qiguaFa: 'manual', up: '乾', lo: '兑', dongYaos: [3], yongGong: 1, askEvent: '求财' });
  ['[问事]', '[起卦]', '[佈局]', '[推导]', '[四象]', '[应期]'].forEach((h) => assert(manual.snapshot_text.includes(h), `missing ${h}`));
  assert(!manual.snapshot_text.includes('[股市]'), 'non-stock must not emit [股市]');
  const stock = runXiaoChengTu({ qiguaFa: 'stock', open: '1563.60', close: '1571.10', yongGong: 1 });
  assert(stock.snapshot_text.includes('[股市]'), 'stock mode must emit [股市]');
  const noSeed = runXiaoChengTu({ qiguaFa: 'dayan' });
  assert(noSeed.data.reason === 'dayan_seed_required', 'dayan without seed must refuse');
  const a = runXiaoChengTu({ qiguaFa: 'dayan', seed: 12345 });
  const b = runXiaoChengTu({ qiguaFa: 'dayan', seed: 12345 });
  assert(a.snapshot_text === b.snapshot_text, '大衍同 seed 须同盘');
});

check('guice 报数起卦 + 演数四位 + 卦变断法 + determinism', () => {
  const p = { qiguaFa: 'baoshu', nums: [7, 9], hourZhi: '午', yearZhi: '午', monthZhi: '巳', lunarMonth: 4, lunarDay: 5, year: 2026, dayGan: '甲', pillars: ['丙午', '癸巳', '甲子', '庚午'], askEvent: '问事业' };
  const r = runGuice(p);
  assert(r.snapshot_text, 'should emit a snapshot');
  ['[占事直断]', '[起卦]', '[演数]', '[四位]', '[卦变]', '[断法]'].forEach((h) => assert(r.snapshot_text.includes(h), `missing ${h}`));
  assert(r.data.gua.ben === '山天大畜', `unexpected 本卦: ${r.data.gua.ben}`);
  assert(r.snapshot_text.includes('策数'), 'missing 策数');
  const again = runGuice(p);
  assert(again.snapshot_text === r.snapshot_text, '同起卦输入须同盘（冻结卦）');
});

// zhengchuan 铁板异步载条文正文库 → 用异步块（.mjs 顶层 await 可用）。
try {
  const tb = await runZhengChuan({ school: 'tieban', pillars: ['戊寅', '甲寅', '壬戌', '庚戌'], gender: 1, lunarMonth: 1, lunarDay: 24 });
  ['[起盘信息]', '[起数]', '[本命条文]', '[流年条文]'].forEach((h) => assert(tb.snapshot_text.includes(h), `tieban missing ${h}`));
  assert(tb.snapshot_text.length > 2000, 'tieban 本命条文正文应非空（verses 已链）');
  const xy = await runZhengChuan({ school: 'xinyi', item: '财', gong: '乾' });
  assert(xy.snapshot_text.includes('[起盘信息]'), 'xinyi 起盘信息 missing');
  const lq = await runZhengChuan({ school: 'liuqin', pillars: ['戊寅', '甲寅', '壬戌', '庚戌'], gender: 1, lunarMonth: 1, lunarDay: 24 });
  assert(lq.snapshot_text.includes('[十二宫与六亲宫]'), 'liuqin 十二宫与六亲宫 missing');
  console.log('  ok   zhengchuan tieban(条文)/xinyi(查询)/liuqin(六亲) 三流派');
} catch (err) {
  failures += 1;
  console.error(`  FAIL zhengchuan: ${err.message}`);
}

// 六壬三传 **值级** 钉死（v0.26.0）。此前只断言 `sanChuanBranches.length === 3` —— 那是形状不是值，
// 三传重排能静默通过。上游 v3.7.1 的两处勘正各留了可复核的具名课式，正好当金标：
//   #46 列举序≠判定序：八专须在遥克**之前**。旧序把「八专结构 + 遥克」误发蒿矢/弹射。
//   #62 伏吟末传子卯互刑：丁卯/己卯/辛卯 三日伏吟，末传 卯 → 午。
// 全域 8640 课（60 日干支 × 12 月将 × 12 时）穷举差分显示：改动仅落在这两桶内，桶外为 0。
try {
  const { buildLiuRengLayout, buildKeData } = await import('../src/vendor/liureng/liurengRefContext.js');
  const ChuangChart = (await import('../src/vendor/liureng/ChuangChart.js')).default;
  const baseObj = normalizeChart(liurengFix);
  const cast = (dayGanZi, yue, timeZhi) => {
    const chartObj = { ...baseObj, nongli: { ...baseObj.nongli, dayGanZi, time: `甲${timeZhi}` } };
    const layout = buildLiuRengLayout(chartObj, 2, { yue, timeZhi });
    const ke = buildKeData(layout, chartObj);
    const h = new ChuangChart({
      owner: null, chartObj, nongli: chartObj.nongli, ke: ke.raw,
      liuRengChart: { upZi: layout.upZi, downZi: layout.downZi, houseTianJiang: layout.houseTianJiang },
      x: 0, y: 0, width: 0, height: 0,
    });
    h.genCuangs();
    return { name: h.cuangs.name, chuan: h.cuangs.cuang.join('→') };
  };
  // #46 —— 上游逐字点名的两课。旧（错）序在此发蒿矢课/弹射课。
  const a = cast('甲寅', '戌', '丑');
  assert(a.name === '八专课', `甲寅日戌将丑时 应为八专课(上游 #46)，实得 ${a.name}`);
  assert(a.chuan === '空丑→癸亥→癸亥', `甲寅日戌将丑时 三传应为 空丑→癸亥→癸亥，实得 ${a.chuan}`);
  const b = cast('甲寅', '戌', '午');
  assert(b.name === '八专课', `甲寅日戌将午时 应为八专课(上游 #46)，实得 ${b.name}`);
  assert(b.chuan === '庚申→戊午→戊午', `甲寅日戌将午时 三传应为 庚申→戊午→戊午，实得 ${b.chuan}`);
  // #62 —— 伏吟(月将=时支)三卯日，末传取 午 而非 卯。
  for (const day of ['丁卯', '己卯', '辛卯']) {
    const r = cast(day, '子', '子');
    assert(r.chuan.endsWith('午'), `${day}日伏吟 末传应为 午(上游 #62 子卯互刑)，实得 ${r.chuan}`);
  }
  console.log('  ok   liureng 三传值级金标：#46 八专序 + #62 伏吟末传子卯互刑');
} catch (err) {
  failures += 1;
  console.error(`  FAIL liureng 三传值级金标: ${err.message}`);
}

// 灵棋经（上游 v3.9.0）值级金标 —— 段集恒定 + 同刻同卦幂等 + 卦是冻结值。
// 这三条是上游 __tests__/lingqi*.test.js 的不变量，headless 侧必须同样成立：
//   ① 七段恒出（注家开关只影响段内行，不改段集 —— 上游 parityAll 双向哨兵口径）；
//   ② 同一占时两次调用字节幂等（占时种子；headless 不走 random 档，否则古法「不可再擲」失守）；
//   ③ 给了 counts 就复排、绝不重掷（读档/事盘纪律）。
check('lingqi 七段恒出 + 同刻幂等 + counts 冻结不重掷', () => {
  const at = { year: 2028, month: 4, day: 6, hour: 9, minute: 33, question: '事业', category: 'career' };
  const a = runLingqi(at);
  const b = runLingqi({ ...at });
  const titles = a.snapshot_text.split('\n').filter((l) => l.startsWith('[')).map((l) => l.trim());
  assert(
    JSON.stringify(titles) === JSON.stringify(['[起盘信息]', '[棋势]', '[卦象]', '[繇辞]', '[诸家注]', '[课断]', '[断诗]']),
    `段集应恒为七段，实得 ${titles.join(' ')}`,
  );
  assert(a.snapshot_text === b.snapshot_text, '同一占时两次调用必须字节幂等（占时种子）');
  assert(Array.isArray(a.counts) && a.counts.length === 3, 'counts 必须是三层');
  assert(a.counts.every((n) => n >= 0 && n <= 4), `counts 各层应在 0..4，实得 ${a.counts}`);
  // 关掉全部注家显示：段头仍在，只有段内行变 —— 这正是「开关不改段集」。
  const hidden = runLingqi({ ...at, zhuVisible: { yan: 0, he: 0, chen: 0, liu: 0, ke: 0, shi: 0 } });
  const hiddenTitles = hidden.snapshot_text.split('\n').filter((l) => l.startsWith('[')).map((l) => l.trim());
  assert(JSON.stringify(hiddenTitles) === JSON.stringify(titles), '注家开关不得改变段集');
  assert(hidden.snapshot_text !== a.snapshot_text, '注家开关必须改变段内文本（否则开关是死旋钮）');
  // 冻结卦：显式 counts 必须被照单复排，而不是按种子重掷。
  const frozen = runLingqi({ ...at, counts: [4, 0, 2] });
  assert(
    JSON.stringify(frozen.counts) === JSON.stringify([4, 0, 2]),
    `冻结 counts 必须原样复排，实得 ${frozen.counts}`,
  );
});

// 天星择日 [单时判读]（v0.33.0）：explain 树（编译形）+ UI 树 DFS 配对 → 设定/实际 文本段。
check('tianxing explain_section renders 设定/实际 pairs with ✓✗', () => {
  // 叶用 skill schema 的裸形（{type, params}，无 kind）——这是 agent 实际传入的形状。
  const uiTree = {
    kind: 'group', joiner: 'all', children: [
      { type: 'in_sign', params: { planet: 'Venus', signs: [5] } },
      { type: 'aspect', params: { planetA: 'Venus', planetB: 'Moon', angle: 120, orb: 6 }, negate: true },
    ],
  };
  const explain = {
    kind: 'group', op: 'all', pass: false, children: [
      { kind: 'leaf', type: 'in_sign', pass: true, actual: '金 158°51′ 处女' },
      { kind: 'leaf', type: 'aspect', pass: false, actual: '金-月 距 120° 差 8.2°(限 6°)' },
    ],
  };
  const r = runTianxing({ action: 'explain_section', t: '2026/09/01 14:30:00', tree: uiTree, explain });
  assert(r.data.ok === true, 'data.ok should be true');
  const s = r.snapshot_text || '';
  assert(s.startsWith('[单时判读]'), 'missing [单时判读] header');
  assert(s.includes('判读时刻：2026/09/01 14:30:00'), 'missing 判读时刻 line');
  assert(s.includes('且(全部满足) ✗'), 'missing group gate line');
  assert(s.includes('✓') && s.includes('✗'), 'missing pass marks');
  const settings = s.split('\n').filter((l) => l.trim().startsWith('设定 '));
  const actuals = s.split('\n').filter((l) => l.trim().startsWith('实际 '));
  assert(settings.length === 2 && actuals.length === 2, `expected 2 设定/实际 pairs, got ${settings.length}/${actuals.length}`);
  assert(s.includes('(取反)'), 'negate leaf must carry (取反)');
  assert(actuals[1].includes('金-月'), 'actual text must come from the explain tree');
});

// 七政择日动盘（v0.33.0 批 I-1b）：山位换算走 vendored electionCore（232.9° 罗盘 → 00申山24，
// 与 GuoLaoElectionTable 同式）；黄道列为地支镜像度（白羊=戌）。
check('qizhengelection pan renders 地支度+山位+地平号', () => {
  const r = runQizhengElection({
    kind: 'pan',
    fields: { date: '2026-09-01', time: '14:30', zone: '+08:00', pos: '北京' },
    options: { plate: 'di', ziZheng: 'true', eleLifeMode: 'sunrise' },
    data: {
      trueSolarTime: '14:15:31', equationOfTimeMin: -0.0809, lifeDeg: 157.578,
      sunAzimuthSpeedDegPerMin: 0.2819,
      rise: { sunrise: '05:42:11', sunset: '18:31:04', moonrise: '20:02:00', moonset: '08:11:00' },
      planets: [
        { id: 'Sun', label: '日', lonTropical: 158.855, retrograde: false, azimuth: 232.9188, altitudeTrue: 46.25 },
        { id: 'Mercury', label: '水', lonTropical: 172.4, retrograde: true, azimuth: 245.1, altitudeTrue: -3.4 },
      ],
    },
  });
  assert(r.data.ok === true, `ok=false: ${JSON.stringify(r.data.error || {})}`);
  const s = r.snapshot_text || '';
  for (const sec of ['[起盘信息]', '[择日动盘]', '[天象要素]']) {
    assert(s.includes(sec), `missing ${sec}`);
  }
  // 158.855° = 处女 8°51′ → 镜像地支 巳（白羊=戌序）；232.92° 罗盘 → 00申山25（vendored mountainPosition 实算）。
  assert(s.includes('日：08巳51 | 00申山25+ | 方位 232.9° 高度 46.3° | 平'), `sun row wrong: ${s.split('\n').find((l) => l.startsWith('日：'))}`);
  assert(s.includes('| 逆'), 'retrograde mark missing');
  assert(s.includes('真太阳时：14:15:31') && s.includes('命度：07巳34（日出起）'), 'astronomy extras wrong');
});

check('qizhengelection eclipses decodes swisseph kind flags', () => {
  const r = runQizhengElection({
    kind: 'eclipses',
    fields: { date: '2026-09-01', zone: '+08:00' },
    options: { kind: 'solar' },
    data: { rows: [
      { date: '2027-02-06', time: '23:59:39', kindFlag: 9 },
      { date: '2027-08-02', time: '18:06:41', kindFlag: 5 },
    ] },
  });
  const s = r.snapshot_text || '';
  assert(s.includes('未来日食'), 'missing title');
  assert(s.includes('2027-02-06 23:59:39　环食·中心'), 'annular decode wrong');
  assert(s.includes('2027-08-02 18:06:41　全食·中心'), 'total decode wrong');
});

check('qizhengelection azimuthsearch rows carry 山位', () => {
  const r = runQizhengElection({
    kind: 'azimuthsearch',
    fields: { date: '2026-09-01', zone: '+08:00' },
    options: { body: '日', targetAz: 180, days: 1 },
    data: { rows: [{ date: '2026-09-01', time: '12:14:31', azimuth: 180.0 }] },
  });
  const s = r.snapshot_text || '';
  assert(s.includes('日 到达 180.0°(未来 1 天)'), 'missing title (upstream verbatim)');
  assert(s.includes('12:14:31　180.0°（07午山30）'), `row wrong: ${s}`);
});

check('tianxing explain_section without explain tree fails loudly', () => {
  const r = runTianxing({ action: 'explain_section', t: 'x', tree: null, explain: null });
  assert(r.data.ok === false, 'missing explain must be ok=false');
  assert(r.data.error.code === 'missing_explain_tree', `code=${r.data.error.code}`);
});

// 八字格局 值级金标：固定盘 1989-09-04 00:30 男（己巳 壬申 丁卯 庚子）跑真引擎，逐字冻结四项。
//
// 🔴 为什么要值级、不只查段头：baziGeju.js 曾把时柱键写成 `hour`（三个引擎一律读 `time`），四柱
// 静默变三柱 —— 段头照出、行数照够、任何「有没有 [格局·用神]」式断言全绿，只有值是错的：取格从
// 正财格塌成正官格、日主同党 34.3%(真值 27.9%)、盲派 `时宾()` 空。四柱来源与生产同构
// （buildLocalBaziResult 即上游本地引擎），所以这里冻的就是用户会看到的那串字。
check('baziGeju 值级金标：时柱入算 + 取格/成败/盲派逐字', () => {
  const birth = { date: '1989-09-04', time: '00:30:00', zone: 8, lon: 120, gender: 1, timeAlg: 1 };
  const bazi = buildLocalBaziResult(birth).bazi;
  const fc = bazi.fourColumns;
  assert(fc.time && fc.time.ganzi === '庚子', `fixture 时柱 drifted: ${fc.time && fc.time.ganzi}`);
  const s = runBaziGeju({ fourColumns: fc, birth }).snapshot_text || '';
  for (const sec of ['[五行力量]', '[格局·用神]', '[盲派结构]', '[月令司令（分野）]']) {
    assert(s.includes(sec), `missing ${sec}`);
  }
  // 取格：时柱缺席时会误判成「正官格（月令官·中气透干）」。
  assert(s.includes('格局：正财格（月令财·本气透干）'), `geju wrong: ${s.split('\n').find((l) => l.startsWith('格局：'))}`);
  // 成败/破格行（桌面 BaZi.js 有、快照层曾整行不渲染）。
  assert(s.includes('成败：破格——月令申逢刑，忌神坏格无救。'), 'missing 成败 line');
  // 五行力量：时柱庚子入算才是 27.9%（缺时柱 34.3%）。
  assert(s.includes('日主火：身弱（同党印比 27.9%'), `dayMaster wrong: ${s.split('\n').find((l) => l.startsWith('日主'))}`);
  // 盲派宾主四位齐全 —— 时柱缺席时这里是 `时宾()`。
  assert(s.includes('宾主：年宾(己巳) 月宾(壬申) 日主(丁卯) 时宾(庚子)'), `mangpai wrong: ${s.split('\n').find((l) => l.startsWith('宾主：'))}`);
  assert(!/时宾\(\)/.test(s), '时柱 dropped out of 盲派 (fourColumns key must be `time`, not `hour`)');
});

// ── 世运右栏卡片段（上游 v3.11 [Q-444/T-407]，vendored buildMundaneCardSections）───────────────────────
// 期望值一律**独立算出**，不抄 builder 的输出：上升座主星（古典宫主表）、赤道上升点（坐标公式）、元素计数
// （三分表）、KP 宿主/副主与 Vimshottari 余额（KP 定义：27 宿等分 13°20′、副主按 120 年大运比例细分）。
// 这组金标守的是「vendored 闭包真的活着」：截断/桩/改写任何一步出错（例如 ingressGovernance 没接回来），
// builder 的逐卡 try/catch 会把 ReferenceError 吞成「该卡不产」—— 只有值级断言能把它抓出来。
check('mundaneCards 值级金标：入宫底盘卡 + 吠陀/周期/食卡（vendored buildMundaneCardSections）', () => {
  const objs = Object.fromEntries(chart.chart.objects.map((o) => [o.id, o]));
  const jobs = [
    {
      id: 'ingress', chart,
      extra: { mundaneType: 'ingress', ingressTerm: '春分', ingressYear: 2025, ingressMoment: '2025-03-20 17:01:21' },
      state: { seasonSeed: { 春分: { time: '2025-03-20 17:01:21' }, 夏至: { time: '2025-06-21 10:42:00' } }, seasonSeedYear: 2025,
        patData: [{ type: 't_square', apex: 'Mars', points: ['Mars', 'Sun', 'Moon'] }] },
    },
    { id: 'vedic', chart, extra: { mundaneType: 'vedicmundane', vedicYear: 2025 }, state: { vedicMoment: '2025-04-14 05:53:45' } },
    { id: 'cycles', chart, extra: { mundaneType: 'cycles' }, state: {
      gcResults: [{ year: 2000, month: 5, sign: 1, lon: 52.7 }, { year: 2020, month: 12, sign: 10, lon: 300.5 }],
      gcPair: 'jupiter-saturn', gcAspect: 0, gcMode: 'ages', gcStart: 1300, gcEnd: 2200,
      bbData: { points: [{ year: 1990, month: 7, index: 512.4 }, { year: 1983, month: 1, index: 300.2 }, { year: 1901, month: 1, index: 1080 }] },
      bbSet: 'slow5', bbStart: 1900, bbEnd: 2050 } },
    { id: 'solecl', chart, extra: { mundaneType: 'solecl', selectedMoment: '2025-03-29 18:47:26', eclipseTypeText: 'partial', scanYear: 2025 },
      state: { eclipseDetail: { kind: 'solar', durationHours: 3.88, influence: 3.9, influenceUnit: '年' } } },
  ];
  const out = runMundaneCards({ jobs });
  assert(out.data.ok === true, 'every card job should be ok');
  const card = (id, title) => {
    const job = out.data.jobs.find((j) => j.id === id);
    const hit = job && job.cards.find((c) => c.title === title);
    assert(hit, `${id}: missing card [${title}]`);
    return hit.text.split('\n');
  };
  // [年盘概要]：上升天秤（fixture Asc 196.98°）→ 年主星=天秤宫主金星（古典宫主表）。modern 规则集 aries_annual → 12 个月。
  const ann = card('ingress', '年盘概要');
  assert(ann[1] === '2025 年 · 春分 · 白羊入宫 · 入宫时刻 2025-03-20 17:01:21', `年盘概要 head: ${ann[1]}`);
  assert(ann[2] === '上升 天秤 → 年主星(命主) 金星', `年盘概要 ruler: ${ann[2]}`);
  assert(ann[3] === '本盘上升 基本星座 · 现代(Carter–Campion) → 主管约 12 个月', `年盘概要 governance: ${ann[3]}`);
  // [四季入境盘]：时刻截到分（hit.time.slice(0,16)），缺的季写 —，当前节气标（当前）。
  const four = card('ingress', '四季入境盘');
  assert(JSON.stringify(four.slice(2)) === JSON.stringify(['- 春分·白羊：2025-03-20 17:01（当前）', '- 夏至·巨蟹：2025-06-21 10:42', '- 秋分·天秤：—', '- 冬至·摩羯：—']), `四季入境盘: ${four.slice(2)}`);
  // [四轴特殊点] 赤道上升点：λ_EQ = atan2(cos RAMC, −sin RAMC·cos ε)，RAMC 由 λ_MC 反推，ε 取 23.4367°。
  const D = Math.PI / 180; const eps = 23.4367 * D; const lm = objs.MC.lon * D;
  const ramc = Math.atan2(Math.sin(lm) * Math.cos(eps), Math.cos(lm));
  const ep = ((Math.atan2(Math.cos(ramc), -Math.sin(ramc) * Math.cos(eps)) / D) % 360 + 360) % 360;
  const SIGN_CN = ['白羊', '金牛', '双子', '巨蟹', '狮子', '处女', '天秤', '天蝎', '射手', '摩羯', '水瓶', '双鱼'];
  const axes = card('ingress', '四轴特殊点');
  assert(axes[1] === `赤道上升点：${SIGN_CN[Math.floor(ep / 30)]} ${(ep % 30).toFixed(2)}°`, `east point: ${axes[1]} vs ${ep}`);
  // [盘型格局] 元素计数：十体（七曜+三王星）按三分表计 —— fixture：日双子/月摩羯/水巨蟹/金巨蟹/火金牛/木巨蟹/土白羊/天双子/海白羊/冥水瓶。
  const EL = { aries: '火', leo: '火', sagittarius: '火', taurus: '土', virgo: '土', capricorn: '土', gemini: '风', libra: '风', aquarius: '风', cancer: '水', scorpio: '水', pisces: '水' };
  const tally = { 火: 0, 土: 0, 风: 0, 水: 0 };
  ['Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune', 'Pluto'].forEach((id) => { tally[EL[objs[id].sign.toLowerCase()]] += 1; });
  const pattern = card('ingress', '盘型格局');
  assert(pattern.some((l) => l.includes(`（火${tally.火}·土${tally.土}·风${tally.风}·水${tally.水}）`)), `element tally: ${pattern[2]}`);
  // 相位格局行只在 patData 属于本盘时出（st.patKey === chartRequestKey(chart)，headless 恒等键）：T 三角顶点火星。
  assert(pattern.includes('相位格局：'), 'patData must reach [盘型格局] (patKey pairing with the AstroExtraCommon stub)');
  assert(pattern.some((l) => l.startsWith('- T 三角（顶点 火星）：')), `T-square line: ${pattern.join(' | ')}`);
  // KP / Vimshottari：月黄经 → 第 floor(λ/13°20′)+1 宿；宿主按 Vimshottari 序；副主按 120 年比例细分。
  const NAK_LEN = 40 / 3; const SEQ = ['ketu', 'venus', 'sun', 'moon', 'mars', 'rahu', 'jupiter', 'saturn', 'mercury'];
  const YEARS = { ketu: 7, venus: 20, sun: 6, moon: 10, mars: 7, rahu: 18, jupiter: 16, saturn: 19, mercury: 17 };
  const CN_V = { sun: '日', moon: '月', mars: '火', mercury: '水', jupiter: '木', venus: '金', saturn: '土', rahu: '罗睺', ketu: '计都' };
  const moonLon = objs.Moon.lon; const nak = Math.floor(moonLon / NAK_LEN); const frac = (moonLon - nak * NAK_LEN) / NAK_LEN;
  const starLord = SEQ[nak % 9];
  let acc = 0; let subLord = null;
  for (let k = 0; k < 9 && !subLord; k += 1) { const lord = SEQ[(nak + k) % 9]; acc += YEARS[lord] / 120; if (frac < acc) subLord = lord; }
  const kp = card('vedic', 'KP 副主链');
  assert(kp.some((l) => l.startsWith(`| 月 | `) && l.endsWith(` | ${CN_V[starLord]} | ${CN_V[subLord]} |`)), `KP moon row: ${kp.find((l) => l.startsWith('| 月'))}`);
  const dasha = card('vedic', '世运大运');
  assert(dasha[1] === `（Vimshottari · 年长口径 365.2425（现代））起运主 ${CN_V[starLord]}（月在第 ${nak + 1} 宿,余额 ${((1 - frac) * 100).toFixed(1)}%）`, `dasha head: ${dasha[1]}`);
  const vedic = card('vedic', '吠陀世运·年度盘');
  assert(vedic[1] === '当前入境时刻：2025-04-14 05:53:45', `vedic moment: ${vedic[1]}`);
  // [木土纪元]：木土合相 · 地心 · 1300–2200（页面缺省，同 builder 的 clampYear 回落）· 共 2 次。
  const eras = card('cycles', '木土纪元');
  assert(eras[1] === '（木 ✕ 土（时代纪元）合相 · 地心 · 1300–2200 · 共 2 次）', `木土纪元 head: ${eras[1]}`);
  // [Barbault 聚散指数]：最深谷 = index 最小点（1983-01, 300.2→300°），最高峰 = 最大点（1901-01, 1080°）。
  const bb = card('cycles', 'Barbault 聚散指数');
  assert(bb[2] === '最深谷（聚集）1983-01（300°）；最高峰（四散）1901-01（1080°）', `barbault extrema: ${bb[2]}`);
  // [日食图判读] 食时长定则：日食 3.88 小时 → 3.9 年（state.eclipseDetail 原样入段）。
  const ecl = card('solecl', '日食图判读');
  assert(ecl[1] === '时刻 2025-03-29 18:47:26 · partial', `eclipse head: ${ecl[1]}`);
  assert(ecl.includes('时长：约 3.88 小时 → 影响约 3.9 年（食时长定则）'), 'eclipse duration rule line');
  card('solecl', '食族 Saros');
  card('solecl', '天象占参考');
});

// 择日 [回归与主限]（上游 v3.11 [Q-445]）：extra 由 Python 求根/取数后传入；JS 只 buildFacts + 上游排版。
// 期望：fixture 盘上升天秤；角宫（1/4/7/10）吉星木金、凶星土 → ▲▲▼；主限行照
// electionSnapshot.js:130-133 的「日期（±N 日）：应星 ← 迫星（法）」，method 为空时不带括号。
check('election [回归与主限] 值级金标：回归盘利钝 + 主限命中排版', () => {
  const r = runElectionTool({
    chart, topicId: 'marriage', natalChart: chart,
    extra: {
      returnSet: { solar: { momentStr: '2027-06-15 07:03:11', chart }, lunar: null },
      pdHits: [
        { promissor: 'N_Mars_180', significator: 'N_Pluto_0', method: 'Z', date: '2028-02-18', deltaDays: -48 },
        { promissor: 'S_Mars_60', significator: 'N_Jupiter_0', method: '', date: '2028-07-01', deltaDays: 86 },
      ],
    },
  });
  const s = r.snapshot_text || '';
  const start = s.indexOf('[回归与主限]');
  assert(start >= 0, 'missing [回归与主限]');
  const body = s.slice(start, s.indexOf('\n[', start + 1)).split('\n');
  assert(JSON.stringify(body) === JSON.stringify([
    '[回归与主限]',
    '- · 日返时刻 2027-06-15 07:03:11，上升 天秤。',
    '- ▲ 日返盘吉星 木星 临角宫（本期得助）。',
    '- ▲ 日返盘吉星 金星 临角宫（本期得助）。',
    '- ▼ 日返盘凶星 土星 临角宫（本期承压）。',
    '择日日期前后主限命中（±240 日内最近 2 条）：',
    '- 2028-02-18（-48 日）：N_Pluto_0 ← N_Mars_180（Z）',
    '- 2028-07-01（+86 日）：N_Jupiter_0 ← S_Mars_60',
  ]), `回归与主限 body: ${JSON.stringify(body)}`);
  assert(s.includes('[本命合参]'), 'natalChart must reach runElection (本命合参)');
  assert(r.data.natal.integrated === true && r.data.returns.returnCharts === 1, `receipts: ${JSON.stringify(r.data)}`);
  // 缺省路径（无本命/无 extra）：段不出、data 不多键。
  const plain = runElectionTool({ chart, topicId: 'marriage' });
  assert(!(plain.snapshot_text || '').includes('[回归与主限]') && !('natal' in plain.data) && !('returns' in plain.data), 'default path must stay byte-identical');
  // 有效主限时间钥匙由引擎解析器给（流派档 × 覆写），Python 不手抄。
  assert(runElectionTool({ chart, action: 'resolve_params', options: { pdTimeKey: 'Naibod' } }).data.effective.pdTimeKey === 'Naibod', 'override pdTimeKey');
  assert(runElectionTool({ chart, action: 'resolve_params' }).data.effective.pdTimeKey === 'Ptolemy', 'default pdTimeKey');
});

// [占星地图]（上游 utils/acgSnapshot.js 逐字 vendored）：数字全来自后端 ACGraph 响应，builder 只做取点/去重/格式化。
// 期望值按上游规则手推（acgSnapshot.js）：fmtLon 东经正 → MC 120.5 = 120.50°E、IC −59.5 = 59.50°W；ascAnchor 取 |纬| 最小点
// （lat −2 那点，lon 48.25）；交映 lum 档滤掉无日月的对（火–木），Math.round(42.5)=43 与 Math.round(42.9)=43 同纬线去重只留首条
// → 共 1 条；口径头行读 meta（topo=站心、draconic 'true'=真交点、harmonic 5）；uiState 缺省（无图层）时不出 ◆ 子块。
check('acgSection 值级金标：角化线取点 + 交映去重 + 口径头行（vendored buildAcgSectionText）', () => {
  const acgData = {
    meta: { mode: 'mundo', coord: 'topo', draconic: 'true', harmonic: 5, lsMode: 'great' },
    planets: {
      Sun: { lines: { mc: { lon: 120.5 }, ic: { lon: -59.5 }, lsAz: { az: 247.2, alt: 6.9 },
        asc: [{ lat: 10, lon: 50 }, { lat: -2, lon: 48.25 }, { lat: 30, lon: 60 }], desc: [] } },
      Moon: { lines: { mc: { lon: 30 }, ic: { lon: -150 }, asc: [], desc: [] }, oob: true },
    },
    parans: [
      { lat: 42.5, a: 'Sun', aEvent: 'mc', b: 'Moon', bEvent: 'rise' },
      { lat: 42.9, a: 'Moon', aEvent: 'set', b: 'Sun', bEvent: 'ic' },
      { lat: -12.25, a: 'Mars', aEvent: 'rise', b: 'Jupiter', bEvent: 'mc' },
    ],
  };
  const lines = runAcgSection({ acgData, uiState: { paranMode: 'lum', showLS: true } }).text.split('\n');
  assert(JSON.stringify(lines) === JSON.stringify([
    '【占星地图】',
    '口径 本体(in-mundo·真黄纬) · 坐标系 站心 · 龙黄道 真交点 · 谐波 H5',
    '主要行星角化线(中天/天底=经线;上升/下降取赤道附近代表点):',
    '- 太阳:MC 120.50°E / IC 59.50°W / ASC 48.25°E / DSC —',
    '- 月亮:MC 30.00°E / IC 150.00°W / ASC — / DSC — · 超界OOB',
    '◆ 本地空间线(画法 大圆;自出生地沿各星罗盘方位角延伸,方位角=正北起顺时针,高度角=出生时刻该星地平高度):',
    '| 星 | 方位角 | 高度角 |',
    '| --- | --- | --- |',
    '| 太阳 | 247.2° | 6.9° |',
    '◆ 行星交映(仅日月对,同图 1° 去重,共 1 条纬线):',
    '| 星A | 事件 | 星B | 事件 | 纬度 |',
    '| --- | --- | --- | --- | --- |',
    '| 太阳 | 中天 | 月亮 | 升 | 42.50°N |',
  ]), `acg lines: ${JSON.stringify(lines)}`);
  // 全部行星对：火–木那条纬线（−12.25 → 12.25°S）也进，共 2 条。
  const all = runAcgSection({ acgData, uiState: { paranMode: 'all' } }).text;
  assert(all.includes('共 2 条纬线') && all.includes('| 火星 | 升 | 木星 | 中天 | 12.25°S |'), `paran all: ${all}`);
  // 模块级「最近一次地图状态」每次调用前后清空：无 planets 的响应不许串出上一张图。
  assert(runAcgSection({ acgData: { meta: {} } }).text === '', 'stale acg snapshot leaked across calls');
});

// ── v0.40 mingli：八字 / 紫微 / 宿占 改由 vendored 上游 builder 出快照 ────────────────────────────
// 八字本地优先（tools/baziLocal.js = 上游 BaZi.js:716-755 fetchBaziCached 主路径）。
check('baziLocal 值级金标：晚子时四象限 + 命宫起法 + Java 回退形状', () => {
  const genParams = (extra) => ({
    date: '2026-05-27', time: '23:30:00', ad: 1, zone: '+08:00', lon: '121e28', lat: '31n13', gender: 1,
    timeAlg: 1, phaseType: 0, godKeyPos: '年', adjustJieqi: 0, minggongMethod: 'tongxing',
    fenyeVersion: 'common', cangVersion: 'common', dayunPrecision: 'precise', ...extra,
  });
  const pillar = (text, label) => (text.split('\n').find((l) => l.startsWith(`| ${label} |`)) || '').split(' | ')[1];
  // 权威：上游 utils/dayBoundary.js:49-57 矩阵（2026-05-27 23:30 直接时间；jest baziLunarLocal.dayBoundary
  // + Java BaZiHelper + 七路 Python 同口径 2026-09-18）：(1,1) 壬寅庚子 · (1,0) 壬寅戊子 · (0,1) 辛丑庚子 · (0,0) 辛丑戊子。
  const want = { '1,1': ['壬寅', '庚子'], '1,0': ['壬寅', '戊子'], '0,1': ['辛丑', '庚子'], '0,0': ['辛丑', '戊子'] };
  for (const [key, [day, hour]] of Object.entries(want)) {
    const [a23, lz] = key.split(',').map(Number);
    const out = runBaziLocal({ params: genParams({ after23NewDay: a23, lateZiHourUseNextDay: lz }) });
    assert(out.data.ok === true && out.data.local === true, `local engine must compute (${key})`);
    assert(pillar(out.snapshot_text, '日柱') === day && pillar(out.snapshot_text, '时柱') === hour,
      `${key}: ${pillar(out.snapshot_text, '日柱')} ${pillar(out.snapshot_text, '时柱')}`);
  }
  // 命宫起法（techniqueMountSettings.js:1705）：1990-05-15 10:30 上海真太阳时，通行版=癸未；子平数法=辛巳
  // （与 Java /bazi/birth 缺省 shufa 同盘实测一致 —— 跨引擎权威）。快照命宫行标起法（BaZi.js:397）。
  const mg = (m) => runBaziLocal({ params: genParams({ date: '1990-05-15', time: '10:30:00', lat: '31n14', timeAlg: 0, after23NewDay: 1, lateZiHourUseNextDay: 1, minggongMethod: m }) }).snapshot_text
    .split('\n').find((l) => l.startsWith('命宫：'));
  assert(mg('tongxing') === '命宫：癸未，干十神:伤，支十神:印（起法：通行版）', `tongxing: ${mg('tongxing')}`);
  assert(mg('shufa') === '命宫：辛巳，干十神:劫，支十神:杀（起法：子平数法）', `shufa: ${mg('shufa')}`);
  // 域外（公元前）本地抛错 → 回报 local_engine_unavailable（Python 据此回退 Java，上游同）。
  const bc = runBaziLocal({ params: genParams({ date: '-0100-05-15', ad: -1 }) });
  assert(bc.data.ok === false && bc.data.reason === 'local_engine_unavailable' && bc.snapshot_text === '', `BC: ${JSON.stringify(bc.data)}`);
  // Java 回退形状：命宫行按回退口径标「子平数法(本域回退)」，本地派生段（五行力量）不出。
  const jv = runBaziLocal({ params: genParams({}), java_result: { bazi: { nongli: { year: '丙午', month: '四月', day: '十一' }, fourColumns: { ming: { stem: { cell: '甲' }, branch: { cell: '子' } } } }, gender: 'Male' } });
  assert(jv.data.local === false && jv.snapshot_text.includes('命宫：甲子（起法：子平数法(本域回退)）') && !jv.snapshot_text.includes('[五行力量]'),
    `java fallback: ${jv.snapshot_text.slice(0, 400)}`);
});

// 紫微（tools/ziweiBirth.js = 上游 buildZiweiSnapshotForParams，ZiWeiMain.js:716-822）：传本开关非缺省 → 本地 ZiweiCalc；
// 流派切四化表；单例用毕还原。
check('ziweiBirth 值级金标：钦天局数年大限 + 中州派四化 + 单例还原', () => {
  const base = { date: '1985-11-07', time: '23:30:00', zone: '+08:00', lon: '121e28', lat: '31n13', gender: 1, timeAlg: 0, after23NewDay: 1, lateZiHourUseNextDay: 1 };
  const row = (text, name) => text.split('\n').find((l) => l.startsWith(`| ${name}`)) || '';
  const ju = runZiweiBirth({ action: 'finalize', params: { ...base, daxianSpan: 'ju' }, result: { chart: {} } });
  assert(ju.data.localEngine === true && ju.data.localApplied === true, `local engine: ${JSON.stringify(ju.data.localError)}`);
  // 土五局 + 钦天「大限跨度=局数年」→ 每限 5 年、命宫 5~9 起（ziweiCore.daxianRanges span=ju；三合缺省是 10 年 5~14）。
  assert(row(ju.text, '命宫·胎').includes('| 丙戌 | 5~9 |'), `命宫 row: ${row(ju.text, '命宫·胎')}`);
  assert(ju.text.includes('传本设置：大限跨度=局数年(钦天)') && ju.text.includes('四化流派：通用·飞星'), 'ju notes');
  // 戊干化科：通用·飞星 = 右弼，中州派 = 太阳（ziweiSchools SIHUA_OVERRIDES.zhongzhou 戊科 → 太阳）。官禄宫干戊 → 右弼自化科只在通用表。
  assert(row(ju.text, '官禄宫').includes('右弼（自化科）·旺'), `beipai 官禄: ${row(ju.text, '官禄宫')}`);
  const zz = runZiweiBirth({ action: 'finalize', params: { ...base, daxianSpan: 'ju', sihuaSchool: 'zhongzhou' }, result: { chart: {} } });
  assert(zz.text.includes('四化流派：中州派') && row(zz.text, '官禄宫').includes('、右弼·旺、'), `zhongzhou 官禄: ${row(zz.text, '官禄宫')}`);
  // prepare：中州派戊干四化表 = 贪狼/太阴/太阳/天机（发 Java 的 sihua）；认不出的值回报不静默。
  const prep = runZiweiBirth({ action: 'prepare', params: { sihuaSchool: 'zhongzhou', kuiYue: 'nope' } });
  assert(JSON.stringify(prep.data.sihua['戊']) === JSON.stringify(['贪狼', '太阴', '太阳', '天机']), `sihua 戊: ${JSON.stringify(prep.data.sihua && prep.data.sihua['戊'])}`);
  assert(prep.warnings.length === 1 && prep.warnings[0].key === 'kuiYue', `warnings: ${JSON.stringify(prep.warnings)}`);
  // 可变单例必须还原（同进程下一次缺省调用不得串味）。
  const plain = runZiweiBirth({ action: 'prepare', params: {} });
  assert(plain.data.school === 'beipai' && plain.data.localEngine === false && plain.data.sihua === null, `leak: ${JSON.stringify(plain.data)}`);
});

// 宿占（tools/suzhan.js = 上游 buildSuzhanSnapshotText，SuZhanMain.js:396-428）：人事十二宫起法 + 宿法标签。
check('suzhan 值级金标：八字公式/ASC 起宫 + 宿法九档标签 + 缺农历回落', () => {
  // fixture 盘（2026-06-02 14:30）上升赤经 201.3° → 天秤(6)；太阳赤经 70.2° → 双子(2)。
  // 八字公式（computeAscSignIndex :148-173）：(日座 − 时支座 − 5 + 24) % 12。时支取申（ZiSign 申=双子(2)）→ 7；ASC → 6。
  // 白羊宫头（signIdx 0）的宫序 = (0 − 起宫 + 12) % 12 + 1：八字公式 6、ASC 7。
  const params = { date: '2026-06-02', time: '14:30:00', zone: '+08:00', lon: '121e28', lat: '31n13', doubingSu28: 3 };
  const withShen = { ...chart, chart: { ...chart.chart, nongli: { bazi: { time: { branch: { cell: '申' } } } } } };
  const aries = (text) => text.split('\n').find((l) => l.startsWith('| 戌—降娄—白羊座—')) || '';
  const bazi = runSuzhan({ chart: withShen, params: { ...params, houseStartMode: 0 } });
  assert(aries(bazi.text).startsWith('| 戌—降娄—白羊座—第6宫 |') && bazi.data.nongliHour === '申', `bazi mode: ${aries(bazi.text)}`);
  assert(bazi.text.includes('宿法：回归古制开禧') && bazi.text.includes('人事十二宫起盘：八字公式起盘'), 'su28 label (guolaoData SU28_MODE_LABEL[3])');
  const asc = runSuzhan({ chart: withShen, params: { ...params, houseStartMode: 1 } });
  assert(aries(asc.text).startsWith('| 戌—降娄—白羊座—第7宫 |') && asc.text.includes('人事十二宫起盘：ASC起盘'), `asc mode: ${aries(asc.text)}`);
  // 缺 nongli（chart 服务的盘）→ 八字公式回落 ASC（上游同），并把「没拿到时支」回报给 Python。
  const bare = runSuzhan({ chart, params: { ...params, houseStartMode: 0 } });
  assert(aries(bare.text).startsWith('| 戌—降娄—白羊座—第7宫 |') && bare.data.nongliHour === null, `no nongli: ${aries(bare.text)}`);
  // 外盘/盘型两行只在显式给了才出（上游模型缺省不带这两键）。
  assert(!bazi.text.includes('外盘：') && runSuzhan({ chart, params: { ...params, szchart: 1 } }).text.includes('外盘：星座外盘'), 'szchart line gating');
});

// 🔴 wave-3 值级金标：三式合一快照由 vendored 上游 buildSanShiUnitedSnapshotText 产出（tools/sanshiUnited.js 按上游
// performRecalcByNongli 装配）。六壬层用 SanShiUnitedMain 自带的 buildLiuRengLayout/buildKeData/buildSanChuan、占时取奇门盘
// 时柱（buildLrNongli）；这里拿独立六壬页的同名三函数（vendored LiuRengMain）在同盘同时柱上再起一遍课 —— 两份上游实现
// 逐课逐传一致即权威。盘：chart_liureng.json（2026-04-04 21:18 上海，戊申日癸亥时，月将戌，星占法贵人，夜占）。
// 【大六壬】行格式 = SanShiUnitedMain.js:1534-1544（日干/上神/天将连写、空行、三传带天将、递生递克 + 徽记）。
// 负向对照：【大六壬】改回旧的 [四课] 体（「一课：地盘=戊，天盘=辰…」）或占时不取奇门盘时柱，本条即红。
check('sanshiUnited 值级金标：【大六壬】= 两份上游六壬实现同盘互证 + 上游行格式', () => {
  const nongli = liurengFix.liureng.nongli;
  const base = { date: '2026-04-04', time: '21:18:00', zone: '+08:00', lat: '31n13', lon: '121e28' };
  const dunjia = calcDunJia(makeFields(base), nongli,
    { paiPanType: 3, qijuMethod: 'zhirun', school: '转盘', timeAlg: 0, after23NewDay: 1, lateZiHourUseNextDay: 1 },
    { year: 2026, jieqiYearSeeds: { 2025: buildLocalJieqiYearSeed(2025, '+08:00'), 2026: buildLocalJieqiYearSeed(2026, '+08:00') },
      isDiurnal: liurengFix.chart.chart.isDiurnal, displaySolarTime: nongli.birth });
  const r = runSanshiUnited({ ...base, options: {}, nongli, displaySolarTime: nongli.birth, dunjia, chart: liurengFix.chart });
  assert(r.data.ok === true && r.data.warnings.length === 0, `sanshiUnited failed: ${JSON.stringify(r.data.error || r.data.warnings)}`);
  const text = r.snapshot_text;
  const block = (t) => ((text.split(`【${t}】\n`)[1] || '').split('\n【')[0].trim().split('\n'));
  const chartObj = { ...liurengFix.chart.chart, nongli: { ...nongli, dayGanZi: dunjia.ganzhi.day, time: dunjia.ganzhi.time } };
  const lay = lrmLayout(chartObj, 2, null);
  const ke = lrmKe(lay, chartObj);
  const sc = lrmSanChuan(lay, ke.raw, chartObj, null);
  const fromLrm = [
    ...ke.raw.map((k, i) => `${'一二三四'[i]}课：${k[2]}${k[1]}${k[0]}`), '',
    ...sc.cuang.map((gz, i) => `${'初中末'[i]}传：${gz}（${sc.tianJiang[i]}）`),
  ];
  const dalr = block('大六壬');
  assert(JSON.stringify(dalr.slice(0, 8)) === JSON.stringify(fromLrm), `三式六壬层 ≠ 独立六壬引擎：${JSON.stringify(dalr)} vs ${JSON.stringify(fromLrm)}`);
  assert(JSON.stringify(dalr) === JSON.stringify([
    '一课：戊辰朱雀', '二课：辰卯螣蛇', '三课：申未青龙', '四课：未午勾陈', '',
    '初传：空卯（螣蛇）', '中传：空寅（贵人）', '末传：癸丑（天后）',
    '三传递生递克：初传→中传 比和；中传→末传 克', '逐传徽记：中传寅(马)',
  ]), `【大六壬】${JSON.stringify(dalr)}`);
  assert(block('起盘信息').includes('月将：戌') && block('起盘信息').includes('四柱：丙午年/辛卯月/戊申日/癸亥时'), `【起盘信息】${JSON.stringify(block('起盘信息'))}`);
});

await Promise.all(pending);
if (failures > 0) {
  console.error(`\nselfcheck: ${failures} failure(s)`);
  process.exit(1);
}
console.log('\nselfcheck: all JS engine golden checks passed');
