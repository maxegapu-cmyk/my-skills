from __future__ import annotations

from pathlib import Path

from xuanshu_skill import config as config_module
from xuanshu_skill.config import Settings


def test_settings_from_env_uses_safe_fallbacks(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("XUANSHU_SKILL_DATA_DIR", str(tmp_path / "data-home"))
    monkeypatch.setenv("XUANSHU_RUNTIME_ROOT", str(tmp_path / "runtime-root"))
    monkeypatch.setenv("XUANSHU_RUNTIME_RELEASE_REPO", "   ")
    monkeypatch.setenv("XUANSHU_LOCAL_BACKEND_PORT", "not-a-port")
    monkeypatch.setenv("XUANSHU_LOCAL_CHART_PORT", "70000")
    monkeypatch.setenv("XUANSHU_RUNTIME_START_TIMEOUT_SECONDS", "0")
    monkeypatch.setenv("XUANSHU_JS_ENGINE_TIMEOUT_SECONDS", "-5")
    monkeypatch.setenv("XUANSHU_SKILL_PORT", "bad")
    monkeypatch.setenv("XUANSHU_SKILL_LOG_LEVEL", "debug")
    monkeypatch.setenv("XUANSHU_TRACE_ENABLED", "no")
    monkeypatch.setenv("XUANSHU_TRACE_CAPTURE_PAYLOADS", "yes")
    monkeypatch.setenv("XUANSHU_TRACE_CAPTURE_AI_ANSWERS", "1")
    monkeypatch.setenv("XUANSHU_TRACE_OTLP_ENDPOINT", "https://example.com/trace")
    # v0.38.1 R11：出厂预算按宿主是否仿真取 45 / 120；这里钉成原生，让断言与跑测试的机器无关。
    monkeypatch.setattr(config_module, "_host_runs_emulated", lambda: False)

    settings = Settings.from_env()

    assert settings.data_dir == tmp_path / "data-home"
    assert settings.runtime_root == tmp_path / "runtime-root"
    assert settings.db_path == settings.data_dir / "memory.db"
    assert settings.output_dir == settings.data_dir / "runs"
    assert settings.runtime_release_repo == "xuanshu-project/xuanshu-skill"
    assert settings.local_backend_port == 9999
    assert settings.local_chart_port == 8899
    # 冷启动默认 45s：Java+Python 后端首启常超 15s。
    assert settings.runtime_start_timeout_seconds == 45.0
    assert settings.mcp_compact is False
    assert settings.js_engine_timeout_seconds == 60.0
    assert settings.port == 8765
    assert settings.log_level == "DEBUG"
    assert settings.trace_enabled is False
    assert settings.trace_capture_payloads is True
    assert settings.trace_capture_ai_answers is True
    assert settings.trace_otlp_endpoint == "https://example.com/trace"


def test_settings_from_env_expands_user_paths(monkeypatch) -> None:
    monkeypatch.setenv("XUANSHU_SKILL_DB_PATH", "~/xuanshu-test/memory.db")
    monkeypatch.setenv("XUANSHU_SKILL_OUTPUT_DIR", "~/xuanshu-test/runs")
    monkeypatch.setenv("XUANSHU_TRACE_DIR", "~/xuanshu-test/traces")

    settings = Settings.from_env()

    assert str(settings.db_path).startswith(str(Path.home()))
    assert str(settings.output_dir).startswith(str(Path.home()))
    assert str(settings.trace_dir).startswith(str(Path.home()))


# ── v0.33.0 批 II-1 · env 旗标前向兼容（warn-and-ignore；STRICT 才拒）──────────────


def test_unknown_env_flag_warns_but_never_raises(monkeypatch) -> None:
    from xuanshu_skill import config as config_module

    monkeypatch.setenv("XUANSHU_TYPO_FLAG", "1")
    monkeypatch.delenv("XUANSHU_STRICT_CONFIG", raising=False)
    warnings = config_module.audit_env_flags(force=True)
    assert any("XUANSHU_TYPO_FLAG" in w for w in warnings)
    settings = config_module.Settings.from_env()  # 未知旗标绝不阻断加载（codex 0.112.0 反面教材）
    assert settings.server_root


def test_strict_config_rejects_unknown_flags(monkeypatch) -> None:
    import pytest

    from xuanshu_skill import config as config_module

    monkeypatch.setenv("XUANSHU_TYPO_FLAG", "1")
    monkeypatch.setenv("XUANSHU_STRICT_CONFIG", "1")
    with pytest.raises(ValueError, match="XUANSHU_TYPO_FLAG"):
        config_module.audit_env_flags(force=True)


def test_known_env_flags_produce_no_warnings(monkeypatch) -> None:
    from xuanshu_skill import config as config_module

    for key in list(__import__("os").environ):
        if key.startswith("XUANSHU_"):
            monkeypatch.delenv(key, raising=False)
    monkeypatch.setenv("XUANSHU_MCP_COMPACT", "1")
    monkeypatch.setenv("XUANSHU_SERVER_ROOT", "http://127.0.0.1:9999")
    assert config_module.audit_env_flags(force=True) == []


def test_env_registry_covers_all_flags_code_reads() -> None:
    """锁步：src/ 里出现的每个 XUANSHU_* 字面量都必须在 ENV_FLAG_REGISTRY 登记——
    新增旗标忘登记 = 用户一设就被 warn-and-ignore 误伤为「未知」。"""
    import re
    from pathlib import Path

    from xuanshu_skill.config import ENV_FLAG_REGISTRY, REMOVED_ENV_FLAGS

    src = Path(__import__("xuanshu_skill").__file__).parent
    seen: set[str] = set()
    for py in src.rglob("*.py"):
        seen.update(re.findall(r"XUANSHU_[A-Z0-9_]+", py.read_text(encoding="utf-8", errors="replace")))
    seen.discard("XUANSHU_")
    known = set(ENV_FLAG_REGISTRY) | set(REMOVED_ENV_FLAGS)
    # 排除测试夹具/文档示例专用名（不是运行时读的旗标）
    unregistered = sorted(k for k in seen if k not in known and not k.startswith("XUANSHU_TYPO"))
    assert unregistered == [], f"XUANSHU_* 旗标未在 ENV_FLAG_REGISTRY 登记：{unregistered}"


def test_default_start_timeout_grows_on_emulated_hosts(monkeypatch, tmp_path: Path) -> None:
    """真机矩阵 ARM lane 实测冷启动 59.6 s；45 s 出厂预算让健康机器的 selfcheck / runtime start 以 starting 收场。"""
    monkeypatch.setenv("XUANSHU_RUNTIME_ROOT", str(tmp_path / "rt"))
    monkeypatch.delenv("XUANSHU_RUNTIME_START_TIMEOUT_SECONDS", raising=False)
    monkeypatch.setattr(config_module, "_host_runs_emulated", lambda: True)
    settings = Settings.from_env()
    assert settings.runtime_start_timeout_seconds == 120.0
    assert settings.settings_provenance["runtime_start_timeout_seconds"] == "default:emulated_host"
    monkeypatch.setenv("XUANSHU_RUNTIME_START_TIMEOUT_SECONDS", "30")
    settings = Settings.from_env()
    assert settings.runtime_start_timeout_seconds == 30.0, "用户显式设置永远优先"
    assert settings.settings_provenance["runtime_start_timeout_seconds"] == "env:XUANSHU_RUNTIME_START_TIMEOUT_SECONDS"
    monkeypatch.delenv("XUANSHU_RUNTIME_START_TIMEOUT_SECONDS", raising=False)
    monkeypatch.setattr(config_module, "_host_runs_emulated", lambda: False)
    settings = Settings.from_env()
    assert settings.runtime_start_timeout_seconds == 45.0
    assert settings.settings_provenance["runtime_start_timeout_seconds"] == "default"


def test_host_runs_emulated_reads_the_arch_report_and_the_fallback_table(monkeypatch) -> None:
    import xuanshu_skill.runtime.manager as manager_module

    monkeypatch.setattr(manager_module, "arch_report", lambda: {"process": "x86_64", "native": "arm64", "emulated": True})
    assert config_module._host_runs_emulated() is True
    monkeypatch.setattr(manager_module, "arch_report", lambda: {"process": "arm64", "native": "arm64", "emulated": False})
    monkeypatch.setattr(manager_module, "_platform_key", lambda: "win32-arm64")
    assert config_module._host_runs_emulated() is True, "Windows on ARM 跑 x64 载荷 = 仿真"
    monkeypatch.setattr(manager_module, "_platform_key", lambda: "darwin-arm64")
    assert config_module._host_runs_emulated() is False
