"""托管发布流水线与真机矩阵的形状契约（v0.38.0 A5）。

**为什么旧检查抓不到**：`release.yml` 曾挂在 `push: tags` 上而 self-hosted runner 数为 0——20 次 tag 触发排队 24 h 后被取消，
零 step 执行，runs 页面却像有覆盖；`publish_darwin_release.sh --publish` 会先发一个 darwin-only 清单的公开 release，
「缺半」窗口由人肉补传关闭。本文件锁：流水线只手动触发、清单只上 draft、publish 必 needs matrix 且先过 [OK]、
矩阵永不挂 push/PR、三 lane 都跑 verify_runtime_live、ARM lane 的阻断性由输入控制、旧 release.yml 不复活。
"""

from __future__ import annotations

import re
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
WORKFLOWS = REPO_ROOT / ".github" / "workflows"
RELEASE = (WORKFLOWS / "release-runtime.yml").read_text(encoding="utf-8")
MATRIX = (WORKFLOWS / "runtime-matrix.yml").read_text(encoding="utf-8")
PUBLISH = (REPO_ROOT / "xuanshu-skill" / "scripts" / "publish_release.sh").read_text(encoding="utf-8")


def _job(text: str, name: str) -> str:
    match = re.search(rf"^  {name}:\n(.*?)(?=^  [a-z_-]+:\n|\Z)", text, re.S | re.M)
    assert match, f"job {name} missing"
    return match.group(1)


def test_release_pipeline_is_dispatch_only() -> None:
    on_block = RELEASE.split("\njobs:", 1)[0]
    assert "workflow_dispatch:" in on_block
    for trigger in ("push:", "pull_request:", "tags:", "schedule:", "release:"):
        assert trigger not in on_block, f"release-runtime.yml must not trigger on {trigger}"
    assert "github.repository_owner == 'xuanshu-project'" in _job(RELEASE, "resolve")


def test_release_pipeline_never_creates_a_public_release_itself() -> None:
    assert "gh release create" not in RELEASE, "only publish_release.sh creates the (draft) release"
    publish = _job(RELEASE, "publish")
    assert "needs: [resolve, assemble, matrix]" in publish
    assert "sync_windows_release.py --check --tag" in publish and "--draft" in publish
    assert "--draft=false --latest" in publish
    assert "!inputs.dry_run" in publish and "inputs.publish" in publish
    assert publish.index("sync_windows_release.py --check --tag") < publish.index("--draft=false --latest"), "[OK] before flipping"
    # release events raised with GITHUB_TOKEN start no workflows: the guard must be dispatched by the publish job itself
    assert "gh workflow run release-completeness.yml" in publish
    assert publish.index("--draft=false --latest") < publish.index("gh workflow run release-completeness.yml")
    # after flipping, the public latest is checked again; then (v0.38.1 R1/R5) the release-mode matrix is dispatched —
    # a real https download of the public assets — so the check is no longer the last step, but it still follows the flip
    recheck = publish.rindex("sync_windows_release.py --check\n")
    assert publish.index("--draft=false --latest") < recheck < publish.index("gh workflow run runtime-matrix.yml")


def test_windows_half_is_derived_from_the_seed_and_verified_before_upload() -> None:
    build = _job(RELEASE, "build-windows")
    assert "build_runtime_release_windows.py --seed" in build
    assert "runs-on: windows-latest" in build
    assemble = _job(RELEASE, "assemble")
    for needle in (
        "verify_runtime_python_lock.py --seed",
        "generate_release_manifest.py",
        "--url-base",
        "verify_runtime_release.py",
        "--expect-platforms darwin-arm64,win32-x64",
        "SHA256SUMS.txt",
        "generate_sbom.py",
        "attest-build-provenance",
    ):
        assert needle in assemble, needle
    upload = assemble[assemble.index("gh release upload"):]
    assert "runtime-manifest.json" in upload, "the dual manifest reaches the draft only from assemble"
    assert assemble.index("verify_runtime_release.py") < assemble.index("gh release upload"), "verify before upload"
    assert "if: ${{ !inputs.dry_run }}" in assemble, "dry runs never upload"


def test_matrix_is_called_between_assemble_and_publish() -> None:
    matrix = _job(RELEASE, "matrix")
    assert "uses: ./.github/workflows/runtime-matrix.yml" in matrix
    assert "source: artifact" in matrix and "needs: [resolve, assemble]" in matrix


def test_runtime_matrix_never_runs_per_push_and_covers_three_real_machines() -> None:
    on_block = MATRIX.split("\njobs:", 1)[0]
    assert "workflow_call:" in on_block and "workflow_dispatch:" in on_block and "schedule:" in on_block
    for trigger in ("push:", "pull_request:"):
        assert trigger not in on_block, f"runtime-matrix.yml must not trigger on {trigger}"
    for runner in ("macos-latest", "windows-latest", "windows-11-arm"):
        assert f"runner: {runner}" in MATRIX, runner
    assert "fail-fast: false" in MATRIX
    assert MATRIX.count("verify_runtime_live.py") >= 2, "both the POSIX and the Windows lane steps must run the verifier"
    assert "--expect-payload-platform" in MATRIX and "--expect-emulated" in MATRIX


def test_arm_lane_blocking_is_an_input_not_a_hardcode() -> None:
    assert "continue-on-error: ${{ matrix.platform == 'win32-arm64' && inputs.arm_nonblocking == true }}" in MATRIX
    # blocking by default since dry run #4 went green on windows-11-arm (2026-09-11)
    assert MATRIX.count("arm_nonblocking:\n        type: boolean\n        default: false") == 2
    assert "default: true" not in RELEASE.split("arm_nonblocking:", 1)[1][:200]
    assert "expect_payload: win32-x64" in MATRIX.split("runner: windows-11-arm", 1)[1][:600], "the ARM lane installs the x64 payload"


def test_matrix_uploads_evidence_even_on_failure() -> None:
    tail = MATRIX[MATRIX.index("Upload lane evidence"):]
    assert "if: always()" in tail and "xuanshu 测试 lane/logs/**" in tail and "lane-report.json" in MATRIX
    # one artifact root only (Windows upload-artifact refused runner.temp + `~`); the verifier copies launcher.log into logs/
    assert "~/" not in tail
    verifier = (REPO_ROOT / "xuanshu-skill" / "scripts" / "verify_runtime_live.py").read_text(encoding="utf-8")
    assert "launcher.log" in verifier and "_collect_service_logs" in verifier


def test_publish_script_only_ever_makes_drafts() -> None:
    creates = [line for line in PUBLISH.splitlines() if "gh release create" in line and not line.lstrip().startswith("#")]
    assert creates and all("--draft" in line for line in creates), creates
    assert "--publish" not in [a for line in PUBLISH.splitlines() if not line.lstrip().startswith("#") for a in line.split()], (
        "the darwin-only public publish path is gone"
    )
    assert "runtime-manifest.json" not in PUBLISH.split("=== [8/8] draft release", 1)[1], "the draft upload never carries the manifest"
    assert "gh workflow run release-runtime.yml" in PUBLISH
    assert "gh run watch" in PUBLISH


def test_the_never_run_self_hosted_release_workflow_is_gone() -> None:
    assert not (WORKFLOWS / "release.yml").exists(), "release.yml (self-hosted, 20 cancelled tag runs) must not come back"
    assert not (REPO_ROOT / "xuanshu-skill" / "scripts" / "publish_darwin_release.sh").exists()


# ---------------------------------------------------------------- v0.38.1 B3：矩阵与 CI 覆盖

COMPLETENESS = (WORKFLOWS / "release-completeness.yml").read_text(encoding="utf-8")
CI = (WORKFLOWS / "ci.yml").read_text(encoding="utf-8")


def test_release_and_schedule_lanes_install_through_the_public_manifest_url() -> None:
    """R1：release / dispatch / schedule 模式必须走公开清单 URL（真下载）。旧写法两种模式都 `--assets-dir` → file://，
    2026-09-14 的 schedule 跑的 lane-report 里 install.source 仍是 file://…lane-manifest.json —— 从没有 lane 下载过。"""
    source = MATRIX[MATRIX.index("Resolve the install source"):MATRIX.index("Live verification (POSIX)")]
    assert "mode=manifest-url" in source and "releases/download/${TAG}/runtime-manifest.json" in source
    assert "gh release download" not in source, "release/schedule lanes must not pre-download and localise to file://"
    assert "mode=assets-dir" in source, "artifact mode still installs the pipeline's assembled set"
    assert '"--${{ steps.source.outputs.mode }}" "${{ steps.source.outputs.value }}"' in MATRIX
    assert '--assets-dir "' not in MATRIX, "a hard-coded --assets-dir would silently skip the download path again"
    verifier = (REPO_ROOT / "xuanshu-skill" / "scripts" / "verify_runtime_live.py").read_text(encoding="utf-8")
    assert "download_problems(" in verifier and "installed_archive_sha256" in verifier


def test_matrix_cron_is_off_the_hour_and_the_completeness_guard_kicks_it() -> None:
    cron = re.search(r'cron: "(\d+) (\d+) \* \* 1"', MATRIX)
    assert cron, "weekly cron missing"
    assert cron.group(1) != "0", "on-the-hour slots are delayed/dropped by GitHub (the 03:00 slot fired 5.5 h late on 2026-09-14)"
    kick = _job(COMPLETENESS, "weekly-matrix-kick")
    assert "actions: write" in kick and "gh workflow run runtime-matrix.yml" in kick
    assert "github.event_name == 'schedule'" in kick and "--created" in kick


def test_matrix_work_dir_carries_a_space_and_cjk() -> None:
    """R10：带空格 + 中文的工作目录在三台真机上过一遍（A1 编码 / A4 引号）。"""
    assert MATRIX.count("xuanshu 测试 lane") >= 5
    assert "xuanshu-lane" not in MATRIX.split("Resolve the install source", 1)[1]
    # v0.38.1：Windows 的 runtime 根必须纯 ASCII（java.exe 的 ANSI API + Swiss Ephemeris 的 C fopen）——保留空格，不许任何非 ASCII
    windows_step = MATRIX[MATRIX.index("Live verification (Windows)"):MATRIX.index("Upload lane evidence")]
    root_line = next(line for line in windows_step.splitlines() if line.strip().startswith("$runtimeRoot ="))
    root_literal = root_line.split("'")[1]
    assert " " in root_literal and root_literal.isascii(), root_literal
    assert '--runtime-root "$runtimeRoot"' in windows_step
    verifier = (REPO_ROOT / "xuanshu-skill" / "scripts" / "verify_runtime_live.py").read_text(encoding="utf-8")
    assert "def non_ascii_root_refusal" in verifier and "self.non_ascii_root_refusal() and self.install()" in verifier


def test_publish_requires_the_matrix_and_the_same_bytes() -> None:
    """R5：publish=true 没有 run_matrix=true 直接 fail；publish job 不再接受 skipped 的 matrix；翻公开前比对 lane 装的 sha 与 draft 资产。"""
    resolve = _job(RELEASE, "resolve")
    assert "publish=true requires run_matrix=true" in resolve
    publish = _job(RELEASE, "publish")
    condition = next(line for line in publish.splitlines() if line.strip().startswith("if:"))
    assert "needs.matrix.result == 'success'" in condition and "skipped" not in condition
    assert "verify_matrix_digests.py" in publish and "pattern: runtime-matrix-*" in publish and ".digest" in publish
    # 负向对照：`releases/tags/<tag>` 只返回已公开的 release——publish job 在翻公开之前跑，对 draft 必然 404（首次核对时实测）
    publish_code = "\n".join(line for line in publish.splitlines() if not line.lstrip().startswith("#"))
    assert "releases/tags/" not in publish_code, "the draft's asset digests must come from the list endpoint, not releases/tags/<tag>"
    assert 'select(.tag_name == \\"${TAG}\\")' in publish and "--paginate" in publish
    # `gh workflow run` needs actions: write on GITHUB_TOKEN; job-level permissions replace the workflow's, so contents: write stays too
    assert "gh workflow run" in publish_code
    perms = publish.split("permissions:", 1)[1].split("runs-on:", 1)[0] if "permissions:" in publish else ""
    assert "actions: write" in perms and "contents: write" in perms, "publish must be allowed to dispatch workflows and edit the release"
    assert publish.index("verify_matrix_digests.py") < publish.index("--draft=false --latest"), "digest gate before the flip"
    assert "gh workflow run runtime-matrix.yml" in publish
    assert publish.index("--draft=false --latest") < publish.index("gh workflow run runtime-matrix.yml"), "release-mode matrix after the flip"


def test_completeness_checks_digests_min_os_and_the_mcpb_bundle() -> None:
    check = _job(COMPLETENESS, "check-latest-release-complete")
    assert "verify_mcpb_manifest.py --bundle" in check, "R8: unpack the published bundle"
    assert ".digest" in check and "SHA256SUMS.txt says" in check, "R15: SHA256SUMS lines vs GitHub's asset digests"
    assert "min_os" in check and "(0, 38, 1)" in check, "R16: min_os asserted from 0.38.1 on"


def test_ci_wheel_path_runs_a_real_stdio_probe_on_both_os() -> None:
    """R9/R18：wheel 装出来的包真起一次 stdio（全量面工具数从 contracts/mcp_list_budget.json 读，v0.40.0 起不再写死），Windows 上同样。"""
    test_job = _job(CI, "test")
    assert "--no-write --no-probe-network --skip-install" in test_job
    assert 'probe["tools"] == full == probe["expected_tools"]' in test_job and "mcp_list_budget.json" in test_job
    # 探针跑的是配置里那条命令：uvx-wheel 形态默认写发布页 URL，CI 上该版本尚未发布 → 必须预置 C15 的本地 wheel 缓存
    assert ".xuanshu/wheels" in test_job and "--no-cache-wheel" not in test_job, "the probe must run from the cached local wheel, not the unpublished URL"
    assert 'wheel_cached_path' in test_job
    assert "--dry-run --no-probe-network" not in test_job, "dry-run proves nothing about the wheel's data files"
    smoke = _job(CI, "windows-smoke")
    assert "--surface full" in smoke and "-ne $fullTools" in smoke and "full_tools" in smoke and "-ne 116" not in smoke
    assert "uvx --from $whl xuanshu-skill setup" in smoke and "uv build --wheel" in smoke
    assert ".xuanshu\\wheels" in smoke and "--no-cache-wheel" not in smoke and "wheel_cached_path" in smoke
