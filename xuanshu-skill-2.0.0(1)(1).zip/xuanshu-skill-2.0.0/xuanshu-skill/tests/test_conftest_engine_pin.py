"""The session pin in conftest.py must make the repo's core-js win over an installed runtime's copy."""

from __future__ import annotations

from pathlib import Path

from conftest import REPO_CORE_JS_ROOT

from xuanshu_skill.config import Settings
from xuanshu_skill.engine.js_client import XuanshuJsEngineClient


def _client_with_installed_runtime(tmp_path: Path) -> XuanshuJsEngineClient:
    """A fake installed runtime whose manifest points core-js at its own (stale) bundled copy."""
    runtime_root = tmp_path / "runtime"
    settings = Settings(runtime_root=runtime_root, data_dir=tmp_path / "data")
    (settings.runtime_current_dir / "xuanshu-core-js").mkdir(parents=True)
    client = XuanshuJsEngineClient(settings)
    manifest = {"artifacts": {"xuanshu_core_js_root": "xuanshu-core-js"}, "runtimes": {}}
    client.runtime_manager.load_installed_manifest = lambda *a, **k: manifest  # type: ignore[method-assign]
    return client


def test_repo_core_js_wins_over_an_installed_runtime_during_tests(tmp_path: Path) -> None:
    client = _client_with_installed_runtime(tmp_path)
    assert client._resolve_engine_root().resolve() == REPO_CORE_JS_ROOT.resolve()


def test_without_the_pin_the_installed_runtime_copy_would_win(tmp_path: Path, monkeypatch) -> None:
    # 负向对照：去掉 pin，解析顺序落回「已装 runtime 优先」——正是 pin 要防的那条路。
    monkeypatch.delenv("XUANSHU_CORE_JS_ROOT", raising=False)
    client = _client_with_installed_runtime(tmp_path)
    assert client._resolve_engine_root().resolve() == (client.settings.runtime_current_dir / "xuanshu-core-js").resolve()


def test_subprocess_children_import_this_checkout_not_the_editable_install() -> None:
    """Children spawned by the stdio/http tests must import the package under test.

    Without the conftest PYTHONPATH pin a child resolves `xuanshu_skill` through the venv's editable install,
    i.e. the checkout that ran `uv sync` — from a git worktree that is the main checkout (negative control,
    run by hand from a worktree: no pin → `<main>/xuanshu-skill/src/xuanshu_skill/__init__.py`).
    """
    import subprocess
    import sys

    from conftest import REPO_SRC

    out = subprocess.run(
        [sys.executable, "-c", "import xuanshu_skill, pathlib; print(pathlib.Path(xuanshu_skill.__file__).resolve())"],
        capture_output=True, text=True, check=True, timeout=60,
    ).stdout.strip()
    assert Path(out).is_relative_to(REPO_SRC.resolve()), out
