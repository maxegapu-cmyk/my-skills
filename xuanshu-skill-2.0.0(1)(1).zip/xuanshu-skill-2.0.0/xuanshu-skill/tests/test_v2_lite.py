"""玄枢 2.0 轻量引擎：不装离线 runtime 也能出盘，且关键数值与完整引擎对齐。"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import pytest

from xuanshu_skill import lite
from xuanshu_skill.config import Settings
from xuanshu_skill.input_normalization import normalize_request_payload
from xuanshu_skill.lite import almanac, astro, bazi, liuyao, ziwei
from xuanshu_skill.service import XuanshuSkillService

FIXTURES = Path(__file__).parent / "fixtures"


def _service(tmp_path: Path) -> XuanshuSkillService:
    return XuanshuSkillService(Settings(
        server_root="http://127.0.0.1:9", db_path=tmp_path / "m.db", output_dir=tmp_path / "runs",
        trace_dir=tmp_path / "tr", runtime_root=tmp_path / "no-runtime",
    ))


# ── 八字 ────────────────────────────────────────────────────────────────────────
def test_bazi_lichun_boundary_pillars_and_dayun() -> None:
    out = bazi.run(normalize_request_payload({"date": "1990-02-04", "time": "10:00", "place": "北京", "gender": "男"}))
    assert out["lite"]["pillars"] == {"年": "己巳", "月": "丁丑", "日": "庚子", "时": "辛巳"}
    text = out["snapshot_text"]
    assert "逆排" in text and "丙子" in text  # 阴年男命逆排，首运丙子
    titles = [s["title"] for s in out["export_snapshot"]["sections"]]
    assert titles[:3] == ["起盘信息", "四柱", "五行统计"] and "大运" in titles and "流年" in titles


def test_bazi_shishen_and_changsheng_tables() -> None:
    assert bazi.shishen("甲", "庚") == "七杀" and bazi.shishen("甲", "辛") == "正官" and bazi.shishen("甲", "癸") == "正印"
    assert bazi.changsheng("甲", "亥") == "长生" and bazi.changsheng("乙", "午") == "长生" and bazi.changsheng("乙", "巳") == "沐浴"


# ── 西洋星盘：与完整引擎（Swiss Ephemeris）同一张盘对照 ───────────────────────────
def _deg(text: str) -> float:
    signs = "牡羊 金牛 双子 巨蟹 狮子 室女 天秤 天蝎 射手 摩羯 宝瓶 双鱼".split()
    import re

    m = re.match(r"(\d+)˚(\S\S)(\d+)分", text)
    assert m, text
    return signs.index(m.group(2)) * 30 + int(m.group(1)) + int(m.group(3)) / 60


def test_lite_chart_matches_full_engine_within_arcminutes() -> None:
    fx = json.loads((FIXTURES / "sync311_chartexport_live.json").read_text(encoding="utf-8"))["tropical_default"]
    upstream = fx["upstream_text"]
    chart = astro.compute_chart(datetime(1990, 5, 4, 4, 30, tzinfo=timezone.utc), 31.233333, 121.5, 1)

    def upstream_value(label: str) -> float:
        line = next(l for l in upstream.splitlines() if l.startswith(f"| {label}"))
        return _deg(line.split("|")[2].strip())

    def close(a: float, b: float, tol: float = 0.05) -> bool:
        return abs((a - b + 180) % 360 - 180) <= tol

    assert close(chart["asc"], upstream_value("第一宫"))
    assert close(chart["mc"], upstream_value("第十宫"))
    assert close(chart["cusps"][10], upstream_value("第十一宫")) and close(chart["cusps"][1], upstream_value("第二宫"))
    names = {"太阳": "日 ", "月亮": "月 ", "金星": "金 ", "火星": "火 ", "木星": "木 ", "土星": "土 ", "冥王星": "冥 "}
    for p in chart["points"]:
        if p["name"] in names:
            assert close(p["lon"], upstream_value(names[p["name"]])), p["name"]
    retro = {p["name"] for p in chart["points"] if p["retro"]}
    assert {"水星", "天王星", "海王星", "冥王星"} <= retro and "金星" not in retro


def test_placidus_and_whole_sign_houses_are_consistent() -> None:
    t = datetime(1990, 5, 4, 4, 30, tzinfo=timezone.utc)
    for hsys in (0, 3, 9, 11):
        chart = astro.compute_chart(t, 31.23, 121.5, hsys)
        cusps = chart["cusps"]
        assert len(cusps) == 12
        for i in range(6):
            assert abs(((cusps[i + 6] - cusps[i]) % 360) - 180) < 1e-6
    whole = astro.compute_chart(t, 31.23, 121.5, 0)["cusps"]
    assert all(abs(c % 30) < 1e-9 for c in whole)


def test_solar_return_lands_on_natal_sun() -> None:
    inp = normalize_request_payload({"date": "1992-03-08", "time": "07:40", "place": "湖南长沙", "datetime": "2026-06-01 12:00:00"})
    out = astro.run_solarreturn(inp)
    assert "2026-03-0" in out["snapshot_text"] and "年度重点" in out["snapshot_text"]


def test_profection_year_lord() -> None:
    out = astro.run_profection(normalize_request_payload({"date": "1990-05-04", "time": "12:30", "zone": "+08:00",
                                                         "lat": 31.233, "lon": 121.5, "datetime": "2026-06-01"}))
    # 上升狮子座；36 岁 → 第 1 宫（36 % 12 = 0）→ 狮子座 → 年主星太阳
    assert out["lite"]["age"] == 36 and out["lite"]["house"] == 1 and out["lite"]["year_lord"] == "太阳"


# ── 紫微 ────────────────────────────────────────────────────────────────────────
def test_ziwei_chart_has_twelve_palaces_and_birth_year_sihua() -> None:
    out = ziwei.run(normalize_request_payload({"date": "1992-03-08", "time": "09:30", "place": "上海", "gender": "女"}))
    text = out["snapshot_text"]
    palace_rows = [s for s in out["export_snapshot"]["sections"] if s["title"] == "十二宫"][0]["body"].splitlines()[2:]
    assert len(palace_rows) == 12 and "命宫" in text and "五行局" in text
    # 壬年四化：天梁禄、紫微权、左辅科、武曲忌
    for s in ("天梁化禄", "紫微化权", "左辅化科", "武曲化忌"):
        assert s in text


def test_ziwei_without_gender_asks_for_it() -> None:
    out = ziwei.run({"date": "1992-03-08", "time": "09:30", "zone": "+08:00"})
    assert "需要性别" in out["snapshot_text"]


# ── 六爻 ────────────────────────────────────────────────────────────────────────
def test_liuyao_eight_palaces_and_shi_ying() -> None:
    assert len(liuyao.PALACE) == 64

    def desc(up: str, low: str) -> dict:
        return liuyao.describe(list(liuyao.TRIGRAMS[low] + liuyao.TRIGRAMS[up]))

    gou = desc("乾", "巽")
    assert gou["name"] == "天风姤" and gou["gong"] == "乾" and gou["shi"] == 1 and gou["ying"] == 4
    assert desc("离", "乾")["stage"] == "归魂卦" and desc("巽", "兑")["stage"] == "游魂卦"
    assert desc("坎", "离")["gong"] == "坎" and desc("坤", "乾")["shi"] == 3
    assert liuyao.liuqin("金", "火") == "官鬼" and liuyao.liuqin("金", "木") == "妻财" and liuyao.liuqin("金", "土") == "父母"


def test_liuyao_coin_input_and_moving_lines() -> None:
    out = liuyao.run({"lines": [7, 8, 9, 7, 6, 8], "askType": "wealth", "date": "2026-10-09", "time": "10:00"})
    assert out["lite"]["ben"] == "雷火丰" and out["lite"]["bian"] == "泽雷随" and out["lite"]["moving"] == [3, 5]
    assert "用神：妻财" in out["snapshot_text"]


# ── 黄历 / 小六壬 ───────────────────────────────────────────────────────────────
def test_huangli_and_xiaoliuren() -> None:
    hl = almanac.run_huangli({"date": "2026-10-09"})["snapshot_text"]
    assert "丙辰日" in hl and "宜：" in hl and "时辰吉凶" in hl
    xl = almanac.run_xiaoliuren({"nums": [8, 29, 10]})
    assert xl["lite"]["chain"] == ["留连", "空亡", "速喜"]


# ── 调度：没有 runtime 时自动改用轻量引擎 ───────────────────────────────────────
def test_run_tool_falls_back_to_lite_without_runtime(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("XUANSHU_ENGINE", "auto")
    svc = _service(tmp_path)
    env = svc.run_tool("ziwei_birth", {"date": "1992-03-08", "time": "09:30", "place": "上海", "gender": "女",
                                       "defaults_accepted": True}, save_result=False)
    assert env.ok, env.error
    assert env.data["export_snapshot"]["format_source"] == "xuanshu_lite"
    assert any("轻量引擎" in w for w in env.warnings)


def test_forced_lite_mode_and_full_mode(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("XUANSHU_ENGINE", "lite")
    assert lite.engine_mode() == "lite"
    svc = _service(tmp_path)
    env = svc.run_tool("sixyao", {"date": "2026-10-09", "time": "10:00", "zone": "+08:00", "lat": "31n13", "lon": "121e28",
                                  "defaults_accepted": True}, save_result=False)
    assert env.ok and env.data["export_snapshot"]["technique"]["key"] == "lite_sixyao"
    monkeypatch.setenv("XUANSHU_ENGINE", "full")
    assert not lite.should_fallback("runtime.not_installed")


def test_guide_only_recommends_available_methods_without_runtime(tmp_path: Path) -> None:
    svc = _service(tmp_path)
    guide = svc.beginner_guide({"question": "这次面试能过吗", "location": "上海"})
    tools = [r["tool"] for r in guide["recommended"]]
    available = lite.available_tools(tmp_path / "no-runtime")
    assert available is not None and set(tools) <= available
    assert "sixyao" in tools and "qimen" not in tools


def test_full_reading_natal_without_runtime(tmp_path: Path) -> None:
    out = _service(tmp_path).full_reading({
        "question": "我适合做什么工作", "defaults_accepted": True,
        "birth": {"date": "1992-03-08", "time": "09:30", "place": "湖南长沙", "gender": "女"},
    })
    assert out["ok"], out
    got = {t["tool"]: t for t in out["techniques"]}
    assert {"bazi_birth", "ziwei_birth", "chart"} <= set(got)
    assert all(t["ok"] and t["sections"] for t in got.values())
