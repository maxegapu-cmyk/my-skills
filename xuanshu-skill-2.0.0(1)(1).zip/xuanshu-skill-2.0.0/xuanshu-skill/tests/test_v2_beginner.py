"""玄枢 2.0 小白模式：问事分类、向导、白话解释、术语词典、一键全面解读、MCP / CLI 接入。"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from xuanshu_skill.beginner import MATTERS, annotate_terms, beginner_guide, classify_matter, explain
from xuanshu_skill.beginner.guide import READING_STYLE_RULES, REPORT_SECTIONS, load_glossary, load_technique_cards
from xuanshu_skill.beginner.matters import suggest_mode, tools_for
from xuanshu_skill.config import Settings
from xuanshu_skill.engine.registry import TOOL_DEFINITIONS
from xuanshu_skill.service import XuanshuSkillService

DATA = Path(__file__).resolve().parents[1] / "src" / "xuanshu_skill" / "beginner" / "data"


def _service(tmp_path: Path) -> XuanshuSkillService:
    settings = Settings(
        server_root="http://127.0.0.1:9", db_path=tmp_path / "m.db", output_dir=tmp_path / "runs", trace_dir=tmp_path / "tr"
    )
    return XuanshuSkillService(settings)


# ── 数据完整性 ──────────────────────────────────────────────────────────────────
def test_glossary_has_no_duplicate_keys_and_every_entry_is_complete() -> None:
    pairs = json.loads((DATA / "glossary.json").read_text(encoding="utf-8"), object_pairs_hook=list)
    terms = dict(pairs)["terms"]
    keys = [k for k, _ in terms]
    assert len(keys) == len(set(keys)), "duplicate glossary terms"
    glossary = load_glossary()
    assert len(glossary) >= 200
    for term, (domain, plain) in glossary.items():
        assert domain and len(plain) >= 8, term


def test_technique_cards_point_at_real_tools_and_are_complete() -> None:
    cards = load_technique_cards()
    assert len(cards) >= 20
    for tool, card in cards.items():
        assert tool in TOOL_DEFINITIONS, tool
        for key in ("name", "kind", "one_liner", "good_for", "needs", "how_to_read", "beginner_tip"):
            assert card.get(key), (tool, key)


def test_every_matter_recommends_real_tools_with_focus_points() -> None:
    assert len(MATTERS) >= 15
    for matter in MATTERS.values():
        for tool in (*matter.natal_tools, *matter.event_tools):
            assert tool in TOOL_DEFINITIONS, (matter.key, tool)
        for tool in matter.focus:
            assert tool in TOOL_DEFINITIONS, (matter.key, tool)


def test_reading_rules_and_report_sections_cover_the_beginner_contract() -> None:
    text = "".join(READING_STYLE_RULES)
    for must in ("第一句直接回答", "术语", "依据", "时间节点", "行动建议", "分歧", "医生"):
        assert must in text
    titles = [title for title, _ in REPORT_SECTIONS]
    assert titles[0] == "一句话结论" and titles[-1] == "本次用到的术语"


# ── 分类与看法 ──────────────────────────────────────────────────────────────────
@pytest.mark.parametrize(
    ("question", "matter", "mode"),
    [
        ("我这次面试能过吗", "career", "event"),
        ("我适合做什么工作", "career", "natal"),
        ("今年财运怎么样", "wealth", "natal"),
        ("我的钱包丢了能找到吗", "lost", "event"),
        ("下个月搬家选哪天好", "date", "date"),
        ("我是什么样的性格", "personality", "natal"),
        ("考研能上岸吗", "study", "event"),
        ("我该去北京还是上海工作", "decision", "event"),
    ],
)
def test_classify_and_mode(question: str, matter: str, mode: str) -> None:
    item = classify_matter(question)
    assert item.key == matter
    assert suggest_mode(question, item, True) == mode
    assert tools_for(item, mode)


def test_unknown_question_falls_back_to_general() -> None:
    assert classify_matter("随便看看").key == "general"
    assert classify_matter(None, "love").key == "love"


# ── 向导 ────────────────────────────────────────────────────────────────────────
def test_guide_asks_for_missing_birth_info_in_plain_words() -> None:
    guide = beginner_guide(question="我适合做什么工作")
    fields = {m["field"] for m in guide["missing_info"]}
    assert {"birth.date", "birth.time", "birth.place", "birth.gender"} <= fields
    assert guide["next_step"]["ready"] is False
    assert all("？" in q or "?" in q for q in guide["ask_user"])


def test_guide_ready_with_birth_info_runs_precision_check() -> None:
    guide = beginner_guide(question="我今年适合换工作吗", birth={"date": "1995-05-20", "time": "10:00", "place": "上海", "gender": "女"})
    assert guide["mode"] == "natal" and guide["next_step"]["ready"] is True
    assert guide["birth_precision"]["grade"] in {"A", "B", "C"}
    rec = guide["recommended"][0]
    assert rec["tool"] == "bazi_birth" and rec["look_at"] and rec["mcp_name"] == "xuanshu_cn_bazi_birth"


def test_event_guide_needs_question_and_location() -> None:
    guide = beginner_guide(mode="event")
    fields = {m["field"] for m in guide["missing_info"]}
    assert {"question", "location"} <= fields


def test_match_needs_partner_birth() -> None:
    guide = beginner_guide(question="我们俩合不合", birth={"date": "1995-05-20", "time": "10:00", "place": "上海", "gender": "男"})
    assert any(m["field"] == "partner_birth" for m in guide["missing_info"])


# ── 解释 ────────────────────────────────────────────────────────────────────────
def test_explain_term_tool_and_text() -> None:
    assert explain("七杀")["term"]["domain"] == "八字"
    card = explain(tool="ziwei_birth")["technique"]
    assert card["name"] == "紫微斗数" and card["how_to_read"]
    found = explain(text="日主庚金身弱，七杀透干，大运走正印，化忌入夫妻宫")["terms"]
    names = [t["term"] for t in found]
    assert names[:3] == ["日主", "身弱", "七杀"] and "化忌" in names
    overview = explain()
    assert overview["techniques"] and overview["matters"]


def test_annotate_terms_skips_single_character_terms() -> None:
    names = {t["term"] for t in annotate_terms("子午相冲，卯酉合")}
    assert "冲" not in names and "合" not in names


# ── 一键全面解读（本地 JS 技法，无需 runtime）──────────────────────────────────
def test_full_reading_need_info_when_birth_missing(tmp_path: Path) -> None:
    result = _service(tmp_path).full_reading({"question": "我的性格怎么样", "defaults_accepted": True})
    assert result["ok"] is False and result["stage"] == "need_info" and result["ask_user"]


def test_full_reading_event_mode_with_local_tarot(tmp_path: Path) -> None:
    result = _service(tmp_path).full_reading({
        "question": "我和他还有可能复合吗", "location": "上海", "tools": ["tarot"],
        "ask_time": "2026-10-09 18:30", "defaults_accepted": True,
    })
    assert result["ok"], result
    assert result["matter"]["key"] == "love" and result["mode"] == "event"
    tech = result["techniques"][0]
    assert tech["tool"] == "tarot" and tech["ok"] and tech["sections"]
    assert tech["look_at_for_this_question"] and tech["plain_card"]["name"] == "塔罗牌"
    assert "关系牌阵" in json.dumps(tech["sections"], ensure_ascii=False)
    assert result["glossary"] and result["report_skeleton"]["sections"]
    draft_titles = [s["title"] for s in result["ai_report_draft"]["analysis_sections"]]
    assert draft_titles[0] == "我们怎么看的" and draft_titles[-1] == "本次用到的术语"
    assert result["memory_ref"]["run_id"]


# ── MCP / CLI 接入 ──────────────────────────────────────────────────────────────
def test_mcp_registers_v2_facades_and_full_reading_is_gated(tmp_path: Path) -> None:
    from xuanshu_skill.surfaces.mcp_server import create_mcp_server

    service = _service(tmp_path)
    server = create_mcp_server(service, service.settings)
    names = {tool.name for tool in asyncio.run(server.list_tools())}
    for name in ("xuanshu_beginner_guide", "xuanshu_place_lookup", "xuanshu_birth_check", "xuanshu_explain", "xuanshu_full_reading"):
        assert name in names
    result = asyncio.run(server.call_tool("xuanshu_full_reading", {"question": "这次面试能过吗", "location": "上海"}))
    payload = result[1] if isinstance(result, tuple) else result
    text = json.dumps(payload if isinstance(payload, dict) else [getattr(c, "text", "") for c in payload], ensure_ascii=False)
    assert "need_confirmation" in text


def test_cli_birth_check_plain_and_guide(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from xuanshu_skill.surfaces.cli import app

    monkeypatch.setenv("XUANSHU_SKILL_DATA_DIR", str(tmp_path))
    runner = CliRunner()
    out = runner.invoke(app, ["birth-check", "--date", "1990-02-04", "--time", "10:00", "--place", "北京", "--plain"])
    assert out.exit_code == 0, out.output
    assert "出生时间体检" in out.output and "立春" in out.output
    out = runner.invoke(app, ["guide", "-q", "这次面试能过吗", "--plain"])
    assert out.exit_code == 0 and "六爻" in out.output
    out = runner.invoke(app, ["place", "湖南长沙"])
    assert out.exit_code == 0 and "Asia/Shanghai" in out.output
    out = runner.invoke(app, ["explain", "化忌"])
    assert out.exit_code == 0 and "紫微" in out.output
