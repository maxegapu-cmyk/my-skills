[简体中文](./README.md) | **English**

<div align="center">
  <h1>Xuanshu 玄枢 2.0</h1>
  <p><strong>An offline metaphysics &amp; astrology engine any AI can call locally — now with a birth-time precision check and a plain-language beginner mode.</strong></p>
  <p>Clone the repo, install the offline runtime once, and let Claude, Codex, Open WebUI, OpenClaw, etc. call <strong>110</strong> real techniques on your own machine — Western natal / predictive / horary / electional, BaZi / Zi Wei / Da Liu Ren / the Three Styles, and all <strong>14 Shen Shu</strong> systems — read the full Xuanshu AI-export protocol, return stable structured output, and persist every analysis as a retrievable local record. Every answer ships with a deterministic provenance card, a cited methodology knowledge base, a chart-fact faithfulness evaluator, and a multi-technique synthesis contract. Works offline, value-for-value identical to the Xuanshu desktop engine.</p>
  <p><a href="./docs/RELEASE_NOTES_2.0.md">What's new in 2.0</a> · <a href="./docs/BEGINNER_GUIDE.md">Beginner guide (中文)</a></p>

  <p><a href="https://github.com/xuanshu-project/xuanshu-skill"><img src="https://img.shields.io/badge/GitHub-Repository-111827?style=for-the-badge&logo=github" alt="Repository" /></a>&nbsp;<a href="https://github.com/xuanshu-project/xuanshu-skill/releases"><img src="https://img.shields.io/badge/GitHub-Releases-1d4ed8?style=for-the-badge&logo=github" alt="Releases" /></a>&nbsp;<a href="./README.md"><img src="https://img.shields.io/badge/阅读-简体中文-0f766e?style=for-the-badge" alt="Read in Chinese" /></a></p>

  <p>
    <img src="https://img.shields.io/github/stars/xuanshu-project/xuanshu-skill?style=flat-square" alt="GitHub stars" />
    <img src="https://img.shields.io/github/v/release/xuanshu-project/xuanshu-skill?display_name=tag&style=flat-square" alt="Release" />
    <img src="https://img.shields.io/badge/tools-110-1d4ed8?style=flat-square" alt="110 tools" />
    <img src="https://img.shields.io/badge/platform-macOS%20(arm64)%20%7C%20Windows%20(x64)-0f766e?style=flat-square" alt="Platforms" />
    <img src="https://img.shields.io/badge/runtime-offline%20first-111827?style=flat-square" alt="Offline runtime" />
    <img src="https://img.shields.io/badge/MCP-ready-111827?style=flat-square" alt="MCP ready" />
    <img src="https://img.shields.io/badge/knowledge-30%20domains%2C%20cited-111827?style=flat-square" alt="Cited knowledge base" />
    <img src="https://img.shields.io/badge/storage-SQLite%20%2B%20JSON-111827?style=flat-square" alt="SQLite and JSON" />
  </p>

  <p><a href="./LICENSE"><img src="https://img.shields.io/badge/License-AGPL--3.0-374151?style=flat-square" alt="License" /></a>&nbsp;<a href="./CONTRIBUTING.md"><img src="https://img.shields.io/badge/Contributing-Guide-0f766e?style=flat-square" alt="Contributing" /></a>&nbsp;<a href="./SECURITY.md"><img src="https://img.shields.io/badge/Security-Policy-991b1b?style=flat-square" alt="Security" /></a>&nbsp;<a href="./SUPPORT.md"><img src="https://img.shields.io/badge/Support-Paths-1d4ed8?style=flat-square" alt="Support" /></a>&nbsp;<a href="./CITATION.cff"><img src="https://img.shields.io/badge/Citation-CFF-7c3aed?style=flat-square" alt="Citation" /></a></p>
</div>

---

## What's new in 2.0

**Beginner mode — ask in plain words.**

- `xuanshu_beginner_guide`: classifies a plain question into 16 matters (career, wealth, love, compatibility, health, study, travel, lawsuits, lost items, date selection, personality, yearly outlook, children, family, decisions, general), decides between reading a **natal chart**, **casting a divination** or **electing a date**, recommends two or three techniques with *why* and *what to look at on the chart*, and asks for missing data in plain language.
- `xuanshu_full_reading`: one call = guide → birth-time check → multi-technique synthesis → a beginner reading workbook (plain technique cards, a per-question checklist, the real exported sections, an auto-glossary of every term in the output, a report skeleton and a pre-filled `ai_report` draft for DOCX/PDF).
- `xuanshu_explain`: a 215-term plain-language glossary and 27 technique cards (what it is, what it answers, what it needs, how to read it step by step).
- A shared reading style: answer first, gloss every term on first use, cite the chart section for every claim, concrete timing and actionable advice, disclose divergence, no fatalistic or frightening language, and refer health / legal / financial questions to professionals.

**Precision layer — catch input errors before casting.**

- Offline gazetteer (~18,000 places; ~5,400 towns in Greater China) with IANA timezones; **every calculation tool accepts `place`** instead of lat/lon/zone.
- `xuanshu_birth_check`: historical daylight saving (China 1986–1991 and worldwide), nonexistent and repeated wall-clock times, fixed-offset vs. legal-time conflicts, true solar time (longitude + equation of time, ±3 s, with a longitude / DST / EoT breakdown), 时辰 and solar-term boundary risk with candidate pillars on the other side, both 晚子时 conventions, zodiac split, and an A/B/C grade.
- 28 natal techniques run the check automatically and surface boundary risks in `warnings`.

**No big download needed.** A built-in pure-Python lite engine (a few MB of dependencies) casts BaZi, Zi Wei, Western natal charts, solar returns, profections, 六爻, 小六壬, the almanac, lunar conversion and solar terms right after `uv sync`. When the full offline runtime is installed it is used automatically; otherwise calls fall back to the lite engine, and the beginner guide only recommends methods that can run (`XUANSHU_ENGINE=auto|lite|full`). Use `xuanshu setup --client <client> --lite` to skip the 730 MB runtime.

**New naming.** Package `xuanshu-skill`, CLI `xuanshu`, MCP tools `xuanshu_*`, env vars `XUANSHU_*`, version 2.0.0.

## In one sentence

Xuanshu already has a complete local engine, ephemeris, export settings, and a multi-technique system. **Xuanshu Skill does not rebuild a simplified calculator** — it packages those capabilities into a product-grade interface layer made for GitHub distribution, AI invocation, and long-term local management: the engine runs on your machine, the output is stable JSON + Xuanshu-style export snapshots, and every call is automatically written as a retrievable local knowledge record.

It solves six things:

- **Get it and use it** — clone from GitHub, install the full offline runtime from GitHub Releases, then run offline.
- **A real AI interface** — call genuine Xuanshu methods over `MCP` or a `JSON-first CLI`, not a loose prompt layer.
- **Stable & consumable** — every technique returns a uniform envelope + Xuanshu-style `export_snapshot` / `export_format`; neither machine nor human has to guess fields.
- **Auditable** — every response carries a technique provenance card; doctrine quotes carry sources; AI readings can be verified claim-by-claim against machine-read chart facts.
- **Manageable long-term** — one call = one traceable record (run / artifact / manifest / final AI answer).
- **Light repo** — code, docs, CLI, MCP, tests in Git; the heavy runtime in Releases.

License: the repo is published under `GNU AGPL-3.0-only` (root [LICENSE](./LICENSE)). The three bundled third-party `ken` engines are used under their own MIT licenses (see [Credits](#credits-the-bundled-open-source-ken-engines)).

## Documentation map

| Doc | Content |
| --- | --- |
| [`docs/RELEASE_NOTES_2.0.md`](./docs/RELEASE_NOTES_2.0.md) | What's new in 2.0 |
| [`docs/BEGINNER_GUIDE.md`](./docs/BEGINNER_GUIDE.md) | Beginner guide (Chinese) |
| [`NOTICE.md`](./NOTICE.md) | Third-party components and data |
| [`docs/ARCHITECTURE.md`](./docs/ARCHITECTURE.md) | Architecture |
| [`docs/INPUT_CONTRACTS.md`](./docs/INPUT_CONTRACTS.md) | Per-tool input contracts (required fields) |
| [`docs/DATA_CONTRACTS.md`](./docs/DATA_CONTRACTS.md) | Output / envelope / export data contracts |
| [`docs/EXPORT_AUDIT_GUIDE.md`](./docs/EXPORT_AUDIT_GUIDE.md) | Section-by-section audit method for predictive exports |
| [`docs/OPERATIONS.md`](./docs/OPERATIONS.md) · [`docs/EVALUATION.md`](./docs/EVALUATION.md) | Operations · evaluation (XuanshuBench / faithfulness) |
| [`docs/OFFLINE_RUNTIME_RELEASES.md`](./docs/OFFLINE_RUNTIME_RELEASES.md) | Offline runtime packaging & release |
| [`docs/LESSONS.md`](./docs/LESSONS.md) · [`docs/GLOSSARY.md`](./docs/GLOSSARY.md) | Append-only lessons ledger · domain glossary |
| [`server.json`](./server.json) · [`skills/xuanshu-agent/SKILL.md`](./skills/xuanshu-agent/SKILL.md) · [`AGENTS.md`](./AGENTS.md) | MCP metadata · the single policy source for AI clients (with references/ sheets) · agent rules-of-record (iron laws / compute model / packaging & release law / symptom table) |

## Current stable baseline

**Current public version: `Xuanshu Skill 2.0.0` (110 callable tools).**

This release line brings the capability surface roughly to parity with the desktop app — and adds a trust stack no other metaphysics tool ships:

- **Trust stack (v0.27.0–v0.36.0)** — every response carries a deterministic **technique provenance card** (`data.technique_card`); `xuanshu_technique_report` renders methods reports and detects cross-technique setting conflicts; a **31-domain knowledge base** (409 cited entries) returns every doctrine entry with a file-and-version citation; a **chart-fact faithfulness evaluator** verifies AI readings claim-by-claim against machine-read chart truth; and **`xuanshu_hecan`** runs multi-technique synthesis under a divergence-disclosure contract.
- **Upstream parity (v0.28.0)** — export contract v14 mirrors the desktop app's aiExport v56 (Xuanshu v3.9.3): four classical-derived sections, BaZi stem/branch combination-clash lines, Zi Wei body palace + BaZi major periods, almanac sub-source labels, derived-chart dedicated sections, and the 天星择日 selected-moment chart.
- **Full Western astrology** — natal and derived charts, 10 classic return/progression/timeline tools, 3 v2.4.0 Western additions (Age Point / Distributions / mundane ingress), 7 v2.5.0 progressions (Jayne declination / Vedic sidereal / Planetary Arc / Ages of Man / Balbillus / 129-year system / Persian Directed), plus full **horary** and **electional** judgment engines.
- **Primary Direction v12, verified methods (v2.6.6)** — the directions table converges on the **5 per-row-verified methods** (Alcabitius / Meridian / Porphyry / Equal-ecliptic / Equal-hour-circle; unverified values fall back to Alcabitius inside the engine), In Zodiaco/In Mundo frames, direct+converse, **22 time keys** (incl. per-chart Simmonite/Kepler/Brahe and dynamic True/Symbolic Solar Arc), antiscia/terms as promissors, **Vertex significator rows**, and **pdYears up to 3000** with per-revolution recurrence rows; the **midpoint chart** is a Hamburg/Uranian 90° dial (8 TNP + planetary pictures / antiscia / midpoint list).
- **Sidereal zodiac & full India (v2.6.4)** — every Western technique chart supports **47 ayanāṃśa** sidereal modes (default Lahiri, tropical charts unchanged) + a **nakshatra (西洋月宿)** row; Vedic India charts go from 4→**24 house systems** and 6→**47 ayanāṃśa**.
- **Classical astrology completion (v2.6.7)** — the chart family gains **[古典] (Classical)** and **[古典格局] (Classical patterns)** sections (per-planet classical status, besiegement, doryphory, translation/collection of light, Almuten figuris, temperament, extended Arabic lots, …), derived value-for-value by vendored formulas; v0.28.0 adds the four **classical-derived** sections (derived houses / dispositor chains / almuten table / planetary-hours ruler). 
- **Chinese metaphysics core** — BaZi, Zi Wei, Da Liu Ren, Qi Men, Tai Yi, Jin Kou Jue, the Three Styles unified, Tong She Fa, He Luo Li Shu, Shao Zi Can Ping Shu, harmonic charts, Su Zhan, Liu Yao.
- **Interpretation layers (v0.10.0 / v0.11.0)** — Qi Zheng Si Yu gains **major-period + aspects + Zheng-Yu patterns** (Moira DSL), Jin Kou Jue a **20-section reading layer**, Da Liu Ren **common shen-sha + the 100 Bi-Fa rules + divination guide**, Qi Men the **Fa Qi Men overlay**, and Zi Wei **matched patterns / secondary stars / school-specific si-hua** (incl. Tian-Shang/Tian-Shi placement).
- **All 14 Shen Shu** — 5 standalone (Huang Ji Jing Shi / Wu Zhao / Tai Xuan / Jing Fang Yi / Shen Yi Shu) + 9 (Shao Zi / Tie Ban / Fen Jing / Bei Ji / Nan Ji / Chun Zi / Yan Qin / Ce Tian / Qi Zheng·Zhang Guo).
- **Same backend** — Qi Men / Tai Yi / Jin Kou Jue (and the Qi Men + Tai Yi inside the Three Styles) run on Xuanshu's `ken` backend (`kinqimen` / `kintaiyi` / `kinjinkou`); the 14 Shen Shu run on kentang engines mounted on the Xuanshu chart service; results are reformatted by the headless JS layer into `aiExport.js` sections. **The Skill and the Xuanshu desktop app share one backend, value-for-value identical.**

A hard protocol runs throughout: **the AI may not invent parameters**. Whenever a technique is affected by time, place, timezone, gender, topic, house system, calendar, or casting method, the agent cannot proceed until the user confirms — the tool returns a structured block with a question you can forward verbatim.

Local end-to-end signals:

| Check | Result |
| --- | --- |
| Callable tools | `110 / 110 ok=true` |
| Engineering tests | `1723 / 1723 pass` (offline CI shape: contract + export fixtures + node JS golden; a further 115 live integration tests need a local runtime and auto-skip when services are down) |
| Forced clarification when params unconfirmed | `84` technique tools trigger `must_ask_user=true` |
| Safe-exempt tools | `8` registry / knowledge / parser tools are directly readable |
| Xuanshu-style export structure | every business technique carries `export_snapshot` / `export_format` (`107` export techniques modeled; contract v14 mirrors desktop aiExport v56) |
| Technique provenance | every technique response carries `data.technique_card`; a declared-vs-measured compute mismatch is flagged explicitly |
| Knowledge base | 31 domains; 236 manual entries, each returned with a file-and-version citation |
| XuanshuBench | 106 registry-locked benchmark cases + chart-fact faithfulness evaluation (wrong-chart and sycophancy adversarial cases go red) |
| Local memory / report | every technique call writes 1 local run record + 1 JSON artifact |
| Qi Men / Tai Yi / Jin Kou / Three Styles | unified on `ken`, same as the desktop app |
| Tong She Fa / Decennials | headless, value-for-value with Xuanshu (`decennials.test.js` golden) |
| GitHub CI | Linux unit tests + xuanshu-core-js JS golden self-check + Windows OpenClaw smoke (**does not cover the cross-tree upstream checks** — those need an upstream checkout and only run via `preflight_release.py` on the maintenance box) |
| Release runtime | macOS (arm64) + Windows (x64) assets (ken + 14 Shen Shu engines bundled) packaged and verified on every release; other platforms/arches fail install with an explicit unsupported error |

> About `solarreturn` / `lunarreturn` / `solararc` / `givenyear` / `profection` / `pd` / `pdchart` / `zr`: these predictive tools are verified working in this version and should not be flagged by an agent as "Java `/predict/*` unavailable". If a client still says so, check whether it is on an old runtime, bypassing MCP to hand-compute, or hasn't run `doctor` / `openclaw-check --full`.

## Capability map (110 tools)

> Every business technique returns a uniform envelope plus a Xuanshu-style `export_snapshot` / `export_format` and a `data.technique_card` provenance card. Tools marked ⓟ are setting-sensitive and require parameter confirmation before calling.

### Western astrology · natal & derived charts (11)

| Tool ID | Name | Notes |
| --- | --- | --- |
| `chart` ⓟ | Standard chart | Western natal chart + full AI export (Dodekatemoria / dispositor chain / hyleg lifespan / classical + classical-derived / classical patterns) |
| `chart13` ⓟ | 13-house variant | `chart13` form |
| `chart12` ⓟ | Dwadasamsa (12th-harmonic) | lon×12 mod 360, same shape as chart13 |
| `babylon` | Babylonian astrology | Aldebaran-anchored sidereal list, arithmetic calendar, bīt niṣirti, numina, microzodiac |
| `draconic` | Draconic chart | all longitudes measured from the North Node + a node-baseline dedicated section |
| `relocation` | Relocation chart | same birth moment, houses/angles recomputed for a new place + an angle-comparison section |
| `hellen_chart` ⓟ | Hellenistic chart | Hellenistic-oriented chart |
| `india_chart` ⓟ | Indian chart | Vedic chart |
| `guolao_chart` ⓟ | Seven Governors (Guolao) | Seven Governors / Guo Lao chart |
| `relative` ⓟ | Synastry / relationship | Two-person relationship, composite, relative output |
| `germany` ⓟ | Cosmobiology / midpoints | Hamburg 90° dial, 8 TNP, midpoint structures and quantitative analysis |

### Western astrology · returns / progressions / timelines (28)

| Tool ID | Name | Notes |
| --- | --- | --- |
| `solarreturn` ⓟ | Solar return | natal + return chart + aspects |
| `lunarreturn` ⓟ | Lunar return | natal + lunar return + aspects |
| `solararc` ⓟ | Solar arc | natal + directed chart + aspects |
| `givenyear` ⓟ | Given-year | natal + given-year chart + aspects |
| `profection` ⓟ | Profection | profection timeline |
| `pd` ⓟ | Primary directions | real primary-direction table |
| `pdchart` ⓟ | Primary-direction chart | readable PD chart + aspects |
| `zr` ⓟ | Zodiacal release | ZR timeline |
| `firdaria` ⓟ | Firdaria | Firdaria structure & timeline |
| `decennials` ⓟ | Decennials | decennials timeline (headless, Xuanshu golden) |
| `agepoint` ⓟ | Age Point / Huber | Koch-house age-point cycle (6 yrs/house) |
| `distributions` ⓟ | Distributions | Asc through the Egyptian bounds |
| `mundane` ⓟ | Mundane astrology | yearly ingress chart + sub-charts (lunations / eclipses / world chart / planetary cycles / chart validity / rulership geography) |
| `jaynesprog` ⓟ | Jayne declination | secondary progression + declination parallels |
| `vedicprog` ⓟ | Vedic sidereal progression | progressions under the sidereal zodiac |
| `prog` ⓟ | Secondary progression (tropical) | secondary / tertiary / minor progressions (minorVariant: synodic default / sidereal / engine); new upstream v3.11 export key |
| `ephemeris` ⓟ | Ephemeris | ingresses · stations · lunations · eclipses in a date window, plus transits to natal (default: today + 90 days) |
| `returntimeline` ⓟ | Return timeline | yearly solar / lunar return moments (start year + count 1–40) |
| `prenatalsyzygy` ⓟ | Prenatal syzygy | the last new / full moon before birth, its degree and chart |
| `planetaryarc` ⓟ | Planetary Arc | whole chart directed by arcSource's secondary arc |
| `planetaryages` ⓟ | Ages of Man | Ptolemy seven ages + current band |
| `yearsystem129` ⓟ | 129-year system | seven-planet succession, 129-year cycle |
| `persiandirected` ⓟ | Persian Directed | symbolic 1°/year direction hit-list + directed chart cast at any date |
| `balbillus` ⓟ | Balbillus 129-year | exaltation-distance reduction + recursive sub-periods (vendored JS, identical to Xuanshu) |
| `triplicityrulers` ⓟ | Triplicity rulers | sect light's triplicity rulers split life into stages |
| `keypoints` ⓟ | Numeric keypoints | period-numbers + release-point sign distances activate planets by year |
| `lunationphase` ⓟ | Progressed lunation phase | natal Sun-Moon elongation advanced by the secondary rate (8 phases) |
| `extrareturns` ⓟ | Multiple returns | Saturn / Jupiter / lunar-node return dates + yearly solar/lunar-return timeline |
| `acg` ⓟ | AstroCartoGraphy | planetary geographic lines (MC/IC longitudes, zenith points, parans, crossings) + click-point analysis / mundane event moments |
| `india_rectify` ⓟ | KP birth-time rectification | scan ±window around the anchor: RP / Pranapada / gandanta-boundary scored candidates |
| `planet_cycles` | Planet cycles | exact conjunction/opposition timeline for any planet pair (geo/helio/topo) |
| `astrodata` ⓟ | Celebrity chart catalog | offline celebrity birth-data search (FTS/category/Rodden, chart-ready detail) |
| `xuanshi` | Esoteric-history KB | 7900+ sourced events (original text / reading / citations), 27000+ celestial records, figure graph, dynasty & timeline views (read-only) |

### Western divination · horary / electional (5)

| Tool ID | Name | Notes |
| --- | --- | --- |
| `horary` ⓟ | Horary | radicality / significators (14 categories) / perfection / moon story / verdict / timing |
| `election` ⓟ | Electional | hard flags / 28 topic rule packs / scoring / cast moment / recommendations |
| `tianxing` ⓟ | 天星择日 omen search | scan a window for a Western-astrology omen condition tree / matched intervals + per-moment leaf verdicts + the selected-moment chart |
| `qizhengelection` ⓟ | Qizheng electional wheel | 11-body compass-mountain positions / altitudes / eclipse search / azimuth-arrival search |
| `qimenzeri` ⓟ | 奇门择日 window search | scan a window for a 奇门 condition tree / matched 时辰 + the full 17-section 奇门 chart |
| `huanglizeri` ⓟ | 黄历 almanac election | scan a date range for a 通书 condition tree (26 types) / matched days + the full 10-section almanac |
| `bazizeri` ⓟ | BaZi election | scan a window for a BaZi condition tree (26 types: ten gods by pillar, clashes/harms, nayin phases…) + the full chart |
| `taiyizeri` ⓟ | 太乙 election | scan a window for a 太乙 condition tree (24 types: the ten essences, the nine provinces…) + the full chart |
| `ziweizeri` ⓟ | Zi Wei election | scan a window for a 紫微 condition tree (28 types: patterns incl. broken ones, palace-stem sihua, origin palace…) + the full chart |
| `liurengzeri` ⓟ | 六壬 election | scan a window for a 六壬 condition tree (27 types: minor/major patterns, hidden stems, vitality…) + the full chart |
| `sanshizeri` ⓟ | Three-Styles election | conditions spanning 六壬 / 奇门 / 太乙 at once (70 types, the largest set) + the united chart |
| `qizhengzeri` | 七政 election | minute-level interval search (7-state dignities etc., 11 types; adjudicated by the backend swisseph) + the 果老 chart |
| `indiazeri` | Muhurta election | minute-level interval search (Panchanga limbs, Lagna, the 30 muhurtas, Choghadia, the five doshas — 18 types; backend-adjudicated) |

### Chinese metaphysics core · Three Styles (10)

| Tool ID | Name | Notes |
| --- | --- | --- |
| `bazi_birth` ⓟ / `bazi_direct` ⓟ / `bazi_inverse` | BaZi chart / direct reading / reverse lookup | Four Pillars + major periods + shen-sha + stem/branch combination-clash lines + strength / patterns / blind-school structures; reverse lookup = four ganzhi pillars → candidate birth moments (Java year-by-year search, no confirmation gate) |
| `ziwei_birth` ⓟ | Zi Wei Dou Shu | custom si-hua / schools / body palace / BaZi major periods / matched patterns; 22 lineage switches (non-default → re-cast on Xuanshu's local ZiweiCalc) |
| `ziwei_rules` | Zi Wei rule base | returns the full Zi Wei pattern rule base (readable without confirmation) |
| `liureng_gods` ⓟ / `liureng_runyear` ⓟ | Da Liu Ren / yearly | 26 casting methods / four lessons & three transmissions / 100 Bi-Fa rules / divination guide / runyear |
| `qimen` ⓟ | Qi Men Dun Jia | cast by ken (`kinqimen`; default 置闰, non-hourly / flying-plate settings route to the local engine exactly as Xuanshu does), palace detail + Fa Qi Men overlay + gua |
| `taiyi` ⓟ | Tai Yi Shen Shu | cast by ken (`kintaiyi`), 16-palace marks |
| `jinkou` ⓟ | Jin Kou Jue | cast by ken (`kinjinkou`), 20-section reading layer |
| `sanshiunited` ⓟ | Three Styles unified | aggregates ken Qi Men + Tai Yi with Da Liu Ren (incl. all three engines' enriched sections) |

### Local metaphysics · numerology · divination (16)

| Tool ID | Name | Notes |
| --- | --- | --- |
| `tongshefa` ⓟ | Tong She Fa | gua, six lines, hidden, affinity (headless, Xuanshu parity) |
| `canping` ⓟ | Shao Zi Can Ping Shu | four-pillar numbers, verses (in-process, bundled `lunar-javascript`) |
| `heluo` ⓟ | He Luo Li Shu | pre/post-heaven gua, fate chapter, decade + yearly fortunes with verdict (in-process) |
| `yizhangjing` ⓟ | Yi Zhang Jing | palm-chart four palaces, life palace / twelve mansions, decade + annual cycles, shensha overlay (in-process) |
| `zhengchuan` ⓟ | Shen Shu Zheng Chuan | five schools (铁板/邵子/大定/六亲/铁算心易): four-pillar casting, verse lookup, decade + death-month (in-process) |
| `xiaoliuren` ⓟ | Xiao Liu Ren | three-number 三传 · mainstream six-palace / Daoist nine-palace + 生克 + nine spirits + remedies |
| `feigong` ⓟ | Fei Gong Xiao Qi Men | 青龙 flies the nine palaces + host/guest & life palace + eight gates/nine stars + annual/monthly + timing |
| `xiaochengtu` ⓟ | Xiao Cheng Tu | Luoshu nine-palace layout + forward/side derivation + four images + timing + stock (five casting methods) |
| `guice` ⓟ | Huang Ji Gui Ce | 12 casting methods + 演数四位 + gua-change judgment + 三要十应 + 元会运世 + 大定 |
| `harmonic` ⓟ | Harmonic chart | natal longitude × harmonic number, same-frequency conjunctions + an H-number dedicated section |
| `suzhan` ⓟ | Su Zhan | mansion-divination structure |
| `sixyao` ⓟ | Liu Yao / I Ching | hexagram, changing lines, question-oriented output + judging sections (Xuanshu's time cast and doctrine library) |
| `geomancy` ⓟ | Astronomical geomancy | 4 mothers → 16 figures, figures into 12 houses + judge/witnesses, deterministic cast from the query moment |
| `tarot` ⓟ | Tarot | Waite 78-card deck, deterministic seeded shuffle from the query moment + spread verdict / detail / synthesis |
| `lingqi` ⓟ | 灵棋经 / Numinous Chess | Twelve pieces cast at once (4 upper / 4 middle / 4 lower) → one of 64 figures, with 三才 layer reading, oracle verse, commentator notes, verdict and poem |
| `otherbu` ⓟ | Astro dice | astrological dice + reading |

### Shen Shu (all 14)

> kentang engines mounted on the Xuanshu chart service; the backend emits the `snapshot` directly, with section headers matching the aiExport preset. `shaozi` / `tieban` / `cetian` / `qizhengkin` / `xianqin` also take gender (+ place).

| Tool ID | Name | Engine |
| --- | --- | --- |
| `wangji` ⓟ | Huang Ji Jing Shi · Xin Yi Fa Wei | standalone |
| `wuzhao` ⓟ | Wu Zhao | standalone |
| `taixuan` ⓟ | Tai Xuan Shi Fa (太玄筮法) · milfoil | standalone |
| `jingjue` ⓟ | Jing Jue (荆诀) | standalone |
| `shenyishu` ⓟ | Shen Yi Shu (神易数) | standalone |
| `shaozi` ⓟ | Shao Zi Shen Shu | kinastro |
| `tieban` ⓟ | Tie Ban Shen Shu | kinastro |
| `fendjing` ⓟ | Guigu Fen Ding Jing (鬼谷分定经) · Liang Tou Qian | kinastro |
| `beiji` ⓟ | Bei Ji Shen Shu | kinastro |
| `nanji` ⓟ | Nan Ji Shen Shu | kinastro |
| `chunzi` ⓟ | Chun Zi Shu (蠢子数) | kinastro |
| `xianqin` ⓟ | Wan Hua Xian Qin (万化仙禽) · Yan Qin | kinastro |
| `cetian` ⓟ | Ce Tian Fei Xing · Zi Wei | kinastro |
| `qizhengkin` ⓟ | Seven Governors · Zhang Guo | kinastro |

### Solar terms / lunar calendar / almanac (6)

| Tool ID | Name | Notes |
| --- | --- | --- |
| `jieqi_year` ⓟ / `nongli_time` ⓟ | Year solar terms / lunar time | solar-term nodes / lunar ganzhi |
| `jieqi_birth` ⓟ | Birth solar-term window | exact term moments around a birth + the bracketing interval (same window BaZi luck-counting uses) |
| `calendar_month` ⓟ | Chinese almanac / month calendar | whole-month lunar / ganzhi / solar terms / lunations + selected-day detail (lunar / old-almanac / date-selection sub-sources) |
| `huangli` | Chinese day almanac | daily do/avoid, duty spirits, Peng Zu taboos, clash-sha & fetal-god directions, hourly luck |
| `tongshu` | Tongshu date selection | verdict across the five classical schools |

### Protocol / knowledge (6) + MCP facades (16)

| Tool ID | Name | Notes |
| --- | --- | --- |
| `gua_desc` / `gua_meiyi` | Gua meaning / Mei Yi gua | hexagram names & texts / Plum-Blossom gua |
| `export_registry` / `export_parse` | Export registry / parser | machine-readable export table / parse Xuanshu export text back to JSON |
| `knowledge_registry` / `knowledge_read` | Knowledge catalog / reader | list / read / full-text search (`query`) across 31 domains (hover knowledge + technique manuals), every entry cited |

Beyond the calculation tools, the MCP surface adds 16 facades (`XUANSHU_MCP_COMPACT=1` exposes only this layer):

| Facade | Role |
| --- | --- |
| `xuanshu_beginner_guide` | 🆕 beginner guide: matter, natal vs. divination vs. date, techniques with what to look at, plain follow-up questions |
| `xuanshu_full_reading` | 🆕 one-call beginner reading: guide → birth-time check → synthesis → plain-language workbook |
| `xuanshu_birth_check` | 🆕 birth-time precision check: place, timezone, DST, true solar time, hour / solar-term boundaries, candidate pillars, A/B/C grade |
| `xuanshu_place_lookup` | 🆕 offline gazetteer: place name → lat/lon + IANA timezone |
| `xuanshu_explain` | 🆕 plain-language glossary and technique cards |
| `xuanshu_dispatch` | routes natural-language intent to the right technique; the aggregation layer carries each sub-result's export contract |
| `xuanshu_hecan` | multi-technique synthesis: casts several techniques in parallel on one question (default 5, up to 8) and returns a synthesis template with evidence pointers and conclusion slots |
| `xuanshu_tool_run` | call any of the 110 tools by name + payload |
| `xuanshu_agent_guidance` | which fields must be asked first, which Xuanshu defaults may be used after the user accepts |
| `xuanshu_technique_report` | the deterministic "which techniques, which settings, computed by what" methods report (per run or per conversation) |
| `xuanshu_report_template` / `xuanshu_report_render` / `xuanshu_report_from_tool` | consulting reports: AI final text → JSON / DOCX / PDF, auto-written back to memory |
| `xuanshu_memory_query` / `xuanshu_memory_show` / `xuanshu_memory_record_answer` | local memory: search / replay a full record / write back the final answer |

> **Explicitly excluded:** `fengshui` (not yet headless; we don't disguise unfinished capability as shippable).

## Hard rules for agents

This is the **most important** rule when wiring into Cursor, OpenClaw, Claude, Codex, Open WebUI.

If an agent is unsure of the user's settings before calling a technique, it should first query `xuanshu_agent_guidance` (CLI: `uv run xuanshu-skill agent guidance --tool <tool> --intent "..."`) — it tells the AI which fields must be asked first and which Xuanshu defaults may be used once the user accepts.

Calculation tools and `xuanshu_dispatch` are gated: if the agent didn't confirm settings it gets `agent_guidance.required`, and must pass `agent_confirmed_settings: true` after the user confirms, or `defaults_accepted: true` after the user explicitly accepts defaults. If the response has `details.agent_recovery.prompt_to_user`, the AI client must stop and forward that question to the user — it may not bypass or self-fill.

Standard flow: ① user states a need → ② agent checks if params suffice; if not, call `xuanshu_agent_guidance` or ask the user → ③ user confirms time/place/topic/whether to accept defaults → ④ agent calls the real tool with `agent_confirmed_settings: true` + `clarification_notes` → ⑤ explain from `export_snapshot` / `export_format`, not from a hand calculation.

❌ Blocked (missing confirmation, place, timezone, topic):

```json
{ "date": "2026-05-18", "time": "13:14:00" }
```

✅ Correct (user confirmation + full context):

```json
{
  "agent_confirmed_settings": true,
  "clarification_notes": "User confirmed: 2026-05-18 13:14:00, America/Los_Angeles, San Francisco, topic = current work decision.",
  "date": "2026-05-18", "time": "13:14:00", "zone": "-07:00",
  "lat": "37n46", "lon": "122w25", "gpsLat": 37.7667, "gpsLon": -122.4167,
  "after23NewDay": false
}
```

When the user says "use Xuanshu defaults", switch to `{ "defaults_accepted": true, "clarification_notes": "User explicitly accepted Xuanshu defaults." }` — but the agent **must not** set `defaults_accepted: true` on the user's behalf.

> Timezone accepts both fixed offsets (`+08:00` / `-07:00`) and IANA names (`America/Los_Angeles` / `Asia/Shanghai`); Xuanshu Skill normalizes to a backend-stable offset using the chart's date and time.

## Trust stack: provenance · knowledge · evaluation · synthesis

The biggest risk in metaphysics output is not a miscalculation — it is the AI improvising beyond the chart. Xuanshu Skill turns "where did this conclusion come from" into machine contracts, enforced by deterministic code rather than model goodwill:

- **Technique provenance card** — every technique response carries `data.technique_card`: technique + school settings (incl. the late-Zi midnight switches), **declared vs. measured compute source** (`compute.matches_declaration=false` must be surfaced as "treat with caution"), section completeness, version chain. `xuanshu_technique_report` renders a methods report (markdown / json / docx / pdf) for one run (`run_id`) or a whole conversation (`group_id`) and detects **cross-technique setting conflicts** (two techniques on different late-Zi switches cannot corroborate each other). Disable with `XUANSHU_TECHNIQUE_CARD=0`.
- **Cited knowledge base** — 31 domains = 3 in-app hover domains + 27 technique operation manuals + the 21-category bazi pithy corpus (409 entries: per-setting values and differences, school splits, algorithms and conventions), harvested from the desktop app's help panels. `knowledge_read` returns each entry with a "manual · domain · entry (file @ upstream version)" citation. Policy (in [SKILL.md](./skills/xuanshu-agent/SKILL.md)): doctrine quotes must carry a source; uncited readings must be labeled as general inference — the first anti-Barnum mechanism.
- **Chart-fact faithfulness evaluation** — `xuanshu-skill benchmark faithfulness` runs a **deterministic verifier** (no LLM judge) over an AI reading: factual claims (pillar ganzhi, planet-in-sign, Zi Wei major-star palaces and body palace, Liu Ren three transmissions, Liu Yao hexagram names and moving lines, tarot card names and orientations, …) are checked one by one against machine-read chart truth and classified **supported / invented / contradicted**. Wrong-chart answers and sycophantic echoes ("my Moon is in Scorpio, right?" when it isn't) go red. XuanshuBench: 106 benchmark cases generated from the tool registry and locked to it — a new tool without a case fails.
- **Multi-technique synthesis (合参)** — `xuanshu_hecan` (CLI: `xuanshu-skill hecan`) casts several techniques in parallel on one question (same `group_id`; default 5, up to 8; `tools` may be explicit) and returns a synthesis **template**, not a verdict: per-technique conclusion slots must bind to that technique's real exported sections (responses carry evidence pointers; full text via `memory_show(run_id)`); `convergence` only when independently agreed; **`divergence` disclosed item by item — never averaged away, never one-sided**; setting conflicts (`consistency.setting_conflicts`) must be declared first.

### Optional cloud decision layer (TypeSafe Jev · off by default)

Every promise above (offline, nothing uploaded) holds **as shipped**. An operator may explicitly
enable a cloud "decision layer" — TypeSafe's Jev, a System One decision model that returns typed choices and
probabilities, never text — for three narrow jobs: picking a technique when the deterministic keyword router
finds **no match**; turning a setting the user **explicitly stated** (e.g. 「我老婆的八字」→ female) into a
provided value (lexicon evidence + model verdict + confidence threshold must all agree; defaults are never
chosen for the user); classifying the topic of a 大六壬 question. It never computes or explains a chart.

| Item | Detail |
| --- | --- |
| Switch | `XUANSHU_JEV=off` (default) / `shadow` (records what it would decide, behaviour unchanged) / `enforce`; key in `XUANSHU_JEV_API_KEY` (Claude Desktop / plugin settings field; never written into Xuanshu files) |
| What leaves the machine | tier `meta` (default): the request text **redacted locally** (dates / times / coordinates / place names / numbers → placeholders) + technique names + setting key names; tier `snapshot`: additionally export-snapshot text, only for the future faithfulness / synthesis judges |
| What never leaves | birth date, time, coordinates and place names as given; the chart and export text (tier meta); the key; local memory |
| Provider facts | hosted closed model in US data centres; "not used for training" is contractual, not architectural; no published retention window, zero-retention only on enterprise terms |
| Self-reporting | `data.technique_card.decisions[]` / `decision_layer` on `xuanshu_dispatch` (model id, option, confidence, adopted or not); `xuanshu-skill jev status` / `jev events` (local ledger) |
| Authority boundary | code owns authority — the deterministic path always wins; `enforce` needs a thresholds lock promoted on our own Chinese labelled sets; every failure degrades closed into `warnings` |

## Output protocol: the point is "stably consumable", not just "compute"

Every tool call returns a uniform envelope:

```json
{
  "ok": true, "tool": "qimen", "version": "0.39.0",
  "input_normalized": {}, "data": {}, "summary": [],
  "warnings": [], "memory_ref": {}, "error": null
}
```

Techniques wired into the Xuanshu export protocol also carry `data.export_snapshot` (with `.snapshot_text` / `.sections` / `.selected_sections`), `data.export_format`, and `data.technique_card`. So: the AI doesn't guess structure from free text; repeated calls of one technique return the same contract; `xuanshu_dispatch`'s aggregation layer carries each sub-result's export contract; and the structure survives into the JSON artifact. Full field tables: [`docs/DATA_CONTRACTS.md`](./docs/DATA_CONTRACTS.md) and [`docs/INPUT_CONTRACTS.md`](./docs/INPUT_CONTRACTS.md).

## Data management: a full local record system

Local data defaults to `~/.xuanshu-skill/` (Windows: `%APPDATA%/XuanshuSkill/`). Each run persists: run metadata, tool-call records, an entity index, JSON artifacts, a `run manifest`, the raw `query_text`, the user's `user_question`, the final `ai_answer_text`, and optional `ai_answer_structured`.

```bash
uv run xuanshu-skill memory query                 # query history by tool / entity / run_id
uv run xuanshu-skill memory show <run_id>          # replay one full call
echo '{"run_id":"<run_id>","user_question":"...","ai_answer":"...","ai_answer_structured":{}}' \
  | uv run xuanshu-skill memory answer --stdin     # write the final AI answer back to a record
```

This makes it not just a "tool layer" but a "tool layer + traceable knowledge base".

## Quick start

Prerequisites: [uv](https://docs.astral.sh/uv/) — macOS / Linux `curl -LsSf https://astral.sh/uv/install.sh | sh`; Windows (PowerShell) `powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"`. **Reopen the terminal** afterwards (or `source $HOME/.local/bin/env`) so `uv` is on PATH; Python ≥3.12 is provisioned by uv; keep ~5GB disk free (runtime download ~730MB, ~2GB unpacked).

```bash
git clone https://github.com/xuanshu-project/xuanshu-skill.git
cd xuanshu-skill/xuanshu-skill
uv sync
uv run xuanshu-skill install      # install the offline runtime (~730MB, progress + resumable; no-op when up to date)
uv run xuanshu-skill doctor       # environment checkup (disk / ports / node probe; expect issues: [])
uv run xuanshu-skill selfcheck    # live check: cast one chart -> store -> read back
uv run xuanshu-skill serve        # start local MCP (default http://127.0.0.1:8765/mcp)
```

No checkout needed: **zero-install (no git, no PyPI)** — every release ships a pure-Python wheel, and `uvx` starts
straight from its URL; `XUANSHU_RUNTIME_MIRROR` rewrites the wheel URL and the runtime URLs alike:

```bash
WHL="https://github.com/xuanshu-project/xuanshu-skill/releases/download/v2.0.0/xuanshu_skill-2.0.0-py3-none-any.whl"
uvx --from "$WHL" xuanshu-skill install                    # install the offline runtime (same as above)
uvx --from "$WHL" xuanshu-skill doctor                     # health check
uvx --from "$WHL" xuanshu-skill setup --client cursor       # zero-install one-command onboarding (picks `--launcher uvx-wheel`, writes the wheel URL)
uvx --from "$WHL" xuanshu-skill serve --transport stdio    # stdio for clients; `client config --launcher uvx-wheel` emits matching configs
```

> Restricted network (mirror prefix / assets API / offline USB / proxies & corporate CAs): see [docs/INSTALL_RESTRICTED_NETWORK.md](./docs/INSTALL_RESTRICTED_NETWORK.md).
> The PyPI channel (`uvx xuanshu-skill …`) is wired but **not yet live** (it needs the maintainer's one-time Trusted Publisher setup); once on, the commands get shorter and behave the same.

> [!NOTE]
> 🐳 **Docker / Linux (experimental)**: the offline runtime is published for macOS (arm64) and Windows (x64) only — there is no Linux payload. What runs in a container is the **MCP gateway** (Python package + knowledge base + memory) pointed at a host or another machine that has the runtime via `XUANSHU_SERVER_ROOT` / `XUANSHU_CHART_SERVER_ROOT`. An **experimental** `xuanshu-skill/Dockerfile` + `docker-compose.yml` ship with the repo (gateway image: no offline runtime inside the container, so those two variables are mandatory; binding 0.0.0.0 requires `XUANSHU_MCP_TOKEN`); by hand, `pip install "https://github.com/xuanshu-project/xuanshu-skill/releases/download/v2.0.0/xuanshu_skill-2.0.0-py3-none-any.whl"` (the release wheel — PyPI is not open yet) then `xuanshu-skill serve --transport streamable-http` is the gateway.

Troubleshooting install: `uv: command not found` -> install uv first (one-liner above); slow/broken network -> re-run `install` (resumes from the partial download) or set `XUANSHU_RUNTIME_MIRROR=<mirror-prefix>`; low disk / busy ports / an unfamiliar doctor code -> `doctor --explain` adds 6–10 plain-language lines on stderr (stdout stays JSON) and `advice[]` gives every issue / warning code a `user_summary` + `next_action`, `--probe-network` checks the manifest URL through every mirror (the default makes no external request); macOS: the runtime will not start and leaves no log, or `doctor` reports `quarantine:runtime_binaries` -> the browser-downloaded archive carries Gatekeeper's quarantine attribute, run the `xattr -dr com.apple.quarantine <runtime/current>` command from `quarantine.fix`, then `runtime restart`; Windows `runtime.path_not_ascii` (or doctor issue `windows:runtime_root_not_ascii`; bazi / ziwei / liureng fail and chart-side techniques report parameter errors) -> the runtime path contains non-ASCII characters (the default path under a Chinese user name does) and the bundled Java 17 and Swiss Ephemeris access files through narrow-character APIs: `setx XUANSHU_RUNTIME_ROOT C:\xuanshu`, open a new terminal, restart your AI client, rerun `install` / `setup`; Windows `runtime.install_long_path` -> `doctor.windows.headroom_chars` below zero means install will refuse: set `XUANSHU_RUNTIME_ROOT=C:\xuanshu` or enable `LongPathsEnabled` (v0.38.0 shortens the install temp prefix, ~20 characters more headroom); slow or proxied downloads -> `XUANSHU_RUNTIME_DOWNLOAD_TIMEOUT_SECONDS` (default 120) and `XUANSHU_RUNTIME_DOWNLOAD_ATTEMPTS` (default 3, per mirror); a Windows Firewall prompt on first start or `doctor` warning `listener:not_loopback_only` -> the old launcher bound Java to 0.0.0.0; after upgrading run `uv run xuanshu-skill runtime restart` to re-apply the template (pins 127.0.0.1); services not starting under a Windows user name with spaces/CJK -> fixed in v0.38.0 (every path argument is quoted), `runtime restart` after upgrading; Codex showing a pile of errors or no tools on the first turn -> usually the timeouts are unset (Codex defaults 10 s/60 s): `uv run xuanshu-skill client check --client codex` names the missing keys and `client config --format codex --write ~/.codex/config.toml` merges the fix in place; `uvx` works in a terminal but a GUI client cannot start it -> GUI clients do not inherit your shell PATH, rerun `client config` (it now writes absolute paths) and `client check` reports `command_not_on_path`; upgrade -> `uv run xuanshu-skill upgrade` (skips the download when already current); uninstall -> `uv run xuanshu-skill uninstall` (dry-run by default).

More troubleshooting: if `github.com:443` is unreachable but `api.github.com` works (full recipe incl. mirrors and offline USB: [docs/INSTALL_RESTRICTED_NETWORK.md](./docs/INSTALL_RESTRICTED_NETWORK.md)), download the runtime via the assets API (`curl -s https://api.github.com/repos/xuanshu-project/xuanshu-skill/releases/latest` to find your platform archive's `assets[].id`, then `curl -L -H "Accept: application/octet-stream" -o runtime.zip https://api.github.com/repos/xuanshu-project/xuanshu-skill/releases/assets/<id>`) and run `uv run xuanshu-skill install --archive runtime.zip`. If the Java backend (:9999) will not come up — `doctor` reports `services:java_backend_not_running` — the runtime now degrades to **chart-only** instead of locking everything: 三式 ken (qimen/taiyi/jinkou), 神数, geomancy, tarot and the western chart family keep working while nongli/bazi/ziwei/liureng and time-cast flows error until it recovers; `doctor` attaches the captured Java boot error under `java_diagnostics` and `selfcheck` falls back to a chart-side probe. A known Windows cause is proxy/VPN/security software whose WFP filters block `java.exe` loopback (JDK 17's internal pipes prefer AF_UNIX with no TCP fallback on connect — see issue #14); stopping the service is usually not enough, disable it and reboot.

For stdio clients like Claude Desktop: `uv run xuanshu-skill serve --transport stdio`. Context-constrained clients can set `XUANSHU_MCP_COMPACT=1` to expose only the 16 facades, or `XUANSHU_TOOLSETS=astro,cn` to flatten just those domains (domains astro/predict/chart/cn/shenshu/other, aliases western/chinese/all/none; unknown tokens are warned about and ignored, an empty result falls back to the full surface; any effective filter also registers `xuanshu_tool_run`; facades always register). The clarification gate still applies.

### Let the dispatcher pick the technique

```bash
echo '{
  "agent_confirmed_settings": true,
  "clarification_notes": "User confirmed: sample birth data, Shanghai, +08:00, Xuanshu defaults.",
  "query":"Analyze my current situation across Qi Men, Liu Ren, and the chart",
  "birth":{"date":"1990-01-01","time":"12:00","zone":"+08:00","lat":"31n14","lon":"121e28"},
  "save_result": true
}' | uv run xuanshu-skill ask --stdin
```

### Call a single tool / read cited knowledge / parse export text

```bash
echo '{"agent_confirmed_settings":true,"clarification_notes":"sample chart, Shanghai defaults","date":"1990-01-01","time":"12:00","zone":"+08:00","lat":"31n14","lon":"121e28","gpsLat":31.2333,"gpsLon":121.4667}' \
  | uv run xuanshu-skill tool run chart --stdin
echo '{"domain":"qimen","category":"door","key":"休门"}' | uv run xuanshu-skill knowledge read --stdin
echo '{"technique":"qimen","content":"[起盘信息]\n参数\n\n[八宫]\n八宫内容"}' | uv run xuanshu-skill export parse --stdin
uv run xuanshu-skill export registry
```

> If an agent calls Qi Men / Tai Yi / Liu Yao with too few params and `/nongli/time` returns `200001 param error`, have it use `xuanshu_agent_guidance` to ask for date / time / timezone / lat-lon and defaults first; Xuanshu Skill also retries Xuanshu-compatible date formats against the Java endpoint so a backend format error isn't mistaken for an unavailable algorithm.

## Supported AI clients

`setup --client <client>` does the whole onboarding in one command (v0.38.0): network probe (5 s) → install / verify the
offline runtime → write the config (auto-located, only the xuanshu entry, `.xuanshu-bak` backup, atomic replace) → doctor →
re-read the file from disk → **start the server once over stdio with the exact command the client will run and count
the tools** → print next steps. On failure a structured envelope goes to stderr (`step` / `code` / `config_untouched` /
`backup_path` / `retry_command`) with exit code 2; failing before the config step guarantees `config_untouched: true`.
`client config` only prints a config without writing it:

```bash
uv run xuanshu-skill setup --client cursor                # one-command onboarding (claude-code / claude-desktop / cursor / vscode / codex / gemini / windsurf / cline / zed)
uv run xuanshu-skill setup --client cursor --dry-run      # plan only: zero side effects
uv run xuanshu-skill client config --format claude-code   # print only: the `claude mcp add …` command
uv run xuanshu-skill client config --format codex         # config.toml snippet (with timeouts)
uv run xuanshu-skill client check                         # audit what each client ACTUALLY has
```

The repo root also carries 6 thin mirrors — `GEMINI.md` (Gemini CLI), `.github/copilot-instructions.md` (Copilot),
`.windsurf/rules/`, `.clinerules/`, `.cursor/rules/` (Cursor), `.agents/skills/xuanshu-agent/` (Codex / agentskills.io) — so those agents know the gate, the reading contract and the compact-surface `xuanshu_tool_run` call the moment they open the
repo; the single policy source stays [SKILL.md](./skills/xuanshu-agent/SKILL.md), whose "Shell-only agents" section
gives agents without MCP a pure-CLI contract (`tool run --input/--output`, exit codes, the gate flow).

### Works with

| Client | Transport | One-line setup | Default surface | Notes |
| :-- | :-- | :-- | :-- | :-- |
| **Claude Code** | stdio | `setup --client claude-code` (writes the project `.mcp.json` when the CWD has one, else runs `claude mcp add --scope user`) | full (125) | The repo ships a project `.mcp.json`; [guide](./xuanshu-skill/examples/clients/claude-code.md) |
| **Claude Code Plugin** | stdio | `/plugin marketplace add xuanshu-project/xuanshu-skill` → `/plugin install xuanshu@xuanshu-skill` | full (125) | Skill + MCP in one step; the plugin lives in `~/.claude/plugins/cache/xuanshu-skill/xuanshu/<version>/xuanshu-skill` — run `uv run --directory "<that dir>" xuanshu-skill install` once for the offline runtime (a `runtime.not_installed` error prints this command with the real path) |
| **Claude Desktop** | stdio | `setup --client claude-desktop`, or install the `.mcpb` bundle | full (125) | The `.mcpb` ships as a release asset |
| **Cursor** | stdio | `setup --client cursor` (or `client config --format cursor` for the official install deep link) | compact (16) | Cursor caps at ~40 tools globally and **drops the rest silently** |
| **VS Code (Copilot)** | stdio | `setup --client vscode` (writes the user-level `mcp.json`; or `client config --format vscode` for the `vscode:mcp/install` link) | compact (16) | 128-tool cap across all servers; the repo ships `.vscode/mcp.json` |
| **Codex** | stdio | `setup --client codex` (merges into `~/.codex/config.toml` in place, timeouts included) | compact (16) | Raise `startup_timeout_sec` (default 10 s) and `tool_timeout_sec` (default 60 s) |
| **Gemini CLI** | stdio | `setup --client gemini` | compact (16) | Tool names ≤63 chars + strict JSON Schema 2020-12 (the advertised layer already conforms) |
| **Windsurf** | stdio | `setup --client windsurf` | compact (16) | 100-tool cap |
| **Cline** | stdio | `setup --client cline` | compact (16) | No tool search; the full surface is heavy |
| **Zed** | stdio | `setup --client zed` | compact (16) | Config root key is `context_servers` |
| **OpenClaw / mcporter** | stdio | `client openclaw-setup --workspace ~/.openclaw/workspace` | full (125) | — |
| **Open WebUI · n8n · Dify** | streamable-http | `xuanshu-skill serve --host 0.0.0.0 --token <random>` | full (125) | [Guide](./xuanshu-skill/examples/clients/openwebui-streamable-http.md); a token is required off-loopback, and there is **no TLS** — put it behind a reverse proxy |
| **ChatGPT / claude.ai remote connectors** | streamable-http | As above, plus an **OAuth-terminating HTTPS gateway** (Cloudflare Access / oauth2-proxy) — both connectors speak OAuth only, this server offers a static Bearer token only, so the gateway exchanges the OAuth session for an injected `Authorization: Bearer <XUANSHU_MCP_TOKEN>` | full (125) | **No hosted endpoint**; recipe: [guide](./xuanshu-skill/examples/clients/remote-connectors-oauth-gateway.md) |

`--surface full` / `--surface compact` overrides the default. `--launcher uvx-git` emits a
checkout-free command (`uvx --from "git+…#subdirectory=xuanshu-skill"`; the PyPI channel is not open yet).

### Platforms

| Platform | Offline runtime | Notes |
| :-- | :-- | :-- |
| macOS arm64 | ✅ published | Primary platform |
| Windows x64 | ✅ published | See [Windows notes](./docs/OFFLINE_RUNTIME_RELEASES.md) |
| Windows ARM (Snapdragon / Surface) | ✅ installs the x64 payload under emulation (since 0.38.0) | Java / Python / Node all run under Windows 11 x64 emulation (verified on GitHub's `windows-11-arm` runner); `install` reports `runtime.platform_emulated`, `doctor` reports `emulated: true` (`payload_platform: win32-x64`) |
| Linux | ⚠️ no payload (experimental) | Use **gateway mode**: point `XUANSHU_SERVER_ROOT` / `XUANSHU_CHART_SERVER_ROOT` at a supported machine |
| Intel Mac | ❌ unsupported | The arm64 payload **cannot** run under Rosetta (its JDK/Python are native arm64); no x86_64 payload this round — use gateway mode |

> `server.json` at the repo root is MCP Registry metadata — regular users never edit it.

> Configured it but the client shows no xuanshu tools? Run `uv run xuanshu-skill client check` —
> it reads what each client **actually** has and names unexpanded placeholders, a missing
> `--transport stdio`, a moved checkout, and Codex's default timeouts.

For OpenClaw / mcporter, prefer the generator to avoid hand-editing JSON and paths:

```bash
cd xuanshu-skill
uv run xuanshu-skill client openclaw-setup --workspace ~/.openclaw/workspace
uv run xuanshu-skill client openclaw-check --workspace ~/.openclaw/workspace
```

> If `openclaw-check` passes and `xuanshu__...` tools appear in a real session but the agent trace still shows `clientToolCount: 0`, that's stale trajectory-stat noise — restart OpenClaw or open a new session; don't let the agent fall back to Shell / Python hand-computation.

## Credits: the bundled open-source ken engines

Qi Men Dun Jia / Tai Yi Shen Shu / Jin Kou Jue (and the Qi Men + Tai Yi inside the Three Styles) are computed by three open-source Python engines from **[kentang2017](https://github.com/kentang2017)**. Xuanshu wired them into its backend; Xuanshu Skill reuses the same compute path and ships them with the offline runtime:

- **kinqimen** (Qi Men Dun Jia) — MIT — <https://github.com/kentang2017/kinqimen>
- **kintaiyi** (Tai Yi Shen Shu) — MIT — <https://github.com/kentang2017/kintaiyi>
- **kinjinkou** (Jin Kou Jue) — MIT — <https://github.com/kentang2017/kinjinkou>

Full copyright and license text ships in `Horosa-Web/vendor/{kinqimen,kintaiyi,kinjinkou}/LICENSE` and is preserved on distribution.

**License attribution:** the three `ken` engines above are third-party MIT components (by kentang2017). Every other metaphysics implementation here — Tong She Fa, Decennials, and the `aiExport.js` formatting + headless adapters for Qi Men / Tai Yi / Jin Kou / Da Liu Ren / charts / progressions / horary / electional / Shen Shu — is **Xuanshu's own algorithm**, licensed under the root `GNU AGPL-3.0-only`. The traditional systems themselves (Jing Fang's eight palaces, Hellenistic decennials, etc.) are public knowledge and constitute no third-party copyright.

## Release & runtime strategy

The repo is intentionally split into three layers:

| Layer | Where | Role |
| --- | --- | --- |
| Public repo | GitHub repo | code, docs, CLI, MCP, tests, examples, packaging scripts |
| Maintainer packaging inputs | `vendor/runtime-source/` | large inputs to build the offline runtime (not in Git history) |
| End-user runtime | `~/.xuanshu/runtime/current` / `%LOCALAPPDATA%/Xuanshu/runtime/current` | the local runtime users actually execute after install |

This keeps the GitHub page clean, the Release assets complete, local execution offline, and the maintainer packaging flow independent of sibling directories. Further reading: [Offline Runtime Releases](./docs/OFFLINE_RUNTIME_RELEASES.md) · [Runtime Manifest Spec](./docs/RUNTIME_MANIFEST_SPEC.md) · [Repo Layout](./docs/REPO_LAYOUT.md).

## Repository layout

| Path | Description |
| --- | --- |
| [`xuanshu-skill/`](./xuanshu-skill) | Core Python package, CLI, MCP server, `xuanshu-core-js` (headless JS engines), tests, examples, release scripts |
| [`docs/`](./docs) | runtime spec, algorithm coverage, release docs, maintainer docs |
| [`vendor/`](./vendor) | local runtime packaging inputs |

## Verification checklist

After a fresh clone, to confirm "this isn't an empty shell", run this minimal set:

```bash
cd xuanshu-skill
uv sync
uv run xuanshu-skill install
uv run xuanshu-skill doctor                              # expect issues: []
uv run pytest -q                                        # 1723 passed; live integration tests auto-skip when services are down
uv run python scripts/run_benchmark.py                  # XuanshuBench: registry-locked cases + dispatch / export parity / knowledge
uv run python scripts/run_full_self_check.py --rounds 1 # all-tool call / export / persist / retrieve / dispatch
```

The full self-check covers: each tool is callable → returns a uniform envelope → business techniques carry `export_snapshot` / `export_format` + `technique_card` → export text re-parses → the run is written to memory → `memory show/query` retrieves it → report JSON/DOCX/PDF generate and register artifacts → `xuanshu_dispatch`'s aggregation layer keeps sub-tool export contracts → OpenClaw / mcporter see the MCP tools and complete smoke/full check.

> **When auditing predictive / Shen Shu tools, don't read only the short preview.** Their Xuanshu-style body usually writes the natal chart first, then the return / progressed / annual / primary-direction / Shen Shu tables; a 1200-char prefix may show only the natal chart. Open the full artifact and check each `export_format.sections`. See [`docs/EXPORT_AUDIT_GUIDE.md`](./docs/EXPORT_AUDIT_GUIDE.md).

## Is the output identical to Xuanshu?

"Identical to Xuanshu" means two things:

1. **Identical export structure** — business techniques generate a Xuanshu-style `export_snapshot.export_text`, parsed by `snapshot_parser` into `export_format`; the full self-check confirms no missing or unknown sections. The export contract (v14) mirrors the desktop app's aiExport v56 section-for-section.
2. **Identical compute path** — the Skill forbids agents from hand-computing charts with shell / Python / web search. Qi Men / Tai Yi / Jin Kou and the Qi Men+Tai Yi in the Three Styles are computed exclusively by the ken backend; the 14 Shen Shu by the kentang engines on the chart service; horary / electional / Balbillus by the vendored Xuanshu frontend engines — all same-source. The per-response `technique_card` reports the measured compute source and flags any mismatch with the declaration.

> Content fidelity was byte-checked: running Xuanshu's actual frontend builder on the same chart, the ages / aspects / promittors / significators are identical; only Persian Directed's hit dates differ by ≤1 day (moment's fractional-day truncation + JS↔Python float), which is astrologically negligible and documented (see [`xuanshu-skill/docs/v091-fidelity-spotcheck.md`](./xuanshu-skill/docs/v091-fidelity-spotcheck.md)). To prove a specific input matches the Xuanshu desktop UI field-for-field, put Xuanshu's golden snapshot for that input into fixtures and diff.

## FAQ / boundaries

**Why isn't the release a pure cloud build?** Because the full runtime depends on locally maintained runtime sources and platform runtimes. Keeping the repo light is a goal, but the full runtime still needs reliable local packaging inputs — hence "light repo + heavy release + explicit verification".

**Why keep stressing `export_snapshot` / `export_format`?** Because one of the project's core values is "let the AI stably consume Xuanshu output". Without this contract the AI can only read loose text, and retrieval / comparison / write-back / evaluation all become brittle.

**Why keep both SQLite and JSON?** SQLite handles structured indexing and queries; JSON artifacts handle long-term archival — portable, diffable, reviewable.

**Why isn't `fengshui` in the surface yet?** The current goal is the "complete, headless, offline-verifiable" surface. `fengshui` stays excluded; we don't disguise an un-headless capability as shippable.

**What's the most important quality signal?** Not badges or screenshots, but whether these five hold at once: tools really call · exports are really stable structured · every answer is really traceable to its technique and settings · results really persist and write back · benchmark / self-check / faithfulness evaluation really keep passing.
