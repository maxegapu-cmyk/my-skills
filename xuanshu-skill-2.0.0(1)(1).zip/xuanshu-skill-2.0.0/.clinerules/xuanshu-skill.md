# Xuanshu Skill — rules for Cline

This repo ships Xuanshu (玄枢): 110 real techniques (Western astrology, 八字, 紫微, 六壬, 奇门, 太乙, 六爻, 神数 …)
as a local-first MCP server + CLI. The **single policy source** is [skills/xuanshu-agent/SKILL.md](../skills/xuanshu-agent/SKILL.md);
maintainer law is [AGENTS.md](../AGENTS.md). This file is a thin
pointer — do not add rules here.

1. **Never hand-calculate** a technique (no formulas, no memorised tables, no web lookups). Every chart comes
   from a `xuanshu_*` MCP tool or the `xuanshu-skill` CLI.
2. **Clarify before calling.** A missing result-changing setting (time, place, timezone, gender, 流派 / house
   system / 起局方式) makes the tool refuse with `agent_guidance.required`. Ask the user with
   `details.agent_recovery.prompt_to_user`, then retry with `agent_confirmed_settings: true` +
   `clarification_notes` (or `defaults_accepted: true` only when the user explicitly accepts defaults).
   Never self-confirm, never switch tools to bypass the gate.
3. **Explain only from `export_snapshot.export_text` / `.sections`.** A missing section is "not returned",
   never a missing dependency (no MongoDB / 7897 / desktop app stories). Quote `data.technique_card` after
   every answer; `warnings` non-empty means the result is incomplete — say so.
4. No `xuanshu` tools in the list? One command registers everything:
   `xuanshu-skill setup --client cline` (`uv run xuanshu-skill setup --client cline` inside this checkout),
   then `xuanshu-skill doctor` for the machine-readable health report.
5. **Compact surface.** By default this client sees only the 16 facade tools (`XUANSHU_MCP_COMPACT=1`); every
   technique is still reachable by name through `xuanshu_tool_run(tool_name="qimen", …)` and the full list is the
   `xuanshu://catalog/techniques` resource — a missing flat `xuanshu_*` name does not mean the technique is missing.
   No `xuanshu` tools at all? `xuanshu-skill setup --client cline` registers everything.
6. **Plain-language users (小白).** Start with `xuanshu_beginner_guide` → `xuanshu_full_reading`; run `xuanshu_birth_check` before
   natal readings; gloss jargon with `xuanshu_explain`. Any tool accepts `place` (e.g. "湖南长沙") instead of lat/lon/zone.
