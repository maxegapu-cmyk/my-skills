# Repo Layout

> 读者：所有 agent（新 agent 首读之一）。何时读：定位代码、理解一次调用的层间流转时。路由：[`AGENTS.md`](../AGENTS.md) §0。

Xuanshu Skill is a local-first, offline MCP server + CLI that exposes Xuanshu (玄枢) divination
techniques to AI agents. The Git repository stays lightweight; the heavy runtime is published as
GitHub Release assets and assembled locally from `vendor/runtime-source/`.

This document maps the tree and shows how a tool call actually flows through the layers.

## Compute model (read this first)

A tool call resolves through `XuanshuSkillService.run_tool` (`xuanshu-skill/src/xuanshu_skill/service.py`),
which dispatches by the tool's `execution` mode in `engine/registry.py`:

- **remote** → HTTP to the local runtime. Two backends: the Java aggregation layer (`:9999`,
  `self.client`) and the Python chart service (`:8899`, `self.chart_client`). The chart service hosts
  the astrology engines (`/chart`, `/predict/*`, `/india/*`, `/germany/*`, `/jieqi/*`) **and the ken
  engines** (`/qimen/pan`, `/taiyi/pan`, `/jinkou/pan`); the set of chart-routed endpoints is
  `_PYTHON_CHART_ENDPOINTS` in `service.py`.
- **local** → computed in-process or via the bundled Node engine (`engine/js_client.py` →
  `xuanshu-core-js`).

**奇门 / 太乙 / 金口 use the ken backend** (`kinqimen` / `kintaiyi` / `kinjinkou`) as the sole compute
authority. `_run_{qimen,taiyi,jinkou}_tool` fetch the ken chart endpoint, then hand the ken response to
`xuanshu-core-js`, which **reformats** it (via `normalizeKinqimenData` / `normalizeBackendPan` /
`normalizeKinjinkouData` + `buildDunJiaSnapshotText` / `buildTaiyiSnapshotText` / `buildJinkouSnapshotText`)
into 玄枢 `aiExport.js` sections — so the `export_snapshot` contract is identical to the product's.
`三式合一` composes the ken 奇门 + 太乙 with the 大六壬 leg; `统摄法` (tongshefa) is the one technique with
no ken engine and stays a pure headless JS calculation.

## Public repository surface (top level)

- `README.md` / `README_EN.md` / `README.zh-CN.md` — Chinese / English landing pages (zh-CN forwards).
- `CLAUDE.md` / `AGENTS.md` — agent entry points: thin Claude Code router / the full rules-of-record
  (routing, iron laws, problem-logging protocol, compute/packaging/release law).
- `CHANGELOG.md` — release-oriented change log (version lockstep enforced by
  `scripts/verify_docs_sync.py`).
- `server.json` — Model Context Protocol registry metadata (name, version, packages, transports).
- `CITATION.cff` — citation metadata; version kept in lockstep with the package.
- `LICENSE` — GNU AGPL-3.0-only.
- `CODE_OF_CONDUCT.md`, `CONTRIBUTING.md`, `SECURITY.md`, `SUPPORT.md`, `.github/` — community + CI surface.
- `docs/` — maintainer-facing docs (see below).
- `skills/xuanshu-agent/` — the published agent skill (SKILL.md + references/) — the single policy
  source for AI-client behaviour.
- `.agents/skills/xuanshu-agent/SKILL.md` (Codex / agentskills.io), `GEMINI.md` (Gemini CLI),
  `.github/copilot-instructions.md` (Copilot), `.windsurf/rules/xuanshu-skill.md`, `.clinerules/xuanshu-skill.md` —
  thin per-client mirrors (≤30 lines, pointer + gate + reading contract + `setup --client …`); locked by
  `verify_docs_sync.check_agent_mirrors` (v0.38.0 B5). Policy never lives here.
- `vendor/` — local-only runtime packaging inputs (see below).
- `xuanshu-skill/` — the actual Python package + bundled JS engine + scripts + tests.

## docs/

- `REPO_LAYOUT.md` — this file.
- `LESSONS.md` — append-only ledger of per-version lessons (原文); current-truth rules live in `AGENTS.md`.
- `GLOSSARY.md` — domain/name glossary (ken, kentang, 命盘/事盘, pin-forward, …).
- `ARCHITECTURE.md` — layer diagram and module roles.
- `ALGORITHM_COVERAGE.md` — per-technique coverage matrix and the runtime layer that backs each.
- `INPUT_CONTRACTS.md` — per-tool input contracts (required fields).
- `DATA_CONTRACTS.md` — tool-envelope version, export-contract / record / manifest schema identifiers.
- `EXPORT_AUDIT_GUIDE.md` — section-by-section audit method for predictive exports.
- `OPERATIONS.md` — install / doctor / serve / run operational guide.
- `INSTALL_RESTRICTED_NETWORK.md` — mirrors / assets API / offline USB / proxies for machines that cannot reach github.com.
- `OFFLINE_RUNTIME_RELEASES.md` — what a runtime release must contain (incl. the ken engines + their
  Python deps) and the maintainer build/publish workflow.
- `RUNTIME_MANIFEST_SPEC.md` + `runtime-manifest.example.json` + `runtime-payload-manifest.example.json` —
  the manifest formats for installed runtimes and payloads.
- `EVALUATION.md` — benchmark / self-check methodology.
- `WINDOWS_RELEASE_BUILD_PROMPT.md` — Windows build-box runbook (release half / sync incidents).
- `WINDOWS_REPORT_STABILITY_PROMPT.md` — cross-platform report/OpenClaw verification prompt.

## xuanshu-skill/ — the package

### src/xuanshu_skill/ (Python)

- `service.py` — `XuanshuSkillService`: tool dispatch, remote/chart routing (`_call_remote`,
  `_PYTHON_CHART_ENDPOINTS`), the per-technique `_run_*_tool` runners (including the ken runners for
  qimen/taiyi/jinkou and the `sanshiunited` aggregator), snapshot builders, export-contract attachment,
  summaries, and memory write-back.
- `config.py` — `Settings` (server/chart roots, ports, runtime root, timeouts) + `from_env`.
- `engine/`
  - `registry.py` — `TOOL_DEFINITIONS` (name → domain/action/endpoint/`execution`/input model).
  - `client.py` — HTTP clients (`XuanshuApiClient`, `XuanshuPlainJsonClient`) for `:9999` / `:8899`.
  - `js_client.py` — `XuanshuJsEngineClient`: runs `xuanshu-core-js` via the bundled Node; raises on JS failure.
  - `router.py` — natural-language dispatch across tools (shared group/trace ids).
  - `decennials.py` — standalone Python 十年大运 port.
- `exports/` — `registry.py` (the `aiExport.js`-mirroring `AI_EXPORT_PRESET_SECTIONS` per technique) +
  `parser.py` (parse snapshot text into structured sections, with missing/unknown-section checks).
- `schemas/` — `tools.py` (per-tool pydantic input models) + `common.py`.
- `runtime/manager.py` — install / doctor / start / stop of the local runtime services.
- `memory/store.py` — SQLite + JSON artifacts + run manifests + AI-answer write-back.
- `knowledge/` — bundled Xuanshu hover knowledge (`store.py` + `data/`).
- `reports/` — JSON / DOCX / PDF report builder + renderers.
- `surfaces/` — `mcp_server.py` (MCP stdio/HTTP) and `cli.py` (JSON CLI).
- `tracing.py`, `errors.py`, `evaluation_lock.py`, `input_normalization.py`, `testing_payloads.py`,
  `client_tools.py`, `benchmark/` — tracing, typed errors, eval gating, input normalization, sample
  payloads, the callable-tool client layer, and benchmarking.

### xuanshu-core-js/ (bundled Node engine)

- `bin/cli.mjs` — `run <tool>` / `list` entry; reads a JSON payload on stdin, returns `{ok, ...}`.
- `src/tools/` — `index.js` (runner registry) + `qimen.js` / `taiyi.js` / `jinkou.js` (ken-response
  formatters) + `tongshefa.js` (standalone 统摄法 engine) + `canping.js` / `heluo.js` (数算 engines that
  compute pillars in-process via the vendored bazi chain).
- `src/vendor/` — engine code vendored from the 玄枢 frontend. Two kinds:
  - **ken-response formatters** (keep `normalize*Data` + `build*SnapshotText`; only the backend
    `fetch*Pan` calls are stripped, Python does the ken fetch): `dunjia/{DunJiaCalc,DunJiaBaGongRules}.js`,
    `taiyi/{TaiYiCalc,core/TaiYiCore}.js`, `jinkou/{JinKouCalc,JinKouState}.js`, `liureng/LRConst.js`.
  - **原生·非 ken 数算 engines** (computed wholly in-process, only edit = JSON import attribute): the bazi
    chain `bazi/{ZWConst,baziShenShaLocal,baziLunarLocal}.js` (→ the `lunar-javascript` npm package),
    `canping/{canpingLocal.js,data/canpingTiaowen.json}`, `heluo/{heluoLocal.js,data/heluoTiaowen.json}`.
- `node_modules/lunar-javascript` — runtime dependency of the bazi chain (declared in `package.json`),
  installed via `npm install --omit=dev` and bundled into the offline runtime payload.
- `src/shared/` — `fields.js`, `unpack.js`, `localNongliAdapter.js` helpers.

### scripts/ (maintainer utilities)

- `sync_vendored_runtime_sources.sh` — pull the runtime subset (incl. `Horosa-Web/vendor/{kinqimen,
  kintaiyi,kinjinkou}`) from a local 玄枢 tree into `vendor/runtime-source/`.
- `package_runtime_payload.sh` — assemble the macOS runtime payload tarball (bundles the ken engines and
  patches the staged kentang mount to skip absent engines).
- `build_runtime_release.sh` — orchestrate macOS + Windows archives, manifest, checksums, verification.
- `build_runtime_release_windows.{py,ps1}` + `scaffold_windows_runtime.py` + `runtime_templates/windows/` —
  Windows payload build, skeleton, and PowerShell start/stop templates (PYTHONPATH includes `vendor`).
- `generate_release_manifest.py`, `generate_sbom.py`, `build_knowledge_index.py`,
  `build_hover_knowledge_bundle.mjs` — manifest, SBOM, and knowledge-bundle generation.
- `run_full_self_check.py`, `run_openclaw_full_self_check.py`, `run_benchmark.py` — end-to-end self-checks.
- `verify_runtime_release.py`, `verify_vendor_runtime_sources.py`, `verify_server_json.py`,
  `verify_readme_links.py`, `verify_docs_sync.py`, `verify_builder_parity.py` — release / source /
  metadata / docs-drift / builder-parity verifiers.
- **跨树校验（需要上游 checkout，CI 跑不了）**：`verify_upstream_sync.py`（vendored ↔ 上游 HEAD：
  契约版本 / 技法键集 / 哨兵 / 运行时子树 / core-js manifest）、`verify_export_section_baseline.py`
  （段级欠账棘轮）、`verify_export_contract_mirror.py`（skill 注册表 ↔ vendored aiExport）。
  编排入口 = `preflight_release.py`，**打 tag 前必跑**（AGENTS §7）。
- 支撑件：`_upstream_preset.py`（上游 aiExport 解析器，三个陷阱都在它 docstring 里）、
  `revendor_core_js.py`（vendor 树唯一驱动入口，`--from-manifest`）、`gen_shaozi_tiaowen.py`。
- `sync_windows_release.py` — detect + remediate a `latest` release missing its Windows half
  (`--check` is the authoritative pin-forward detector; `--upload` runs the full build→verify→upload
  pipeline on the Windows box).

### tests/ and examples/

- `tests/` — pytest suite (router, service, export tools, memory, runtime manager, CLI, MCP server,
  and `test_local_js_tools.py` — qimen/taiyi/jinkou/sanshi run as integration tests against the live ken
  chart service and skip when `:8899`/`:9999` are down; tongshefa runs unconditionally).
- `examples/clients/` — Claude Desktop / Codex / Open WebUI / OpenClaw setup snippets.

## Local-only packaging surface

- `vendor/runtime-source/` — maintainer-only packaging inputs (a 玄枢 subset + embedded runtimes). May
  exist on disk uncommitted; `package_runtime_payload.sh` / the Windows builder read from it. Must include
  `Horosa-Web/vendor/{kinqimen,kintaiyi,kinjinkou}` for the ken endpoints.

## What stays out of this repo

- Full 玄枢 desktop application source copies
- Built runtime payloads and release archives (published as GitHub Release assets)
- Local databases, run outputs, caches
- Machine-specific files (`.DS_Store`, `.venv`, `__pycache__`, build dirs)

## Cross-platform

macOS and Windows are both first-class. The Python package, `engine/` routing, and `xuanshu-core-js`
formatters are platform-neutral. Platform specifics live in the runtime layer: macOS uses
`Horosa-Web/start_horosa_local.sh` (`PYTHONPATH_ASTRO` includes `flatlib-ctrad2:astropy:vendor`); Windows
uses `runtime_templates/windows/start_horosa_local.ps1` (`PYTHONPATH` includes `astropy;flatlib-ctrad2;vendor`).
Both put `vendor` on the path so `import kinqimen / kintaiyi / kinjinkou` resolves. The embedded macOS
Python already carries the ken deps (bidict / numpy / kerykeion / ephem / pendulum); the Windows wheel
bundle must include them too (see `OFFLINE_RUNTIME_RELEASES.md`).
