# 经验台账（LESSONS — append-only ledger）

> **读者**：维护者 / 在本仓改代码或发版的任何 agent。**何时读**：需要某条现行规则的历史来龙去脉、或按
> 「问题记录协议 v2」（见 [`AGENTS.md`](../AGENTS.md) §2）落一条新教训时。
>
> 本文件是**只增不删**的编年台账：每条教训的原文永久保存在这里；「现行真相」的蒸馏版规则住在
> [`AGENTS.md`](../AGENTS.md) 对应主题章节。两者分工：查历史 → 这里；照着干 → `AGENTS.md`。
> 新条目**加在「台账正文」最上方**，标题格式 `### vX.Y.Z / YYYY-MM — 主题`，正文保持
> 症状 → 根因 → 守卫 三要素。
>
> 注：v0.15.0–v0.19.0 各轮的教训当时直接蒸馏进了 `AGENTS.md` 主题章节与 `CHANGELOG.md`
> （如 v0.17 引擎升级 / 名人库、v0.18 pin-forward 复发、法奇门对宫表订正、安装回滚加固），
> 未单列编年节；自本台账建立起，新教训一律在此落原文。

## 索引

| 时代 | 条目 | 一句话 |
| --- | --- | --- |
| v0.40.0-dev (2026-09-24) | Windows 复验 lane：main（已同步上游 v3.11，契约 15）× 公开 v0.39.0 runtime（payload 14）→ 6 条 sync311 / sanshiunited live 红——版本偏斜，不是回归；`requires_chart` 只看「活不活、点没点名」，看不出「够不够新」 | `requires_current_runtime_contract`：已装 payload 的 `export_registry_version` < 本树 `AI_EXPORT_SETTINGS_VERSION` 即 skip 并写明偏斜（未知不跳）；挂到 sync311 全部 17 条 live + sanshiunited；每周一矩阵（main × latest）因此不再假红 |
| v0.40.0-dev (2026-09-24) | Windows 复验：`run_ci_gates` 23/24——benchmark smoke 在 cp1252 管道上 `print(json.dumps(报告, ensure_ascii=False))` 炸；stdio 守卫只扫 print **字面量**，对「打印数据」失明，同盲区 19 个脚本 | 打印数据 = 承诺输出非 ASCII：`ensure_ascii=False`+`print(` 也须 reconfigure；19 脚本补惯用块；windows-smoke 加 benchmark 步骤（唯一非 UTF-8 stdout 的 runner） |
| v0.40.0 (2026-09) | 首推 windows-smoke 红：tests/ 里 7 处起 node 复算金标的 `subprocess.run(…, text=True)` 没给 encoding，CJK 输出按 cp1252 解炸 | node 调用一律 `encoding="utf-8"`；`test_subprocess_encoding` 扩到 tests/ 的 node 调用（负向对照） |
| v0.40.0 (2026-09) | 首推 CI 红：ci.yml 两个 stdio 探针把全量面工具数写死 116，四个新工具把它变成 120 | 数字只许一个源：探针从 contracts/mcp_list_budget.json 读 full_tools/compact_tools；docs-sync 扫 README 全量行 + ci.yml 字面数 |
| v0.40.0 (2026-09) | 审计 P0：报告类 MCP 工具 `output_path` 可写任意路径（提示注入 = 覆盖用户任意文件） | 落盘路径闸：相对路径按输出目录解析、绝对路径须在输出目录 / `XUANSHU_REPORT_OUTPUT_ROOTS` 内，越界 `report.output_path_not_allowed` 不写文件；三工具 destructiveHint=True |
| v0.40.0 (2026-09) | 审计 P1：`contracts/` 不在 wheel / MCPB 里——Jev enforce 永不生效、技法算源恒「未标注」（v0.39.0 已出货） | 运行期契约经 `contracts_locator`（源码树 → 包内副本）；pyproject force-include + `.mcpbignore` 反选 + wheel 守卫锁条目 |
| v0.40.0 (2026-09) | 并行同步实现者踩坑：stub 杀死纯逻辑（六壬择时恒零命中）/ worktree 子进程跑主 checkout / 算源生成器不幂等 / `_js_round` 负数截断 / 移植口径与测试替身 | stub 审计进 revendor；conftest 钉 PYTHONPATH；契约 == 生成器输出；桩按真实下发参数校验 |
| v0.40.0 (2026-09) | 上游 v3.11.x 重同步：六处「同步了却没同步」——live 复验跑的是已装 runtime 的旧 JS / curated 件 restamp 不带内容 / 生成器修产物不修源 / 裸 `export default X` 漏剥 / vendored JSON 不在 manifest / 知识库计数无真值守卫 | 复验只认本仓引擎（conftest 钉根）；能 verbatim 的手工件一律 verbatim；修生成器不修产物 |
| v0.39.0 (2026-09) | 发布前 CI 红：双语棘轮抓到新包 28 处单语 raise；本机跑的是「顺手的守卫」不是 run_ci_gates.py | 本机门禁 = `run_ci_gates.py`；按文件计数的棘轮是 API 契约，新包落地就按它写 |
| v0.39.0 (2026-09) | 决策层：问题构造在 `ask()` 之外抛错，把 liureng_gods 打成 internal_error | 可选增强的**每一行**都要在降级护栏里；「英文 instructions」改成占比规则 |
| v0.38.1 (2026-09) | 复审：自动化的盲区与 Windows 编码——B0 归属证据不经代码页 / doctor 预算 / 长路径闸 / 隔离前置；B1 升级就地不砍服务、doctor 报载荷过期、selfcheck 先起 runtime；B2 九客户端按各家真实规则（占位符白名单、JSONC 保注释、Cline/Zed timeout、Codex env 根、探针按客户端形状 + `xuanshu://runtime/status`、wheel 预下载、OAuth 网关改口、镜像指针）；B3 矩阵真下载、出厂预算、HTTP 握手、九客户端、挂着客户端不停、publish 与矩阵同字节、cron 离整点 + kick、min_os 进清单、mcpb 解包断言 | PowerShell 5.1 往管道写的是 OEM 代码页，Python 侧只许收字节（base64）或走 ctypes；「lane 传了 file:// 就以为验过下载」= 本机环境替测试补前提的第三例；换目录前必停自己的服务、但永不停陌生人的；每个客户端的占位符 / 超时 / 环境转发规则都要按**它的**文档写，并让 `client check` 对着真文件说话；发布期：publish job 的每一步先对真 draft 跑（draft 对 `releases/tags` 404、job 级 permissions 整块替换）；发布后：只在没人跑的平台可达的分支靠静态检查兜（F821 闸），带完整输出的超时要按阶段拆预算 |
| v0.38.0 (2026-09) | 适配性：B0 三处「绿得不真」；B1 Windows 启动器；B2 客户端接入；B3 wheel 零安装；A0/A1 托管派生地基；A2 Windows 半边从 darwin 种子派生；A3 发布契约（清单钉 tag + size、按契约逐平台判完整、平台表锁）；A4 安装侧平台策略（Windows ARM 公告式回退、`min_os`、平台键看芯片）；B4 `setup --client` 一条命令接入（七步、失败包、真 stdio 探测）；B5 agent 文档（shell-only 契约、四份薄镜像、命令守卫）；B6 doctor 机器条件（码表人话、--explain、长路径余量、quarantine、仿真进程、下载旋钮、零外网）；A5 托管流水线（draft → 派生 → 三台真机矩阵 → [OK] 才公开；首跑抓到非默认端口下 stop 停不掉）；主干 CI 红了 19 个 commit 没人看（Windows CRLF checkout / 路径分隔符 / 宿主 OS 默认路径 / macOS runner netstat CLOSED）；A6 v0.38.0 首次托管双平台一次公开（GITHUB_TOKEN 的 release 事件不触发下游 workflow） | CI 的绿由每条命令背书；路径元素自己带引号；写用户文件只动自己的键；配置里的命令一律绝对路径；分发每条路要在没 git/没 github.com 的机器上成立；派生只从过闸的种子开始、依赖集是种子的纯函数；回退只许公告着做、载荷自带解释器所以平台键看芯片不看宿主 Python；接入的终点是客户端那条命令真起了 server；给 agent 抄的每条命令都要有守卫对到真实 CLI；每个诊断码都要有人话、doctor 只报不改且默认不碰外网；清单只在两平台齐了才上 release、真机证据由流水线产出 |
| v0.37.0 (2026-09) | 任意 AI 客户端可调用：广告层只对一个客户端对过 / 自家 .mcp.json 从未连通 / 端口静默采用与误杀 / 回环走代理 | 按**别人的**约束测；改 golden 前先答「旧断言为何不会红」；负向对照跑不红就如实改口 |
| v0.36.0 收尾 (2026-09) | 「Java 族 live 需 Mongo」十个版本的误定性 = vendored 脚本裸 `-jar`；演禽假闸门 | 贴「环境限制」前先读 `Result` 原文、用上游桌面起法起一遍；闸门问项以 live 翻转为准，不以转发为准 |
| v0.36.0 (2026-09) | 止血/可用性/捞回能力 15 批（响应放大、静默降级、手抄表、死键、降级误杀、扁平面丢键、moira 误排除、闸门半盲、错误码……） | 每批四件套 + 全量门禁；台账正文按批见下 |
| v0.35.0 (2026-09) | 手工件零信号 + 整拷树不比对（六亲两格错值滞留四轮） | 不经流水线的文件都要有「源变了就叫人」的边；守卫树集合 == sync 整拷集合 |
| v0.35.0 (2026-09) | 手册知识包白名单脱钩 + 读脏工作区 | 每册手册要么收割要么明文排除；出处与正文同源于同一 commit |
| v0.35.0 (2026-09) | SQLite 日志侧车混进镜像与发布包 | 排除集四处同加（sync / 守卫 / 三 builder）；侧车不是源文件 |
| v0.34.0 (2026-09) | 上游 v3.10.0 择日十技法同步 | 闭包按停止节点算；抽壳要机械化；解析器盲区造假债务；兜底分类=待确认 |
| v0.33.1 (2026-09) | issue #15 家族全清剿 | presence 级断言对值失明；跨边界不改键；静默降级会上移；schema 描述不是愿望清单 |
| v0.14.0 (2026-06) | 古典占星 [古典]/[古典格局] | endpoint 必须登记 `_PYTHON_CHART_ENDPOINTS`；段补≠新工具；离线/live 覆盖分层 |
| v0.13.0 (2026-06) | 4 未同步 AI 技法 + 太乙/八字段口径 | 审计先查自家排除项；`EXPORT_TECHNIQUES` 才是权威清单；请求型 builder 归 Python |
| v0.12.0 (2026-06) | 主限法 v12 核5收敛 + faRelatedPeople | vendor 源=xuanshu-engine；params 回显≠引擎值；live 必打 vendored 实例；pdSyncRev 心跳 |
| ↳ 附录 | 主限法 v12 同步清单（历史核对参照） | 显示窗/Vertex/钥匙修真/pdYears 3000/golden v266 |
| v0.11.0 (2026-06) | 玄枢 v2.6.3→v2.6.5 parity | 恒星黄道透传；JS 闭包提取三陷阱；政余诚实局限；离线契约禁裸「无」 |
| v0.10.0 (2026-06) | 玄枢 v2.5.4/v2.6.x parity | PD 参数走 perchart；依赖闭包是头号陷阱；法奇门外科式接入；live 服务让测试真跑 |
| v0.9.2 (2026-05) | 加固审计 | f-string None 陷阱；禁静默回退；runtime 瘦身实测；preset 是超集 |
| v0.9.0→v0.9.1 (2026-05) | 神数家族 14 路全上 | kentang 路由坑；`Result.snapshot` 嵌套；kinastro 只 vendor 引擎；中立 CWD 验证 |
| ≈v0.8.x | v2.5.0 推运(7)+卜卦/择日 | JS-vendor vs Python-port 决策树的来历与四个坑 |
| ≈v0.7.x | v2.4.0 西占 4 件 | backend-predict 模式；本命增补 JS算/Python排；mundane 复合盘；runtime-source 重同步 |
| v0.10.0–v0.18.0 | 发布完整性编年（缺半/repack/pin-forward 全史） | 三种失效模式的完整案例史；现行法则见 `AGENTS.md` §7 |
| Windows 发布侧 | 独立台账（本文下节） | 三失效模式/逐版本 win 半边史/横切教训（维护者视角） |
| upstream v2.2.1 | AI-analysis SSE Issue #8 | 只影响玄枢桌面端 chat 流，不影响 skill 计算路径 |

---

## Windows 发布侧台账（维护者视角 · 原文收编）

Windows 侧离线 runtime 发布的逐版本经验台账。这里是**为什么**与**踩过的坑**的叙事视角；
可执行的操作细节（命令、脚本、闸门）在 [`AGENTS.md`](../AGENTS.md) 的对应条目与
[`OFFLINE_RUNTIME_RELEASES.md`](./OFFLINE_RUNTIME_RELEASES.md)、
[`WINDOWS_RELEASE_BUILD_PROMPT.md`](./WINDOWS_RELEASE_BUILD_PROMPT.md)。名词见 [`GLOSSARY.md`](./GLOSSARY.md)。

## 背景：为什么有 Windows 侧台账

离线 runtime 分 darwin-arm64 与 win32-x64 两个平台构建。**Windows 半边在一台真实 Windows
机器上离线构建**（要 embed Python + JDK17 + Node + astropy + 引擎 + core-js），不进 CI。mac 侧发布
新版时，win 半边常常缺席或滞后——这台台账记录了它的每一次形态与修法。

## 主线：`latest` 的 Windows 半边完整性（三种失败模式）

| 模式 | 表现 | 守卫 | install | 探测 |
| --- | --- | --- | --- | --- |
| **无 manifest** | `runtime-manifest.json` 直接 404 | — | **两平台都坏** | 手查 |
| **darwin-only** | manifest 只列 `darwin-arm64`，无 win zip | **红**（v0.13.0 起自动抓） | Windows 找不到 `win32-x64` / zip 404 | 守卫红 或 `sync --check` |
| **pin-forward** | manifest 列 win32 但**指向旧版 zip** | **绿**（URL 能解析、sha 匹配） | 不坏，但装到**滞后 N 版**的旧运行时 | 只有 `sync_windows_release.py --check` 抓得到 |

**pin-forward 是最隐蔽的**：守卫只查“存在 + 可解析”，查不出版本不匹配。唯一可靠探测是
`sync_windows_release.py --check`——它找版本专属的 `xuanshu-runtime-win32-x64-vX.Y.Z.zip`
资产，pin-forward 下该资产缺失即报 `[GAP]`。**把 `--check` 的 GAP 当权威，不管守卫什么颜色。**

## 逐版本

| 版本 | Windows 侧发生了什么 | 教训 |
| --- | --- | --- |
| v0.7.0 | 构建脚本用了 `rsync`（Windows 没有） | 改 `shutil.copytree`，让同一个 builder 跨平台可跑。 |
| v0.9.1 | 补 14 个神数引擎 | 神数族（5 独立 + 9 kinastro）要全量 vendor。 |
| v0.10.0 | `latest` 无 manifest → 两平台 install 全坏；且 mac builder 有 shaozi 生成 + plotly 剥离两步，Windows builder 没有 → 会出占位邵子条文且 zip 大 40MB，**却仍通过 verify** | 加 builder 间步骤对齐；`verify` 的 `REQUIRED_ENTRIES` 是两 builder 必须满足的跨平台契约。**动一个 builder 就 grep 另一个 + 两份 REQUIRED_ENTRIES。** |
| v0.12.0 | 启动器加固；建立两道 CI 闸 | PID 归属须用 `[System.IO.Path]::GetFullPath` 规范化后比对（否则 `..\` 未规范化→永不匹配→stop 静默空转、漏杀进程）；java 加 `-Dfile.encoding=UTF-8 -Dsun.jnu.encoding=UTF-8`（Temurin 17 pre-JEP-400 CJK 乱码）；端口占用快速失败 + 300s 就绪闸。新增 `release-completeness.yml` + `verify_builder_parity.py`。 |
| v0.13.0 | 第一个被守卫**自动抓到**的 darwin-only | 从此靠那道红勾，不再靠手工发现。 |
| v0.14.0 | 造出 `sync_windows_release.py` 一键补齐 | 把手工的“构建→下 darwin→双 manifest+校验和→verify→上传”封装成幂等、安全（无 `--upload` 不做不可逆动作）的一条命令。 |
| v0.15.0 | 天文地占/塔罗两新技法 | 新技法可能带**新后端端点**（`/geomancy/reading`）——源树 astropy 须够新，否则新端点 404 而 verify（只查文件在不在）照过。 |
| v0.16.1 | mac **首次自发全双平台**（重封包 v0.16.0 win zip + 改内嵌 manifest）；但 `export_registry_version` 6→7 只改了 mac builder | 重封包合法的前提是发布 diff **无 payload 层改动**（core-js/引擎/wheels/启动器）；用 HTTP range 读已发布 zip 的内嵌 manifest 可免下 800MB 核验。**数字常量会漂移**：子串级 parity 看不见 6 vs 7，遂给 `verify_builder_parity.py` 加了 `schema_version`/`runtime_layout_version`/`export_registry_version` 交叉核对。 |
| v0.17.0 | pin-forward 模式开始；一掌经/占星地图/名人库 + 引擎全面升级 | 新增 `/location/acg` 端点 + `astrodata-aa.sqlite.gz`（约 50MB，在 `dist-file/astrodata/`）——**源树新鲜度成真风险**，须从当前 Windows 工作区重灌 vendor 并原生验证新端点返回真数据。 |
| v0.18.0 | pin-forward（钉 v0.16.1） | 验证 install 落盘时踩过假警报：真运行时根在 `AppData\Local\Xuanshu\runtime\current`，别错查了旧的 `.xuanshu\runtime\current`。 |
| v0.19.0 | 名人库中文化 + 法奇门对宫订正 | 名人库靠 astrodata sqlite 的 `name_zh` 列（07-07 源树已含 5.9 万行）；对宫订正在 `DunJiaFaCalc.js`（JS，随 repo）——原生验证可用 sha 对齐“bundle 里的 JS == repo 的 JS”。 |
| v0.20.0 | pin-forward **基线前移**（钉到上一个真 zip 而非冻结 v0.16.1）；黄历/六壬七政 | 滞后从多版降到约一版；黄历依赖 java 端 `/nongli/time` + `/jieqi/year`，直接裸 POST 会因 payload 归一化差异 500，须走 skill 自己的 `_call_remote` 归一化路径验证。 |
| v0.21.0 | 安装链增强（断点续传/多镜像/进度/uninstall/upgrade/selfcheck） | 新 install UX 往 stdout 打**进度/引导文案，不再是纯 JSON**——脚本化判定改用 `doctor`（仍是干净 JSON）或从混合输出提取末尾 JSON 块的 `asset.sha256`。“版本短路”被 `--force` 绕过，`install --archive --force` 仍做真安装。 |
| v0.23.0 | darwin-only 复发；vendor 缺 v3.5.x 新顶层件（kin_year_domain/ifa_odu/prepareruntime）+ jar 落后须从当前 Windows workspace 重灌；首建死于 Temurin `releases/latest` 半发布窗口（jdk-17.0.20-ga 无 win 二进制）→ JDK 改走 Adoptium API；kintaiyi game_theory/scipy 吓人 traceback 定性为两平台一致良性噪音 | JDK 解析必须 asset-existence-aware；重灌后必跑 `verify_vendor_runtime_sources.py` + `verify_export_contract_mirror.py`；吓人 traceback 先对照 mac 半边定性再动手；无 Mongo 机器 live 验证按「chart 半边绿 + 占时路径 java 500 属预期」判读。 |

## 横切教训

- **构建/验证 parity 是唯一防回归的锚**：`verify_runtime_release.py` 的 `REQUIRED_ENTRIES` +
  `verify_builder_parity.py`（步骤子串 + 数字常量）。改任一 builder，同一提交内对齐另一个。
- **源树新鲜度**：技法多在 repo 层（core-js/service.py），随 checkout 走；但**新后端端点/新数据文件**
  （astropy 端点、astrodata sqlite）来自外部 Windows 工作区。跳版前核工作区 astropy/dist-file 的 mtime
  是否新于目标发布，并原生验证新端点返回真数据。
- **环境坑**：PowerShell 5.1 以 cp1252 读无 BOM 的 `.ps1`（毁 CJK 字面量）→ 用 `pwsh`；Python stdout
  cp1252 遇 CJK 崩 → `PYTHONUTF8=1`；`gh api --jq .tag_name` 返回裸标量不是 JSON。
- **原生验证优先走真生产路径**：`install --archive <zip> --force` → `doctor`（结构）→ 启动加固启动器 →
  直接压测 chart 端点（ken×3 + 神数 + geomancy/acg 各 `rc=0`/真数据）+ 查无乱码。
- **不碰 mac 层**：Windows 侧只补 Windows 半边与 Windows 侧工具/文档；不改 mac 的发布自动化。

---

## 台账正文（新条目加在最上方）

### v0.40.0-dev / 2026-09-24 — Windows 维护机 lane：main × 公开 v0.39.0 runtime 的 6 条 live 红是版本偏斜——live 闸只看「活不活」，不看「够不够新」

- **背景**：同一轮复验，`verify_runtime_live.py` 用全新根 `rt-lane` 真下载公开 v0.39.0（`xuanshu-runtime-win32-x64-v0.39.0.zip`，
  60 s 装 / 21 s 起）：非 ASCII 根拒装、doctor、四引擎、**九客户端全绿（含 codex）**、HTTP 握手、挂客户端不停、自动换端口、stop
  ——Windows 原生的 12 步全过。唯一红：live pytest `1733 passed / 6 failed / 28 skipped`。
- **症状 → 定性**：6 条 = `test_sanshiunited_combines_ken_qimen_taiyi`（`taiyi.kook` 为 None）、`test_sync311_chartfamily`
  派生盘标签「，整宫(变换后上升)」、`test_sync311_newtools` ephemeris 金标两例（行格式差一列）、`test_sync311_shenshu` wuzhao
  castSeed 复现（断言信息自己写着「旧码不带 castSeed → 后端 random.Random() 真随机」）与 cetian「地点：上海」（引擎回「玄枢地点」）。
  逐条对回提交史：`kook` 随 sanshi 同步（`21e3076` / `5a6148d`，快照改由 vendored 上游 `buildSanShiUnitedSnapshotText` 产出）
  进 main；其余全是 sync311 钉的上游 v3.11 行为。而 lane 装的是 v0.39.0 payload（`export_registry_version` 14），本树契约
  `AI_EXPORT_SETTINGS_VERSION` 15——**这些行为要下一版 runtime 才有**。JS 技法在 lane 里走的也是已装 runtime 的 core-js
  0.39.0（解析顺序 env → installed manifest → bundled，AGENTS §6 早有记载）。结论：偏斜，不是回归，也不是 Windows 问题。
- **为什么会红而不是跳过**：`requires_chart` / `requires_runtime` 只看两件事——实例活不活、是不是显式点名的（AGENTS §8
  「默认端口栈不可信」）；「实例够不够新」没有任何闸。`pdSyncRev` 心跳闸只管主限法。于是主干一旦领先于公开 runtime，
  钉新行为的 live 用例在「main × latest」形状下必红——**托管矩阵每周一（`23 4 * * 1`）就是这个形状**（`actions/checkout`
  无 `ref` = main，资产 = 公开 latest），下一次跑必红同样 6 条，把真回归淹在里面。
- **修**：`tests/test_local_js_tools.py` 新增 `requires_current_runtime_contract`——读已装 payload 的 `export_registry_version`
  （`<runtime_root>/current/runtime-manifest.json`），小于本树 `AI_EXPORT_SETTINGS_VERSION` 即 skip，理由写明
  「payload N < tree M：引擎早于这些断言钉的上游同步（偏斜，非回归）」；**未知不跳**（外部 vendored 实例没有已装 payload，
  它的新鲜度由 preflight / mirror 守卫另管）。挂到 sync311 三个模块的全部 17 条 live 用例 + sanshiunited。判定函数纯函数化，
  `tests/test_live_contract_gate.py` 四条（旧 / 相等或更新 / 未知 / 从清单读）。skip 理由避开 lane 的 `FORBIDDEN_SKIP_REASONS`
  子串。CI 形状（`XUANSHU_RUNTIME_ROOT` 空目录）实测 installed=None → 不跳；指向 `rt-lane` 实测 14 < 15 → 跳。
- **顺手：一条真 flake 的定性与加固**。门禁复跑 `test_port_bindable_distinguishes_held_from_free` 红一次（首跑绿）：夹具
  `listening_server` 起 `python -m http.server` 只等 10 s，Windows 全量 pytest 下 CPython 冷起 + Defender 可超过 10 s，到点
  照样 yield → 下游 `port_bindable(port) is False` 红成一条像产品缺陷的断言。`_bindable_on` 不设 SO_REUSEADDR、语义确定，
  不是端口探测 bug。夹具改 30 s，到点仍可绑就 `pytest.fail("http.server never started listening … slow spawn, not a port bug")`。
- **法则**：live 闸要问三件事——活不活、点没点名、**够不够新**；主干领先公开 runtime 是常态，钉新行为的 live 用例必须能
  说出「我在等下一版 runtime」而不是红。夹具的就绪等待到点必须自己点名，不许静默放行。

### v0.40.0-dev / 2026-09-24 — Windows 维护机复验 main（f05f727）：benchmark smoke 在 cp1252 管道上炸——stdio 守卫对「打印数据」失明

- **背景**：v0.39.0 五件齐、`--check` [OK]，Windows 半边无需补；本机按「原生复验」角色在独立 worktree `hs-lane` 跑
  `run_ci_gates.py` + `verify_runtime_live.py` + 桌面端占默认端口的真机形状。当天 mac 侧为 windows-smoke 连红四次
  盲修（node 子进程 encoding、ESM file:// URL），CI 刚转绿。
- **症状**：门禁 **23/24**——唯一红是 `Run XuanshuBench local-only smoke`：`scripts/run_benchmark.py --skip-runtime`
  在 `print(text)` 处 `UnicodeEncodeError: 'charmap' codec can't encode characters in position 3323-3324`。
  09-22 同一步还是绿的。
- **根因**：报告是 `json.dumps(report, ensure_ascii=False)`；基准用例新进了 `休门`（奇门 required_fragments）与
  `宝剑骑士（逆位）` 等塔罗牌名共 15 种 / 58 处非 cp1252 字符。`run_ci_gates.py` 用管道收子进程输出 → Windows 上
  子进程 stdout 落回 locale = cp1252 → 首个 CJK 即炸。ubuntu 的 `test` job 是 UTF-8 恒绿；`windows-smoke` **根本不跑
  这一步**。守卫层面：`tests/test_scripts_stdio.py::test_every_script_that_prints_non_ascii_forces_utf8_stdio`
  的检测器只扫 **print 字面量**里的非 ASCII（`NON_ASCII_PRINT`），`print(变量)` 打印数据的形状它看不见——同一盲区下
  共 **19 个脚本**（含 verify_error_recovery / verify_export_section_baseline / verify_silent_* / verify_runtime_release
  / verify_server_json / build_knowledge_index 等门禁步骤）没有 reconfigure，今天没炸只因它们的数据恰好全是 ASCII。
- **修**：① 19 个脚本逐一补仓内既有惯用块（`for _stream in (sys.stdout, sys.stderr): … reconfigure(encoding="utf-8",
  errors="replace")`，紧跟 `import sys`，字节级插入、EOL 原样）；② 守卫检测器扩到「`ensure_ascii=False` + `print(`」
  （打印数据 = 承诺输出非 ASCII），新增 `test_guard_catches_a_script_that_prints_non_ascii_data`（只写文件不打印的不算、
  `json.dumps` 默认 ASCII 的不算）；③ ci.yml `windows-smoke` 加同名 benchmark 步骤——它是唯一 stdout 非 UTF-8 的 runner，
  这类炸只有它能红。验证：定向 23 绿；cp1252 管道下 `run_benchmark.py --skip-runtime` exit 0。
- **法则**：脚本「打印非 ASCII」有两条路——字面量**和数据**，守卫两条都要看；凡 `ensure_ascii=False` 进了 `print(`，
  reconfigure 就不是可选项。跨平台守卫要落在**会红的 runner** 上：ubuntu 上恒绿的编码闸等于没有。
- **本机同轮其它原生证据**：桌面端占着 8899/9999 时 doctor 点名「占着端口的是玄枢自己（多半是桌面端）」并列出
  `XuanshuDesktop\embedded-runtime\…` 映像（5ef87cb 在它为之而写的形状上首次真机通过）；lane 用全新根 `rt-lane`
  （release 模式 `download_problems` 要求真实下载字节 > 0——已装同版本的 `rt-verify` 会短路成假红，故换新根）。

### v0.40.0 / 2026-09-24 — 首推 windows-smoke 红：测试里起 node 复算金标的子进程按 cp1252 解 CJK

- 症状：v0.40.0 候选第一次上 Windows runner，`windows-smoke` 的 pytest 红 11 条（六爻 / 正传 / 节气宿盘 / guidance 词表 / 择日判读…），
  全是 `UnicodeDecodeError: 'charmap' codec can't decode byte 0x8d`（读线程里炸 → `stdout=None` → `json.loads(None)` 再炸一层）。
  本机（macOS）与 ubuntu job 全绿。
- 根因：同步各波新增了一种主要测试形态——测试自己 `subprocess.run(["node", "-e", …], text=True)` 跑 vendored 上游 JS 算金标；
  7 处都没给 `encoding=`，Windows 上 `text=True` 按控制台代码页解。`tests/test_subprocess_encoding.py` 的守卫只扫 `src/`
  （v0.37.0 那次是产品代码踩的同一坑），tests/ 是盲区。
- 守卫：7 处补 `encoding="utf-8"`（node 恒 UTF-8 输出）；`test_subprocess_encoding.py` 新增对 tests/ 的 node 调用扫描 +
  负向对照（旧形状必红、非 node 子进程不误报）。
- 规则：**在 tests/ 里起子进程读文本，与 src/ 同一条纪律——`encoding="utf-8"` 显式给。** Windows job 是唯一能抓到它的地方，
  推之前本机没法复现（macOS 默认 UTF-8），所以守卫必须是静态扫描。
- 第二轮（同一推送修完编码后再红 9 条）：`node --input-type=module -e "import(process.argv[1])"` 在 Windows 上不接受裸盘符
  绝对路径（`ERR_UNSUPPORTED_ESM_URL_SCHEME` ×18），只认 `file://` URL；macOS / Linux 的 `/abs/x.js` 恰好能过。守卫：tests/node_esm.py
  是起 node ESM 的唯一入口（Path 参数转 `as_uri()`，字符串形式的绝对 `.js` 路径直接拒绝），`test_subprocess_encoding` 禁止别处再写
  `--input-type=module`（负向对照两条）。规则：**测试里给 node 的模块路径一律传 Path、经 helper 转 URL；本机绿不等于 Windows 绿的
  又一个实例，静态守卫先行。**

### v0.40.0 / 2026-09-24 — 首推 CI 红：stdio 探针把全量面工具数写死在 ci.yml 里

- 症状：v0.40.0 候选第一次推上 main，CI `test` job 在「Zero-install path from the wheel works」这一步红：`assert probe["tools"] == 116 == probe["expected_tools"]`，
  而探针报 `expected_tools: 120`；windows-smoke 的两处 pwsh `-ne 116` 同样会红。本机 24 步门禁全绿——`run_ci_gates.py` 不跑这两步（它们要
  `uvx --from <wheel>` 真起 server），而工作流文本里的数字没有任何守卫。
- 根因：v0.38.1 R9/R18 把「全量面 = 116 个工具」写成字面量塞进 ci.yml（三处）和 README 客户端表（每份 6 行），四个新工具（ephemeris /
  returntimeline / prenatalsyzygy / prog）让真值变成 120，docs-sync 的工具计数只盯「110 技法」措辞，看不见「全量 116」。又一个「计数写在文档里、
  真值在别处」（同形：v0.38.0 B0 marketplace.json 97 工具）。
- 守卫：ci.yml 两个探针改从 `contracts/mcp_list_budget.json` 读 `full_tools` / `compact_tools`（这份契约本身由 `verify_mcp_list_budget.py` 对真
  server 核过）；`verify_docs_sync.check_full_surface_counts` 扫 README×2 的「全量 N / full (N)」行对 `full_tools`，并禁止 ci.yml 出现
  `-ne <数字>` / `== <数字>` 形式的工具数断言；`tests/test_ci_workflow_shape.py` 同一正则的负向对照。
- 规则：**任何写进工作流 / 文档的计数都要能指出它的真值文件；指不出就不许写数字。** 本机门禁不覆盖的 CI 步骤，推之前至少把它的断言值核一遍。

### v0.40.0 / 2026-09-24 — 审计 P0：报告类 MCP 工具的 `output_path` 是任意路径写；P1：运行期契约不在安装包里

两条都是 v0.40.0 同步收尾时的接口 / 分发审计结论（交接文档 §6.1），用户拍板后与同步一起修。

1. **P0 安全：`xuanshu_report_render` / `xuanshu_report_from_tool` / `xuanshu_technique_report` 的 `output_path`。**
   - 症状：三个工具接受 `output_path`，经 `Path(...).expanduser().resolve()` 后 `renderers.render_report` 用 `os.replace` 直接覆盖目标；
     没有「只能写到输出目录」的约束；annotations 还标着 `destructiveHint=False`。MCP 工具的调用方是模型——一次被提示注入的
     `xuanshu_report_render(output_path="~/.zshrc")` 就把用户的 shell 配置换成一份 JSON 报告，而客户端因为「非破坏性」不问一句。
   - 根因：报告类工具从 CLI 时代继承了「路径是用户给的」假设；搬到 MCP 面后调用方变成了不可信的模型输出，路径语义没跟着变。
     annotations 的口径只看了「会不会删」，没看「会不会覆盖别的文件」。
   - 守卫：`XuanshuSkillService._report_output_path`——缺省仍是存储层缺省产物路径；相对路径按输出目录解析；绝对路径必须落在
     输出目录或 `XUANSHU_REPORT_OUTPUT_ROOTS`（`os.pathsep` 分隔的白名单根，`Settings.report_output_roots`）之内，否则
     `report.output_path_not_allowed`（带 `allowed_roots`，**不写任何文件**；`..` 逃逸同样拦）。三个工具 `destructiveHint=True`
     （report_from_tool 还非幂等）。`tests/test_report_output_path_guard.py`（负向对照：把闸换回「resolve 即用」的旧写法，越界写入
     真的发生）+ `test_mcp_robustness` 注解断言。
2. **P1 打包：`contracts/` 不在 wheel / MCPB 里。**
   - 症状：`decisions/policy.py`（Jev 阈值锁）/ `decisions/eval.py` / `reports/technique_card.py`（算源契约）用
     `Path(__file__).resolve().parents[3] / "contracts"` 找文件——源码树成立，wheel 安装后 `parents[3]` 是 site-packages 的父目录。
     后果：uvx / wheel 安装下 Jev `enforce` 永不生效，技法依据卡的算源一律「未标注」。这是 v0.39.0 **已经出货**的 bug；
     源码树运行不受影响，所以本机全绿、live 全绿、CI 全绿。MCPB bundle 的 `.mcpbignore` 也整个排掉了 `/contracts/`。
   - 根因：又一个「构建期 include 列表与运行期路径假设各写各的」（同形：v0.38.0 B0 的 Dockerfile 漏 COPY force-include）。
     `verify_wheel_contents.py` 只锁了当时知道的条目，新加的运行期数据文件没人登记。
   - 守卫：`xuanshu_skill/contracts_locator.py`（源码树 `<pkg-root>/contracts/` → 包内 `xuanshu_skill/contracts/`，都缺回源码树路径）；
     pyproject force-include 两份运行期契约；`.mcpbignore` 改 `/contracts/*` + 反选两份文件（父目录整体忽略时反选无效，只能这么写）；
     Dockerfile COPY 两份；`verify_wheel_contents.REQUIRED_ENTRIES` 锁两条；`tests/test_contracts_packaged.py`（负向对照：旧的
     `parents[3]` 表达式在模拟的 site-packages 布局下指向不存在的路径）。
   - 规则：**代码里任何 `Path(__file__)…parents[n]` 找数据文件的写法，都要问一句「安装成 wheel 之后这条路还在吗」**；运行期要读的
     仓内数据文件一律走 force-include + 定位器 + wheel 守卫三件套。

### v0.40.0 / 2026-09-24 — 并行同步各路实现者的踩坑：stub 杀死纯逻辑、移植口径、测试替身与 worktree

背景：v3.11.x 同步拆成十路并行实现（隔离 worktree），各路交回的报告里有一批与技法无关、会再犯的形态。按「有没有机器守卫」分两类。

**有守卫的**

1. **stub 掉的 import，死的是纯逻辑、不是 UI。**
   - 症状：六壬择时 / 三式择时的六壬条件对任何条件都 0 命中（形状合法的空结果，live 样例 元首课 修后 0 → 19）。
   - 根因：`liureng/LiuRengMain.js` 的 manifest 把 `ChuangChart` / `LRXiangDoc` / `LRSanChuanRelationMini` 当「只有 React 尾部用」
     stub 成空，而保留的纯逻辑（`buildSanChuanData` 里 `new ChuangChart`）也在用 → ReferenceError 被 try/catch 吞成 null。
     selfcheck 当时只断言 `Number.isFinite(hit_count)`，看不见。
   - 守卫：`revendor_core_js._stubbed_names_still_used`——stub 掉的绑定仍被保留代码引用、且 stub 没定义同名 → `--check` 报 ⚠
     （负向对照：给 LiuRengMain 重加这两条历史 stub，分别报 ChuangChart / buildXiangContext）；首跑还揪出 `DateTime`（UI 草稿恢复链，
     不可达）→ stub 改为定义同名、调到即抛明确错误的类。selfcheck 择日命中改锚独立算出的真值。
2. **worktree 里的子进程测试跑的是主 checkout 的代码。**
   - 症状：四路实现者各自在 worktree 里看到 stdio/http 测试报「116 个工具」，而本树已是 120。
   - 根因：共享 venv 的 editable install 指向跑过 `uv sync` 的主 checkout；`python -m xuanshu_skill…` 子进程不经 pytest 的
     `pythonpath=["src"]`。同形还有：同一秒内改回同长度代码会留下陈旧 `.pyc`（`PYTHONDONTWRITEBYTECODE=1`）。
   - 守卫：`tests/conftest.py` 会话期把本 checkout 的 `src` 前置进 `PYTHONPATH`；`test_subprocess_children_import_this_checkout_not_the_editable_install`
     （负向对照：worktree 里去掉 pin 即红，子进程解析到主 checkout）。
3. **生成器不幂等：契约是手改的。**
   - 症状：`gen_technique_provenance.py` 重跑，契约 26 个工具被改写（神数 14 路丢 `/wangji/xinyi` 与 `yanqin_yanfa`、bazi_inverse 被判成
     python_chart_backend、guolao_chart 从 composite 变 headless_js……）；反过来契约也落后生成器 9 处（择日八键 `export_technique` 仍 null）。
   - 根因：AST 只扫 runner 本体，helper 间接调用的证据与逐工具说明只能手改契约；`eps and not js` 一律判 chart 服务。
   - 守卫：`EXTRA_EVIDENCE` / `NOTE_OVERRIDES` 进生成器，Java 端点判 java_backend；`--check` + `test_technique_provenance_generator.py`
     锁「契约 == 生成器输出」（负向对照：改前契约下报 9 个工具不一致）。
4. **`_js_round` 名为 JS Math.round，实为向零截断。**
   - 症状：世俗盘实现者变异测试发现 `service._js_round(-1.7) == -1`（JS 为 -2）；AGENTS §4 一直写的是 `floor(x+0.5)`。
   - 根因：`int(x+0.5)`，注释假设「age/span 恒正」，而调用点后来已不止这些。服务里另有一份正确的 `_js_math_round`。
   - 守卫：改 `math.floor`（正数行为不变）；`test_js_round_mirrors_math_round_for_negative_values`（旧实现在 -0.7 / -1.7 / -2.5 三处红）。

**只有测试、没有通用守卫的（照着做）**

5. **移植口径**：`/nongli/time` 的 `year` 是**正月初一**口径干支、`yearJieqi` 才是立春口径——六爻以时起卦旧移植取
   `yearJieqi`，立春到正月初一之间年数就与上游 `buildTimeGua` 不同（连同月/日用了地支序而非农历月日数，三处合起来卦都不同）；
   两层两个缺省——奇门 Python 侧缺省发 `chaibu`、JS 本地层缺省 `zhirun`，盘按拆补算、标签写置闰（缺省必须一处
   定义、两层同读）；上游 builder 读 `params.date` 是 `YYYY/MM/DD`，skill 归一成 `YYYY-MM-DD` → 七政 [大限] 出生年 0；moment
   `add(x,'days')` 把小数天四舍五入到整天，照搬成 `timedelta(days=float)` 让波斯向运日期差一天；上游 AstroTxtMsg 是单字名（日/月），
   skill 的 ASTRO_TEXT_MAP 是全名（太阳/月亮）——v56 宫神星表就这么印错而测试也断言错值；上游页面的**出厂缺省**≠引擎缺省
   （六爻贵人 页面 2、引擎 0），只送调用方选项会落到引擎缺省；种子与缺省照上游 headless 路径（`build*SnapshotForFields` /
   `aiAnalysisContext`），不照页面 state。
6. **工具自身的盲区**：`_drop_orphaned_imports` 把注释里的提及也算「在用」（`LiuYaoReference` 出现在注释里 → 整个
   `LiuYaoBoard` import 被留下、只能再手写 stub）；边界契约生成器按局部变量名跨函数配对（`const base = {…}` 被记到别的
   函数调用名下 → 假死键）。已知局限，遇到就改名/显式 stub，并在报告里点名。
7. **测试替身会说谎**：`/liureng/runyear` 的 fake 回的是真端点从不发的包装形态，离线全绿而 live 下 liureng_runyear 四课/
   三传/行年全空（三式实现者：改为按「端点 + 决定结果的请求字段」键控的**录制回放**夹具，回放与 live 逐字节一致才准裁剪——
   请求形状一错即 miss，天然负向对照）；离线 fake 收到的 `/chart` 端点是 `"/"`（按 `/chart` 做键会静默落到罐装盘）；FakeClient 回显斜杠日期；
   对所有端点同答一份的桩藏住了玄史 `id`/`slug` 映射错（改为逐端点校验真实下发参数）；导出解析器会去重段名，同一张卡出两次
   对 missing/unknown 检查不可见；择日快照段间无空行，按 `\n\n` 切段会漏段；上游自己的 jest 骰子盘夹具把 `aspects` 嵌错了层，
   真后端下那几段不可达而上游测试照绿（上游 bug，已如实上报，不写回上游）。
8. **运行期语义**：合法的 JSON `null`（「查无」）被 `_call_remote` 当失败无限重试，且每轮都真打后端；输入归一化会把嵌套
   `options.gender` 的 male/female 递归改成 1/0（五兆恰好只收字符串）；`/jieqi/year` Java 与 Python 两端都有、数据不同
   （Java 多 bazi.fourColumns 与 chart.nongli），`test_endpoint_registry.py` 那句「chart-only」注释已改正。
9. **上游代码自己也会崩**：逐字 vendor 的 `jyotishSnapshot` 有暂时性死区（`scS`）与键名错（`index`/`month`），从没在真数据上跑过；
   世俗盘卡 builder 吞掉每张卡的异常，闭包坏了只表现为「卡不见了」——只有值级金标抓得到。
10. **动态 `import('./x')` 没补 `.js`，懒加载路径静默返回空。**
   - 症状：六爻实现者要接 [断诀命中]/[占类断语] 时发现 vendored `gua/data/liuyaoDoctrineCache.js` 的 `loadDoctrine()` 恒返回 null。
   - 根因：re-vendor 只给静态 `from './x'` 补扩展名；动态 `import('./tianjiDoctrine')` 在原生 Node ESM 下 ERR_MODULE_NOT_FOUND，
     被模块自己的 catch 吞成「断语库缺失」。模块照常加载，loadcheck 恒绿。
   - 守卫：transform 补动态相对 import 的 `.js`（`_DYNAMIC_RELATIVE_IMPORT`）+ `test_dynamic_relative_imports_get_the_js_suffix_too`；
     重渲染后同一调用返回 40 键断语库（修前 null）。
11. **worktree 隔离的 agent 建在「当前目录所在的仓」——一次落进了只读上游。**
   - 症状：派发三式合一 agent 时 shell 恰好 `cd` 在 `xuanshu-engine/…/src`（刚查完上游源码），worktree 被建成
     `xuanshu-engine/.claude/worktrees/agent-*`（上游仓多出一个 worktree + 一个分支）。agent 按规则先跑 `git log`/`worktree list`
     察觉不对，只做了只读命令；约一分钟内被叫停。
   - 处置：停 agent；harness 随之移除该 worktree 与分支（核对：上游 `.git/worktrees` 不存在、无 `worktree-agent-*` 分支与 reflog）；
     手删它留下的空 `.claude/worktrees/` 目录。上游工作区里一处 `SELFCHECK_LOG.md` 修改早于本会话（9-22），未碰。
   - 守卫：派发前先 `cd` 回本仓并 `git rev-parse --show-toplevel` 核对；agent 规则第一条改为 LOCATION CHECK（toplevel 不在本仓
     `.claude/worktrees/` 下即停手、零写入、一行报告）。这是编排侧的流程守卫，无法在仓内代码里机器化。
12. **类型收窄会吞掉上游缺省；未声明的键会被 MCP 扁平面丢掉。**
   - 七政 `doubingSu28` 声明成 bool：`True` 被后端读成宿度制 1（斗柄定房法），上游缺省是 2（回归今宿），2–8 七档根本传不进来；
     宿占 / 节气年盘同病。上游是枚举就声明成枚举（int 0–8，缺省照上游），别用 bool「近似」。
   - 汉堡盘 `school/orb/strictFactors/frames/…` 未在 `GermanyInput` 声明：CLI 走整包能用，MCP 扁平签名把顶层键静默丢掉
     （A6 同类）。长尾旋钮用 `ADVERTISE_HIDDEN` / `x-xuanshu-hidden` 声明而不广告：校验照收、tools/list 零字节。
   - 日界开关的 schema 缺省 `False` + `model_dump` = 每次都发 0，Java 把 JSON `false` 读成 0，盖掉上游缺省 1；
     缺省改 `None`（不发即后端缺省），本地引擎路径显式传 1/1（lunar 本地引擎把「缺键」当「不换日」而非上游缺省）。
13. **两路实现各发明一种「声明而不广告」，合并时一行赋值把另一种覆盖掉。**
   - 症状：命理 chunk 合并后 tools/list 一次 +8 KB（253 → 262 KB，离 256 KiB 硬顶 18 B）；acg/india/guolao/mundane/germany…
     的长尾旋钮全部回到广告层。
   - 根因：西占用模型级 `ADVERTISE_HIDDEN`，命理用字段级 `x-xuanshu-hidden`；git 自动合并把两行 `unadvertised = …` 都留下，
     后一行覆盖前一行——语法、测试全绿，只有字节预算守卫抓到。
   - 守卫：两者取并集；`tests/test_mcp_hidden_fields.py` 逐字段锁两种声明法都不进广告层（负向对照：合并版下模型级那条红）。
     并行拆分时同一机制只许一处定义（后来者复用先行者的机制，别再发明第二种）。
14. **自拼快照的「占位」藏住了条件段；截断会悄悄收窄导出。**（三式合一 agent）
   - Python 自拼 sanshiunited 时给缺席段补「本盘未产出」占位，registry 于是从不需要 optional 登记；换成上游 builder 原样输出后
     8 段立刻报 missing——占位等于在导出层替上游「编」段。守卫：条件段按上游双登记，skill 不补占位段。
   - `truncate_before` 剪掉 React 尾部时连带剪掉了尾部的 `export { … }` 列表（LiuRengMain 的 `buildLiuRengReferenceBundle` 等 8 个
     导出靠它），vendored 调用方链接失败。修：transform 保留「头部已定义名」的尾部 export 列表（+ 单测）。
   - 录制回放夹具的键太窄（`/chart` 只按 date/time 键控）会让「请求错了 hsys」回放出看似正确的答案；键必须含所有改变结果的字段。
   - 共享 shim 少一个常量（`constants/AstroConst.js` 缺 URANUS/NEPTUNE/PLUTO/MC…）→ 以它为键的表全变 `obj[undefined]` 互相覆盖、零报错；
     三式合一改用对上游打戳的 curated 子集，七政侧另查。
15. **页面 getter 的兜底值不是页面缺省；「缺键透传」会翻转缺省。**（数算 agent）
   - AGENTS §4 曾据 `fieldVal(f,'timeAlg',1)` 把 canping/heluo/yizhangjing 缺省写成 1（钟表时）；可那个全局字段恒被预置为 0，
     字面 1 从不触发——skill 多个版本按钟表时出数算盘（1998-02-20 11:05 上海：巳时 vs 旧 午时）。找缺省追字段种子。
   - vendored `baziLunarLocal` 判 `after23NewDay === 1`，`undefined` 即 24 点换日（与上游出厂 1 相反）；canping/heluo「缺键透传」
     于是把 23:30 生人的日柱算成前一天（戊戌 vs 己亥）。凡「不给就不传」的工具，下游若把缺键当 0，必须补上游缺省。
16. **`BirthInput` 不是家族共享旋钮的安全落点；条件行要移植 helper 而不是移植「意图」。**（西占正文 agent）
   - 广告层用「不在 BirthInput 里」判定子类自有字段：把 `after23NewDay` 声明进 BirthInput，紫微 / 八字 / 奇门原本广告着的同名键
     被静默踢出 tools/list（症状只是预算缩了 564 B）。家族共享的隐藏旋钮放 mixin + `ADVERTISE_HIDDEN`（`_ChartDayBoundaryKnobs`）。
   - 上游 `fieldValue` 从不返回 `undefined`（缺省 `null`），所以 `排盘规则：` 这类「看似条件」的行实际恒出——按条件移植就少一行。
   - 离线 CaptureClient 记录的是**远端**路径（`/chart` 落成 `/`），断言端点要过 `_chart_server_endpoint`。

### v0.40.0 / 2026-09-24 — 上游 v3.11.x 重同步：六处「同步了却没同步」

背景：上游从 v3.10.0（0604fa41，aiExport v56）走到 v3.11.1 + 三个发布后修（HEAD 9b74714b，aiExport v58；后三个在上游
本机未推送）。runtime-source 97 文件、core-js 89 文件、导出契约两版、四个新技法键一起漂移。同步过程中撞到六个「看起来同步了、
其实没有」的形态：

1. **live 复验跑的是已装 runtime 的旧 JS 引擎。**
   - 症状：起好 vendored 新后端、只设 `XUANSHU_SERVER_ROOT/XUANSHU_CHART_SERVER_ROOT` 跑 live 套件与段级 harness，jinkou 缺 18 段、
     qimen 缺 10 段、tongshefa 缺 5 段；拿提交前的旧代码对照也一样缺 → 差点记成「上游/后端问题」。
   - 根因：`XuanshuJsEngineClient._candidate_engine_roots` 的顺序是 `XUANSHU_CORE_JS_ROOT` → **已装 runtime 的随包 core-js** →
     本仓源码树。维护机装着一份旧载荷，于是所有 JS 技法跑的是它，与被测代码无关；两个「对照组」用的是同一个旧引擎。把
     `XUANSHU_RUNTIME_ROOT` 钉到空目录重跑，101/106 工具干净、剩余 5 个只差上游新段。CI 无 runtime，永远看不到。
   - 守卫：`tests/conftest.py` 会话期 `setdefault XUANSHU_CORE_JS_ROOT=<本仓 xuanshu-core-js>`；
     `tests/test_conftest_engine_pin.py` 锁「本仓优先」+ 负向对照（去掉 pin 时已装副本胜出）。复验手工脚本同样要钉。
2. **curated 件 restamp 了源 sha，却没把上游改动带进副本。**
   - 症状：本轮复核 `suzhan/SZConst.js` 时发现它连 0604fa41 的上游都没跟上——双鱼分野上游早已把形近误植的「魏」改「卫」，
     本仓仍是「魏」，而 manifest 里的 `upstream_sha256` 恰好等于 0604fa41 那份上游。
   - 根因：curated / bespoke 只断言「上游源 sha == 记录的 sha」，**不比内容**；某轮有人 `--restamp` 了却没逐项落改动，看守就此失明。
     （本件的 FengYe 表恰好没人消费，所以没伤到输出——下一次未必这么幸运。）
   - 守卫：能表达成「上游全文件 + 声明式 deviation」的手工件一律改 **verbatim**：`suzhan/SZConst.js`（replace_text 注入 localStorage
     空 shim）与 `tongshefa/TongSheFaCore.js`（truncate_before 类定义 + 4 个 UI import stub + 解构删除，`_reexport_required` 补 export）
     已改；流水线输出逐字等于 vendored 文件，上游一动 `verify_upstream_sync` check 3 就红。
   - **同一轮第三次**：三式实现者发现 `liureng/LRConst.js`（curated）sha 戳等于上游而内容停在旧版——缺 B 派「甲戊兼牛羊」/
     C 派「干合阳阴贵」两张贵人表（贵人 3/4 直接 TypeError）与阴阳系昼夜互换（第 4 参被静默丢弃）。「上游全文件 import 了
     headless 不存在的路径」这条 curated 理由早已过期（唯一 import 已解析到共享 shim），改 verbatim 后流水线逐字复现。
3. **v0.38.1 A16 修了知识包产物，没修生成器。**
   - 症状：重跑 `build_hover_knowledge_bundle.mjs`，`astro/liureng/qimen.json` 的 `source` 又变回维护者本机绝对路径，
     `test_knowledge_pack_sources_are_relative_upstream_paths` 红；`generated_at` 还取 `now()`，每跑一次 index.json 漂一次。
   - 根因：A16 当时手改了三份 JSON 产物，生成器照旧写 `path.resolve(...)` 的绝对路径。
   - 守卫：生成器改写相对上游根的 posix 路径 + 上游 HEAD 提交时间（与 gen_knowledge_packs.py 同纪律，同 commit 重跑逐字节一致）；
     产物测试仍在。法则：**修生成的东西，修生成器**。
4. **re-vendor 变换漏了裸 `export default fetchReturnSet;`。**
   - 症状：新 vendor 的 `divination/election/returnCharts.js` 网络函数被正确剥掉，末行 `export default fetchReturnSet;` 留着 →
     模块加载期 ReferenceError。
   - 根因：`_prune_default_export` 只认 `export default { … }` / `export { … }` 两种聚合形态。
   - 守卫：补第三种形态（被剥的裸标识符整行删）+ `tests/test_revendor_transform.py` 两条（含「没被剥的默认导出原样保留」），
     负向对照：去掉该段后旧函数留下陈旧导出。
5. **vendored JSON 数据不在 manifest 里，上游改值零信号。**
   - 症状：星运族 agent 移植 [行星年四档] 时发现 vendored `divination/data/hellenisticData.json` 的日/月中年仍是 39.5，
     上游 v3.11.0（846756b5）早已改成 69.5 / 66.5；agent 只好在 Python 侧手抄上游值绕开。
   - 根因：`vendor_manifest.json` 只由 `bootstrap_manifest` 按 `*.js` 生成，32 份 vendored JSON 仅 1 份（v0.27.0 手加）在册；
     `revendor --check` 与 `verify_upstream_sync` check 3 都只看 manifest → 另 31 份 JSON 永远是绿的。
   - 守卫：31 份 JSON 全部登记为 verbatim（对 JSON 即逐字节比对上游，负向对照：换回旧文件 `--check` 即 FAIL）；
     `test_every_vendored_js_and_json_file_is_in_the_manifest` 锁「vendor 树 .js/.json 集合 == manifest 集合」（负向对照：旧
     manifest 下报 31 份未登记）；Python 手抄表 `predictive_text.PLANETARY_YEARS` 与 vendored JSON 互锚。
6. **知识库计数没有真值守卫，文档里同一件事写着四个数。**
   - 症状：重收割后手册条目 235 → 236；文档里 README「31 域」与「30 域」并存，SKILL.md 与 AGENTS.md 还写「24 域」，条目数停在 235/408。
   - 根因：工具数、测试数、门面数都有 `verify_docs_sync` 的真值检查，知识库的域数 / 手册数 / 条目数只有人记得时才改。
   - 守卫：`check_knowledge_counts`——真值取 store 实际加载的 bundle 与 helpdoc 条目，16 条措辞正则逐处比对（每条至少命中一次，
     措辞改了守卫不会悄悄变瞎）；负向对照：修文档前报 13 处不符。

### v0.39.0 / 2026-09-22 — Windows 维护机复验 v0.39.0：玄枢桌面端占着默认端口时 doctor 把它说成「查不出身份的进程」；setup 探针对「运行中会话占着 venv 文件」只给一屏 uv 噪声；Jev 数据集指纹按原始字节算

- **背景**：v0.39.0（可选云端决策层）发布后五件齐、托管流水线与 windows-smoke 全绿，Windows 半边无需补。本机按
  v0.38.0 起的「原生复验」角色做「门禁 → lane → 真机场景」，并第一次在**玄枢桌面端开着**的状态下复验——8899/9999
  由 `%LOCALAPPDATA%\XuanshuDesktop\embedded-runtime\<sha>\rt\{python,java}` 占着（这是装了桌面端的用户的默认形状）。
- **① doctor 误诊（用户可见）**。症状：用户默认根（`.mcp.json` 不设 `XUANSHU_RUNTIME_ROOT`）的 doctor 报
  `needs_attention`：「端口被非本工具的进程占用：java_backend 端口 9999 被 **一个查不出身份的进程** 占着…」，next_action
  叫人「关掉上面点名的进程」。根因：`classify_endpoint` 的 `identity.nonce_mismatch`（与 `identity.other_app`）分支由
  身份握手下结论后**提前返回、不收集 holders**；`_doctor_summary` 只看 holders，空就写「查不出身份」——可握手明明答出了
  `horosa-chart` / `horosa-backend`（桌面端自己的 nonce），ctypes 也能直接拿到映像路径。最常见的真实形状（桌面端 + skill）
  被说成「有不明进程占端口」，还被引导去关掉自己的桌面端。修：`identity._name_holders_cheaply` 在这两个分支点名监听者
  （Windows 只用 ctypes 映像、不起 PowerShell；实测 listener_pids 27 ms 首次后缓存、映像 0.3 ms）；`_doctor_port_holders`
  带上 `app` / `evidence`；`_doctor_summary` 按握手**实际证明了什么**措辞——玄枢标记 →「另一份玄枢实例（…很可能是你开着的
  玄枢桌面端，或另一个 runtime 根下的服务）」，next_action 先给「不想关它：XUANSHU_PORTS=auto；想用它的引擎：
  XUANSHU_SERVER_ROOT/XUANSHU_CHART_SERVER_ROOT（外部模式）」；只有什么都没证明时才说「查不出身份」。
- **② setup 探针的 Windows 文件锁**。症状：lane 的 `client_setup` 里只有 codex 红（v0.38.1 复验起两次）：
  `setup.stdio_probe_failed`，stderr 尾巴是 uv 的 `failed to remove file …\.venv\Lib\site-packages\../../Scripts/xuanshu-skill.exe
  : … (os error 32)`。根因：本 session 的 xuanshu MCP 会话（`uv run … serve`）占着 venv 的 exe；codex 形状的探针不继承
  `UV_NO_SYNC`，`uv run` 发现 venv 元数据落后（`git pull` 换了版本号）要同步，删不掉被占文件，server 未启动即退出——
  macOS/Linux 能替换运行中的文件，所以只在 Windows。用户侧同形：客户端开着 xuanshu、终端里 `git pull` 后再 `setup`。
  修：`cli._diagnose_probe_stderr` 只锚不本地化的两头（uv 的英文 `failed to remove file` + Rust 的 `(os error 32)`；
  中间的系统描述随显示语言变），认出就换成中英双语原因 + 下一步，`details.diagnosis` 与 `steps.stdio_probe.diagnosis` 同带，
  原始 stderr 保留、错误码不变。**本机复验法**：别在本 session 的 venv 上跑 lane / 门禁——`git worktree add --detach
  C:\Users\dev\hs-lane <sha>` + 自有 venv（`uv sync --dev` + core-js `npm ci --omit=dev`），测的正好是要推送的那个提交。
  （先试过把被占的 exe 改名再 `uv sync`：这颗 trampoline 打开时没给删除共享，NTFS 改名同样被拒——此路不通。）
- **③ Jev 数据集指纹按原始字节算（隐患，非现行缺陷）**。`decisions/eval.py::dataset_sha256` = `sha256(read_bytes())`，
  锁进 `contracts/jev_thresholds.json`。正常检出全平台 LF（`.gitattributes` `* text=auto eol=lf` 压过本机
  `core.autocrlf=true`；本机实测 raw == LF 归一化 == 锁），但 `gen_jev_eval_sets.py` 用文本模式写——Windows 上重生成即
  CRLF，随后 `compile` 会写进只在那台机器成立的 sha，提交后（git 归一化回 LF）全平台 `check` 报 dataset changed。
  与 v0.35.0 vendor 戳恒红同型。修：哈希前 `\r\n → \n`（LF 内容空操作，已提交的锁仍有效，`jev_eval.py check` 实测 ok）；
  三处提交物写入器改 `newline="\n"`；AGENTS §9 那条「vendor stamps are EOL independent」泛化为所有跨平台文本摘要，并修掉
  该条里 `newline="` 与 `"` 之间误写入的真实换行符（渲染成 `newline=" "`）。
  **自己在这条上的误判也记下**：先用 Git Bash 的 `grep -c $'\r'` 数 CRLF，得出「routing 213 行 CRLF」，其实那是文件总行数
  （命令替换里的 `$'\r'` 没按预期生效）；`git ls-files --eol`（`w/lf`）与字节级 sha 比对才是可信判据。
- **守卫**：`tests/test_runtime_lifecycle.py::test_doctor_names_another_xuanshu_instance_instead_of_calling_it_unidentifiable`；
  `tests/test_runtime_ports_identity.py::test_handshake_decided_foreign_branches_name_their_holders_without_powershell`；
  `tests/test_setup_command.py::test_probe_stderr_diagnosis_recognises_the_windows_file_lock`（英/中文 Windows、.pyd、os error 5
  与无关 stderr 不误认）+ `::test_setup_names_the_windows_file_lock_when_the_probe_dies_on_it`；
  `tests/test_decisions_eval.py::test_dataset_sha256_is_line_ending_agnostic`。
- **本机原生证据**：门禁（`run_ci_gates.py`，worktree 形状）两次 24/24 全绿：修复前 `98ef9ec` 1227 passed、最终代码提交 1229 passed。lane（`verify_runtime_live.py`，公开 v0.39.0 真下载装进 `rt-verify`）install 83 s / start 20 s / 四引擎 / **九客户端全绿（含此前两轮环境性红的 codex）** / HTTP 握手 / 挂客户端不停 / 自动换端口 / live pytest 1297 passed / stop 全过——唯一红是**本轮自己引入的**回归（见下）。用户默认根（`.mcp.json` 用的那一个）v0.30.0 → v0.39.0 用真实命令 `xuanshu-skill upgrade` 升级，桌面端正占着旧清单钉的 8899/9999：`ok`、`stopped_before_swap=False`、`runtime.install_ports_held_elsewhere` 点名 pid 19392 / 7316 的 `XuanshuDesktop\embedded-runtime\…` 映像，两颗进程 pid 与路径前后完全一致——v0.38.1 换目录闸修复（2e6db9c）在最真实形状下的首次原生验证（修前这里是 `install_refused_running_foreign`）。doctor 前后：「被 一个查不出身份的进程 占着」→「被 另一份玄枢实例（horosa-backend；pid 7316 …\XuanshuDesktop\embedded-runtime\——很可能是你开着的玄枢桌面端…）占着」。
- **本轮自己踩的两个坑**：（a）用 Git Bash 的 `grep -c $'\r'` 数 CRLF，得出「routing 213 行 CRLF」并据此断言现行缺陷——其实是文件总行数；`git ls-files --eol`（`w/lf`）与字节级 sha 才是可信判据。（b）给 doctor 摘要加的公开常量起名 `XUANSHU_APP_MARKERS`，撞上约定「`src/` 里的 `XUANSHU_*` 字面量专属环境变量」（`test_config.py::test_env_registry_covers_all_flags_code_reads` 锁着）；定向测试挑不到它，是 lane 的全量 live pytest 抓到的——改为函数 `identity.is_xuanshu_app()`，并 amend 未推送的提交。**法则**：动了 `src/` 就在最终提交上跑全量（门禁或 lane），定向测试只是加速，不是闸
- **法则**：诊断文本要按证据**实际证明了什么**措辞，「没收集」≠「查不出」；Windows 上「运行中的文件不可替换」是一类
  独有失败，遇到先认签名再给人话；跨平台比对的文本摘要一律先归一化换行，写 LF 提交物的脚本一律 `newline="\n"`。

### v0.39.0 / 2026-09-22 — 发布前 CI 红：错误信息双语棘轮抓到新包 28 处 raise；本机只跑了「顺手的守卫」而不是 run_ci_gates.py

- **症状**：bump 0.39.0 推上 main，ci.yml `test` job 在 `verify_error_recovery.py` 一步红：`non-bilingual error messages rose 110 → 138`
  （`decisions/questions.py` 22、`jev_http.py` 3、`eval.py` 2、`layer.py` 1）。推之前本机跑了 docs-sync、六把顺手的 `verify_*`、
  全量 pytest（1234 绿）、npm、preflight——全绿。
- **根因**：新包的 raise 信息全是英文单语。棘轮按「异常类名以 `Error` 结尾 + 字面 message 同时含 CJK 与拉丁」按文件计数，
  没有任何 pytest 用例断言双语，所以本机测试不会红，只有 CI 那一步会。更根本的：AGENTS §6 第 0 条早写着「push 前跑
  `scripts/run_ci_gates.py`」（它解析 ci.yml 的 `test` job 逐步执行），我跑的是自己记得的子集——正是 v0.38.0「本机绿 ≠ CI 绿」的重演。
- **修**：32 处（含 4 处不以 `Error` 结尾、棘轮不计的 `JevResponseInvalid` / `JevUnavailable`）改成「中文 / English」字面双语，英文原句保留
  （没有测试断言 message 文本）。新增包级零容忍守卫 `tests/test_decisions_governance.py::test_every_raise_in_the_decisions_package_is_bilingual`
  （全局棘轮只挡总量上升，别处还债这里新欠也能过；负向对照 `test_bilingual_raise_guard_catches_a_single_language_message`）。
  本次发布改为跑 `run_ci_gates.py` 再推。
- **法则**：**本机门禁只有一个名字：`run_ci_gates.py`，不是「我记得的那几把」**；仓里每一条按文件计数的棘轮（双语信息、
  静默降级、静默空返回、未定义名）都是新代码的 API 契约——新包落地时就按它写，不等 CI 来教。

### v0.39.0 / 2026-09-22 — 决策层（TypeSafe Jev）接入期：护栏只包住了 provider，问题构造漏在外面

- **症状**：S3 门类面第一次跑离线用例，`liureng_gods` 整个变成 `tool.internal_error`——`QuestionSpecError:
  instructions must be English`。决策层号称「失败一律关闭式降级」，可这条异常照样把一次真实起课打死。
- **根因**：`DecisionLayer.ask()` 的 try/except 只包住 `provider.decide()`；问题构造（`build_zhan_question()`）
  在调用 `ask()` 的**参数表达式**里执行，早于任何护栏。而问题规格校验又是我自己刚加的（instructions 禁 CJK），
  自家 instructions 引用了「大六壬」「老婆/妻子」这类必要的中文线索词——规则写死成「零 CJK」是错的，
  抽取面**必须**引用原话线索。
- **guard**：`XuanshuSkillService._decision_guard(surface, fallback, fn)` 把三个面的**整个**决策块（构造 + 调用 +
  采纳）包进去，任何异常 → `_degrade` 进 `envelope.warnings` + 返回确定性结果；负向对照
  `test_a_bug_in_the_decision_surface_degrades_instead_of_failing_the_technique`（monkeypatch 让构造函数抛
  ValueError，技法必须 ok=True 且 warnings 里有「决策层」）。规则改成 `cjk_ratio ≤ 0.30`（英文为主、允许中文线索词），
  `test_question_construction_points_follow_the_house_rules` 逐面锁。
- **法则**：**可选增强的每一行代码都要在同一个降级护栏里**——「provider 失败会降级」不等于「这个面失败会降级」；
  护栏的边界要画在**调用方看得见的最外层**（进入面 / 离开面），不是画在网络 I/O 周围。

### v0.38.1 / 2026-09-15 — install/upgrade 的换目录闸不认 root：别的根的实例占着旧清单的端口就拒装，提示还救不了（Windows 维护机原生复验抓到）

- **症状**：本机按 v0.38.0 起的新角色跑 `verify_runtime_live.py` 复验 v0.38.1（独立 root `rt-verify` + lane 端口
  18899/19999），第 2 步 `install` 就红：`runtime.install_refused_running_foreign`，`details.conflicts` 两端点
  `identity.evidence = identity.app_marker`、`started_by_us = false`、`holders = []`，`force_ignored = true`。
  rt-verify 的旧清单（上一轮按默认端口装的 0.38.0）baked `8899/9999`，而这两个端口被 `%LOCALAPPDATA%\Xuanshu\runtime\current`
  根下的旧实例（v0.30.0，桌面端 / 早前 manager 起的，挂着客户端所以 `stop` 也拒）占着。
- **根因**：`_stop_own_services_before_swap`（v0.38.1 R3「升级就地不砍正在跑的服务」）只看 `started_by_us`，
  **不看持有者跑在哪个根**。可占着端口的两颗进程映像/命令行全在 `%LOCALAPPDATA%` 根——换 rt-verify 的 `current/`
  动不到它们的任何文件，「替换别人在用的 runtime」这个前提根本不成立，它只是**端口被占**。而提示里的
  `XUANSHU_PORTS=auto` 对这形状无效：闸探的是**旧清单**钉的端口，改端口只影响新清单。真实用户形状 = 桌面端开着 +
  之前按默认端口装过（人人如此）→ `install`/`upgrade` 永久拒绝、按提示做也不通。`holders: []` **不是** bug：
  app_marker 路径按设计只「升级不点名」（v0.37.0 那条注释），`port_holders(8899)` 在本机实测能解析出两颗进程。
- **修**：`identity.holders_outside_runtime_root(port, runtime_root)` —— 端口的监听者若**全部**可证明跑在本根之外
  （映像路径 / 命令行都不在本根下，复用 `_holder_evidence`）返回它们，任一住在本根下 / 点不出名 / 没监听者 / 没端口
  → `None`（**永远不把「查不到」当「在别处」**）。闸改成：不是我们起的端点若全部证明在别处 → **放行**、不停任何进程、
  记 `runtime.install_ports_held_elsewhere` 警告（`held_by` 点名 + 正确的 next_action：关那份实例，或给本 runtime 换端口
  再 `start`）；证明不了 → 仍 `install_refused_running_foreign`，`--force` 仍不覆盖。本根自己起的服务仍走停 → 换 → 起。
- **守卫**：`tests/test_runtime_ports_identity.py::test_holders_outside_runtime_root_*`（在别处 / 本根下 / 命令行引用本根 /
  点不出名 / 无监听者 / 无端口）；`tests/test_runtime_manager.py::test_install_proceeds_when_the_busy_ports_belong_to_another_runtime_root`
  （放行 + 警告 + 绝不 stop + current 已换）、`::test_install_still_refuses_when_only_some_busy_ports_are_provably_elsewhere`
  （一个端口证明不了就整体拒）；原 `::test_install_refuses_to_replace_a_runtime_someone_else_is_running` 改为钉住
  「查不到持有者」这一分支。本机原生复现（`scratchpad/repro_swap_gate.py`）：`rt-repro` 根按默认端口装 v0.38.1 →
  再 `--force` 装 → 放行 + `install_ports_held_elsewhere`（`held_by` 点名 pid 141964 / 41580 及其 %LOCALAPPDATA% 映像）、
  `stopped_before_swap=False`、两颗占用进程 pid 前后不变。lane 侧运维解法 = 清掉 rt-verify 的旧 `current/` 与状态
  再跑（无旧清单 → 无闸）。
- **法则**：**「不是我们起的」≠「换目录会伤到它」——闸要问的是「它的文件在不在我要换的根下」**；任何按端口做的
  拒绝，其提示给出的绕行路径必须对触发形状真的有效（这里 `XUANSHU_PORTS=auto` 就不是）。


### v0.38.1 / 2026-09-14 — 复审：自动化的盲区与 Windows 编码（B0 平台 / B1 升级与 doctor / B2 客户端 / B3 矩阵与 CI）

- **起因**：v0.38.0 公开（CI / CodeQL / 三真机矩阵全绿）后再查一遍「任何平台、任何客户端是否顺滑」。三路只读审计 + 九处第三方官方文档核实 +
  每条发现在源码里坐实。结论：主线成立，剩下 6 条 P0、~25 条 P1、~20 条 P2，全部一次做完（用户决定 2026-09-14）。
- **① Windows 编码（P0）**：`procs.process_command` 让 PowerShell 吐文本再按 UTF-8 解，而 Windows PowerShell 5.1 往管道写的是 **OEM 代码页**
  （en-US cp437 / zh-CN cp936）——`C:\Users\张三\…` 回来是 `????` 或 U+FFFD，与 Python 侧 Unicode 路径永不相等，用户名带中文/重音的
  **健康**机器被判 `port_conflict_foreign` / `stop_refused_foreign`。修：归属证据按「不经代码页」排序——ctypes `QueryFullProcessImageNameW`
  的映像路径（新强证据 `process.image_under_runtime_root`）→ PowerShell 只搬 UTF-8 字节的 base64 → tasklist 按 `oem` 解；两份 `.ps1`
  模板首行 `[Console]::OutputEncoding = UTF8`。守卫：`tests/test_subprocess_encoding.py`（AST：`text=True` 无 `encoding=` 基线 0）、
  base64 路径测试 + 旧解法对 OEM 字节得 U+FFFD 的负向对照、模板首行测试；真机证明 = 矩阵 lane 的带空格 + 中文工作目录（R10）。
- **② doctor 最坏 165 s**：每个子进程探针各自 5–15 s，加起来没人管（两端口 × 两地址族的 netstat + 每个持有者一次 PowerShell + node/uv 探针），
  而 MCP 客户端 60 s 掐工具——doctor 恰在最需要它的时候挂。修：`runtime/budget.py`（scope/clamp/timed）+ doctor 25 s / status 15 s 硬顶、
  `ports._run` 2 s memo、Windows 一条裸 `netstat -ano` 同时解析 v4/v6、映像命中就不起 PowerShell、探针并发；`report.budget` 记 timings / skipped。
  顺手：`port_bindable` 双栈（只听 `[::]:port` 的服务此前被当空闲端口发给 XUANSHU_PORTS=auto）；`PAYLOAD_LONGEST_ENTRY_CHARS` 200→180
  （darwin 实测 179，默认根在用户名 ≥ 6 字符时被误报「装不下」）→ `verify_runtime_release.py` 双向闸。
- **③ 升级不停服务（P0）**：`install()` 直接 `replace` + `rmtree(previous)`——Windows WinError 32/5，macOS 旧进程继续从已删路径服务、新载荷
  永远不启动。本机就是活例：已装 0.3.0、doctor 说 ready、从不提示过期。修：换目录前 `endpoint_identities`——全不可达直接换；全部
  `started_by_us` → 先停、换完再起（`stopped_before_swap` / `restarted`）；任一可达但不是我们起的 → `runtime.install_refused_running_foreign`，
  **`--force` 不覆盖**（不杀陌生人是不变量）；previous/ 清理失败分头部（`install_previous_locked`，current 不动）与尾部（warning
  `previous_cleanup_deferred`）。doctor 新字段 `latest_version` / `freshness`（来源 `.latest-manifest-cache.json`，默认只读缓存，零外网不变量保住）
  + warning `runtime:payload_outdated`（版本落后或 `export_registry_version` < `exports.registry` 常量——本机 6 < 14）。
- **④ selfcheck 必红**：`setup` 之后紧跟 `selfcheck`，工具路径只为等 runtime 阻塞 5 s，每个平台都以 `runtime.starting` 退出 1（原审计表述
  「runtime start 报 start_timeout」有误：`start` 早已返回 `starting`）。修：selfcheck 在 managed + 已装 + 不全可达时先全预算 `start_local_services()`；
  仿真宿主（Windows on ARM / Rosetta 进程）的出厂预算 45 → 120 s（矩阵 ARM 实测 59.6 s），显式 env 永远优先。
- **⑤ 客户端细节**：Docker 网关缺 `XUANSHU_CHART_SERVER_ROOT`（chart 族全失败）；README 教裸包名的 `pip install xuanshu-skill`（PyPI 未开通，404）；Zed / VS Code 的
  JSONC 配置让 `--write` 拒写（新 `jsonc.py` 文本级 upsert，注释与其它键逐字节保留）；Cline / Zed 各自 per-server `timeout`（秒，默认 60）
  没写；Codex 不转发 shell 环境——runtime 根只设在 shell 里时 Codex 起的 server 用**另一套目录**（env 表写两个绝对根；**不写 `env_vars`**：
  老版本 deny_unknown_fields 整块拒收）；`.vscode` 用 Claude Code 的占位符是绿的而 `${env:HOME}` 是红的（按客户端白名单，展开后再查
  pyproject）；`runtime.not_installed` 的修复提示默认你有 checkout（`runtime/hints.py` 按 checkout / wheel URL / 插件目录 / MCPB 生成，
  由 `XUANSHU_INSTALL_CONTEXT` + `XUANSHU_PLUGIN_ROOT` 注入）；ChatGPT / claude.ai 连接器只接 OAuth 而本 server 只有静态 Bearer——README 改口
  「经终结 OAuth 的 HTTPS 网关」并给配方，不实现 OAuth 资源服务器（用户决定）；`.agents` 入口指针指向不存在的
  `xuanshu-skill/skills/…`；精简面下 agent 会把「平铺名不在」读成「技法不存在」——六份镜像统一 `xuanshu_tool_run` 段落。
  探针改按客户端形状起 server（Codex = 最小环境 ∪ env 表；cwd = 项目根）并读新资源 `xuanshu://runtime/status` 比对宿主 runtime 根。
  `setup --launcher uvx-wheel` 把 wheel 预下载到 `~/.xuanshu/wheels/`（uv 对直链依赖会按 HTTP 缓存头再验证，离线不保证）。
- **⑥ 自动化的盲区（P0）**：三台真机矩阵**从不走真下载**——两种模式都 `--assets-dir` → file://（2026-09-14 那次 schedule 跑的 lane-report
  里 `install.source` 仍是 `file://…lane-manifest.json`）；每周 cron 的 03:00 槽晚了 5.5 h 才触发（GitHub 整点槽延迟/丢弃）；HTTP 传输、MCPB
  解包、wheel 在 Windows 上、`claude mcp add --scope user`、带空格/中文的路径、升级就地、挂着客户端的 stop、出厂预算——没有任何 lane 跑过。
  修：release/schedule 模式传公开 `--manifest-url`（安装器自己的下载链）+ 结果带 `download{bytes,…}`；cron 移到 04:23 + completeness 的
  `weekly-matrix-kick`；lane 增九客户端 setup、claude-code user scope、streamable-http 握手（401/421/116）、第二个 stdio 客户端挂着时 stop 必拒、
  restart + XUANSHU_PORTS=auto 复用登记表端口、出厂预算启动、带空格 + 中文工作目录；publish job 用 `verify_matrix_digests.py` 比对三条 lane
  装的 sha 与 draft 资产 digest（退路 SHA256SUMS），publish=true 必须 run_matrix=true、skipped 不再放行，翻公开后再 dispatch 一次 release
  模式矩阵；completeness 用资产 digest 校 SHA256SUMS 每一行、断言 `min_os`、解包已发布的 `.mcpb`；`min_os` 由契约进清单，install 下载前拒老系统。
- **横切教训（第三例）**：「本机环境替测试补了一个它没声明的前提」——v0.37.0 是归属判定（本机 9999 上跑着真 runtime），本轮是
  **矩阵 lane 传了 file:// 就以为验过下载**、以及 **stop 的客户端登记只有 RECOVERY_TABLE 里的一条错误码而没有任何代码路径**（`runtime.stop_refused_clients_attached`
  在错误表里躺了一个版本，`stop_local_services` 从没读过登记表）。规则：**一条错误码 / 一个 lane 步骤存在，不等于那条路径被走过**——
  每个「我们验过」都要能指着一份产物（lane-report 的 `download.bytes`、`installed_archive_sha256`、`clients_attached_stop.attached`）。
- **CI 首推抓到 4 条「本机不会红」（2026-09-14 run 34869125562）**：① Linux runner 设着 `XDG_CONFIG_HOME=/home/runner/.config`，C19 起它覆盖
  合成 home → 路径表用例只在 Linux 红（用例改 `env={}`，先在本机 `XDG_CONFIG_HOME=… pytest` 复现出红再改）；② Linux 上 `run_tool` 的第一跳如今是
  `runtime.platform_unsupported`（A9），其 agent_recovery 没提 doctor → `test_operational_errors_carry_agent_recovery` 红（死胡同建议补
  `xuanshu-skill doctor --explain`）；③④ hints 测试把 `Path(root) / "xuanshu-skill"` 写死成 POSIX 斜杠，Windows 上是反斜杠（行为正确，断言按平台拼）。
  ⑤（第二推）R9 让 wheel 路径的 `setup` 真起 stdio——探针跑的是配置里那条 `uvx --from <发布页 wheel URL>`，而 CI 上这个版本**还没发布**
  （uvx：Failed to download …/v0.38.1/…whl），Linux 与 Windows 同红。修：CI 预置 C15 的本地缓存 `~/.xuanshu/wheels/<whl>`（Windows 取
  USERPROFILE），setup 写 `--from <本地 wheel>`，探针离线真起。教训：**「客户端将要执行的命令」在 CI 上必须先问「它指向的东西此刻存在吗」**。
  规则不变：**推送之后看 CI**，五条都是维护机（macOS、无 XDG、能上 github.com 取已发布 wheel）替测试补了前提。
- **⑥ draft 真机矩阵抓到的产品缺陷：Windows 上 runtime 根必须纯 ASCII（三轮真机，每轮揭开一层）**：R10 把 lane 工作目录改成
  「xuanshu 测试 lane」后，两条 Windows lane（windows-latest / windows-11-arm）连红：
  · 第 1 轮（draft，run 34880898270）Java stderr `Unable to access jarfile D:\a\_temp\xuanshu ?? lane\…`——随包 JDK 17 的 java.exe 用
    `GetCommandLineA` 读参数，runner 的 ANSI 代码页 cp1252 表示不了的字符变 `?`。修：jar 参数改为相对 `$Root` 的纯 ASCII `$JarArg`（b4a2f40）。
  · 第 2 轮（draft，run 34885945827）`could not find java.dll`——java.exe 找自己时（`GetModuleFileNameA`）同样丢字，参数怎么改都绕不开。
    修：install 拒绝「ANSI 代码页表示不了」的根（d9e9aa5），lane 的 Windows runtime 根改成 cp1252 能表示的「xuanshu lane é」。
  · 第 3 轮（dry run，run 34888946816）Java 起来了，但 chart 引擎报 `tool.backend_param_error`、29 个 chart 族 live 测试红；chart 服务的
    stderr 是 `KeyError: 'Chiron'`——flatlib 把星历目录（runtime 根下的 swefiles）交给 pyswisseph，pyswisseph 以 **UTF-8** 编码传给 C 的
    `fopen`，而 Windows 的窄字符 fopen 按 ANSI 代码页解字节：**任何**非 ASCII 字符都对不上，哪怕代码页能表示。Chiron 离不开星历文件，
    行星还能靠内置 Moshier 算，于是症状是「部分技法报参数错误」这种误导性的样子。
  所以规则只能是**纯 ASCII**，受影响的真实用户也比第 2 轮以为的多得多：**中文系统（cp936）上的中文用户名同样中招**（Java 能起，星历打不开），
  默认 runtime 根 `C:\Users\张三\AppData\Local\Xuanshu\runtime` 就是这个形状——而维护者的机器、此前所有 lane 都是 ASCII 路径。
  定稿（与长路径同一套路：先检测、早拒绝、给确切修法）：`manager.windows_runtime_path_ok`（纯 ASCII）→ install 在读清单 / 下载之前
  `runtime.path_not_ascii`（修法 `setx XUANSHU_RUNTIME_ROOT C:\xuanshu`，agent_recovery.must_ask_user），doctor issue
  `windows:runtime_root_not_ascii`，`doctor.windows` 带 `ansi_code_page` / `runtime_root_ascii` / `path_fix`；相对 `$JarArg` 保留。
  lane：Windows runtime 根改为纯 ASCII 带空格的「xuanshu lane runtime」，中文留在工作目录（数据目录 / 客户端配置 / 日志）；Windows 专属步骤
  `non_ascii_root_refusal` 在真 cp1252 主机上走一次真 CLI，断言中文根被拒（d9e9aa5 的 windows-smoke 意外先证明了一次）。
  没做的：自动把 runtime 挪到 ASCII 位置（ProgramData / junction）——对中文用户名这一大类用户会更顺，但那是新的 ACL / 抢注 / DLL 植入面，留给维护者决定。
  教训：**只在「维护者自己的机器形状」上验过的路径，等于没验**；**修一层就宣布修好，要等真机把下一层也跑过**——第 1、2 轮的修法 commit
  都写着「真机证明 = 下一次 draft」，下一次正是推翻它的那一次；以及**「代码页能表示」不是安全判据，原生库各有各的字节约定**。
  同一批跑还抓到 lane 自己的 bug：Windows venv 的 python.exe 是 launcher，`serve` 登记的是子进程 pid，按 Popen pid 找客户端必然落空（本机实跑 lane 时先修掉）。
- **⑦ 发布期（2026-09-14）：一次公开；publish job 里两条从没跑过的路径，先在真 draft 上修掉**：
  · 过程：tag v0.38.1 在 draft 期间重指两次（draft 矩阵抓到 Windows 缺陷 → 修 → 删 tag 重打 → seed / .mcpb / wheel 从新 commit 重建；终版 tag → 4ac8a1b）
    → dry run 34893385857（4ac8a1b，三 lane 绿，windows-latest live pytest 1210 passed、零 KeyError）→ `sync_windows_release.py --check --tag v0.38.1 --draft` [OK]
    → `release-runtime.yml -f publish=true -f run_matrix=true`（run 34900145215，b23d49b）：派生 Windows 半 → assemble → 三 lane 绿 → publish job：
    `verify_matrix_digests` 三条 lane 装的归档 = release 资产 digest（darwin b02592a6… / 两条 Windows 2c3b8cbf…）→ draft [OK] → 翻 latest（22:13:03Z）
    → dispatch completeness（34902977795 绿：SBOM、`.mcpb` 解包且 server.json sha = ebdaff83、wheel 零安装报 0.38.1、清单带 min_os、digest 对 SHA256SUMS）
    → 公开 latest [OK] → dispatch release 模式矩阵（34902982361 绿：三 lane 都经公开清单 URL 真 HTTPS 下载——darwin 737083959 B / 11.6 s、
    windows-latest 723171811 B / 45.4 s、windows-11-arm 723171811 B / 19.0 s，均 1 次、未走镜像；已装归档 sha = 公开 digest；HTTP 探针 116 个工具；
    两条 Windows lane 的 `non_ascii_root_refusal` 用真 CLI 拒掉中文根；ARM 仿真起 runtime 60.7 s）。
  · 新知 ①：`GET repos/{owner}/{repo}/releases/tags/{tag}` 对 **draft 返回 404**。R5 字节一致性闸的第一版就用它——第一次真跑必红。
    是在 dispatch publish 之前、拿真 lane 产物 + 真 draft 资产把闸预跑一遍才发现的（a2eedff：列表端点 + `--paginate` + 按 tag 选）。
  · 新知 ②：job 级 `permissions:` **整块替换** workflow 级。publish job 只声明了 `contents: write`，而翻公开后的两条 `gh workflow run` 需要
    `actions: write`——这两步是 v0.38.0 公开之后才加的，从没真跑过（0af3a60）。本次两条后续 run 的 triggering actor 都是 `github-actions[bot]`，路径已证。
  · 顺带：同一 commit 的推送起了两条 CI（34893379906 / 34893381989），门禁读最新那条，它的 OpenClaw smoke 超时（见 ⑧）→ `gh run rerun --failed` 绿。
    21:35Z 的 scheduled completeness 红在 mcpb sha（main 已回填 v0.38.1 的 ebdaff83，公开的仍是 v0.38.0 的 7bb5b63e）——「回填先于公开」窗口里的预期红，翻公开后自愈。
  教训：**publish job 的每一步，在它第一次改变公开状态之前，都要先对真 draft 跑过一次**——shape 测试锁得住「写成了什么样」，锁不住「GitHub 对这个输入怎么回应」。
- **⑧ 发布后自查抓到的三条（2026-09-14，公开之后）**：
  · **一条随 v0.38.1 出货的 NameError**：`cli._friendly_runtime_error_payload` 的 `runtime.platform_unsupported` 分支（1aefdd2，B0 A9/A10）读
    `(details or {})`，而函数里根本没有 `details` 这个名字——Linux / Intel Mac 上 `client openclaw-setup` / `openclaw-check` 本该打印网关出路，
    实际是一段 traceback。没有任何测试、lane、维护机（darwin-arm64）走过那一行：它只在「我们不发载荷的平台」上可达。
    抓法是对全树跑一遍 pyflakes 的 F821（顺带抓出 `astro_sidereal.py` 两处 `Any` 未导入——在 `from __future__ import annotations` 下运行时无害）。
    修：分支读 `exc.details`；回归测试（负向对照：旧代码 `NameError: name 'details' is not defined`）；新闸 `scripts/verify_undefined_names.py`
    （`ruff==0.16.7` 钉死为 dev 依赖，只选 F821/F822/F823 这三条「运行时必崩」规则、不选风格规则，src/scripts/tests 基线 0，`--self-test`
    用同形状的合成模块证明能抓；对已出货源码跑出 3 条 = 负向对照），接 ci.yml test job（`run_ci_gates.py` 自动镜像）。修复在 main，要随下一版才到用户手里。
  · **Windows CI 的 OpenClaw smoke 偶发超时**（run 34893381989 第 1 次尝试；同 commit 的另一条重复 CI 绿，`--failed` 重跑绿）：
    `npx mcporter call xuanshu.xuanshu_knowledge_registry` 撞 150 s，而截获的 stdout **已经是完整的工具结果**，stderr 是
    `npm warn exec … will be installed: mcporter@0.9.0`。正常形态：整个 setup 142 s（install 19 s / start 17.5 s / smoke 103 s 覆盖 ≥ 3 次调用）。
    两个候选原因从日志里**分不开**：① npx 首次安装算进了这一次调用的预算（mcporter 依赖 rolldown，其 Windows 原生绑定 24 MB）；
    ② 结果打印后进程没退出——mcporter 自己的 `docs/hang-debug.md` 描述的正是这个症状，并点名「子 MCP server 拖住 stdio」；TS SDK 起 server 时
    stderr 是 inherit，而 SDK 的 `close()` 有界（stdin.end → 2 s → SIGTERM → 2 s → SIGKILL）、mcporter 之后强制 exit，所以真拖住调用方管道的只能是
    server 的后代进程。本轮不下没证据的结论，只把两条路都变成可判：`_run_openclaw_smoke_check` 在 mcporter 走 npx 兜底时先 `npx mcporter --version`
    （独立 300 s 预算）；超时详情新增 `output_complete`（并修掉 POSIX 上 `TimeoutExpired.stdout` 是 bytes 被旧代码丢成 "" 的问题），友好提示分
    「npx 下载超时 / 结果完整但没退出（给 `MCPORTER_DEBUG_HANG=1`）/ 没回来」三种；新 `tests/test_stdio_server_exit.py` 用真子进程（不带
    `--skip-runtime-start`，预热线程照跑）握手 + 真调一次工具 + 关 stdin，断言 15 s 内退出（负向对照：注入一个非 daemon 的 sleep 线程 →
    「still running 45.0s」红）——Linux 与 Windows 的 CI 都跑。孤儿 `serve` 不是小事：它一直登记为 attached client，`runtime stop` / 升级会拒。
    没做：CI 里设 `MCPORTER_DEBUG_HANG=1`——mcporter 0.9.0 的 debug 分支在 dump 后立刻 `process.exit(0)`，Windows 管道上可能截断 stdout，等于亲手造一个新 flake。
    下一次再超时：预热之后 `output_complete: true` = 退出期挂起，`false` = 调用本身慢。
    **修后 CI 实测（de7d3c3，run 34905947666）**：windows-latest 上 `npx_warmup_seconds` = **127.8 s**——光是 npx 首次安装 mcporter 就逼近旧的
    150 s 单次调用预算；预热之后几次工具调用合计约 13 s（smoke 共 141.2 s），随后 `openclaw-check` 的预热 1.1 s（已缓存）。原因 ① 足以单独解释
    那次超时；② 没有被排除，但已不需要它来解释。所以「分不开」的那一跑，靠的是把阶段拆开后的下一跑来回答。
  · **本机误跑 lane 暴露的隐患**：自查时按计划文件里的 `for g in scripts/verify_*.py` 把全部脚本裸跑了一遍——`verify_runtime_live.py` 于是在本机
    以默认参数真起了一条 lane（临时目录、非默认端口，隔离本身没问题），在 install 下载到 689 MB 时被发现并中止、临时目录清掉；没走到 start 与客户端
    步骤，`~/.claude.json` 与 Codex 配置的 mtime 都早于这次运行。顺着看代码发现真正的坑：Claude Code user scope 步骤**继承真 HOME**——维护机上
    `claude` 在 PATH 时，`claude mcp add --scope user` 写维护者自己的 `~/.claude.json`，清理 `claude mcp remove --scope user xuanshu` 还会删掉维护者
    **原有的** xuanshu 条目；托管 runner 没有 `claude`，矩阵永远只走「打印命令」分支。（此前本机跑 lane 靠「把 claude 从 PATH 拿掉」这条口头注意。）
    修：该步骤的 setup / get / remove 全部用 `claude_user_scope_env()`（`HOME` / `USERPROFILE` / `CLAUDE_CONFIG_DIR` → `<work>/claude-user-home`）；
    测试断言三次调用的这三个变量都落在 lane 工作目录内（负向对照：旧代码不传 env → 继承真 HOME）；并在本机用真 `claude` 以唯一名字的探针验过：
    add / get / remove 全落在隔离目录，真 `~/.claude.json` 的 sha256 前后不变。`verify_matrix_digests.py` 裸跑 exit 2（需 publish job 的输入）是预期。
  教训：**只在没人跑的平台上可达的分支，就是没测过的代码**——对「运行时必崩」这一类错误用静态检查兜底，别指望 pytest 走到；
  **带着完整输出的超时是证据不是噪声**：先把证据留全（bytes 也要解码），再按阶段拆预算，让下一次失败自己说出是哪一段。
  **靠口头注意维持的隔离不算隔离**（「本机跑 lane 先把 claude 拿出 PATH」）——写进代码并用真二进制验一次；门禁的本机镜像只有 `run_ci_gates.py`。
- **守卫清单（本轮新增）**：`test_subprocess_encoding`、`test_runtime_procs_encoding`（OEM 负向对照）、`test_runtime_ports_cache`（netstat 1 vs 4）、
  `verify_runtime_release` 双向长度闸、`verify_wheel_contents` 主目录路径闸、`test_scripts_stdio`、`verify_client_configs` 覆盖 `.cursor/.vscode`
  （白名单与 cli 锁步）、docs-sync 五闸（PyPI 命令 / 连接器行 / 入口文档指针 / 镜像计数 / 示例配置无裸 uv）、`verify_matrix_digests`、
  `verify_mcpb_manifest --bundle`、`test_release_pipeline_shape` +6（旧写法 `--assets-dir "` / 整点 cron / skipped 放行 必红）、R7 本地 HTTP e2e、
  R14 挂着客户端不停、R3 顺序 `["stop","swap","start"]`（旧 `["swap"]`）、R11 顺序 `["start","run_tool"]`（旧 `["run_tool"]`）；发布后：`verify_undefined_names`（F821 基线 0）、`test_stdio_server_exit`（关 stdin 15 s 内退出）、npx 预热与 `output_complete` 四条 cli 测试、lane 的 Claude Code user scope 隔离测试。
### v0.38.0 / 2026-09-14 — 反向的「本机绿≠CI绿」：Windows 维护机红、CI 绿——两条测试没声明对本机环境的暗含前提

- **症状**：v0.38.0 公开后在本机复验，`scripts/run_ci_gates.py`（ci.yml `test` job 的本机镜像）与真机 lane 的
  live pytest 各撞到同一批红，而 GitHub 的 `test`（ubuntu）/`windows-smoke` 全绿：
  ① `test_resolve_uvx_command_derives_from_the_uv_sibling`——断言「无 uvx 时从 `uv` 兄弟推导出 `uvx`」，但只
  monkeypatch 了 `shutil.which`，没挡住 `_windows_uvx_fallbacks()` 扫真实安装目录。本机三处目录
  （`%LOCALAPPDATA%\Programs\uv`、`%APPDATA%\…\Scripts`、`%USERPROFILE%\.local\bin`）里真装着 uvx，fallback 先
  命中，压根走不到兄弟推导那支 → 拿到真 `uvx.exe` 路径而非 tmp 桩。ubuntu `test` job 只因 `os.name != "nt"` 整条
  fallback 被跳过才绿——**托管 windows-latest lane 同样会红，只要那台装了 uvx**。
  ② `test_runtime_launcher_patch` 三条 spawn `bash` 校验补丁脚本的用例偶发 `WinError 2`（bash 找不到），而 bash
  就在 PATH 上：本机同时跑着第二套 pytest + runtime lane（进程 churn + Defender 扫描）时，裸名 `"bash"` 的
  `CreateProcess` PATH 搜索输给竞态。孤立跑一直绿、清场后整套也绿（`envsentinel` 全程 spawn 探针零失败）——是
  **并发满载下的 flake**，不是有序污染；`test_setup_command::test_stdio_probe_*`（真 spawn `uv run … serve`）同族偶发。
- **根因**：都是横切教训 #7「维护机的环境会替测试补上它没声明的前提」的**镜像**——这次是维护机环境**破坏**了测试
  的暗含前提（本机装了 uvx / 本机被自己另一套跑满）。两台 CI runner 恰好满足前提（无 uvx 的 ubuntu / 空载）于是绿，
  维护机不满足于是红；真机 lane 的 live pytest 是唯一同时踩到两者的地方。
- **guard**：① uvx 测试 `monkeypatch.setattr(client_tools, "_windows_uvx_fallbacks", list)`——把已装目录扫描清零，
  强制走它命名的兄弟推导路径（任何平台都对，posix 上本就不调该函数）；② 三条 bash 用例导入期
  `BASH = shutil.which("bash")` 解析一次绝对路径再 spawn（跳过每次调用的 PATH 搜索 = 消掉竞态），bash 缺席即模块
  skip。**`run_ci_gates.py` 本身是这批的 meta-guard**：它在本机按 ci.yml `test` job 形状把每条门禁原样跑一遍，正是
  它把这两条从「只有真机 lane 才撞见」提前到本机每次可复现。
- **法则**：**测试 spawn 系统工具（bash/uv/…）一律导入期解析成绝对路径，别用裸名**——满负载 Windows 的 PATH 搜索
  会偶发 `WinError 2`；**扫真实安装目录的解析器，其测试必须把那层 monkeypatch 掉**，否则测的是「这台机器装没装该
  工具」；**复验时一次只跑一套重活**，否则把自己制造的并发 flake 当成产品缺陷去追。

### v0.38.0 / 2026-09-11 — A6 首次托管发布：v0.38.0 双平台一次公开；两条发布期新知（GITHUB_TOKEN 的 release 事件不触发下游、publish 会再派生一次）

- **过程**：CI 绿（6987a3e）→ `git tag v0.38.0` → `publish_release.sh --draft --dispatch`（seed 737 MB + .mcpb + wheel + SBOM 上 draft；
  run 34572343136：build-windows 5 min 派生、assemble 双平台清单 + attestation、三 lane 真机全绿）→ `sync_windows_release.py --check
  --tag v0.38.0 --draft` **[OK] complete** → `gh workflow run release-runtime.yml -f version=0.38.0 -f publish=true`（run 34574921999，
  再跑一遍派生 + 三 lane，publish job 先 `--check --tag --draft` 再 `gh release edit --draft=false --latest`）→ 公开 `--check` [OK]，
  `releases/latest/download/runtime-manifest.json` 列 darwin-arm64 + win32-x64（URL 钉 v0.38.0、带 size），
  `uvx --from <wheel URL> xuanshu-skill --version` = 0.38.0，`gh attestation verify` 对清单与 seed 归档 exit 0。
  「缺半」窗口首次为零：Windows 用户从公开的第一秒起就有自己的半边。
- **新知 ①**：用 `GITHUB_TOKEN` 做的 `gh release edit --draft=false` 产生的 `release: published` 事件**不触发任何 workflow**
  （GitHub 防递归规则）——`release-completeness.yml` 与 `publish-pypi.yml` 都没跑。`workflow_dispatch` 是明文例外，所以 publish job
  现在自己 `gh workflow run release-completeness.yml`；PyPI 通道开通后也要在 publish job 里显式 dispatch（或用 PAT）。本次手动
  dispatch 了 completeness（绿）。
- **新知 ②**：`publish=true` 那一跑会**再派生一次** Windows 半（zip 字节不同：723171512 → 723171643，时间戳所致），清单 / SHA256SUMS /
  attestation 在同一跑里同步重生成，所以自洽；但 draft 上的第一份 zip 被 --clobber 覆盖、第一次的 attestation 作废。可接受，
  但更好的形状是 publish 跑复用 draft 上已验证的资产（后续项，记在 memory）。
- **新知 ③（发布后追到）**：`.mcpb` 打包**不可复现**——`--draft` 那一轮重打的包字节不同，上传的是它，而 `server.json` 里提交的
  `fileSha256` 还是前一次 no-upload 构建回填的值（a06dbc1d… vs 发布上的 7bb5b63e…），注册表客户端装前校验必失败。修：把发布
  上那份的 sha 提交回 main；守卫：`release-completeness.yml` 下载发布上的 mcpb 算 sha 与 main 的 `server.json` 对齐（≥ 0.37.0）。
  规则：**sha 回填只能来自真正上传的那一次构建**，`--draft` 之后必须 `git diff server.json` 并提交。
- **法则**：**公开的判据只有 `--check` 的 [OK]**（本次两次都 [OK]）；**下游 workflow 不要指望 release 事件，publish 侧显式 dispatch**。

### v0.38.0 / 2026-09-11 — 主干 CI 红了 19 个 commit 没人看：本机门禁全绿 ≠ CI 绿；Windows checkout 与 macOS runner 各有一套「本机不会红」

- **症状**：v0.38.0 专项从 B0（87da8ec）起每次推送都跑了本机全量 pytest + docs-sync 才提交，但 GitHub CI 的 `test` 与
  `windows-smoke` **连续 19 个 commit 全红**，直到 A5 dry run #3 在真机 lane 上跑 live pytest 才撞见同一批失败，回头查
  `gh run list` 才发现。四类根因，全部是「本机不会红」的形状：
  ① `tests/test_tracked_text_is_lf.py`（B0 加的 CR 守卫）读**工作树**字节——Windows runner 的 checkout 把文本写成 CRLF：
  本机的 `.gitattributes`（`* text=auto eol=lf`）**从来没进过仓库**（0d98f4b 把它当「本地 IDE 配置」一起 gitignore 了），
  GitHub 的 Windows checkout 只有 Git for Windows 的 autocrlf，守卫从加上那天起在 Windows 上就没绿过，而 mac 上永远绿；
  ② `test_client_config_locations_darwin_and_linux_shapes` 用 `str(Path).endswith(".config/zed/settings.json")`——Windows 上
  `str(Path)` 是反斜杠；③ `test_quarantined_binaries…` 用只有 `{"version"}` 的假归档，manifest 默认路径按**宿主 OS** 解析
  （Windows 上 `runtime/windows/*`）→ 文件全缺、quarantine 一个都没查；④ `test_rosetta_python_still_gets_the_arm64_payload`
  只 monkeypatch 了 `sys.platform`，`native_machine()` 先看 `os.name`。另：托管 macOS 26 runner 的 `netstat -anv` 把别的进程的
  监听 socket 打成 `CLOSED`（本机打 `LISTEN`），`_listener_pids_darwin` 只认 `LISTEN` → 「端口上明明有监听进程，却一个持有者都
  查不出来」（A5 lane 两条红）。
- **guard**：① `.gitattributes` 改为跟踪（它是仓库策略不是本地状态），CR 守卫改读 **git 索引 blob**（`git ls-files -s` 的 sha
  喂 `git cat-file --batch`；`cat-file --batch` 不认 `:<path>`）——守的是提交内容，不是 checkout 写出来的字节，且断言
  `.gitattributes` 已被跟踪并含 `eol=lf`；
  ② 路径断言用 `Path.as_posix()`；③ 假归档 manifest 显式写全 `runtimes`/`artifacts` 路径（`test_setup_command._fake_archive`）；
  ④ 测试同时钉 `os.name`；⑤ `ports._darwin_listener_line`：外端地址 `*.*` 才是监听的签名，状态列不可信（负向对照：CLOSED 行必须
  被认出、已连接行必须被排除）。⑥ **机器闸**：`preflight_release.py` 新增 CI 闸——`gh run list --commit <HEAD>` 的 ci.yml 结论
  必须 success（红 / 未跑 / 进行中都阻断；`gh` 缺席只警告）；`publish_release.sh --draft` 同样先查。
- **同一轮又追到两条**：⑤ CI 的 `test` job 跑 `verify_error_recovery.py`（双语消息棘轮），本机从没跑过它——`_assert_min_os`
  与 uvx 缺席两条新消息是英文单语，110 → 112 就红（修：`errors.bilingual`；根治：`scripts/run_ci_gates.py` 把 ci.yml `test` job
  的 23 条门禁原样在本机跑，`test_guard_wiring` 锁它覆盖每条单行 verify_*）；⑥ windows-smoke 的 qimen `tool run --stdin` 载荷没带
  `agent_confirmed_settings`，B0 让 step 诚实之后它一直被闸门拒（exit 2）——之前几十轮是被 pwsh 吞掉的；修完又撞 pwsh
  `ConvertFrom-Json` 默认大小写不敏感（信封里 `xunKong` / `xunkong` 并存直接抛错）→ `-AsHashtable` + `['key']` 取值。
- **法则**：**推送之后看 CI 结论，红了先修再继续**——本机全绿只证明「在维护机上绿」；**新守卫要在三种 runner（ubuntu /
  windows / macos）的形状下都想一遍**：路径分隔符、行尾、宿主 OS 决定的默认值、系统工具的输出差异。

### v0.38.0 / 2026-09-11 — A5 首跑抓到的产品缺陷：非默认端口下 `runtime stop` 永远停不掉（停脚本拿的是裸 os.environ）

- **症状**：本机跑 `verify_runtime_live.py`（`XUANSHU_LOCAL_BACKEND_PORT=19999` / `XUANSHU_LOCAL_CHART_PORT=18899`）：install / doctor /
  start / 四引擎 / 四客户端 setup 全绿，`runtime stop` 退出 0、结果 `ok: false`、状态卡 `stop_requested`，两个端口照样在听——
  Java 与 Python 服务留在机器上（本次按 PID 手动清掉）。
- **根因**：上游停脚本按 **端口命名的 pid 文件** 找进程（`.xuanshu_py.<CHART_PORT>.pid` / `.xuanshu_java.<BACKEND_PORT>.pid`，
  `CHART_PORT="${HOROSA_CHART_PORT:-8899}"`）。启动路径给启动器传了 `HOROSA_SERVER_PORT` / `HOROSA_CHART_PORT`，停路径却传裸
  `os.environ` → 停脚本去找 8899 / 9999 的 pid 文件 → "not running (pid file missing)" → 什么都没杀。v0.37.0 的
  `runtime stop` 测试全是 stub 脚本，端口一致性从没被断言；默认端口下两边恰好一致，所以维护机上永远绿——
  `XUANSHU_PORTS=auto`、显式改端口、矩阵 lane 三种真实用法全中招。
- **guard**：`manager._launcher_env()` 单一来源（端口 + HOME 族），start 与 stop 都用它；
  `tests/test_runtime_manager.py::test_stop_passes_the_same_ports_as_start_to_the_stop_script`（旧代码必红）；
  `verify_runtime_live.py` 的 stop 步骤给 60 s 宽限后仍要求端口释放、状态清空，并把 stop 的原始结果带进 lane 报告。
- **法则**：**起与停必须同源同环境**（端口、HOME、身份口令以外的一切），谁改启动器 env 就同一 change 改停脚本 env；
  只用 stub 测过的生命周期操作，在真机 lane 上跑一遍才算数。

### v0.38.0 / 2026-09-11 — A5 托管流水线 + 真机矩阵：「CI 起不了 runtime」是旧时代的规则，发布从此 draft → 派生 → 三台真机 → [OK] 才公开

- **症状**：① 发布靠 `publish_darwin_release.sh --publish` 先发一个 darwin-only 清单的**公开** release，Windows 半由构建机人肉补传——
  中间那段时间每一次 Windows install 都 404，「缺半」台账记了六个版本；② `release.yml` 挂 `runs-on: self-hosted` 而仓库从未注册过
  runner，20 次 tag 触发排队 24 h 后被取消、零 step 执行，attestation / SBOM 都是纸面覆盖；③ 「CI 起不了 runtime」写进 AGENTS §7 的
  年代只有 Linux runner，如今 macos-latest（arm64）/ windows-latest / windows-11-arm 都是现成的真机，但从未有一条流水线在它们上
  装过、起过、调过 runtime——发布是否真的能装能跑，只在维护者一台 Mac 上成立过。
- **guard**：① `scripts/publish_release.sh`（改名自 publish_darwin_release.sh）：无参只构建校验；`--draft` 把 seed / .mcpb / wheel / SBOM
  放上 **draft** release，**永不上清单、永不建公开 release**（`--publish` 已删除并报错指路）；`--dispatch` 触发流水线并 `gh run watch`。
  ② `.github/workflows/release-runtime.yml`（仅 dispatch，owner 守卫，并发组按版本）：`resolve`（draft 上必须有 seed；非 dry run
  的 release 必须仍是 draft）→ `build-windows`（windows-latest 缓存钉版本工具链，`build_runtime_release_windows.py --seed`）→
  `assemble`（`verify_runtime_python_lock --seed`、`generate_release_manifest --url-base <tag>`、SHA256SUMS、SBOM、
  `verify_runtime_release --expect-platforms darwin-arm64,win32-x64`，artifact `runtime-release-assets`，非 dry run 才上 draft +
  `attest-build-provenance`）→ `matrix`（workflow_call）→ `publish`（`inputs.publish && !dry_run && matrix 绿或跳过`：
  `sync_windows_release.py --check --tag vX --draft` 必 [OK] → `gh release edit --draft=false --latest` → 再 `--check`）。
  ③ `.github/workflows/runtime-matrix.yml`（workflow_call + dispatch + 每周一对公开 latest；**绝不挂 push/PR**）三 lane：
  macos-latest→darwin-arm64、windows-latest→win32-x64、windows-11-arm→win32-arm64（装 win32-x64，x64 CPython 让依赖全有 wheel、
  也正是用户 x64 Python 的形态）；ARM lane `continue-on-error: ${{ inputs.arm_nonblocking != false }}`；失败也上传 lane 报告 /
  doctor 快照 / launcher.log / `.xuanshu-local-logs`。④ `scripts/verify_runtime_live.py`（纯 Python 驱动 CLI 子进程，JSON + 退出码）：
  `--assets-dir` 把清单 URL 本地化成 file://（draft / dry run 时 tag URL 还不存在，但 ARM 回退仍走清单路径）→ install（断言
  `platform` / `platform_fallback` 与 lane 期望一致）→ doctor（installed / platform_supported / payload_platform / emulated / files）→
  `runtime start` + 轮询 doctor（issues==[]、双端点可达、**chart-only 降级即失败**）→ chart / qimen / nongli_time / bazi_birth
  （ok、段非空、`missing_selected_sections==[]`、`technique_card.compute.matches_declaration`）→ `setup --client` 四客户端（写配置 →
  回读 → 真 stdio 探测）→ live pytest（`XUANSHU_*_SERVER_ROOT` / `XUANSHU_NODE_BIN` 指向已装 runtime，`-rs` 输出里闸门 skip 理由
  不得出现）→ `runtime stop`（端口释放、状态清空）；纯函数由 `tests/test_verify_runtime_live.py` 负向对照。⑤ 形状锁
  `tests/test_release_pipeline_shape.py`（只手动触发 / 不 `gh release create` / publish 必 needs matrix 且先 [OK] / 矩阵不挂 push /
  三 runner / ARM 由输入控制 / 旧 release.yml 与 publish_darwin_release.sh 不复活）；`test_guard_wiring.RUNNERS` 收录两条新
  workflow 与 publish_release.sh（`verify_runtime_live.py` 由矩阵调用，不再是孤儿守卫）。
- **首次 dry run（run 34562626963）抓到**：`build-windows` 死在 `.venv\Scripts\python.exe: No module named pip`——uv 的 venv
  **没有 pip**，`fetch_native_wheels` 默认用 `sys.executable -m pip download`。修法：`runtime_seed.resolve_pip_python()` 依次试
  显式 `--python` / 本解释器 / `sys.base_prefix` 的解释器（setup-python、uv-managed CPython 都带 pip）/ PATH 上的 python3|python，
  以 `-m pip --version` 为准；workflow 显式传 `--python "$env:pythonLocation\python.exe"`；`test_resolve_pip_python_skips_interpreters_without_pip`。
  另：job 级 `env:` 不能引用 `runner.temp`（dispatch 时解析即报错），只能在 step 里用 `$RUNNER_TEMP`。
- **第二次 dry run（run 34563086660）——三台真机全部装起跑通**：build-windows 5 min 派生出 Windows 半、assemble 过双平台清单 +
  verifier；macos-latest / windows-latest / **windows-11-arm（x64 仿真）** 三 lane 都 install → doctor → start → 四引擎 → 四客户端
  `setup`（真 stdio 探测 116/11/11/116 工具）→ stop 全绿，只剩 live pytest 步骤与报告打印四处 verifier 自己的错：① doctor 的
  `endpoints[*].url` 带探测路径（`…/common/time`），verifier 原样导出成 `XUANSHU_SERVER_ROOT` → 闸门探 `…/common/time/nongli/time`
  404 → `java_routes_dead`，Java 明明活着的 lane 把全部 Java 族 live 用例 skip 掉（修：`origin_of()` 只取 scheme://host:port）；
  ② Windows 控制台 cp1252 编不了报告里的中文，`print(json)` 在全部步骤通过之后炸（修：`sys.stdout.reconfigure(utf-8)` +
  job env `PYTHONIOENCODING`/`PYTHONUTF8`）；③ upload-artifact 在 Windows 上拒绝 `runner.temp` + `~` 混合根（"rootDirectory … is not
  a parent directory"），证据一份都没传上来（修：verifier 把 launcher.log 与服务日志拷进 `<lane>/logs/`，上传只给一个根）；
  ④ macOS lane 的 `test_runtime_ports_identity` 两条红：满负载下 `netstat -anv` 超过 `_run` 的 5 s → 空串 → 「查不到持有者」
  （修：15 s + 用例耐心重试 + 失败信息带诊断）。另把 lane 的 runtime 端口改为非默认 19999/18899（维护者 live 配方同款；
  默认端口上跑真服务会让假定端口空闲的离线用例误红——AGENTS §8 早有这条）。
- **dry run #4（run 34568103210，2026-09-11）全绿**：三 lane 各 install → doctor → start → chart/qimen/nongli_time/bazi_birth →
  `setup` ×4（stdio 探测 116/11/11/116）→ live pytest **1025 passed / 0 failed / 14 skipped**（无闸门 skip）→ stop；
  windows-11-arm 装的是 win32-x64（`platform_fallback.mode = x64-emulation`，doctor `emulated: true`），全程 19 min。ARM lane 随即
  转阻断（`arm_nonblocking` 默认 false）。
- **法则**：**清单只在两平台齐了才上 release**；**发布前的真机证据由流水线产出，不由「维护者机器上跑过」代替**；「CI 做不到 X」
  这类规则要写清时代前提，runner 变了就要重审。

### v0.38.0 / 2026-09-11 — B6 doctor 的机器条件：码没有人话、长路径与磁盘预检从没测过、quarantine 没人查、「不上外网」只是口头承诺

- **症状**：① doctor 的 issue / warning 码只是字符串（`services:not_running`、`missing:boot_jar`…），agent 与脚本用户拿到码就原样甩给
  用户；② `_guard_windows_long_paths` 只在 Windows 真机上才走到、`_require_install_disk_space` 只在磁盘真满时才走到——两者零测试，
  而安装临时目录 `.xuanshu-install-XXXXXXXX/extract/` 白吃 20 个字符（最深载荷条目本身已近 200，260 上限下这 20 个字符就是装得上 /
  装不上的差别）；③ macOS 上浏览器下载的归档解出来的 python / java / node 带 `com.apple.quarantine`，首次执行被 Gatekeeper 拦下，症状是
  「起不来 + 无日志」，doctor 一个字不提；④ x64 Python 在 ARM 芯片 / Rosetta 下跑，用户不知道自己在仿真里；⑤ 下载读超时 120 s、
  每镜像 3 次写死，慢网 / 企业代理下只能反复 `install`；⑥ 「doctor 不上外网」没有守卫。
- **guard**：① `manager.DOCTOR_ISSUE_CODES`（`missing:*` 前缀族）+ `cli._DOCTOR_WARNING_CODES` + `cli._DOCTOR_ADVICE` 逐码
  `user_summary` / `next_action`，报告新增 `advice[]`；`doctor --explain` 把 6–10 行人话写 **stderr**（stdout 仍纯 JSON）；
  `test_every_doctor_code_has_advice` 锁步，`test_issue_codes_in_source_are_all_registered` 扫 `doctor()` 源码里的
  `issues.append("…")` 字面量与 `f"missing:…"` 前缀（新码不登记必红）。② 临时目录改 `.hi-XXXXXXXX/x/`（常量 `_INSTALL_TEMP_PREFIX` /
  `_INSTALL_EXTRACT_DIRNAME` / `_INSTALL_TEMP_OVERHEAD`），doctor 新增 `windows{long_paths_enabled, runtime_root_length,
  projected_deepest_path, headroom_chars, ok, fix}` 按同一常量估；`_guard_windows_long_paths` 首个测试（注册表关 + 深条目 →
  `runtime.install_long_path`；开 / 短条目 = 负向对照）；磁盘预检五组参数化（有 size 4×、无 size 3 GB、坏 size 回落）。
  ③ `_quarantine_report`：`xattr -p com.apple.quarantine` 查 python / java / node，flagged → issue `quarantine:runtime_binaries` +
  `quarantine.fix = xattr -dr …`，只报不改（非 macOS / 未装 = 空）。④ `platform:emulated_process` warning（`arch.emulated`）。
  ⑤ `XUANSHU_RUNTIME_DOWNLOAD_TIMEOUT_SECONDS` / `XUANSHU_RUNTIME_DOWNLOAD_ATTEMPTS` 进 `ENV_FLAG_REGISTRY` + `FIELD_ENV_MAP`
  （provenance），`_download_with_resume` 读 settings（测试：2 次 × 1 源 = 2 个 Client、read=300）。⑥ `doctor --probe-network`
  （默认关）逐镜像 HEAD 清单 URL（`stop_at_first_success=False`，每个镜像都报）；负向对照：默认路径把 `_probe_manifest_url` 换成
  raise 仍绿。
- **法则**：**每个诊断码都要有人话，且人话与码在同一处登记**；**只在真机才走到的分支必须有测试**（负向对照让它真红一次）；
  **doctor 只报不改**——修复命令交给用户，且默认不碰外网。

### v0.38.0 / 2026-09-10 — B5 面向 agent 的文档：没有 MCP 的 agent 没有契约、四家客户端打开仓库第一眼看不到规则、SKILL 里抄的命令没人核对

- **症状**：① SKILL.md 全篇按 MCP 工具名写，shell-only agent（CI bot、`codex exec` 无 MCP、只会跑命令的工具）不知道
  `tool run --input/--output`、退出码、闸门在 stderr 里长什么样，Windows PowerShell 5.1 走管道还会把中文重编码；② Gemini CLI /
  Copilot / Windsurf / Cline 各自先读自己的文件（`GEMINI.md`、`.github/copilot-instructions.md`、`.windsurf/rules/`、`.clinerules/`），
  仓里一份都没有——这些 agent 在看到 SKILL.md 之前就已经开始「帮」用户手算；③ 文档里抄给 agent 的 `xuanshu-skill …` 命令与
  `--flag` 没有任何守卫核对（B0 才发现 ci.yml 里调了三十几轮不存在的 `--output`），agent 拿到 Typer usage 报错会判定「工具坏了」
  （issue #5 的模式）；④ Codex 排障表没有「先跑 `client check`」这一步，Windows 特有的反斜杠 TOML、绝对路径、无头 `codex exec`
  的 `defaults_accepted` 边界都没写。
- **guard**：① SKILL.md 新增「Shell-only agents (no MCP)」（命令表 + 载荷文件 + 退出码 0/2 语义 + 闸门流程 + 信封键）与
  「First 3 commands on a fresh machine」（macOS zsh / Windows PowerShell / 源码 checkout 三块，各三条命令，钉版本 wheel URL 由
  `check_pinned_install_commands` 锁）；`.agents` Codex 镜像同一契约。② 四份薄镜像各 ≤ 30 行：指向 SKILL.md + 禁手算 + 闸门
  （`agent_guidance.required` → `agent_confirmed_settings`）+ 只读 `export_snapshot` + `setup --client <x>`；
  `verify_docs_sync.check_agent_mirrors` 锁存在 / 行数 / 指针 / 四个关键词，四份也进 `COUNT_DOCS`（负向：105 必红、31 行必红、
  缺关键词必红、缺文件必红）。③ `tests/test_skill_shell_contract.py`：两节里每条 `xuanshu-skill …` 逐 token 对到 Click 命令树
  （子命令存在、`--flag` 在 `opts ∪ secondary_opts`）；负向 `--nope` / 未知子命令 / 只写到命令组必红；路径里的 `…/xuanshu-skill &&`
  不算命令。④ `examples/clients/codex.md`：排障先跑 `client check --client codex`（五个问题码逐行对应）+ 新「Windows」节；
  windows-smoke 新增 codex 形状 TOML 生成 → `client check` → tomllib 断言 120/600 与绝对路径 `uv.exe`。
- **法则**：**文档里给 agent 抄的每条命令都要有守卫对到真实 CLI**；**每个客户端先读的那份文件里必须有闸门**，哪怕只有
  十行——策略仍只在 SKILL.md 一处，镜像只许指针 + 三个关键词。

### v0.38.0 / 2026-09-10 — B4 一条命令接入：接入曾是四条命令 + 手粘配置，而且没有任何一处验证「客户端将要执行的那条命令真能起 server」

- **症状**：① README 的接入路径是 `install` → `client config` → 手动粘进客户端文件 → 重启客户端 → 在客户端里发现没有工具
  → 再来 `client check`；issue #14 直说「安装说明对 AI agent 不够友好」，issue #18 的「一堆报错」是超时没写；② `client config`
  只打印建议、`client check` 只看文件、进程内 MCP 测试绕开 spawn——绝对路径对不对、uvx 缓存能不能建、Windows 上 spawn 走不走得通，
  三者都只有用户在客户端里失败时才知道；③ 零安装用户（wheel 装出来的包旁边没有 pyproject.toml）跑 `client config --launcher uvx-wheel`
  直接 BadParameter：生成器不分启动器一律先 `_resolve_skill_root`；④ 网络不通的机器要等 120 s 下载超时才知道装不了。
- **guard**：① `xuanshu-skill setup --client <target>`，七步固定并逐步记录 `steps.<name>`：`network_probe`（HEAD 清单 URL 走镜像，5 s，
  失败立刻报 `setup.network_unreachable` 并给三条出路）→ `install`（版本短路即幂等）→ `config`（自动定位 + `_merge_client_config`
  安全合并；claude-code 在 CWD 有 `.mcp.json` / `--scope project` 时写项目文件，否则 `claude` 在 PATH 就执行 `claude mcp add --scope user`
  并记 `rollback`，不在 PATH 只打印命令）→ `doctor`（与 `doctor` 命令共用 `_doctor_report`；`--skip-install`/`--dry-run` 下只报不拦）→
  `client_check`（回读**磁盘上**的条目，共用 `_client_check_report`）→ `stdio_probe`（用 `mcp` 客户端真 spawn 配置里那条命令 +
  `--skip-runtime-start`，断言工具数 = 该客户端工具面；顺带焐热 uvx 缓存）→ `next_steps`（各客户端重启话术 + 一句试用提示 +
  `selfcheck` + doctor 的 warnings）。② 失败包写 stderr、退出码 2：`step` / `code` / `config_untouched` / `backup_path` /
  `retry_command`（探针失败时自动带 `--no-probe-network`）；`tests/test_setup_command.py` 锁「第 3 步之前失败用户配置一个字节不动」
  （负向：装失败时预置文件逐字节相等）、dry-run 零副作用、幂等（第二次写出逐字节相同 + `.xuanshu-bak`）、Intel/mirror/uvx-wheel
  启动器、claude-code 三种 scope（真调 `_claude_mcp_add` 的替身记录命令）、真 stdio 探测数出 11 个工具、stderr 尾巴随失败包。
  ③ `_build_client_config_payload` 只在 `uv` 启动器与 mcporter/openclaw 形态下解析 checkout；`_default_setup_launcher`：checkout 内
  `uv`，否则 `uvx-wheel`；ci.yml 的 wheel 步骤真跑 `uvx --from <wheel> xuanshu-skill setup --dry-run` 断言 `launcher.kind == uvx-wheel`，
  windows-smoke 真跑 `setup --client cursor --skip-install`（写配置 → 回读 → Windows 上真 spawn → 11 个工具）。④ 输出契约冻结在
  `tests/test_cli_output_contract.py::test_setup_public_keys`；doctor 多一个 `environment.probes.uv`（MCPB 的 `server.type: "uv"` 靠它）。
- **法则**：**接入的终点是「客户端将要执行的那条命令真起了 server」，不是「配置文件写好了」**；每一步都要能单独失败、失败要说清
  动了什么没动什么（`config_untouched` / `backup_path`）；进程内测试证明不了 spawn，真 spawn 才算。

### v0.38.0 / 2026-09-10 — A4 安装侧平台策略：Windows ARM 自动装 x64 载荷（公告、不静默），Intel Mac 照旧拒绝，`min_os` 真有人查

- **症状**：① `install()` 只拿本机键去清单里查，查不到就 `runtime.install_missing_platform`——Windows on ARM 被判死刑，
  而 A0 探针已证明 x64 Temurin 17 / Node 22 / 嵌入式 CPython 3.12 在 Windows 11 的 x64 仿真下全能跑；② A2 派生载荷写进
  `platform_requirements{arch, min_os}` 与 `derived_from`，但 `_normalize_manifest_data` 只认识它列过的键，装完这两块就没了——
  `min_os` 写了等于没写，doctor 也看不到载荷来历；③ `_platform_key()` 在 Rosetta 下的 x86_64 Python 报 `darwin-x64`，Apple Silicon
  用户装了个 Intel 版 Python（旧 Homebrew / conda）就被送去「Intel Mac 走网关」——可载荷自带解释器，宿主 Python 是什么架构根本无关；
  ④ `cli._platform_supported` 把 `{"darwin-arm64","win32-x64"}` 写死在第二处，契约改了它不会跟。
- **guard**：① `manager.SUPPORTED_PAYLOAD_PLATFORMS` / `PLATFORM_FALLBACKS = {"win32-arm64": ("win32-x64", "x64-emulation")}`，
  `tests/test_runtime_platform_fallback.py::test_installer_constants_match_the_release_platform_contract` 与
  `contracts/release_platforms.json` 锁步（wheel 不带 contracts，所以必须复制一份并锁）；`install()` 目标键缺席而有回退 → 装回退，
  结果带 `platform_fallback{requested, installed, mode}` + `warnings[{code: runtime.platform_emulated}]`，版本短路那条返回也带
  （setup 重跑 install 时不能丢公告）；**darwin-x64 永不回退**（负向对照：清单里同时有 arm64 与 x64 包，Intel Mac 仍必须
  `install_missing_platform` 且 `current/` 不存在）；② `_normalize_manifest_data` 原样带过 `platform_requirements` / `derived_from`；
  `_assert_min_os` 在下载前查清单条目的 `min_os`、解压后再查载荷自己的 `platform_requirements.min_os`，低于则
  `runtime.install_os_too_old`（读不到宿主版本不拦）；③ `_platform_key()`：darwin 下 x86_64 + `sysctl.proc_translated == 1` → `darwin-arm64`；
  Windows 下 `PROCESSOR_ARCHITEW6432` 优先；新 `process_machine()` / `native_machine()`（`IsWow64Process2` → env → Rosetta）→ doctor
  `arch{process, native, emulated}`，另有 `host_platform / payload_platform / emulated / platform_requirements` 四个顶层键；
  ④ `_platform_supported` 改读常量；`_platform_dead_end_advice` 的 win32-arm64 文案改成「连 win32-x64 都缺 = 发布不完整」。
  负向对照三组（清空回退表 / 剥掉透传 / 关掉 min_os 检查）各让 5 / 3 / 3 个用例变红后才算守卫成立。
- **法则**：**回退只许公告着做**——结果与 doctor 都要说出「本机是什么、装的是什么、为什么能跑」；**载荷自带解释器，平台键看芯片不看宿主
  Python**；**载荷说了要求就得有人在装之前查**，不然「有 min_os 字段」只是装饰。

### v0.38.0 / 2026-09-10 — A3 发布契约：清单钉 tag、带 size、按契约逐平台判完整，别再靠「两个键都在」

- **症状**：① 清单里的资产 URL 一直是 `releases/latest/download/...`——pin-forward（清单指着上一版的包）从清单本身看不出来，
  只有 `sync_windows_release.py --check` 拿资产名去对才抓得到；② 清单没有 `size`，安装侧 `_require_install_disk_space` 早就读
  `asset_meta["size"]`，读不到就退到写死的 3 GiB；③ `release-completeness.yml` 与 `sync_windows_release.py` 各自写死「darwin-arm64 +
  win32-x64 两个键都在」，平台一变两处都要改；④ README 的平台表只有四行，Windows ARM 走仿真这件事没地方写、也没人锁。
- **guard**：① `generate_release_manifest.py --url-base https://github.com/<repo>/releases/download/v<ver>`（钉 tag）+ 每条 `size`；
  `publish_darwin_release.sh` 与 `sync_windows_release.py` 的构建路径都改用它；② `verify_runtime_release.py`：`size` 须为正整数且等于
  归档真实字节数、`--expect-platforms` 断言键集**恰好**相等；③ `release-completeness.yml` 先 checkout，期望平台集 = `contracts/
  release_platforms.json` 里 `since ≤ 版本` 的键，逐平台 HEAD 200、`size == Content-Length`、URL 钉的 tag == latest tag（`latest/download`
  形式接受但不推荐）、`SHA256SUMS.txt` 列全每个归档；④ `sync_windows_release.py`：`assess_from(tag, assets, manifest)` 纯函数按契约逐平台
  判（归档在场 / 在清单 / URL tag 一致），wheel 自 0.38.0 起必需，`gaps()` 把缺项点名成 `[GAP: …]`，新 `--tag vX --draft` 让流水线在
  publish 前对 draft 判完整；⑤ `verify_docs_sync.check_platform_table`：README×2 平台表必须给契约里每个平台/别名/不支持项一行
  （负向对照：删掉 Windows ARM 行必红）；README×2 加 Windows ARM 行、Intel Mac 行写明「本轮不做 x86_64 载荷」。
- **法则**：**清单要自证**——URL 钉 tag、带 size，判完整不需要第二个信息源；**平台集只写一处（契约），守卫与文档都从它派生**。

### v0.38.0 / 2026-09-10 — A2 Windows 半边从「只有构建机能产」变成「从 darwin 种子派生」

- **症状**：Windows 载荷的唯一产地是维护者的 Windows 机（`vendor/runtime-source/runtime/windows/bundle/wheels` 与 `prepareruntime`
  只在那台机器上），于是 v0.37.0 的代码推了 main 却没法 tag——空 tag 会让 `releases/latest` 指向没有资产的 release，所有新安装 404
  （本仓「缺半」台账的老形状）；preflight 的「打包输入」闸在 mac 上恒红，只能降级成警告。
- **根因**：Windows 构建器把「平台无关的树」（Horosa-Web 子集、jar、core-js）和「平台原生件」（JDK/Node/嵌入式 Python/19 个原生
  wheel）混在同一条 vendor 输入链里；而前者在已通过 live 全套的 darwin-arm64 归档里本来就有。
- **guard**：`build_runtime_release_windows.py --seed <darwin tar.gz>`：`verify_seed`（复用发布闸）→ `materialize_seed` → 逐字节复制
  Horosa-Web/core-js/jar、换上仓内 `.ps1` 模板（BOM 原样）→ 钉版本 Temurin JDK（sha 校验）jlink 到与 mac 相同的 17 模块（非 Windows
  主机用 host jlink 交叉链接，`--full-jdk` 兜底）→ 钉版本嵌入式 CPython 3.12.10（此前 3.11.9；与种子共用 cp312 wheel）→ 纯 dist 按
  RECORD 逐文件复制 + 原生 wheel `pip download`（pyswisseph/sxtwl 在目标 runner 上 `pip wheel` 从 sdist 编）→ 钉版本 Node →
  **`assert_binary_arch`** 对 python.exe/java.exe/node.exe/numpy .pyd 断言 x86_64 → `derive_manifest`（只继承种子的版本与注册表常量，
  带 `platform_requirements{arch, min_os}` 与 `derived_from`）→ zip。`--skip-sdist-builds` 只给非 Windows 主机做干跑，产物带 `-DRYRUN`
  后缀不可能被误当发布资产。`verify_runtime_release.py` 新增 `_assert_native_arch`（两平台都查：Windows 三个 exe + numpy .pyd 必须
  x86_64、mac java/node + numpy .so 必须含 arm64）；`verify_builder_parity.py` 加「Windows 构建器必须有 seed 模式且经 `verify_seed(` /
  `derive_manifest(`」与「jlink 模块表 = `contracts/runtime_toolchain.json`」；`verify_vendor_runtime_sources.py` 去掉 `runtime/windows` 与
  `prepareruntime`，preflight 那一闸回到硬闸；`package_runtime_payload.sh` 删掉半接线的 x64 分支。`tests/test_windows_derive_mode.py`
  用合成种子 + 假工具链 zip 走完 staging → 发布闸四项全过；负向对照：ARM64 的 java.exe 在 staging 就被拒、混进归档也被 verifier 抓。
- **实测**：本 Mac 从 v0.36.0 种子交叉派生（`--skip-sdist-builds`）：713 MB 的 `-DRYRUN.zip`，jlink 交叉链接成功——前提是 host jlink
  与目标同大版本（PATH 上的 `/usr/bin/jlink` 是 22，报 `jlink version 22.0 does not match target java.base version 17.0`，
  `host_jlink(major)` 现在按 `--version` 选 vendored Zulu 17 的那把），`verify_runtime_release.py` 条目/内嵌清单/BOM/架构四闸全过，
  site-packages 93 个 dist-info（76 纯 + 17 有 wheel 的原生；pyswisseph/sxtwl 留给 Windows runner 编）。
- **法则**：**平台无关的树只有一个产地（种子），平台原生件只从钉死的工具链与锁取**；**派生出来的每个原生二进制都要按目标架构断言**；
  「只有某台机器能产出的发布输入」是一种缺半等待发生。

### v0.38.0 / 2026-09-10 — A0/A1 托管派生的地基：种子即真值、依赖集是种子的纯函数；探针推翻了「靠版本号拉 wheel 就够」

- **A0 探针（runner-probe 34555801257，四 runner 全绿）**：`windows-latest` x64 剩 32 GB；`windows-11-arm`（Windows 11 Enterprise，
  ARM64，剩 121 GB）上 **x64 Temurin 17.0.20.1 `java -version` 1.39 s、x64 Node 22 与 x64 嵌入式 Python 3.12 都能跑**——win32-arm64
  走 x64 仿真有了证据；`macos-latest` 是 macOS 26.6.2 arm64、Rosetta 在；`ubuntu-latest` 剩 86 GB。另一条要紧的：x64 Python 在
  ARM64 Windows 上 `platform.machine()` 报 **ARM64**（读 `PROCESSOR_ARCHITEW6432`），所以 `_platform_key()` 天然得到
  `win32-arm64`，回退逻辑可直接按这个键做（A4）。
- **A0 wheel 探针（`gen_runtime_python_lock.py --check-index`）**：v0.36.0 种子的 site-packages = 76 纯 + 19 原生 dist（python 3.12）；
  19 个里 17 个在 PyPI 有 `cp312 win_amd64` wheel，**`pyswisseph==2.10.3.2` 只到 cp311、`sxtwl==2.0.6` 只到 cp310**（两家都没有
  cp312 的 Windows wheel，mac x86_64 亦然）——现在的 Windows 载荷（Python 3.11.9）之所以有 sxtwl，是构建机自己从 sdist 编的。
  托管派生因此必须在 `windows-latest` 上用 MSVC 从 sdist 构建这两个包（`pip wheel --no-binary :all:`），锁里以 `wheel_sources[平台][包]
  = "sdist"` 记明。第一次写 `pip download --dry-run` 全 MISS——pip 25 的 `download` 根本没有 `--dry-run`（只有 `install` 有）；改用
  PyPI JSON API 看 wheel 文件名，零下载、零 pip 依赖。
- **A1 落地**：`contracts/runtime_python_lock.json`（由种子生成：pure 逐字节复制、native 同版本重拉、`excluded` 带理由、`wheel_sources`、
  `platform_overrides` 必须在本台账有记）、`contracts/upstream_python_requirements.txt`（xuanshu-engine `scripts/requirements/mac-python.txt`
  逐字副本 + pin sha 头，`sync_vendored_runtime_sources.sh` 同步刷新——注意上游是浮动版本号，种子里 numpy 2.4.6 对上游 `==2.4.2`，
  所以**锁的真值是种子不是 requirements**）、`contracts/runtime_toolchain.json`（Temurin `jdk-17.0.20.1+1` x64 zip sha、Python 嵌入包
  3.12.10 sha、Node 22.23.2 sha、jlink 模块表单一来源、各 runner 事实）、`contracts/release_platforms.json`（darwin-arm64 since 0.9.0、
  win32-x64 since 0.9.1、别名 win32-arm64→win32-x64 x64-emulation、darwin-x64/linux 明确不支持 + 理由）、`scripts/runtime_seed.py`
  （`verify_seed` 复用发布闸的 REQUIRED_ENTRIES / 内嵌清单检查；`materialize_seed` 按 sha 缓存解压；`derive_manifest` 只继承不 stamp；
  `copy_platform_tree`；`copy_pure_site_packages` 按 RECORD 逐文件；`fetch_native_wheels` 有 wheel 就 `pip download`、`sdist` 就 `pip wheel`；
  `assert_binary_arch` 认 Mach-O thin/fat、PE、ELF）、`scripts/verify_runtime_python_lock.py`（入 ci.yml）。
- **guard**：`tests/test_runtime_seed.py`（负向：缺 `kin_year_domain.py` 的种子必拒、版本不符必拒、arm64 Mach-O / ARM64 PE 断言 x64 必红、
  缺 `export_registry_version` 的种子清单不派生）；`tests/test_runtime_python_lock.py`（scipy/plotly 进锁必红、上游新名字未分类必红、
  override 无台账必红、缺 wheel 判定必红）；`tests/test_release_platforms_contract.py`。
- **法则**：**派生只从通过发布闸的种子开始；依赖集 = 种子的 dist 集（版本一致），不跑解析器、不新增任何包**；**「有 wheel」要逐包查
  PyPI 证明，没有的就在目标 runner 上编，并把判定写进锁**；**`@dataclass` + `from __future__ import annotations` 的模块不能靠
  `spec_from_file_location` 裸加载**（dataclasses 要在 `sys.modules` 里找到它）——被 importlib 加载的脚本用普通类。

### v0.38.0 / 2026-09-10 — B3 零安装绑着 git 与 github.com:443；钉版本的安装命令没人锁

- **症状**：PyPI 暂缓（用户决定）后，唯一的零安装命令是 `uvx --from "git+https://github.com/…@v<ver>#subdirectory=xuanshu-skill"`：
  它要求用户机器**有 git**（README 从没写过这个前置）**并且**能直连 github.com 做 clone——issue #14 的机器正是
  `github.com:443` 不通、`api.github.com` 通；把 repo 链接交给 Claude Code / Codex 自动安装的人在这一步就卡死。
  另外 README / SKILL / server.json 里所有钉版本的 URL / git ref（`@v0.37.0`、`/v0.37.0/…mcpb`）只靠人手改，
  `verify_docs_sync.check_versions` 只走 JSON 的 `version` 键，字符串里的版本没人看。
- **根因**：分发只想过「源码 checkout」与「PyPI」两条路；镜像开关 `XUANSHU_RUNTIME_MIRROR` 只给 runtime 归档用，
  没延伸到「拿到 Python 包本身」这一步；受限网络的做法散落在 README 排障表一行里。
- **guard**：① 发布脚本第 [5/8] 步 `uv build --wheel` 产出 `xuanshu_skill-<ver>-py3-none-any.whl` 并随资产上传、进
  SHA256SUMS；`release-completeness.yml` 对 ≥ 0.38.0 的 latest 断言资产在场**并真跑** `uvx --from <URL> xuanshu-skill --version`；
  `ci.yml` 用本 checkout 构建的 wheel 走 `file://` 跑同一条。② `runtime/mirrors.py::mirror_candidates / preferred_mirror_url`
  （manager 委托）——同一个 `XUANSHU_RUNTIME_MIRROR` 同时改写清单、归档与 wheel URL；`client config --launcher uvx-wheel`
  生成镜像优先、钉版本的 `--from` URL，产物 `launcher{wheel_url, alternatives, pinned_version, install_hint, refresh_hint}`。
  ③ `client check` 认 `--from …whl`（不再当成「PyPI 未开通」），钉的版本 ≠ 本包版本报 `launcher_version_drift`。
  ④ `verify_docs_sync.check_pinned_install_commands`：README×2 / SKILL×2 / server.json / examples 里每个 `@v<x>#`、
  `/v<x>/xuanshu_skill-<x>-py3-none-any.whl`、`/v<x>/xuanshu-skill-<x>.mcpb` 必须等于包版本（负向对照 `v0.0.1` 必红；
  `<!-- docs-sync:ignore-version -->` 冻结历史行）。⑤ 新文档 `docs/INSTALL_RESTRICTED_NETWORK.md`（中英）：镜像前缀 /
  API 直链 + `install --archive` / U 盘离线搬运 / 代理与企业证书 / 错误码表；README×2 首屏改「零安装（无需 git、无需 PyPI）」。
- **法则**：**分发的每一条路都要在「没有 git、没有 github.com」的机器上成立一次**；**钉了版本的字符串就是版本号，
  由 docs-sync 锁，不由人记**；**受限网络的做法要成文，不能只活在排障表的一行里**。

### v0.38.0 / 2026-09-10 — B2 客户端接入：`--write` 会清空 VS Code/Zed 的 settings、裸 `uvx` 在 GUI 客户端里找不到、Windows 上 `client check` 一家都找不到、Codex 缺省超时不报

- **症状**：① `client config --write` 只认 `mcpServers` 根键——VS Code 产物没有可合并块、Zed 是 `context_servers`、claude-code
  只有一条命令字符串，这三家 `--write <用户的 settings.json>` 走到「整文件写入」分支：用户的主题、别的 server 全没了，文件里
  还多了 `note`/`tool_surface` 这些说明字段；JSON 目标不备份、`write_text` 非原子。② `--launcher uvx|uvx-git` 生成裸字符串
  `"uvx"`：Claude Desktop / Cursor / VS Code 在 Windows 上 spawn 子进程时**不继承 shell PATH**，终端里能跑的 `uvx` 在客户端里就是
  file not found，而 `uv` 那条早就走 `resolve_uv_command` 写绝对路径了。③ `_CLIENT_CONFIG_PATHS` 是一张 POSIX 路径表，Windows 上
  cursor/vscode/gemini/windsurf/cline/zed 一个都找不到，`client check` 只会说「还没配」。④ Codex 审计只在 `startup_timeout_sec` /
  `tool_timeout_sec` **写了且太短**时才报；没写（= 默认 10 s / 60 s）静默通过——issue #18「一堆报错」最像的成因。
- **根因**：合并逻辑按「多数客户端」写死了根键；路径解析只做了 uv 一条；配置路径表按维护者的 mac 写；审计只覆盖了「写错」
  没覆盖「没写」。四条都是「在维护者的 mac 上永远绿」的形状。
- **guard**：① `_merge_client_config`：按产物根键（`mcpServers`/`servers`/`context_servers`）只合并 `<root>[<name>]`、写前
  `.xuanshu-bak`、临时文件 + `os.replace` 原子替换、非对象/非法 JSON 拒写、没有 server 块的说明产物拒写；vscode 产物补 `servers`
  块（`type: stdio`）、claude-code 产物补 `mcpServers` 块；`tests/test_client_config.py`：zed 的 `theme` 必须保留（旧代码即负向
  对照）、`os.replace` 失败原文件完好且无临时文件、写出文件绝不含元键。② `client_tools.resolve_uvx_command`（`XUANSHU_UVX_BIN`
  → PATH `uvx.exe|uvx.cmd|uvx` → Windows 安装目录 → `uv` 同目录推导），三种 uvx 启动器都写绝对路径，找不到时保留裸名并在产物
  `warnings` 里说明；`client check` 新码 `command_not_on_path`（裸名且 `which` 找不到；绝对路径不查）。不需要 `cmd /c`：uv 发的
  是真 exe，只有 `.cmd` shim 才需要 shell。③ `_client_config_locations(client, os_name, env, home, cwd)` 纯函数：Windows 走
  `%APPDATA%`（Claude/Code/Zed）、mac 走 `~/Library/Application Support`、linux 走 `~/.config`；`client config` 的 `config_path`
  改为真实定位（第一个存在的候选，否则全局级候选）；跨平台形状测试用 `C:\Users\张 三`。④ Codex 审计补 `codex_startup_timeout_missing`
  / `codex_tool_timeout_missing` / `codex_cwd_missing`；Zed 的 `context_servers` 形状按 zed.dev/docs/ai/mcp 核对（直接 `command/args/env`，
  无需 `source` 键）。
- **法则**：**写用户的文件 = 只动自己的那一个键、先备份、原子替换、认不出形状就拒绝**；**写进客户端配置的命令一律绝对路径**（GUI
  客户端没有你的 shell PATH）；**「没写」和「写错」都是审计对象**——默认值不是安全值。

### v0.38.0 / 2026-09-10 — B1 Windows 启动器：用户名带空格就起不来、Java 绑 0.0.0.0、doctor 看不见监听范围

- **症状**：① `start_horosa_local.ps1` 用 `Start-Process -ArgumentList @($PyBootstrapPath)` 与 `"-jar", $JarPath` 起两个服务。
  PowerShell 5.1 把 `-ArgumentList` 的元素用空格拼成命令行**且不加引号**：runtime 根在 `C:\Users\John Doe\…` 时，
  bootstrap 路径被拆成 `C:\Users\John` + `Doe\…`，python 找不到文件退出，java 的 `-jar` 同样断——chart 与 Java 都起不来，
  而这类用户名在 Windows 上极常见。② Java 启动行没有 `--server.address=127.0.0.1`，Spring Boot 默认绑 0.0.0.0：首次启动
  Windows 防火墙弹窗、后端暴露到局域网；mac 启动器（上游）早就钉了回环，只有 Windows 模板漏了。③ bootstrap here-string 用
  `r"$FlatlibRoot"` 这种 raw 字符串嵌路径：尾反斜杠或引号即 SyntaxError（我们的变量目前不会撞上，但那是运气）。④ doctor 只报
  端口通不通，从不报绑在哪个地址上——已装用户升级后模板重拷了，也没人告诉他们要 `runtime restart`。
- **根因**：Windows 模板从没在带空格的 profile 路径上跑过；「路径含空格 / 中文」在测试面是零覆盖（v0.38.0 审计实锤）。
- **guard**：① 路径元素一律 `('"{0}"' -f $Var)` 自带引号，`--key=value` 旗标无空格保持裸；② Java 行加 `"--server.address=127.0.0.1"`；
  ③ here-string 里改 `$(ConvertTo-Json $X -Compress)`——JSON 字符串字面量 ⊂ Python 字符串字面量，任何路径都安全，字面量仍 ASCII-only
  （BOM 那两条守卫不变）；④ `scripts/verify_runtime_scripts.py::audit_windows_launcher`（回环 / 引号 / 裸 `-ArgumentList @($` / raw 嵌入四条）
  + `--self-test` 四种坏法必红（此前 self-test 只在有上游树时才跑，现在 Windows 部分无条件跑），并新增「上游 mac 启动器必须仍钉
  `--server.address=127.0.0.1`」；`tests/test_runtime_launcher_templates.py` 用 `C:\Users\张 三\…` 真渲染 bootstrap → `ast.parse`
  → 桩 `runpy.run_path` 逐字节回传，负向对照 = 旧 raw 写法遇尾反斜杠/引号必 `SyntaxError`；Windows 上再用真 `powershell` 渲染一遍；
  ⑤ mac 侧 `test_runtime_launcher_patch.py`：`-Dhorosa.runtime.root="${ROOT}"` 必须是独立词、`ROOT="/tmp/a b"` 下展开为单个 argv、
  注入的 `xuanshu_owns_pid` 在带空格 ROOT 下认得出自家进程；⑥ `runtime/ports.py::listener_bindings/loopback_only`（win `netstat -ano`
  TCP+TCPv6、mac `netstat -anv`、linux `ss`），doctor 新增 `listener_scope` 与顶层 `warnings[]`，绑非回环 → `listener:not_loopback_only`
  带 fix；查不到 = `None`，绝不当成干净。
- **法则**：**给子进程传路径，每个路径元素自己带引号；写进另一种语言的源码，用那种语言的字面量转义（JSON），不用 raw 字符串赌运气**；
  **两端启动器的网络面必须一致**（回环绑定），差异由守卫抓；**已装用户的修复要靠 doctor 告诉他们**，不是靠 CHANGELOG。

### v0.38.0 / 2026-09-10 — B0 卫生：三处「绿得不真」——pwsh step 吞退出码、计数守卫看措辞、README 否认仓里有的文件

- **症状**：① `ci.yml` 的 Windows smoke 自 v0.30 起就在调 `xuanshu-skill tool run qimen --stdin --output …`，而 `--output`
  这个参数直到本批才存在——那一行每次都以 usage error 失败，step 却一直绿：GitHub 的 `pwsh` 把多行 `run:` 当一个脚本跑，
  只拿**最后一条**命令（`memory query`，回 `[]` 退出 0）的退出码当结果。② `.claude-plugin/marketplace.json` 写「97 local
  Xuanshu (玄枢) technique tools」从 97 陈旧到 106，文件明明在 `COUNT_DOCS` 里：`COUNT_PROSE_EN` 只认 `N real …`，`COUNT_PROSE`
  要数字紧挨名词，「local … 20 字后才是 tools」两条都漏。③ README×2 写「仓库暂不提供 Dockerfile」，而
  `xuanshu-skill/Dockerfile` + `docker-compose.yml` 早已入库；且 Dockerfile 只 `COPY pyproject.toml README.md src`，pyproject
  force-include 的 `scripts/runtime_templates/windows` 没拷 → 镜像里 `uv pip install .` 直接失败（与 `.mcpbignore` 那课同型：
  两张清单没人对）。
- **根因**：三条都是「证据的形状由偶然决定」——退出码由 step 里最后一行决定、守卫的覆盖面由句子用了哪个形容词决定、
  文档的真伪由没人去 `ls` 决定。
- **guard**：① step 首行 `$PSNativeCommandUseErrorActionPreference = $true`（pwsh ≥ 7.3；GitHub 已前置
  `$ErrorActionPreference='stop'`），并断言 `--output` 文件存在且 `.ok`；`tests/test_ci_workflow_shape.py` 扫所有 workflow 里
  `shell: pwsh` job 的多行 `run:` 块首个有效行必须是它（负向对照：把那一行换成任何别的都红；bash job 不受管）。`tool run` /
  `dispatch` / `ask` / `hecan` 真有了 `--output`（stdout 仍打印 JSON，`_emit_json`；`tests/test_cli_output_file.py`）。
  ② `COUNT_PROSE_EN` 放宽到 `N (real|local) … tools|techniques`，`test_stale_count_forms_are_caught` 加原句模板。
  ③ `verify_docs_sync.check_docker_claims`（仓里有 Dockerfile 则 README 不得写「暂不提供/No Dockerfile is shipped」且必须提到它）
  + `tests/test_dockerfile_matches_wheel_includes.py`（force-include 的每个源路径都得在某条 `COPY` 之下；负向对照 = 旧 Dockerfile 必红）。
- **法则**：**CI 的绿必须由「每一条命令」背书，不是最后一条**；**计数/真伪守卫的覆盖面写成机器规则，不写成措辞巧合**；
  **仓里有的东西，文档只能描述，不能否认**。另记两条操作教训：改 README 计数不许整文件 `sed s/766/778/`——它把 `0f766e`
  颜色码和 `37.7667` 经度一起改了，必须按行改并 `git diff` 复核；rebase 冲突用脚本重放改动时，脚本必须 `&&` 进 `git add`，
  否则脚本半路断言失败、`rebase --continue` 照样把「只剩对方版本」的文件提交上去。同一轮还发现别的会话把本文件以 **CRLF**
  提交了上来（`.gitattributes` 是 `eol=lf`），并把台账里的字面路径 `current\runtime` 写成了 `current` + **真回车字节** + `untime`——
  用 `read_text()` 一读那行就被拆成两行。本批把文件归一成 LF、修回那条路径，并加 `tests/test_tracked_text_is_lf.py`
  （任何被跟踪的文本文件里出现 `\r` 字节即红；负向对照内置）。

### v0.37.0+ / 2026-09-09 — DETACHED_PROCESS 让 Windows 启动器**从未运行过**；弱证据短路把自家 runtime 判成外人

v0.37.0 把启动器从阻塞 `subprocess.run` 改成分离 `Popen`（为的是别让「首次调用」卡在一次 MCP 请求里，
方向完全正确）。在真 Windows + 真 runtime 上试，两处新代码各有一个只有这台机器能看见的洞。

- 🔴 **`DETACHED_PROCESS` = 无控制台 = `powershell -File` 静默秒退。** 症状：`selfcheck` 报
  `runtime.start_timeout`（还建议「跑 doctor / install」），而 8899/9999 一个没起、`launcher.log`
  **0 字节**、启动器自己的 `.xuanshu-local-logs` 目录都没建 —— 也就是**启动器从未运行**，却被报成
  「没在 45 秒内就绪」。隔离实验（同一条命令、只换 creationflags）：
  | creationflags | 12 秒后 |
  | --- | --- |
  | `DETACHED_PROCESS \| NEW_PROCESS_GROUP` | `poll()==0`、日志 0 字节、服务零 |
  | `NEW_PROCESS_GROUP` 单独 | 仍在跑、服务真起来 |
  | `NEW_PROCESS_GROUP \| CREATE_NO_WINDOW` | 仍在跑、**父进程退出后照旧存活**、chart 起来回 pdSyncRev |
  根因：DETACHED 让子进程完全没有控制台，PowerShell 主机拿不到控制台就直接 exit 0 且**不写一个字节**
  （所以连诊断都没有）。**判据顺带纠一处误导**：插桩实测这条错误是在 **13 秒**抛出的（启动器已退出即
  跳出等待循环），而 details 里写着 `timeout_seconds: 45.0` —— 谁照这个数字去调大预算都白费，
  真问题是「启动器压根没跑」。起不来时先看 `launcher.log` 是否 0 字节 + 启动器自己的
  `.xuanshu-local-logs` 有没有新目录：两者都空 = 没跑，不是慢。而 DETACHED 想要的「活过父进程」在 Windows 上本来就免费 —— 子进程不随父终止。
  fix = 换 `CREATE_NO_WINDOW`（有控制台、只是不弹窗）。修后同一条 `selfcheck` 立刻变成设计意图的
  `runtime.starting` + `retry_after_seconds: 5`，按提示重试即全绿（`doctor issues: []`）。
  guard = `test_windows_launcher_spawn_never_uses_detached_process`（断言 flags：无 DETACHED、有
  CREATE_NO_WINDOW + NEW_PROCESS_GROUP）。
  **法则**：换进程创建方式属于「只有目标平台能验」的改动 —— CI 的 windows-smoke 没装离线 runtime，
  永远走不到 spawn 启动器这一步，所以它全绿不代表这条路通。

- 🔴 **弱证据（app 标记）抢在强证据（命令行）之前 return，`stop` 就停不掉自家 runtime。**
  `classify_endpoint` 第 1 级：对面自报 `app: horosa-chart` 且**没报 nonce** 时直接返回
  `identity.app_marker`。可 `app_marker` 不在 `_STRONG_EVIDENCE` 里 → `started_by_us=False` →
  `stop` 报 `runtime.stop_refused_foreign`。实测：手动跑 payload 自带启动器起的 chart+java
  （命令行明明在 `rt-verify\current\runtime\windows\...` 下）被拒停，用户只能按 PID 手杀，
  或用 `--force`（那把锤子连用户自己的桌面端一起砸）。
  fix = 只允许**升级**：app 标记先记成兜底，让第 2 级（命令行含 runtime 根）/第 3 级（注册表活 pid）
  先说话；**绝不降级为 foreign** —— 对面已自报玄枢协议，判 foreign 会打掉「外部模式：用用户开着的
  桌面端当后端」。实测修后同样两个进程判 `process.command_matches_runtime_root` / `started_by_us=True`，
  `stop` 真正释放了两个端口。guard = 三条 hermetic 测试（命令行升级 / 注册表 pid 升级 / 陌生命令行
  只停在弱 ours 不判 foreign）。
  **法则**：分级证据里，**弱证据一律只能作兜底**，不许早退 —— 早退等于把强证据从判定里删掉。
  副产品：那条既有测试 `test_app_marker_alone_is_usable_but_not_stoppable` 没 mock `listener_pids`，
  会读真机端口；本机 9999 上跑着 runtime 时它才暴露出来（同 mac 侧 9fd0ff4「维护机环境替测试补了
  它没声明的前提」一族）。

- **观察（未修，属状态机的设计决定）**：分离启动后，持久状态**永久停在 `status: "starting"`**。
  写 `"running"` 的只有启动调用内的那一行，而 `starting` 分支已提前返回，服务随后就绪时没有任何
  收敛点。实测：两个端点都可达、`doctor issues: []`（doctor 的健康判定读的是活探针，所以是对的），
  但状态文件与 `runtime status` 的文案仍说「正在启动」。消费方只有 `cli.py` 两处文案（不阻塞
  start/stop），故影响限于「诊断说谎」——与本仓清过两轮的 9999 误诊同族。修点在 mac 侧正在建的
  状态机里（谁负责收敛：doctor / status / 一个后台 reconciler），留给属主定。

### v0.37.0 / 2026-09-09 — 「能被任意 AI 完美调用」：协议面只对着一个客户端调过、连通性从未验证过、端口安全只写在文档里

**触发**：用户要求「全面检查是否还无法被任意 AI 完美调用，尤其是端口占用问题及其他一切因素」。
四路只读审计 + 外部基准（Codex `startup_timeout_sec` 默认 10s / `tool_timeout_sec` 60s；Cursor
全局约 40 工具静默丢弃；VS Code/OpenAI 128；Gemini CLI 工具名 ≤63 且严格 JSON Schema 2020-12；
OpenAI 描述 ≤1024；MCP 2025-11-25；MCPB `manifest_version 0.4`/`type: uv`）。

结论分六条，每条的共同点是：**在我们唯一常用的那个客户端上一切正常，所以从来没人看见。**

#### ① 广告层只对 Claude Code 对过 —— 严格客户端会拒收整张工具表

实测（116 个工具）：70 个属性广告成空对象 `{}`（gpsLat/gpsLon×26 …）、116/116 带**数组** type、
108 个写 `additionalProperties: true`、106 个漏出私有键 `x-xuanshu-hidden-knobs`、8 个门面完全
没被广告层重写。Gemini CLI / Vertex 的 FunctionDeclaration 与 OpenAI strict 见到这些是拒**整张表** ——
症状不是「某个参数不好使」，而是「这个 server 在某某客户端里一个工具都没有」。
根因三处：`_widen` 里一句表达式语句把唯一的类型信息 pop 掉却不补回去；`apply_advertised_schemas`
豁免了 8 个门面（而精简面下门面**就是**全部工具）；`_normalize_mcp_request` 的两条裸 `ValueError`
发生在每个工具的 try **之前**，被 lowlevel server 转成 `isError: true` + 原始字符串。
**守卫**：`scripts/verify_mcp_client_compat.py` + `contracts/mcp_client_compat.json`。

#### ② 仓自己的 `.mcp.json` 从未连通过

仓根 `.mcp.json` 用的是**插件语法**（`${CLAUDE_PLUGIN_ROOT}` / `${user_config.*}`），而它被
Claude Code 当作**项目**配置读 —— 目录不存在、env 值是字面量。本机 24/24 次连接日志（2026-08-21 起，
含发现它的那一次会话）全部 `CONNECTION_CLOSED`。
教训：**「我们自己的仓」不是被验证过的配置**，它只是没人注意到的那一个。
**守卫**：`scripts/verify_client_configs.py`（项目配置不许有插件占位符；`--directory` 去占位符后
必须指向真实的 `pyproject.toml`；插件占位符 ⊆ plugin.json 已声明的键）。

#### ③ 端口与进程：静默采用、误杀、首调卡几分钟、多客户端竞态

- `_service_status` 的全部判据是「HTTP 响应码 < 500」，于是 8899/9999 上**任何**应答者都算
  「runtime 已在运行」：用户自己开着的玄枢桌面端、另一个项目的 dev server、一个
  `python -m http.server`。症状不是「连不上」，而是**排盘失败但 statusCode 200**。
- 「能用它」与「能停它」被混为一谈：只有 app 标记的服务照样会被停脚本按端口关掉。
- 启动器自己阻塞到就绪或 STARTUP_TIMEOUT（首次含解压 + CDS 训练，300–900 秒），而我们用
  `subprocess.run` 等它 —— 全发生在**一次 MCP 请求内**。Codex 的 tool_timeout_sec 默认 60 秒。
- `self._service_lock` 只是进程内锁：两个客户端同时冷启动会各起一个启动器，后到的看见
  「pid files already exist」就先 stop 再 start，把先到的那个刚起好的服务停掉。
- macOS 启动脚本的 `reclaim_stale_port` 按命令行子串 `kill -9`（stop 脚本与 Windows 脚本都有
  ROOT 守卫，唯独 mac start 没有）。**注意**：已装的 v0.36.0 载荷里没有这段（它是 lsof 后拒绝），
  危险构造只在更新的上游树里 —— 属于**潜伏**而非在线缺陷，补丁器因此设计成「有危险构造才打、
  没有就一字不改」。
**守卫**：`runtime/{identity,ports,procs,pidlock,registry}.py` + `tests/test_runtime_ports_identity.py`
+ `scripts/verify_runtime_scripts.py`（含 `--self-test` 负向对照）。

#### ④ 回环探测走用户代理

shell 层早就绕过了代理，Python 层没跟上。Clash / VPN 用户把 127.0.0.1 也塞进代理时，
后端明明健康却报 `not_running`。同一台机器上 A/B 对拍 `doctor` 证实。
**守卫**：`engine/client.py::loopback_httpx_client` + `tests/test_client_proxy_bypass.py`。

#### ⑤ 杂目录的真根因不是「没修过」

仓里三个 `${env:HOME:-${sys:user.home}}/.xuanshu-logs/…` 目录（仓根 / xuanshu-skill/ /
vendor/runtime-source/）。已装 runtime **早就修好了**（安装时补丁 jar 内 log4j2.xml）；漏网的是
dev 用的 `start_vendored_instance.sh` 直接跑**未补丁**的 vendored jar。
`-Dbasedir=` 覆盖不了它 —— `<Property>` 在配置里已定义，系统属性只在未定义时兜底。
**守卫**：`scripts/verify_no_stray_runtime_dirs.py`。

#### ⑥ 假债务与真债务：四处工具计数互不相同

marketplace 说 97、instructions 说 106、契约基线 115、实际 116。一致性守卫在「五处写成同一个
假数字」时是绿的 —— 所以计数必须**派生**，不能各写各的。

---

### 本轮的横切教训（比上面任何一条都更值得记住）

1. **「在我们的客户端上好用」不是「可用」的证据。** 上面六条里有五条在 Claude Code 上完全正常。
   要证明跨客户端可用，必须按**别人的**约束去测：工具数上限、schema 严格度、描述长度、
   超时默认值、Host 头、传输名拼写。

2. **测试可以「因为错误的原因通过」。** 本轮抓到两例：
   - `test_streamable_http_serve_stops_runtime_after_exit` 直接以 Python 函数调用 typer 命令，
     未传的形参拿到的是 **OptionInfo 对象**（恒真），于是它断言的停机分支其实是被
     `bool(OptionInfo)` 打开的，而不是被默认值打开的。→ 新 `cli._opt()` 从源头还原默认值，
     并留一条测试把陷阱本身钉住。
   - `test_start_runtime_recovers_partial_state_before_launch` 断言 `stop_calls == ["stop"]` ——
     它把「部分可达就先停掉健康的那半边」这个 **bug 本身**写成了契约，所以永远不会为它变红。
   **规则**：改一条既有 golden 之前，先回答「旧断言为什么不会为这个 bug 变红」，并把答案写进注释。

3. **想当然的安全性要当场证伪。** 两例：
   - 「stdio 握手成功就说明 stdout 干净」——**错**。Python SDK 的客户端遇到解析不了的行只记
     一条日志就跳过，注入 `print('starting xuanshu...')` 后照样握手成功。改为逐行断言 stdout 是 JSON。
   - 「旧的 trace 写法会撕行」——**没能复现**。8 进程 × 520 KB 行并发追加，250 行全部可解析；
     它安全靠的是 CPython 的实现细节（TextIOWrapper 在 close 时把整行交给一次 raw.write）。
     改动仍然保留（把「碰巧成立」变成 O_APPEND + 单次 write 的「显式成立」，成本为零），
     但**如实改口**：真正能演示的旧缺陷是没有行长上限（一个 3 MB 事件整条写进去）。
   **规则**：负向对照跑不红时，不许把「它本来就没问题」写成「我修好了它」。

   ↳ **同一条 trace 断言又被现实纠正了第二次**：改成 O_APPEND + 单次写之后，我写下「这下各平台
   都显式成立了」。CI 的 Windows job 当场打脸 —— 4 进程 × 60 次写只剩 191/213 行（每次跑还不一样）。
   Windows 的 `O_APPEND` 由 CRT 模拟，「定位到末尾 + 写」不是一个原子操作。
   ↳ **第三次**：改完之后我又假设「那至少同进程的线程之间是安全的吧」。CI 再次打脸 ——
   Windows 上 6 线程 × 40 次写只剩 190 行。因为每次 `_write_event` 各开一个 fd，
   Windows 的 append 由 CRT 模拟，两个 fd 各按自己的偏移写就互相盖，**与是不是同一个进程无关**。
   最终形态：一把模块级 `threading.Lock` 串行化同进程写（各平台都对、成本可忽略）+
   `os.write` 短写循环补齐 + 跨进程完整性只在 POSIX 断言。
   **规则加一句**：「我改对了」也要被负向对照或 CI 证一次；一个平台上成立不等于所有平台上成立，
   而「同进程总该没事」也是一个需要被证的假设，不是前提。

7. **维护机的环境会替测试补上它没声明的前提。** CI 上四条 `test_runtime_manager` 红在
   `runtime.port_conflict_unknown_holder`，而维护机全绿 —— 因为本机 9999/8899 上正跑着真 runtime，
   归属判定回 `ours`。只 stub `_service_status`（返回 `reachable=True`）的用例，会拿那个 URL 去**真的**
   跑一遍归属判定。**规则**：新增「探真环境」的代码路径时，同批检查既有测试是不是在靠你的机器过关；
   复现 CI 形状的 recipe 要跟着扩（AGENTS §8 已补第三条）。

8. **Windows 的默认编码不是 UTF-8，这条每隔几个版本咬一次。** 新写的 `repack_release_assets.py`
   在最后一步打印 `→`（U+2192），cp1252 控制台上直接 `UnicodeEncodeError` 并让脚本 exit 1 ——
   一个**发布脚本**在「打印成功信息」时失败。与 v0.25.1 的 `.ps1` 丢 BOM 是同一族。
   同批还有一条反向的：`subprocess.run(..., text=True)` 按 locale 解码**子进程**输出，
   Windows 上就是 cp1252，而我们的 initialize instructions 全是中文 → 读回来是 None/乱码。
   **规则**：脚本自己的输出保持 ASCII（或开头 reconfigure 成 UTF-8）；读子进程输出一律收字节、
   自己按 UTF-8 解，别用 `text=True`。

4. **gitignore 语义在三个地方咬人，形状一模一样**：父目录被整体忽略时反选无效
   （`.vscode/` → 必须写 `.vscode/*` + `!.vscode/mcp.json`）；`.mcpbignore` 里不带前导 `/` 的
   `vendor/` 在**任意层级**匹配（把运行时真正需要的 `src/**/vendor/` 一起排掉）；
   排掉 `scripts/` 让 wheel 的 `force-include` 在宿主机上找不到源。三者的共同症状是
   **「打得出来、装得上、一跑就炸」**，而 schema 校验器一概看不见。

5. **`str.lstrip("./")` 剥的是字符集合不是前缀。** 本轮我自己新写的守卫踩了一次：
   它吃掉了 `.claude-plugin` 的前导点，于是守卫误报插件配置缺失。用 `removeprefix`。

6. **`pathlib.Path` 的类型由 `os.name` 决定。** 把 `os.name` 打成 `"nt"` 的跨平台模拟测试里，
   `Path(tmp_name)` 会造出 `WindowsPath`，`str()` 出来是反斜杠 —— macOS 上 `os.replace` 直接
   `FileNotFoundError`。路径全程用 `str` 传递，别 str→Path→str 转一圈。


### v0.36.0 收尾 / 2026-09-04 — 「Java 族 live 需要 Mongo」记了十个版本，真因是 vendored 实例脚本裸 `-jar`；顺手抓出一个假闸门

- **症状**：v0.25.1 起台账一路写「本机无 Mongo → Java 聚合层 app 注册读不到 → nongli/bazi/ziwei/liureng 恒 9999，
  live 0-skip 留给带 Mongo 的发布机」。本轮为验 C2（`/common/inversebazi`）和 B3 神数翻转，起 `--with-java` 实例，
  `bazi_birth`/`nongli_time`/`bazi_inverse` 全 500，而同一实例上 `/qizheng/moira`（C1）却成功。
- **排查**：读 `Result` 原文（§8.5 的规矩）——不是 `no.register.app`，是
  `Timed out after 30000 ms while waiting to connect … address=mongodb.host:27017 … UnknownHostException: mongodb.host`。
  ① `unzip -p astrostudyboot.jar BOOT-INF/classes/conf/properties/cache/*.properties`：Mongo 主机写死 `mongodb.host`
  （nongli/bazi/translog/…共 10 份），Redis 写 127.0.0.1；② `strings RequestHeaderInterceptor.class`：app 注册读 classpath
  `data/rsakey.json`（`checksig` + `ClientApp` + `checkSha256Signature`），**没有任何 Mongo 访问**；本机 brew mongod 里
  只有 astrochart.nongli / astrolog / astrouser / bazidb（缓存与日志），没有注册表；③ 上游桌面启动器
  `Horosa-Web/start_horosa_local.sh` 起 jar 时带 `--mongodb.ip=127.0.0.1 --redis.ip=127.0.0.1` + 环境
  `XUANSHU_DESKTOP_MONGO_OPTIONAL=1 XUANSHU_MONGO_FALLBACK_DIR=… needtranslog=false`——本仓 runtime manager 走的正是它，
  所以**终端用户从来没受过这个影响**；只有本仓的 `start_vendored_instance.sh` 是裸 `java -jar`。
- **实锤**：照桌面方式起、且故意把 `--mongodb.port` 指到空端口 27099（= 模拟干净机器）：nongli/bazi/inversebazi 全部
  真数据，回退目录出现 `nongli.json`/`bazi.json`。本 Mac **首次 0-skip 全量 live：678 passed**（v0.25.1 以来所有
  「4 条/7 条 live 红属环境」的定性，其实都是这个脚本）。
- **顺手抓出的假闸门**：全量 live 唯一一条红是本轮 B3 自己加的 `test_shenshu_place_changes_the_reading[xianqin]`——演禽
  输出没有时区/经纬度行，上海↔乌鲁木齐、`timeAlg` 翻转逐字节相同。B3 当时按「`_run_shenshu_tool` 转发了 lat/lon」
  给它挂了地点问题，而 guard 行里明明写着「合并前按 §5.12 live 验改参数结果必变」——Java 起不来就跳过了那一步。
- **guard**：① `start_vendored_instance.sh --with-java` 改为桌面模式四件（`test_guard_wiring` 断言非注释行含
  `XUANSHU_DESKTOP_MONGO_OPTIONAL=1`/`XUANSHU_MONGO_FALLBACK_DIR=`/`needtranslog=false`/`--mongodb.ip=` 且不含
  `mongodb.host`），并等 Java 端口真开；`MONGO_PORT=<空端口>` 模拟干净机器。② `_java_result_code_hint` 三分：
  `no.register.app` → 指回请求头与 jar 内 `rsakey.json`（不再说「在 MongoDB 里」）；Mongo 超时/`mongodb.host` →
  指回起法；其余中性（`test_mongo_unreachable_9999_points_back_to_the_launch_mode` 含两条负向对照）。③ xianqin 归
  `SHENSHU_GENDER_POLICY`，live 加反向断言 `test_xianqin_ignores_place_so_its_gate_must_not_ask_for_it`；
  `test_gate_policies` 断言 xianqin 不问 location。④ 台账 v0.25.1「live 0-skip 需 Mongo」条目加 🔴 推翻批注（原文保留）。
- **法则**：**「环境限制」是最容易写进台账、最难被推翻的定性——每次给失败贴「环境」标签前，先读原文、再用上游自己的
  起法起一遍。** 判据永远是「上游桌面模式下能不能跑」，不是「我这台机器有没有装 X」。闸门问项同理：以翻转为准。

### v0.36.0 / 2026-09-04 — [主宰星链] 段在、段内「◆ 宫神星(houseRows)」子块缺了两个版本：段级棘轮看不见段内缺项

- **症状**：上游 v56 的 [主宰星链] 段末带一张宫神星 12 宫表（宫|宫头座|宫主|宫主落宫|宫主落座，FIX-1 并入段内、
  不 bump 版本）；skill 的同名段只有主宰链行。`export_section_debt` 按**段名**记账——段在就是绿。同时
  `_attach_natal_extras` 的富化失败是裸 `except: pass`，连日志都没有。
- **根因**：镜像守卫的粒度是段；上游「并入段内、无需 bump 版本」的改动天然从粒度缝里漏过。
- **guard**：`astro_rulers.py`（上游 `wholeSignRulers.js` 移植，夹具 = 上游 jest 基线盘，断言逐字照抄）产
  整宫宫主表 / 分宫宫神星表 / v56 子块；`_attach_natal_extras` 追加子块并改 `_degrade`；`test_astro_rulers`
  五条（含 `ruleHouses` 与后端逐宫对拍）。上游已切 v57（#79：整宫表进段、宫神星表独立成段）——本版镜像仍 56，
  切换时四件同动（CHANGELOG 上游观察）。
- **法则**：**段级镜像只能保证「段在」，段内结构要靠逐字夹具**；上游写「无需 bump 版本」的改动要单独盯。

### v0.36.0 / 2026-09-04 — 忠实性校验器 8 族只盖 6 类技法：调用量第一的奇门、10 择日、23 推运零覆盖

- **症状**：faithfulness v2 的族（四柱/落座/身宫/三传/紫微主星/卦名动爻/塔罗）全是「本命/占卜」类；奇门（值符值使
  说错宫、门星张冠李戴）、择日（推荐一个不在命中区间的日子、有命中却说无命中）、推运（把土星期说成 2005 年
  起）这三类最常见的编造完全不判，`ok=True` 照发。XuanshuBench 也没有 faithfulness 类 case，评测器只在 pytest 里活。
- **根因**：族按「已有机读真值最好抽的技法」长出来，不按「agent 最常调、最容易编」排；bench case 类型只有
  tool/dispatch/knowledge，评测器没有进 bench 的入口。
- **guard**：v3 三族——`qimen_zhifu/zhishi/palace`（快照 `值符：/值使：` 行 + 九宫行）、`hit_window`
  （`data.intervals` 命中区间；推荐日期必须落在区间内、有命中说无命中判红）、`period_boundary`（推运表行的
  行星↔年月配对，EN 行星 id 归一到中文正名）；每族三条对抗测试（supported / contradicted / gated+invented）；
  bench 新 case 类型 `faithfulness`（跑工具→抽真值→判给定答案，`expect_ok` + `expect_min_flagged`），塔罗两条
  离线可跑、六爻两条随 runtime；精选 case 4→10。值金标补 huangli（万年历公开事实）/ liuyao（京房纳甲 +
  六亲生克 + 六神起例）/ tarot（种子确定性），`value_golden_debt` 21→18；qimen/taiyi/jinkou 三个 ken 格式器
  没有离线 pan 夹具，仍在债务表（如实）。
- **法则**：**校验族按「最常调 × 最易编」排优先级，不按真值好不好抽**；评测器必须有 bench 入口，否则它只
  是一段没人跑的代码。

### v0.36.0 / 2026-09-04 — `/qizheng/moira` 被误判「不存在」：测错了服务，6/14 段债务是一条写错的台账

- **症状**：guolao 导出段债务 14 条里 6 条（guolao + qizhengzeri 各 [虚实]/[本命化曜]/[流年流曜]）被标为
  「开源 astropy 无该路由，永久不可得」。上游 `services/qizheng.js` 明明白白 POST `${ServerRoot}/qizheng/moira`
  ——ServerRoot 是 **Java** 聚合层（astrostudycn `QizhengMoiraController`），当年拿 Python chart 服务实测
  500 就下了结论。
- **根因**：把「某个服务返回 500」当成「路由不存在」，没有回到上游源码确认路由挂在哪一层；台账条目一旦写成
  「维持排除」就再没人质疑。
- **guard**：C1 接活——`tools/guolaoMoira.js` 加 `rules_sections` 入口，逐字移植上游三段 builder（selfcheck 金标
  = 上游 jest 夹具 `guolaoWeakSolidBirthStars.test.js`）；`_run_guolao_chart_tool` 二次铸流年盘 → Java
  `/qizheng/moira`（`{params, chartObj, transitParams, transitChartObj}`）→ 三段插在 [大限] 与 [政余格局]
  之间；新 `GuoLaoInput`（guolaoLifeMode/guolaoBodyMode/moiraTransitDate/Time/moiraRules）；preset+optional
  双登记，qizhengzeri 经 `ZERI_DERIVED_KEYS` 自动继承 → 段债务 14→8；Java 不可用走 A5 冷却快速失败 →
  `_degrade` 进 warnings；provenance guolao→composite。旧台账两处**原文保留 + 加更正标注**。
- **法则**：**排除一个上游能力前，先在上游源码里确认它挂在哪一层**；「某服务 500」只证明那台服务没有，
  不证明路由不存在。台账里的「维持排除」要写清判据，便于日后推翻。

### v0.36.0 / 2026-09-04 — 108 个错误码只有 4 类带恢复说明，112/151 条错误文案单语

- **症状**：`_with_operational_recovery` 只认 runtime./transport./js_engine./backend_param，其余 ~100 个码
  （`tool.qimenzeri_missing_window`、`report.technique.no_cards`、`knowledge.*`……）返回给 agent 的只有
  code + message：该问用户、该修入参、该重试还是该让用户跑 doctor，agent 只能猜；MCP 面的错误信封连那
  4 类都不带（`_mcp_error_envelope` 直接透传 details）。新守卫第一次跑就抓出一个三层规则都落不到的码。
- **根因**：错误码被当成日志标签而不是接口——没有「每个码必须可分类」的约束，也没有文案语言要求。
- **guard**：`errors.py`：`bilingual(zh, en)`；`RECOVERY_KINDS`（input / retry_or_doctor / runtime / transport /
  js_engine / environment，各带双语 prompt + next_action[+commands]）+ `RECOVERY_TABLE` 精确码表 +
  `classify_code`（精确 → **前缀** → 后缀：基础设施前缀优先于通用后缀，否则 `js_engine.node_unavailable`
  会被 `unavailable` 抢成泛泛「重试」）+ `recovery_for`（补 agent_recovery/hint/next_action，已带者不覆盖）；
  service 与 MCP 两条错误路径同一码表；`scripts/verify_error_recovery.py`：包内每个 `code="…"` 必须可
  分类（硬规则），非双语文案计数 `contracts/error_recovery_debt.json` 只降不升（现 112）。
- **法则**：**错误码是接口**——新码要么进精确表要么用可分类后缀（`*_missing_*`/`*invalid*`/`*_failed`/
  `*_unavailable`），文案用 `bilingual()`；恢复语义按「谁能修」分层（用户/入参/重试/环境），不按模块分。

### v0.36.0 / 2026-09-04 — 闸门半盲：推运五支从不问目标/弧源，神数五支从不问性别，163/326 问题没选项

- **症状**：`planetaryarc` 用本命盘策略——问宫制、不问 `arcSource`（月亮弧/太阳弧结果完全不同）也不问目标
  时刻；vedicprog/jaynesprog/planetaryages/extrareturns 同病；铁板/邵子按性别分条文、演禽/策天/张果按地点
  起盘，五支共用「只要日期」的神数策略，性别地点从不问；163 个闸问题没有选项，MCP 原生表单只有一个三选一，
  用户在表单里答不了任何具体设置。
- **根因**：策略按「族」复用（ASTRO_BIRTH/SHENSHU），没有「该工具自有的结果敏感项必须出现在问题里」的
  约束；问题与 schema 值之间没有映射，表单答案只能当备注。
- **guard**：`_progression_target_policy` 工厂给五个推运工具各自的目标问题（arcSource 带 options+values）；
  `SHENSHU_GENDER_POLICY`（tieban/shaozi）与 `SHENSHU_PLACE_POLICY`（xianqin/cetian/qizhengkin：性别+地点+时区，
  与 `_run_shenshu_tool` 实际转发一致）
  > 🔴 **收尾更正（同日，首次带 Java 的全量 live）**：演禽（xianqin）对地点/时区/timeAlg **完全不敏感**——输出无
  > 时区/经纬度行，上海↔乌鲁木齐逐字节相同；「转发了就问」是假闸门。xianqin 改归 `SHENSHU_GENDER_POLICY`，
  > live 测试改成**反向断言**（地点必不变）钉住引擎事实。教训：闸门问什么以 live「改参数结果必变」为准，
  > 不以代码转发了什么为准——本条 guard 行原本就写着这个判据，却在 Java 起不来时跳过了它。
  ；可枚举问题配 `options` + 并行 `values`（hsys 带上游索引、zodiacal、
  岁差制、晚子时双开关、diFen 十二支、gender、arcSource），自由文本项进 `FREE_TEXT_GATE_FIELDS` 白名单
  （`test_gate_policies`：新问题要么带选项要么显式入白名单）；elicitation 表单从 `ask_if_missing` 生成
  （每个带选项的问题一个枚举字段，≤6），答案只写回策略声明过的 `values`，逐题作答即视为确认
  （`agent_confirmed_settings=true` + 记录）；`sensitive_settings.json` 加 planetaryarc/tieban 裸调用自测；
  live 翻转测试（tieban/shaozi 性别、xianqin/qizhengkin 地点）随 runtime 跑。
- **法则**：**一个工具自有的结果敏感项，闸门必须点名问到**，族策略只能是底座不能是全部；问题要能落回
  schema 值（options↔values），否则表单只是装饰。

### v0.36.0 / 2026-09-04 — 找不到：25 个技法无路由规则、英文触发 67% 零命中、`XUANSHU_TOOLSETS` 拼错＝零技法

- **症状**：8 个择日搜索工具、tarot/地占/一掌经/龙盘/重置盘/占星地图/多重回归……25 个技法在 `xuanshu_dispatch`
  里没有任何规则（5 个只在未命中候选池），用户说「八字择日开业」拿到的是八字命盘 + 通用择日两张盘；
  58 个常见英文触发词 67% 零命中，`vedic chart` 路由到**推运**工具；`XUANSHU_TOOLSETS=astr`（拼错）注册零个
  技法且没有 `xuanshu_tool_run`，客户端只剩门面、任何技法都到不了。
- **根因**：路由规则是逐个手写的 `if _contains_any(...)`，新工具接线九件套里没有「加路由」这一步；同义词
  没有单一来源（描述里一句、候选池里一份、路由里再一份）；`_selected_toolsets` 把任何 token 都当域名。
- **guard**：`engine/synonyms.py`（105 工具全覆盖，中文口语 + 拼音 + 英文；键集与 TOOL_DEFINITIONS 锁步）
  三处消费：MCP 描述 `aka:` 一行、路由候选打分、语料；路由补 25 条规则 + 择日族互斥表 `_ZERI_PHRASES`
  （基底技法规则一律 `and not is_zeri`）+ 英文触发 + `vedic` 修正；`contracts/router_corpus.json`
  100 条 zh/en 语料 + `verify_router_corpus.py`（`min_pass` 只升不降，现 100/100）；`test_router_corpus`
  「每个技法必须有规则或在豁免表」；`XUANSHU_TOOLSETS` 合法域表 + 别名 western/chinese/all/none，未知
  token 告警丢弃、全空回落全量，只要有过滤生效就注册 `xuanshu_tool_run`；`server_profile` 经
  `xuanshu_agent_guidance` 可查。
- **法则**：**一个技法「能算」不等于「能被找到」**——接线清单必须含路由规则 + 同义词 + 语料各一条；
  配置解析对拼错要告警回落，不能静默变成「什么都没有」。

### v0.36.0 / 2026-09-04 — tools/list 1186 KB（≈318k token）：agent 开口前先付一本字典的钱

- **症状**：默认 MCP 面 115 工具的 `tools/list` 1186 KB；57 个工具各继承 BirthInput 全部 95 字段（每工具 17 KB、
  112 个属性），dispatch/hecan 把 5 路 union 内联两次（各 24 KB），每个工具描述重复一段 322 B 的澄清闸说明；
  精简面也有 93 KB（技法目录在 dispatch 与 tool_run 各放一份）。schema 零 enum，`hsys` 描述还写错（A7）。
- **根因**：广告层与校验层是同一份东西——`_signature_for_input_model` 为了「未声明键不被丢」（A6 那类病）
  把全模型字段都放进签名，FastMCP 又照签名原样广告。想瘦就得砍签名，砍签名就静默丢键：两难被当成没得选。
- **guard**：两层 schema（`surfaces/mcp_schema.py`）：签名不动（校验层，隐藏旋钮顶层照收），注册后重写
  `Tool.parameters`（广告层 = 域核心 + 推运目标字段 + 工具自有字段 + 闸门三键 + `request` 逃生舱，注明还有
  N 个高级旋钮按名可传，`additionalProperties: true`）；enum 只进广告层（hsys 按西占/印占两表、zodiacal/ad/
  response_view；47 岁差制只给常用键——全表 enum 每工具 600 B 超预算）；dispatch/hecan 换单一宽松对象；
  描述去闸门段、指向 guidance；目录只放 tool_run 一份且标签截 28 字。结果 **1186 KB → 253 KB、93 KB → 30 KB**。
  棘轮 `scripts/verify_mcp_list_budget.py`（进程内量两档，硬上限 256/30 KB + 只降不升 2%）；
  `tests/test_mcp_list_budget.py`：隐藏旋钮顶层照收、无 `$ref`、enum 与表锁步、dispatch birth 为单对象。
- **法则**：**广告什么和接受什么是两件事**——校验层求全，广告层求准；任何「瘦 schema」的改法先证明未声明键
  仍然到达 `run_tool`，再看字节。

### v0.36.0 / 2026-09-04 — MCP 扁平面静默丢未声明键：PR #17「性别恒为未知」只是 63 个工具同一类病的一例

- **症状**：外部 PR #17（@xipfs）报 `bazi_birth` 传「男」快照仍「性别：未知」、大运顺逆无法判定。复现只在 MCP
  面：CLI / `xuanshu_tool_run` / dispatch 都正常。
- **根因**：不是 pydantic 丢字段（`FlexibleModel` 是 `extra="allow"`），是 MCP 扁平面——`_signature_for_input_model`
  只广告模型声明的字段，FastMCP 按广告签名生成的 arg model 把未声明的顶层键丢掉，之后才 normalize/validate。
  `BaZiBirthInput` 没声明 `gender`，于是丢。用「每个样例载荷键必须在模型上」一扫：**63 个工具**中招——西占/推运
  /择日全族的 `name`/`pos`（透传盘头）、八字/紫微/正传的 `gpsLat/gpsLon`（后端载荷候选回退键）、
  **神数五支的 `gender` 与 `zone/lat/lon`**（`_run_shenshu_tool` 原样转发，MCP 上全丢）、`pdchart.showPdBounds`
  （服务在读、指南在写、schema 没有）。样例载荷、文档、服务消费点三处都有这些键，唯独 schema 没有。
- **guard**：`tests/test_mcp_flat_surface_keys.py`——每个技法工具的样例载荷（离线套件/Bench/烟测共用的那份）
  的每个**原始**键都必须出现在广告签名里，否则列出「哪个工具丢哪个键」；配套 `tests/test_bazi_gender.py`
  （PR #17 的用例收编，bool→1/0 归一 + `_gender_label`）。修法一律「声明字段」，不是改样例：样例就是文档。
- **法则**：**一个键要么在 schema 上，要么它不存在**——服务读它、文档写它、样例带它而 schema 没声明，就是
  MCP 用户静默拿到另一张盘。新增消费点先加字段（`verify_schema_knob_wiring` 管反向：字段必须有消费点）。

### v0.36.0 / 2026-09-04 — `hsys` 描述写「1=Placidus」：上游索引表 1 是 Alcabitus、3 才是 Placidus

- **症状**：`BirthInput.hsys` 描述「0=整宫、1=Placidus 等」；服务自己的 `ASTRO_HOUSE_SYSTEM_TEXT` 与上游
  perchart 表都是 1=Alcabitus / 2=Regiomontanus / 3=Placidus / 4=Koch…。按描述传 1 想要 Placidus 的 agent
  拿到 Alcabitus 盘，且无任何告警（宫制合法值，闸门不拦）。
- **根因**：描述是手写的，和表没有锁步；印度盘另有一套索引（8=Alcabitus），两套表并存更容易记串。
- **guard**：描述改为逐项列全表并明示「1 不是 Placidus」；`tests/test_house_system_docs.py` 锁步描述 ⊇
  `ASTRO_HOUSE_SYSTEM_TEXT` 每一项且不含「1=Placidus」；B1 出 enum 时以该表为唯一源。
- **法则**：**枚举类参数的文档必须从表生成或被表锁步**，手写一次就是一次抄错的机会。

### v0.36.0 / 2026-09-04 — Java 起不来时，每个碰 Java 的调用都先杀掉健康的 chart 服务再全量重启

- **症状**：Java 后端（:9999）挂着、chart 服务（:8899）健康时，任何 Java 端点调用（含 qimen/taiyi 等前置
  `/nongli/time` 的技法）都要等 ~90s 才失败，期间 chart 族技法也跟着断——用户存档里「起盘慢/时好时坏」的
  一类主诉。issue 里的 Windows「后端起不来」多属此型。
- **根因**：`_call_remote` 探针失败 → `start_local_services()`；管理器见「任一服务在」就 `stop_local_services()`
  先杀健康的 chart 再全量重启，等满 45s 超时才判 degraded 返回；随后调用连不上 → `connection_retry` 再
  `start_local_services()` 一次——同样的 stop+restart 又来一遍。「降级」只在管理器一头有（degraded_chart_only
  状态写进文件），调用侧完全不看它，每次都当冷启动处理。
- **guard**：`runtime_java_retry_cooldown_seconds`（env `XUANSHU_RUNTIME_JAVA_RETRY_COOLDOWN_SECONDS`，默认 120）；
  管理器记住上次 degraded 启动时刻（进程内 + state 文件回读），冷却期内 `start_local_services` 直接返回
  `{degraded, skipped_restart}` 不 stop 任何服务；`_call_remote` 对 Java 端点冷却期内快速失败
  `runtime.java_backend_unavailable`（带 retry_after/hint），start 回来 degraded 也立即失败而不是等连接错误再
  重启；chart 端点全程不受影响；可选 Java 富化经 A2 `_degrade` 落 warnings。测试：冷却期内 Java 工具失败、
  `started==0`、chart 工具照常；start 回 degraded 只起一次。
- **法则**：**就绪是分后端的**——一个后端挂了不能连累另一个；重启是昂贵且有副作用的恢复动作，要有冷却，
  且调用侧必须读管理器的降级状态而不是把每次失败当冷启动。

### v0.36.0 / 2026-09-04 — 河洛流年法旋钮发成死键 `step2`：边界契约看不见，issue #15 同型再现

- **症状**：`tools/heluo.js` 把 `liunianStep2` 装进 `opts.step2`，而引擎 `buildSnapshotText` 读的是
  `snapOpts.liunianStep2`（再转成 `liuNian` 的 `step2`）——`liunianStep2:'sequential'` 传了等于没传，
  流年永远应爻法。半成品里同批的 yizhangjing `leapRule/gradeSet`、tongshefa 纳甲逐爻也都是「引擎接好、
  schema 没声明、金标没有」。
- **根因**：两层盲区叠加。① 边界契约生成器的 import 正则只认 `import { a } from`，`import calc, { … } from`
  的**默认导入**整个不进契约，`calc(...)`/`buildSnapshotText(...)` 两处边界根本没被记录；② 就算记录了，
  verifier 的 oracle 是「键名出现在被调模块源码里」——同模块另一函数 `liuNian` 恰有参数 `step2`，子串命中，
  死键照样绿。契约能抓的是「模块里根本没有这个词」的死键，抓不住「词在、但不是这个函数读」的死键。
- **guard**：生成器补默认导入 + `opts: localLiteral` 嵌套展开（`nested_under`）+ 成员访问 `x.year` 不当整对象
  （否则误报）；真正的守卫是 **能翻转的值金标**：selfcheck 三条——heluo `liunianStep2`（2 岁流年 雷風恆·上六 →
  山風蠱·六四，且写错键名 `step2` 必须**不**翻）、`ziShuMode`、立春前干支年基准；yizhangjing `gradeSet`
  （天驛 中品→下品）、`leapRule`（闰二月十五 00:xx 作下月，23:xx 不作）；tongshefa 纳甲六爻/世应/爻变。
  Python 面同型三条；`value_golden_debt` 24→21。
- **法则**：**声明一个旋钮 = 交付一条「改它结果必变」的金标 + 一条「写错名结果不变」的负向对照**；子串式
  静态契约只能当第一道网，不能替代翻转测试。

### v0.36.0 / 2026-09-04 — 六壬工具手抄了 24 张 LRConst 表：vendor 修了、金标绿了、消费点还是旧值

- **症状**：v0.35.0 修正 vendored `LRConst.ZiLiuQin` 乙日巳/午→子孙并加了 120 格逐格金标，CI 全绿；但
  `tools/liureng.js` 顶部自带一份 `ZI_LIU_QIN`（连同 ZI_LIST/GAN_LIST/贵人六表/刑冲害合/干支相克……共 **24 张**
  与 vendor 逐字相同的表），三传六亲仍按旧表出——金标只看 vendor 导出，对手抄消费点结构性失明。
- **根因**：早期为省 import 把 vendor 常量抄进工具文件，形成第二真值源；此后所有 vendor 同步/修正都绕过它。
  「vendor 金标」验证的是「表对不对」，不是「工具用的是不是这张表」。
- **guard**：24 张表改为 `const { ZiList: ZI_LIST, … } = LRConst` 解构（`SIGN_TO_YUE` 无 vendor 对应保留）；
  `test/handcopy.mjs` 入 `npm test`：`tools/*.js` 顶层字面量 vs 文件所 import 的 vendor 模块导出，按规范化
  名（`ZI_LIU_QIN`~`ZiLiuQin`）或深比对相等即红，内置负向对照（种一份抄表必须被抓、解构与无对应表不许误报）；
  selfcheck 加**消费点**金标：`runLiureng` 输出的三传六亲逐项 == `ZiLiuQin[支][日干]`。
- **法则**：**常量只准有一个源，工具文件只准引用不准抄**；改 vendor 真值时，金标必须打在消费点（工具输出），
  不是打在被修的那张表上。

### v0.36.0 / 2026-09-04 — 35 处「优雅降级」只写日志：ok=True、warnings=[]、少 10 段

- **症状**：真实奇门存档 `missing_selected_sections` 10/17 而 `warnings: []`；agent 把「少了十段」当完整结果
  写报告。`service.py` 35 处 `logger.warning("X failed: %s", exc)` 只有 2 处把说明推进 `_warnings`
  （v0.33.1 修 issue #15 时只补了八字格局/多运限两处），其余 33 处——奇门年干、七政庙旺、天王附注、
  世运子盘、印度分盘、月历附注……——失败即消失。MCP elicitation 更彻底：`except Exception: return None`，
  表单崩了和「客户端不支持表单」在 agent 眼里一模一样。
- **根因**：降级点各自为政——每处 except 里的返回值形状不同（dict/文本/None/continue），把说明「带回」
  信封要改每一处的返回路径，于是都只写了日志；同一层的 `_warnings` 出信封管道只有直接持有
  `response_data` 的两处能用。「优雅降级」被当成了「不炸就行」。
- **guard**：`_degrade(fmt, *args[, note=])` + `contextvars` 收集器（`_degrade_collector`，`run_tool` 作用域，
  嵌套调用冒泡到外层）——不管 except 里返回什么，说明都进 `envelope.warnings`；预设段缺席自动生成
  「结果不完整：预设 N 段中 M 段未产出（…）」进 warnings + summary，dispatch 汇总一行；
  `scripts/verify_silent_degrades.py` 棘轮包内裸 `logger.warning(` 计数（基线 **0**；启动期通知改
  `logger.log(WARNING)` 并注明「无调用方可告知」）；elicitation 拆纯函数
  `_apply_gate_decision`，七种出口各写 `details.elicitation.status`，首批 9 条离线测试。
- **法则**：**降级的定义是「调用方知道少了什么」，不是「没报错」**；降级说明的出口要和返回值解耦（收集器），
  否则每加一处富化就多一处静默。

### v0.36.0 / 2026-09-04 — 导出段 `data` 逐段整份复制：qimen 5 MB / india_chart 101 MB（正文仅几 KB）

- **症状**：用户存档里一次奇门调用返回 5.07 MB，其中 `export_snapshot.sections` 1.55 MB、段正文合计
  2.8 KB——**550:1**；印度盘存档最大 101 MB。agent 一次调用就把上下文撑爆。合成复现：23.8 KB 后端响应
  → 917 KB 导出快照（38×），且 303 KB 原始 dump 直接落进 `export_text`（agent 被要求当真值读的那个字段）。
- **根因**：三处叠加。① `_pick_section_data` 兜底 `return response_data` / `X or response_data`——任何未识别
  段拿到整份引擎对象，qimen 18 段里 11 段各带一份 137 KB 的 `pan`；② `_build_generated_export_snapshot`
  对**每个**段都算 `section_data` 并塞进 `section["data"]`（仓内零消费者：parser/reports/technique_card/
  faithfulness 都不读它）；③ 兜底正文守卫只数行不数字节，单行 JSON dump 穿过。唯一的反膨胀测试只数一个
  24 字符文本探针出现次数，对 `data` 键一字不提。
- **guard**：段形状固定 `{index, raw_title, title, included, body}`（envelope schema 0.7.0→0.8.0，
  `docs/DATA_CONTRACTS.md` 与常量由 `verify_docs_sync::check_envelope_schema_version` 锁步——common.py
  的注释多年宣称有此检查，实际文档停在 0.6.3 无人察觉）；`tests/test_response_budget.py`：段不带 data、
  引擎对象在响应体里**恰出现一次**、全工具循环「信封字节 ≤ data 基线 + 3×正文 + 16 KB」；兜底正文按
  字节+行数双守卫，空正文一律占位（faithfulness/报告/「不得臆造依赖」检查都以非空正文为前提）。
- **法则**：**引擎对象只在 `data.<key>` 存一份，段只存 body**；「有没有膨胀」要量字节、按内容封顶，
  数文本探针的守卫只能证明「没多印那一句」。

### v0.35.0+ / 2026-09-03 — 手工件 sha 戳按裸字节算：CRLF 平台上守卫恒红（windows-smoke 连红两次）

- **症状**：v0.35.0 发布 commit 在 main 上 `CI` 红——`windows-smoke` 里
  `tests/test_vendor_manifest_watch.py` 两条（curated 戳相符应安静 / bespoke derived_from 同理）
  报「source changed upstream since the last audit (sha 13514c5a → 212ca9da)」；Linux `test` job 恒绿。
  本机（`core.autocrlf=true`）一跑即复现。
- **根因**：`revendor_core_js._sha256_file` 对**裸字节**取 sha256，而戳是 mac 侧对 LF 源算的。
  Windows 上同一份文件到手就是 CRLF（autocrlf 检出、`Path.write_text` 文本模式写入都会），
  裸字节摘要永远对不上戳 → 每个 curated/bespoke 条目都被判「上游改了」——**守卫在它最该保护的平台上
  恒红**（恒红 = 没有守卫，人会学会略过它；v0.26.0 台账「永远红的检查等于没有检查」的同族）。
  测试红只是表象：真正的手工件漂移守卫（`--from-manifest --check`）在任何 Windows 检出上也会全体误报。
- **guard**：`_sha256_file` 改为对 **CRLF→LF 归一化后的 UTF-8 文本**取摘要（非 UTF-8 才退回裸字节）。
  LF 源的摘要逐字节不变 → 既有 `upstream_sha256` / `derived_sha256` 戳**无需 restamp**；CRLF 检出
  从此也能对上。新增 `test_stamp_is_line_ending_independent`：**显式**以 `newline="
"` 写源再断言
  戳相符——只靠 `write_text` 的平台换行差异，这条在 mac/Linux 上永远测不到。
- **法则**：**凡跨平台比对文本文件的摘要，先归一化换行再算**；同时记住 Windows 上 `Path.write_text`
  默认会把 `
` 写成 `
`，写 LF 源文件要 `newline="
"`（本轮自己就在改脚本时把整个文件
  写成了 CRLF 一次）。

### v0.35.0 / 2026-09-03 — 手工件零信号 + 两棵整拷树不比对：六壬六亲两格错值静默滞留四轮同步

- **症状**：上游 v3.9.4（08-20）真值校准改了六壬六亲表 `ZiLiuQin` 乙日巳/午两格（父母→子孙，乙木生
  巳午火＝我生者），本仓 v0.31~v0.34 四轮同步、每轮 `verify_upstream_sync` 全绿，vendored
  `liureng/LRConst.js` 仍是旧值——三传/毕法两条链（`ChuangChart.js:176`、`LRBiFaDoc.js:149`）都从它取
  六亲，用户拿到错答案。同批的紫微年基准（`ziwei/zwLuckItems.js`，bespoke）是人读 release note 才补的；
  flatlib 在 v3.9.3 漂过三个文件（aspects / chart / ephem/swe），守卫同样零信号。
- **根因**：三处结构性盲区。① `revendor_core_js.py` 对 `curated` 只断言 extracts 名字仍导出、对 `bespoke`
  只断言上游无同名文件，`manifest_drift()` 对非 verbatim 直接 `continue`——手工件的**内容**从不与上游比；
  ② `SENTINEL_TREES` 只收 astropy 的两个子树，`tests/`（上游 v3.9.3 起 11 个校准套件）、`resources/`、根级
  文件与整棵 flatlib 都不在集合里，而 sync 脚本对这两棵是整棵 rsync——**同步口径 ≠ 比对口径**，正是
  v0.26.0 jieqi.py 事故换了一个层级再犯；③ 六亲表没有值级金标。
- **guard**：手工件记源 sha（curated `upstream_sha256` / bespoke `derived_from` + `derived_sha256`，13 条全部
  打戳），`--from-manifest` 与 `manifest_drift()`（`verify_upstream_sync` check 3）源一动即红、复核后
  `--restamp <条目>` 才灭；`SENTINEL_TREES` = sync 脚本整棵 rsync 的每一棵（astropy 整棵 + flatlib 整棵），
  `tests/test_verify_upstream_sync.py` 用正则从 sync 脚本抓整拷树集合与守卫锁步；`selfcheck.mjs` 六亲表 ≡
  五行生克公式 120 格逐格对拍（负向对照：把任一格改回去即红，验过）；`tests/test_vendor_manifest_watch.py`。
- **法则**：**凡不经流水线的文件都要有一条「源变了就叫人」的边**——名字/basename 检查只证明「还叫这个名」，
  不证明「还是这个值」。**守卫树集合 == sync 脚本整棵 rsync 的集合**，加一条 rsync 就加一棵树。

### v0.35.0 / 2026-09-03 — SQLite 日志侧车被当成源文件：镜像与首版发布包里混进 `editorial.sqlite-wal/-shm`

- **症状**：preflight 对着上游 HEAD 的干净 clone 跑，`verify_upstream_sync` 报
  `astrostudy/xuanshi/data/editorial.sqlite-shm/-wal`「not in upstream」；对着上游脏工作树却恒绿——这两个
  文件在上游磁盘上（进程打开过库就会留下），git 不跟踪。v0.35.0 首次构建的 darwin 包也带着它们
  （wal 0 字节、shm 32KB，这次无害，但形状是错的）。
- **根因**：sync 脚本、守卫与三个 builder 的排除集都没有 SQLite 运行期侧车——「同步口径 == 比对口径」在这类
  文件上**一致地错**，所以只有换一棵干净树才现形。非空 WAL 打进包 = runtime 打开库时回放上游未 checkpoint
  的写入，库内容偏离 git 里那份 `.sqlite`。
- **guard**：`sync_vendored_runtime_sources.sh` RSYNC_FILTERS、`verify_upstream_sync.py` TREE_EXCLUDE_SUFFIXES、
  `package_runtime_payload.sh` 与 windows/linux builder 的排除集同加 `*.sqlite-wal/-shm/-journal`；
  `test_tree_file_walk_honours_the_sync_scripts_exclusions` 覆盖三种后缀；本地 vendored 树已删侧车、包已重打。
- **法则**：排除集加一项要在**四处**同加（sync / 守卫 / 三 builder）；跨树比对的输入用上游 **HEAD 的干净
  checkout**（浅 clone 即可），脏工作树会把「两边一致地错」洗成绿。

### v0.35.0 / 2026-09-03 — 手册知识包白名单与已上架技法脱钩，且生成器读的是脏工作区

- **症状**：`helpdocs/` 21 域全部停在 08-17（上游 v3.9.3 预发），之后上游三个版本改了 AstroHelpDoc（古典
  设置九子组一览）/ AuxchartHelpDoc / ZeriHelpDoc（+113 行择日十技法）；而 `HELPDOC_DOMAINS` 根本没有
  Zeri/Taiyi/Sanshi/Yanqin/Yizhangjing/Xuanshi 六册——对应工具（十个 `*zeri`、`taiyi`、`sanshiunited`、
  `yanqin_yanfa`、`yizhangjing`、`xuanshi`）早在 v0.32~v0.34 上架。技法有了、口径知识没有，AI 客户端引不到教义。
- **根因**：① 白名单是手写常量，与「上游有哪些手册」「skill 上架了哪些技法」都没有机器边；② 生成器从磁盘
  读手册、出处却记 `git rev-parse HEAD`——上游维护机常年带 WIP（本轮 AstroHelpDoc.js 就是脏的），按磁盘
  收割等于把未提交改动记成某个 commit 的内容。
- **guard**：生成器默认读 HEAD blob（`git show HEAD:…`；`--worktree` 只给非 git 快照），脏手册报 notice；
  `*HelpDoc.js` 既未收割也未进 `EXCLUDED_HELPDOCS`（仅 fengshui，政策性排除）即 FAIL；
  `tests/test_knowledge_helpdocs.py` 断言白名单域 == 磁盘包集合 + 六个新域在场。
- **法则**：**上游每一册手册要么收割、要么明文排除，没有第三种状态**；出处与正文必须同源于同一个 commit。
  同步上游新技法时（§5 布线清单第 14 步）把「它的手册进白名单并重跑生成器」算进同一个 change。

### v0.34.0+ / 2026-09-01 — 择日派生键继承了基底段表、没继承基底 optional 集：5/10 新技法 live 导出「缺段」

- **症状**：v0.34.0 Windows 半边原生验证，十个择日技法 live 全部 `ok`，但 5 个的
  `missing_selected_sections` 非空——bazizeri 缺 大运/多运限、taiyizeri 缺 博弈/命法/命宫行限、
  ziweizeri 缺 运限/流派叠层、liurengzeri 缺 年命上神/占断向导/取象、sanshizeri 缺 奇门遁甲/紫微四化。
  离线契约测试全绿（FakeJsClient 发全集），无 live 测试断言择日键的导出洁净——**只有真 runtime 能抓**
  （v0.34.0 上一条台账「离线绿 ≠ 参数对」的同族）。
- **根因**：`AI_EXPORT_PRESET_SECTIONS[<x>zeri] = [*基底段表, 择时三段]` 按 spread 继承了段表，
  `AI_EXPORT_OPTIONAL_SECTIONS` 没有跟着继承——基底里「有条件才出」的 11 段对派生键成了必出段。
  静态证据：12 个缺段全在基底段表内，11 个在基底 optional 内，且 `vendor/divination/zeri/*Snapshot.js`
  对这 12 段**零发射点**（择时盘是时刻盘、无出生信息）——结构性缺席，不是接线错。
  唯一例外 `取象`（liureng 基底必出、zeri builder 不发射）= 派生键的死条目。
- **guard**：`ZERI_DERIVED_KEYS` 提为常量，段表与 optional 集**都**从基底继承（`取象` 单列进
  `_ZERI_MOMENT_CHART_DEAD`）；`tests/test_zeri_optional_inheritance.py` 断言 派生 optional ⊇ 基底
  optional 且 optional ⊆ preset。修后 live 重探：十个键 `missing=[] unknown=[]`。
- **法则**：**凡按 spread 派生的导出键，optional 集必须与段表一起继承**——段表继承、条件集不继承
  = 把基底的条件段升格成必出段，这种「多出来的严格」只在 live 才现形。派生新键时把这条写进 §5.5。

### v0.34.0+ / 2026-09-01 — 补 Windows 半边时：择日十技法的 Python 引擎在三把验证器里没有新鲜度标记

- **症状**：v0.34.0 补 Windows 半边前，本机 `vendor/runtime-source` 停在 08-24（v3.7.x 时代的 astropy），
  而发布已对齐上游 v3.10.0（新增 `qizheng_election_scan.py` / `india_election_scan.py` 与
  `/qizhengelectionscan/*` `/indiaelectionscan/*` 两族路由）。`verify_vendor_runtime_sources.py`
  在这棵陈旧树上**照样全绿**——它的内容断言只有 `AI_EXPORT_SETTINGS_VERSION == 56`，而上游按「只加键
  纪律」把 8 个新技法键加进 aiExport 时**没有 bump 56**。唯一判红的是 mirror 守卫（逐键覆盖）。
  若 mirror 也漏了（或有人为过关加 alias），构建会打出**没有择日后端路由**的 Windows 包，而
  `verify_runtime_release.py` 只查文件在不在、照样放行。
- **根因**：三把验证器（vendor 源 / 发布归档 / builder parity）的「真文件标记」停在 v3.5.1
  （`ifa_odu.json`）与 v0.32.0（xuanshi sqlite），v3.10.0 这一整个新子树没有任何一个文件被点名。
  **标记文件是版本恒等之外唯一能证明「树是当前的」的东西**，每次上游加子树都要同步加一个。
- **guard**：`astrostudy/qizheng_election_scan.py` + `india_election_scan.py` 进
  `verify_vendor_runtime_sources.py::REQUIRED_PATHS`、`verify_runtime_release.py::REQUIRED_ENTRIES`
  （三平台块）与 `verify_builder_parity.py::REQUIRED_ON_BOTH`；fixture 同步。加完对**真归档**跑过：
  mac 打的 darwin tar 与本机打的 win zip 都含这两个文件（顺带证明两平台 payload 同源 v3.10.0）。
- **法则**：上游每新增一个会被 skill 调到的后端子树，同一 change 里给三把验证器加一个**该子树独有
  的真文件**作标记（照 `ifa_odu.json` 先例）。版本号恒等在「只加键纪律」下不是证据。

### v0.34.0 / 2026-09-01 — 同步上游 v3.10.0 择日十技法：抽壳、解析器盲区、与「假债务」

上游一次发了 182 文件 / +25k 行的择日大版本（8 个新技法键）。同步过程本身踩出四条。

- 🔴 **依赖闭包要按「已 vendored 即停止节点」算，否则数字会吓人。** 天真闭包把整个 React 壳
  （amap 地图 / D3 / xq-ui / request.js）都拉进来，六壬那支报 69 个新文件；把已 vendored 的文件
  当停止节点重算后是 5 个。**先算对再决策** —— 按 69 那个数字很容易误判成「这支做不了」。

- 🔴 **上游把纯逻辑和 React 放同一个文件时，剥壳要机械化，不要手抄。** `LiuRengMain.js` 6436 行，
  1–4553 纯逻辑、4554 起 `class … extends Component`，20 个纯 export 全在前半。仓里此前手抄过
  其中三个函数进 `liurengRefContext.js` —— 而上游的 `buildSanChuanData` 早已多出第 4 个参数
  `castOverride`，手抄那份还是三参。**手抄件会静默落后于上游**。改为 `truncate_before` 按正则
  锚点整头 vendored（锚点而非行号：行号随上游编辑漂移，锚点找不到会报错而不是悄悄剪错）。

- 🔴 **截断必须跑在孤儿 import 清理之前。** 孤儿判据是「符号在正文里还用不用」，而截断正是改变
  正文的那一步。放后面的话，React 尾部专用的 16 个 import 在判定时还“在用”，于是全部留下 ——
  模块引用了 vendor 树里根本不存在的路径，加载即炸，**而 re-vendor 那一步看起来是成功的**。
  同族：`_IMPORT_STMT` 不吃行尾注释（`import {...} from '…'; // [观象P1]`）时，stub 报 not found、
  import 原样留下，症状一模一样。

- 🔴 **解析器盲区会造出「假债务」，比漏检更坏。** 上游同一个文件里 spread 有两种写法：
  `...AI_EXPORT_PRESET_SECTIONS.qimen`（v3.7.1）与 `...(AI_EXPORT_PRESET_SECTIONS.bazi || [])`
  （v3.10.0）。只认第一种时，八个新键的基底段全被 export-section 守卫报成「skill 多出来的段」
  （bazizeri +11、sanshizeri +50…）。**这种噪声会诱使人去 `--update-baseline`**，把一条本该常绿的
  检查一次性腌成永久噪声。判据：报出来的债务，要先问「它和某个已入账的基底债务是不是同一笔」——
  本轮七键是解析器的错，第八键（qizhengzeri 缺 3 段）才是 `guolao` 既有债务的真继承。

- 🔴 **execution 标错会让整个 runner 被绕过。** 给 `qizhengzeri`/`indiazeri` 在 registry 上挂了
  endpoint + `execution="remote"`，通用远端路径抢先接管 → 自写的按月分段与快照合成一次都没跑，
  而工具**返回 ok=true**、只是 hit_count 恒 None。tianxing 一直是 `execution="local"` + runner 自己
  打端点，照抄它即可。同一形状：`export_snapshot` 恒 None 是因为忘了把新键加进
  `AI_EXPORT_TECHNIQUES`（有 preset 却不在这张表 → parse 抛 Unknown technique，而调用方 `except
  ValueError: return None` 把它吞成 None）。

- 🔴 **live 一跑，离线全绿的四处接线错同时现形 —— 每一处离线都抓不到。** 本轮八个新技法离线契约
  全绿之后打真 runtime，四类问题一次浮出：① `_PYTHON_CHART_ENDPOINTS` 漏登记 → 请求被路由去
  **Java 聚合层**（那边没这条路由）→ HTTP 500，而同样的请求体直接打 chart 服务是好的，症状像
  「后端坏了」；② 后端吃的是**编译树**不是 UI 树，发 UI 树得到 `unknown condition type: None`
  （与 zeriScan.js 里那条注释同一个坑，只是搬到了 HTTP 边界）；③ 样例 payload 的条件参数我写成
  `{}`，离线桩根本不 compile 所以照绿，live 一次报出四个「至少选择一项」；④ 印度的 `vara`
  要**整数序**不是英文名。**「离线绿 ≠ 参数对」——参数正确性只有真引擎能判。**

- 🔴 **报「铸盘失败」时要把基底工具的原文带出来。** 无 Mongo 机器上 Java 族回 9999，与真正的接线
  错误长得一模一样。本轮为区分这两者做了整轮排查（决定性实验：**单独**调基底工具同刻复现——
  它也红就是环境/基底问题，只有择日这条红才是接线问题），而那轮排查本可以由一行错误信息省掉。

- 🔴 **算源分类落到兜底 = 不诚实的披露。** provenance 生成器按显式名单分类，新工具落到兜底
  `local_data`（「不起盘：读本地离线库」）—— 而它们确实铸盘，只是盘不是搜索算的。正确类是
  `composite`（两条腿算权不同，`compute_sources` 逐项写明）。**兜底类别永远要当成「待人工确认」，
  不是「默认正确」。**

### v0.33.1 / 2026-09-01 — issue #15 不是一个 bug，是一个**家族**：边界改键 + presence 级绿灯

外部贡献者 [zeno17z](https://github.com/xuanshu-project/xuanshu-skill/pull/16) 报了一个具体错误：八字格局段
把 正财格 判成 正官格。根因是 `baziGeju.js` 写 `hour:` 而三个引擎一律读 `time` —— 时柱静默缺席，
取格/五行力量/盲派整批错，而输出照常自信。顺着这个形状全树对抗性扫描（43 个 JS tool、44 个
`js_client.run` 调用点、78 个 Input class）之后，同族活体 **4 个 P0 + 10 个 P1**，外加 36 处无错误码的
静默空返回与 15 个 schema 撒谎的死旋钮。

- 🔴 **presence 级断言对值回归结构性失明。** 「段在 `section_titles_detected` 里」≠「段里的值是对的」。
  六层防线全绿而 bug 照样出货：loadcheck 只扫 `src/vendor/` 不扫 `src/tools/`；selfcheck 对
  baziGeju 零覆盖；vendor manifest 只管引擎不管调用方；离线 fake **手编答案**（引擎从不运行）；
  live 测试 presence-only 且 `@requires_runtime` 在 CI 里 skip；golden fixture 里压根没这三个段。
  `src/tools/` 是整棵 JS 树里**唯一没有任何静态守卫**的部分 —— 而所有改键都发生在那里。
  守卫 = `verify_js_boundary_contracts.py`（死键向 + 锚定向）+ `verify_value_goldens.py`（值级金标棘轮，
  AGENTS §5 第 12 步）。接上一条 :1139 的下一阶：那条讲「桩比真实响应更简单」，这条讲「断言比真实
  结论更浅」。

- 🔴 **跨边界不改键。** 上游原样透传是唯一被证明安全的形状。本轮五例全是同一句话的反例：
  `hour`↔`time`（#15）、`minute`↔`ke`（铁板，96 局塌成 12）、`lunarMonth`/`lunarDay` 在手却不转发
  （参评，起运岁恒 1、九个大运整体平移）、`params: response` 指向 /chart 信封而非起盘时刻（果老
  moira，`isDay` 恒真 → 夜生盘拿天贵而非玉贵）、裸 `gender` 经 `Number('女')`=NaN 判男（神数正传，
  女命大定死限年错）。**判据统一为一句**：「改这个参数，结果必须变」—— 每条修复都配了这样的
  值级金标 + 负向对照（把 bug 改回去，金标必须红）。

- 🔴 **静默降级会沿调用链上移。** #15 的修复给 JS 侧加了结构化错误，而 Python 侧
  `_attach_bazi_geju` 只读 `snapshot_text` —— `data.error` 无人看，四段消失依旧零信号。
  **修一层不等于修一条链**：错误信号每上一层都要有人接。守卫 = `verify_silent_returns.py` 棘轮。

- 🔴 **selfcheck 的 harness 自己也犯同一个病。** `check()` 只 `fn()` 不看返回值 → async 断言体的失败
  变成 unhandled rejection，打印 `ok`、退出码 0、CI 全绿，断言其实根本没验。写这一条时它正好吃掉了
  我自己刚写的 canping 金标里的一处笔误。**给 harness 也要做负向对照。**

- 🔴 **schema 描述不是愿望清单。** `ElectionInput` 的注释一边引着正确出处（"上游 electionParams.js 的
  13 键"），一边列着 11 个与那 13 键**零重合**的发明名字；`HoraryInput` 的 `receptionMode`/
  `almutenScheme` 在任何引擎词表里都不存在。它们被描述、被文档化、三个版本一次都没生效 ——
  agent 照描述传参、读到自信输出，永远学不到那个旋钮被忽略了。
  修法不是一删了事：`lotsSet`/`considerationsMode` 是**真词表**里的名字，真正的病是
  `horaryJudgeOpts(school)` 只喂了四层口径链的第 1 层、`runElection(chart, topicId)` 干脆把 `opts`
  整个丢了 —— 46 + 13 个真参数结构上不可达。**接线时把白名单锚到引擎自带的词表**
  （`HORARY_PARAM_BY_KEY` / `ELECTION_PARAM_BY_KEY` / `BABYLON_SCHEMES`），不手抄会漂移的清单；
  认不出的键回执在 `data.params_ignored`，不静默吞。发明的名字整批删。
  守卫 = `verify_schema_knob_wiring.py`。

- 🔴 **新守卫也要做负向对照，否则它只是更贵的装饰。** `verify_js_boundary_contracts.py` 第一版能抓
  铁板的 `minute`，却抓不到 #15 自己的 `hour` —— 因为 #15 的字面量不在调用处，而在上一行的
  `const four = {…}`，采集器只扫内联实参。**「守卫跑绿了」和「守卫能抓到它声称防的那个 bug」是两件事**；
  后者必须用真 bug 注回去验证。同理，第一版生成器每次 regen 都会把手写豁免块冲掉，而 regen 恰恰是
  修完调用点后的常规动作 —— 等于豁免永远活不过一次修复。

- 🔴 **上游删掉的东西，下游也要跟着删。** `zuoShan` 上游已判定是「双重幽灵」（无流派声明 needs、
  快照 builder 全文不消费）并删除，skill 侧还在 schema/service/JS 三处带着它，白白打散 memo 缓存。
  同理 babylon 的 `era`/`scheme`：流派只当**标签**传，judge 层的 `dodecaVariant`/`cubitDeg` 一个没传，
  于是无论选哪档十二分恒 B，而 [起盘信息] 行照常打出所选档名。

- 🔴 **fork 首次贡献者的 PR，workflow 需维护者手动批准**（`action_required`），否则 CI 永远 pending，
  看起来像「贡献者的代码跑不过」。另：本仓 Dependency graph 未开启，`dependency-review` 在**每个** PR
  上都红，与 PR 内容无关 —— 判断 CI 时要先分清「这条红是不是每个 PR 都红」。

### v0.33.0+ / 2026-08-29 — codex TOML 裸插值：Windows 路径的反斜杠打穿整个 config（main 连红两次）

- **症状**：v0.33.0 发布 commit 起 main 上 `CI` 连红两次——`windows-smoke` 里
  `tests/test_client_config.py` 三条全炸：`tomllib.TOMLDecodeError: Unescaped '\' in a string`
  + 两条 `--write` exit 1；Linux `test` job 与 CodeQL 恒绿。不只是测试红：Windows 用户跑
  `client config --format codex` 拿到的 `toml_stdio` 就是**非法 TOML**，`--write` 也因 tomlkit
  解析失败而拒绝写入——新功能在 Windows 上整个不可用。
- **根因**：`cli.py` 的 codex 片段里 `command = \"{stdio_command[0]}\"` 是**裸 f-string 插值**进
  TOML 基本字符串；Windows 的 `C:\Users\…` 反斜杠在 TOML 里是转义引导符 → 整文件不可解析。
  同块的 `args`/`cwd` 都走了 `json.dumps`（JSON 转义 ⊂ TOML 基本字符串转义，天然兼容），
  唯独 `command` 手写引号。mac/Linux 路径无反斜杠 → 维护机与 Linux CI 恒绿，windows-smoke
  是唯一能红的地方（v0.25.0「维护机形状 ≠ CI 形状”教训的路径分隔符变体）。
- **修复**：`command` 改走 `json.dumps`，与 args/cwd 同惯用法（一行 + 注释）。全仓 sweep 确认
  无兄弟病灶（其余 client 格式全是 dict→`json.dumps`）。真机抽验：本机 `C:\Users\…` 路径下
  `toml_stdio`/`toml_http` 均可被 tomllib round-trip。
- **守卫**：既有 `tests/test_client_config.py`（v0.33.0 III-6 新增）就是逮住它的那把——CI 红得
  完全正确，说明"五格式零测试"补的这层真在工作；无需新守卫，修代码即可。
- **法则（蒸馏进 AGENTS §9）**：凡把路径/用户值序列化进配置文本（TOML/JSON/YAML/deep-link），
  一律走该格式的序列化器（`json.dumps` / tomlkit / `quote`），**禁裸 f-string 插值**——
  「本地能解析」不算证据，Windows 反斜杠路径才是判据。

### v0.33.0 / 2026-08 — 功能大扩容（93→97）+ 成熟度升级：四个现场踩坑 + 一批排除判定

本轮双主线（收割未接入端点 + Codex 标尺工程成熟度）落地：tianxing explainAt、qizhengelection、
india_rectify、planet_cycles、jieqi_birth、persiandirected 指定日期盘、extrareturns 年表、acg 落点/
事件、cetian 判词库、wangji 心易三法、geomancy 十六卦目录、古典参数 30 键 typed 化、/healthz 探针、
SQLite 分类恢复、env 旗标 warn-and-ignore、澄清闸策略即数据、记忆点用记账/prune、hermetic 评测、
codex --write 拆雷、.agents/skills 镜像。现场教训四条：

1. 🔴 **`TOOL_EXPORT_TECHNIQUE_MAP` 漏登记 = bench 静默不覆盖。** 症状：批 I 四个新工具功能全绿
   （契约 missing/unknown 空、live 实产），bench 生成 case 却只 +1。根因：README 承诺的「新增技法
   自动获得用例」由 `generate_tool_cases()` 兑现，它遍历的是 `TOOL_EXPORT_TECHNIQUE_MAP`——而新
   runner 都自己调 `_augment_export_payload`，不经过这张表也一切正常，于是没有任何信号提示入表。
   守卫：`test_every_business_tool_is_in_export_technique_map`（工具 − 表 = 显式非业务四件）；
   §5 布线清单 +第 12 步。
2. **exports registry 同字典重复键第二次踩**（v13 首踩 cetian/astrochart_like，本轮 extrareturns 条件
   段被后写键静默覆盖）。两个新事实：①旧守卫只扫**顶层 `ast.Assign`**，本可抓到却因我用 `-k` 分批跑
   测试而没被触发——守卫只在全量套件里兜底，**每批提交前必须全量跑 offline**（本轮全批照做后再未漏）；
   ②守卫本体已扩 `ast.walk` 全量（嵌套 dict/AnnAssign 位置同防）。另附带：用 regex 从「提及目标字典名
   的注释」处起段做文本编辑，会把条目插进后面**任意**同名键的字典——锚定真赋值行，改完必跑
   `test_export_tools` 全量。
3. **`_unwrap_result` 连剥小写 `result` 键。** `/wangji/xinyi` 返回 `{method, result:{卦面}, sections}`，
   经 `_call_remote` 后 `sections` 整个消失——unwrap 循环对 `Result`/`result` 都剥（至多 4 层）。新端点
   接入时凡响应含这两个键名，先想清剥壳后拿到的是什么；runner 按剥后形状消费（离线桩发全信封，
   两侧形状一致）。
4. **测试期望值不等于真值。** selfcheck 金标里我手写的 `08未51`（处女镜像地支）与 `摩羯`（2020 木土
   大合相落宫）都是错的，渲染器是对的（处女↔巳；合相在宝瓶 0°29′）——金标的期望值必须从权威来源
   （上游表/天文事实）核过再写，测试红先怀疑期望值。

**排除判定入册**（主线 I 收割时逐端点核）：`/predict/pd3d`、`/chart3d/state`、`/planetarium/*` ——
3D/实景渲染场景数据（three.js 场景态/贴图坐标），无文本语义，UI-only 排除，与 fengshui 同性质；
`/jdn/*`、`/calc/*` —— 儒略日/角度换算器，价值低，defer（不计缺口，将来要做随手可加）。
`/qizheng/moira` 排除维持（qizhengelection 的升殿失垣列因此如实不产，见工具 guidance）。【v0.36.0 更正：`/qizheng/moira` 是 Java 聚合层路由，当年拿 Python chart 服务测的 500——C1 已接活，三段落地，见本轮台账。】

### v0.32.0 玄史知识库接入 —— runtime 里躺了 66MB 只读库，skill 层零调用

- **上游能力不只在导出面。** `/xuanshi/*` 26 个只读端点（7900+ 玄学事件 / 27000+ 史书天象 / 人物图 /
  编辑层）随 runtime 分发已久（editorial.sqlite 66MB 就在 astropy/astrostudy/xuanshi/data/、服务挂载表
  里一直有 /xuanshi），但它不在 aiExport 导出面上，所以段级/镜像守卫**永远不会报它**——「上游有什么
  我们没接」的普查必须包含 websrv 端点清单 vs `_PYTHON_CHART_ENDPOINTS` 的差集，不能只看导出键。
- **jsonpickle 直吐的端点可能返回裸数组**（/xuanshi/search、timeline 下钻等）。`_call_remote` 的
  dict 硬约束会把它判成 `transport.invalid_result_shape`——放行必须**按端点前缀圈死**（仅 /xuanshi/*
  包成 {items: […]}），其余端点维持硬约束，形状漂移要炸出来。
- **端点登记守卫只认 `_call_remote("字面量")`。** 分发表形态（action → 端点全路径存表、调用处传变量）
  的字面量在表里不在调用点——守卫要加一条对应的采集规则（本轮给 test_endpoint_registry 加了
  `/xuanshi/[a-z_]+` 字面量扫描），否则 26 个端点全被判成死项。
- 新工具布线在本仓已是**九件套**：schema + ToolDefinition + runner/分派 + 端点白名单 + 导出注册
  （skill-only 键还要进 mirror 白名单）+ guidance（含 PREFLIGHT_EXEMPT，检索类工具无出生盘闸）+
  router 关键词 + technique_provenance 条目 + 样例载荷/FakeClient 桩。bench case 与 server
  instructions 计数由锁步守卫自动拦，文档计数由 docs-sync 拦（本轮它逐处点名了 banner.svg /
  CLAUDE.md / AGENTS.md / 徽章 / 自检行 / 导出技法数 / bench 数——共 12 处，一处不落）。

### v0.31.0 重同步 v3.9.5 —— 版本常量锁步被证伪 + 三种 require 形态 + caller 旧于依赖

- **🔴 `AI_EXPORT_SETTINGS_VERSION` 锁步不可信。** 上游 v3.9.5 给 `horary` 导出段 19 → 28（+9 段），
  **版本常量原地不动仍是 56**。后果：`verify_export_contract_mirror.py`（只比版本号 + key 集合，且只读
  vendored 镜像）全绿穿透；`verify_export_section_baseline.py` 默认 `--source vendored` 也绿——那是拿
  自己的旧镜像对账，同义反复。**权威判据只有两个**：`verify_upstream_sync.py --require-upstream`
  （sentinel sha256）与段级棘轮的 `--source upstream --require-upstream` 形态（`preflight_release.py`
  在跑的就是它）。日常手跑判断同步健康，必须用后一形态，裸跑默认参数会在这类失败上恒绿。
- **上游 require 有三种形态，逐形态踩齐才算修完**：①语句形 `const {X} = require('…')`（v0.25 已处理）
  ②**表达式形** `require('./x').prop`（ZiWeiHelper 的 `require('./ziweiOptions').ZWEngineOptions.kuiYue`，
  语句正则抓不到，ESM 运行到即 ReferenceError；改写=hoist 成命名空间 import + 表达式处换别名。该规则
  顺带抓出 dignities.js / hellenisticData.js 两处同病）③同符号 require **多次**（topicModule 的
  DIR_BY_ELEMENT ×2）→ hoist 队列内也要去重，否则 `Identifier already declared`。另一坑同族：hoist 的
  **插入点必须按完整语句匹配**——按单行匹配时多行 `import {…\n…} from` 块的首行也命中，「最后一条
  import 之后」会落进块中间把它劈成两截（lifespanEngine 实测 SyntaxError）。
- **「caller 旧于 vendored 依赖」是手工抽取件的专属漂移形态。** 本轮 `ZiWeiHelper.js`/`ziweiOptions.js`
  机械重灌后已是新版（effLayerSihuaGan / xiaoxianClockwise / 各流派开关全在），但手工抽取的 caller
  （zwLuckItems 4 函数 / ziweiExtras.formatLuckLayerLines / JinKouSnapshot.buildJinKouSnapshotText）
  还是旧文本——能力在场但不可达，其中 `birthYearOf` 缺 `ganzhiYearBase` 是 v3.9.4 修的**真值错误**
  （流年归属可能错年）。规矩：每轮重灌 vendor 树后，把 `contracts/vendor_manifest.json` 里 mode 为
  bespoke/curated 的条目**逐一与上游现函数对文本**，机械 `--from-manifest` 不覆盖它们。
- **上游后端的「param error」可能是本仓载荷的锅**：`/chart` 的 params 回显块无守卫读 `data['hsys']`
  （上游前端恒发 hsys，从他们视角没毛病）。`HoraryInput` v0.24 typed 化时把 hsys 覆写成 None 默认
  （「随流派档」），归一化剥掉 None → 缺键 KeyError。此前一直误判为「vendored 实例拒绝载荷、改前即
  如此」并绕道 JS 层直验——**其实是真 bug，线上任何 python chart 后端上 horary 全挂**。修=调用侧补
  PerChart 默认 0。教训：typed 化把父类有默认值的字段改成 None 默认时，要查每个直调后端的工具是否
  依赖那个默认值。
- **saturnExalt20 已删档**（上游 2026-08-18 拍板：degree 位全仓零消费者=真死开关，
  `push_request_exalt_variants` 签名 2→1 参）。本仓 typed 字段同步删除；`nodeExaltation` 保留。

### v0.28.0 / 2026-08-17 — v3.9.2/v3.9.3 同步轮的四条 + 首个「AI 层」批次的三条

**同步侧（缺口小了，说明守卫在做功；坑换了形态）。**

1. **上游在你同步时还在动。** v3.9.2 同步做到一半，上游又发 v3.9.3 + 两个 commit——`--write-state`
   记录点必须追 HEAD 而不是停在「我开工时的版本」，否则 provenance 一写完就是陈旧的。
2. **skill-only 键的 lost 检查会自锁。** 上游把 `generic` 从 preset 键降为运行时兜底后，check 1b 的
   lost 方向红 → `--write-state` 拒写 → recorded 永含旧键 → 永远红。修：lost 集减去 mirror 守卫的
   DIVERGENCE_WHITELIST（skill-only 键从来不镜像上游，撤它不构成 retirement），降为 notice。
3. **「聚合导出子源标签」是新段形态。** calendar 的 农历/老黄历/日子馆 三段是整行【X】来源分界、
   非内容段（上游 [E-6]）——必须进 preset（否则用户自定义段时标签行被过滤删除），但 body 为空是
   正常形态。别按内容段的「空即缺」直觉处理。
4. **评测器必须对任意信封形状稳健。** bench 评测器踩 `{"technique": None}` 的 `None.get` 连崩两轮
   ——失败信封的 data 可以带 export_snapshot=None。评测器崩 = 整轮 bench 白跑，比单 case 红严重
   得多；一律 `(x or {})` 边界。

**AI 层批次（B1/B2/B3——「会算」之上的第一层）。**

5. **HelpDoc 是被埋没的知识资产。** 上游 30+ 份方法论手册（每个设置的取值与差别、流派分歧、
   算法口径）只活在桌面端帮助页里——正是 AI 解读最缺的口径知识。收割成知识包（21 域/177 条，
   逐条带 组件文件+tab+上游版本 出处），`knowledge_read` 通用分支零代码扩域。
   生成器幂等纪律：generated_at 取上游 commit 时间，不取 now()。
6. **忠实性校验可以完全确定性。** 导出契约是机读真值 → 「AI 是否编造盘面」不需要 LLM 判官：
   槽位断言（四柱/落座/身宫/三传）逐值比对，裸值断言对快照词元全集查存在性。词元切分要取
   CJK 连续串的**全部 2-4 字子串**——贪婪切词会把「食神制杀」吃掉「食神」。
7. **合参的护栏在模板里，不在提示里。** `xuanshu_hecan` 产模板不产终稿：结论槽必须留白
   （预填即伪造）、证据是指针不是全文（响应不背 N 份快照）、「分歧必须披露不许平均」写进
   synthesis_contract.instructions 而不是靠 SKILL.md 的自觉。

### v0.27.0+ / 2026-08-13 — 发布后制度化批次：口头注意点不收进机器，下一轮还会原样再犯

**背景。** v0.27.0 发布过程里暴露了五件「说过、但没有任何机制拦」的事，当场逐件收进机器。
横切法则：**对话里的注意点 = 还没发生的复发**——能写成断言/脚本的，当场写；只能写成文档的，
问一句「哪个 runner 会读到它」。

1. **live 曾打到默认端口上的另一棵树。** 审计中途从默认 `:8899` 的服务读过段名，事后靠 lsof
   才发现那个实例根本不是本仓的树（来源、版本全不可知），数据当场弃用重推。旧规则「live 必须打
   vendored 实例」只是 §8 的文字。守卫：① live 门禁改为**只认显式 env**——
   `XUANSHU_CHART_SERVER_ROOT`/`XUANSHU_SERVER_ROOT` 未设一律 skip，且短路在探针左侧，
   **连 TCP 都不碰默认端口**；② 起法收进 `scripts/start_vendored_instance.sh`
   （三段 PYTHONPATH + 内嵌解释器 + failed=0 判据 + 不达标自动回收），停法
   `stop_vendored_instance.sh` 只按 pidfile PID。回归：`test_guard_wiring.py` 断言短路形状与两纪律。
2. **git 身份没配，发布 commit 作者串成 `…@主机名.local`。** git 只在 commit 那一刻才猜，全程无
   提示，GitHub 不归属任何账号，要 amend 才能救。守卫：`preflight_release.py::identity_problems`
   （纯函数，直接测），name/email 未配或 email 以 `.local` 结尾 → 阻断。
3. **main 滞留只有文档没有闸。** v0.27.0 写进了 §7 文字；本批把它变成 preflight 的
   `git_gate_failures()`：fetch 后 `HEAD..origin/main` 非空 → 阻断（离线 fetch 失败只警告）。
   **该闸首跑当天就抓到构建机补 Windows 半边时推的一个 commit** —— 不是假想敌。
4. **SBOM 生成器一直在仓里，发布时却漏传了。** `generate_sbom.py` 不在任何发布脚本的调用链上，
   v0.27.0 首发的资产列表少了它，靠人对比 v0.26.1 才发现（「守卫挂在什么都不跑的地方」的资产版）。
   守卫：mac 半边发布收进 `scripts/publish_darwin_release.sh`（SBOM 是显式步骤；无 `--publish`
   不上传）；`release-completeness.yml` 新增 SBOM 资产断言。发布步骤从此只允许以脚本形态存在。
5. **算源生成器躺在 scratchpad（会随会话蒸发）。** 契约可再生 ⇒ 生成器必须入仓：
   `scripts/gen_technique_provenance.py`（仓内相对路径，输出与在册契约逐字节幂等）。
   §5 布线清单补第 11 步「算源声明」。
6. **附带小坑：`json.dumps` 重写 package-lock 会把非 ASCII 转义成 `\uXXXX`**，下次 `npm install`
   按 npm 规范写回真 UTF-8，凭空造一个与版本无关的噪音 diff。规则（§7）：lock 只许字符串替换
   两处版本串，禁整文件 json 往返。

### v0.27.0 / 2026-08-13 — 目录 mtime 判源树新旧会误判（Windows 侧补半）

- **症状**：v0.27.0（上游 v3.9.1 全量同步，92 工具）以 **darwin-only** 发布，守卫自发布起连红三次。
  Windows 侧补半时按当时 AGENTS 的规则「核 astropy / dist-file mtime 新于目标版」判源树新鲜度——
  workspace 的 `astropy/` 顶层 mtime 停在 **07-03**，比 08-13 的目标版旧一个月，按该规则应判「源树陈旧、
  不能构建」。
- **根因**：目录 mtime 只在**直接子项增删**时更新，嵌套深处的文件更新不冒泡到顶层目录。该 astropy 树
  实际已是上游 v3.9.1（`vendor/kin_year_domain.py`、`astropy/astrostudy/geomancy/data/ifa_odu.json` 俱在，
  `electionscan`/`chart12`/`ephemeris`/`draconic` 四个新端点都 grep 得到）。**规则本身是错的**，
  照做会白白拒掉一次可行的构建、或反过来给陈旧树发绿灯（mtime 可被无关操作 touch 新）。
- **守卫/现行规则**：AGENTS §7 改为**按内容判**三条判据（本版新增的 `require_path`/`REQUIRED_ENTRIES`
  目标文件是否存在 → 新端点名是否 grep 得到 `astropy/websrv` → 构建后 native-verify 这些端点是否回真数据），
  明确「不看目录 mtime」。机器守卫侧本已覆盖大半：builder 的 `require_path` 拦缺文件、
  `verify_runtime_release.py` 的 `REQUIRED_ENTRIES` 拦缺 payload 项（本版新增
  `kin_year_domain.py` + `ifa_odu.json` 两项即由它把关）；端点级新鲜度无法静态断言，由 native-verify 兜底。
- **本轮验证留痕**：BC −500 与 2400 年 qimen 均 `rc=0`（缺 `kin_year_domain.py` 会 500）；
  geomancy 响应体从旧版 ~86KB 涨到 **210KB**（`ifa_odu.json` 生效，v3.5.1 地占大改版）；
  `/astroextra/ephemeris`、`/astroextra/draconic` 回真数据；两个启动器带 UTF-8 BOM 通过新 zip 级 BOM 闸。
- 注：协议第 3 件（CHANGELOG）仍不可执行——树内无 `CHANGELOG.md`（同前条）。

### v0.27.0 / 2026-08-13 — 落后上游 4 个 release 而四把守卫全绿：盲区在「根级文件」和「单向键差」

**症状。** 例行「还有什么没同步」审计，结果不是零星缺口：本仓 vendored 树停在上游 `f8275b3`(v3.7.3)，
而上游 HEAD 是 `44a1c9b`(v3.9.1)，中间 381 文件 / +220,597 行；导出契约上游已 v55、本仓镜像基线写 50；
多了一个**整技法** `lingqi`（灵棋经）和 **56 个新段**。CI 全绿，四把守卫也全绿。

**根因（三个互相独立的盲区，任何一个单独存在都足以让这次同步继续隐形）。**

1. 🔴 **`verify_upstream_sync` check 2b 静默丢掉所有「上游新增的根级文件」。**
   `vendored_tops = {n.split("/",1)[0] for n in vendored_files}` 对根级文件 `foo.py` 求出的 top 就是
   文件名自己，于是上游新增的根级文件永远匹配不上任何已 vendor 的顶层目录 → 整类丢弃；配套的
   「新增顶层目录」检查又要求 `"/" in n`，两头都漏。实测让 **6 个引擎模块 / 5,512 行**
   （`cetian_yiyu{,_data,_texts}.py`、`wuzhao_{classics,duanci,leizhan}.py`）对**所有**守卫隐形。
   这正是 check 2b 当初要堵的那一类失效（v0.26.0 的 `kintaiyi/jieqi.py`），只是高了一个目录层级——
   **堵漏时要问「同样的错还能在别的层级上犯一次吗」**。
2. **`verify_export_contract_mirror` 是单向的。** 它只断言 `skill_keys ⊆ upstream_keys`，所以只能抓
   改名/删除，**结构上抓不到新增技法**——哪怕 vendored 树是全新的，`lingqi` 也永远不会让它变红。
3. **两条跨树闸在 CI 上是零断言。** `ci.yml` 调它们时不带 `--require-upstream` / `--source upstream`
   （因为 GitHub runner 上既没有 gitignored 的 vendored 树也没有上游 checkout）。这本身是诚实的设计，
   但意味着「PR 全绿」对跨树漂移**什么都没说**——真闸只在维护机的 `preflight_release.py` 里。

**另外三条本轮现场踩到的。**

- **`--require-upstream --write-state` 自锁**：provenance 陈旧时 check 4 先 raise，而写记录的代码块在
  raise 之后 —— 那句「re-record with --write-state」在它自己的参数组合下永远做不到。而 preflight 用的
  正是这个组合，也就是说「刚重同步到新上游」这个**最常见**的发布前状态必然卡住。
- **无上游时那句 `state current`**：它只知道「常量自上次核对以来没动过」，却印成「当前」。落后 4 个
  release 时它照样这么印。能断言什么就只说什么。
- **`SKILL_ONLY_KEYS` 写错一个键 = 一个永久盲区**：`astrochart_like` 被列为 skill-only 而上游确有该
  preset，于是它的 `占星地图` 缺失**从未被任何一版欠账计入**。
- **Python 字典重复字面量键静默吞掉前一份**：给 v13 补段时在 `AI_EXPORT_OPTIONAL_SECTIONS` 里为
  `cetian`/`astrochart_like` 各写了第二个同名键，解释器不报错，前一份 list 直接消失，症状是
  「明明加了 optional 段，missing 里还在报」。

**守卫。** ① check 2b 拆出 `missing_upstream_files()`，按每棵树的**同步口径**（`whole` 整棵 rsync /
`per-dir` 逐目录+点名根级文件）分别判缺失，根级文件不再被丢；kinastro 专属排除也从全局收窄到单树。
② mirror 守卫补 `upstream_keys − skill_keys` 反向检查 + `UPSTREAM_ONLY_LEDGER`（要跳过必须写理由）。
③ 新增 `tests/test_guard_wiring.py`：**每个 `verify_*.py` 都必须被某个 runner 调用**——它当场抓到了
本轮新写的 `verify_technique_provenance.py` 还没挂进 CI/preflight。④ staleness 在 `--write-state`
在场时降级为 notice。⑤ FAIL 输出带总数 + `--full`，截断不再掩盖规模（56 条和 16 条曾长得一模一样）。
⑥ registry 重复键守卫进 `tests/test_export_tools.py`。

### v0.27.0 / 2026-08-13 — `execution` 不是算源：技法依据卡要是照它写，会系统性说错「谁算的」

**症状。** 要给每次输出附一张「这盘怎么来的」卡片时，发现代码里唯一能机读的算源线索是
`ToolDefinition.execution`（`local`/`remote`），而 AGENTS §4 的「工具算源普查」只是**散文**。

**根因。** `execution` 说的是「runner 在哪跑」，不是「谁算的」：`qimen` 是 `execution="local"`，
整盘却由 ken 后端算（JS 只格式化）。照它写卡片，会给 3 个 ken 技法、14 个神数技法**一致地印错**。

**守卫。** `contracts/technique_provenance.json`（七分类逐工具声明）+ `verify_technique_provenance.py`：
覆盖率（新增技法不声明算源即红，补上 §5 布线清单缺的一环）× ken 一致性（声明 ken 的必须真调过
`_require_ken_pan`，反之亦然）× 算盘端点必须已登记 `_PYTHON_CHART_ENDPOINTS`。
**运行期实测优先于声明**：卡片以 `pan.source`/`compute_sources` 为准，与声明不符时标
`matches_declaration: false` —— ken 端点失败也回 HTTP 200，静默回退本地脚手架正是这个形状。

### v0.27.0 / 2026-08-13 — 一台机器的修复可以无声滞留：`main` 没有 upstream tracking

**症状。** 另一台机器把「9999 不是 no.register.app 的同义词」修复推到了 `origin/main`，本地 `main`
落后一个 commit 一周多，无人察觉。

**根因。** `git config branch.main.remote` / `.merge` 都是空的 —— 没有 upstream tracking，
`git status` 永远不显示 `behind 1`，只显示一句干净的 `## main`。

**守卫。** `git branch -u origin/main`；发布前检查加一条「`git log main..origin/main` 必须为空」。

### v0.26.1+ / 2026-08-06 — 反误诊的提示自己成了误诊源：9999 不是 no.register.app 的同义词

- **背景**：v0.26.1 为终结「HTTP 500 一句话看不出所以然」，给 `XuanshuApiClient` 加了
  `_JAVA_RESULT_CODE_HINTS`，把 `200001`→参数错误、`9999`→「app 注册没读到（在 MongoDB 里）」。
  方向完全正确，**但 9999 的映射按码值硬贴**。
- **症状（Windows 构建机实测取证）**：同一台机器上，缺 `lat` 触发的上游字符串越界回的是
  `{"ResultCode": 9999, "Result": "begin 1, end 3, length 1"}`——**不是** mac 侧看到的 200001。
  于是错误消息变成「ResultCode 9999 (no.register.app) = app 注册没读到（注册信息在 MongoDB 里）」，
  一个**参数 bug 被指去查 Mongo**。这正是本仓连着两轮在清的那类误诊，只是这次躲在「反误诊工具」里。
- **根因**：`9999` 是 Java 聚合层的**通用失败码**，`no.register.app` 只是它的其中一种 `Result`。
  按码值建映射 = 把「一种成因」当成「该码的定义」。
- **fix/guard**：`9999` 必须再读 `Result` 原文——含 `no.register.app` 才给注册/Mongo 提示，否则给
  中性提示（显式否掉「9999 == 注册问题」这个等式 + 指向 `Result` 原文 + 提醒先核 lon/lat 齐全）。
  回归 `test_generic_9999_is_not_labelled_a_mongo_problem`：断言中性分支不出现 MongoDB、显式含
  「不等于」、并指向 Result 与 lat。
- **法则**：**错误码→成因的映射，凡该码可承载多种成因，必须按消息二次判别，认不出就保持中性。**
  替用户断案的诊断比没有诊断更贵——没有诊断只是不知道，错误诊断会把人送去错误的方向排查几小时。
  （同源教训：上一条「4 条 live 红被误判成无 Mongo」；两轮都栽在「把一种成因当定义」。）

### v0.26.1 / 2026-08-05 — 「守卫全绿 + 测试全绿」的 v0.26.0 里躺着 16 个 bug

v0.26.0 发布时七把守卫全绿、320 测试全过。发布**之后**做了一轮三路对抗性复审，查出 16 个真 bug，
其中 5 类会让用户直接拿到错答案。**发布前跑一遍全绿 ≠ 没 bug** —— 复审要当成发布流程的一环，
而不是出事之后才做的事。

- 🔴 **「时好时坏」几乎总是缓存，不是环境。** 五个占时工具（xiaoliuren/feigong/xiaochengtu/guice/
  zhengchuan）用 `payload.get("lat")` 取值而 schema 把 `lat` 列为可选 → 把 `lat: null` 发给要求
  lon+lat 均非空的 `/nongli/time` → `200001 param error`（表现为一句无信息量的 HTTP 500）。
  对照 qimen/taiyi 用 `payload["lat"]`（必填），从来不犯。
  **它之所以被误诊成「本机无 Mongo」整整一个版本**：Java 的农历按**年**缓存，任何一次带 lat 的请求
  都会焐热该年，此后同年无 lat 请求全部成功。决定性实验 = 同一 commit 下先对 1998 年发一次带 lat 的
  请求，两个原本红的测试立刻转绿。**诊断这类问题务必换冷年份**，否则你在测一个自己刚焐热的缓存。
  守卫 = `service.py::_require_cast_geo`；另把 Java 的 200001/9999 翻译成人能读的诊断
  （`engine/client.py::_java_result_code_hint`）——此前 `XuanshuApiClient.call` 从不看 ResultCode。

- 🔴 **schema 声明了却没接线的字段，比没有更糟。** `TianxingInput` 继承 `BirthInput`，12 个古典口径
  字段是顶层带描述的（agent 照 schema 传完全正确），而 `_run_tianxing_tool` 只读 `payload["options"]`
  → 顶层写法被**静默丢弃**，用默认口径跑出不同结果、零报错。`siderealAyanamsa` 更糟：它不进请求
  （后端回落 Lahiri），却照样印在 `[起盘信息]` 里 —— **输出主动声称了一个没被使用的设置**。
  `precision` 则是纯死旋钮。判据很简单：**改这个参数，结果必须变**。实测 combustOrb 3 vs 17 现在
  给出明显不同的区间（修前完全一样）。

- 🔴 **只读 `snapshot_text` 不看 `data.ok`，会把失败伪造成一份正常导出。** tianxing.js 失败时返回
  `{data:{ok:false}, snapshot_text:''}`；Python 拿到 None → `_augment_export_payload` 回落
  `format_source: "generated_template"` → 产出一份拿 payload YAML 填出来的四段假导出，而 SKILL.md
  要求 agent **只依据 export_text 解读**。stitch 那侧的 `or []` 同理把失败变成「零命中」。
  凡是 JS 侧带 `ok` 的返回，一律走统一的检查入口（`_tianxing_js`）。

- 🔴 **`x is not None` 当守卫用 = 解析失败即放行。** `_day_span` 解析不出来就返回 None，而
  `if span is not None and span > max` 让 `'2026-08-05T00:00'` 这类形状**跳过整个上限**——JS 侧
  wallToMs 却能解析它们，于是超长窗口一路跑到超时。倒置窗口得负数，`负数 > max` 恒 False 同样溜过。
  **解析失败必须报错**。另外 tianxing 此前压根没接窗口上限（真正按段发 HTTP 的是它），5 年窗口
  = 60 次串行扫描，>66 年时 `splitByMonth` 的 800 段 guard 耗尽会**丢掉最后一段**却仍报成完整搜索。

- 🔴 **materialize 一批 regex match 再拿旧偏移切新字符串 = 毁文件。** `revendor_core_js.py` 三处犯这个：
  两个孤儿 namespace import 就能把整个模块体切没（实测 `export function f` 消失）；两条
  `export {…};` 产出 `export {export { q };` 语法错误；第 2 个及以后的孤儿具名 import 静默残留
  （实测 JinKouCalc/TaiYiCalc 里就留着两条）。**边扫边改必须每轮重新搜索**（`_rewrite_inline_requires`
  一开始就是对的，另三处照抄它即可）。同处还有 `"default" in match.group(0)` 的子串误判——
  名单里出现 `defaultRules` 就把具名导出清单翻成 `export default`，所有 `import { x }` 全崩。
  **head 要由「匹配到哪个 pattern」决定，不是子串。** vendor 树是 git 跟踪的，这些会直接进仓。

- **「几处一致」不等于「数字是真的」。** README 五处齐刷刷写 320/63，CI 实测 318/65 —— 一致性守卫
  全绿。一致性只能抓「改了一处忘了另一处」。真值那一半要能**够到源头**：现在断言
  offline + live-skipped == `pytest --collect-only` 的收集总数（静态可得，秒级）。
  同族的还有 README 宣称「Linux / macOS 单测」而仓里**零 macOS runner**，以及公开 README 从不提
  「CI 不覆盖跨树上游校验」（AGENTS 和 ci.yml 注释都诚实，只有面向用户的那份不是）。

- **测试门只探 TCP = 半死的后端会让该跳的测试跑起来然后红。** `_server_up` 只 connect，Java
  「在听但每条业务路由都 500」照样 `RUNTIME_UP=True`。且四个打 `/nongli/time`（走 Java）的测试
  标成了 `@requires_chart`。现在 Java 侧改成功能探针，且探 `/nongli/time` 而不是 `/common/time`
  —— 后者正是那条「其余全死它还绿」的路由。⚠️ 顺序要紧：先修 lat bug 再改门，否则功能探针本身
  会焐热年缓存、把 bug 盖住。

- **文档里一条起服务命令，能让人把真 bug 误判成环境问题一整轮。** `xuanshu-dev/SKILL.md` 的
  PYTHONPATH 少了 `Horosa-Web/vendor`（ken 与神数引擎都在那儿）且用裸 `python`（缺 9 个只装在内嵌
  解释器里的依赖）。照它起服务，taiyi/jinkou/sanshiunited/wangji/taixuan/chunzi 全挂不上，
  症状看着就是「这些技法坏了」。**判据 = 启动日志 `kentang prewarm ready (loaded=18, failed=0)`。**
  经验：**当「环境问题」开始解释越来越多的失败时，先怀疑自己的复现命令。**

### v0.26.0+ / 2026-08-05 — 守卫都对，却一条都不在 Windows 构建路径上（vendor 陈旧可静默出货）

- **症状**：v0.26.0 补 Windows 半边前例行跑守卫，`verify_export_contract_mirror.py` 报
  `tianxing`/`qimenzeri` 不在 vendored 上游键表——本机 `vendor/runtime-source` 停在 08-01，
  而 v0.26.0 的引擎树已对齐上游 v3.7.x（含**会改变既有输出**的六壬三传勘正）。
  **若照常构建**：Windows 用户拿到的引擎落后一整轮同步，且 `verify_runtime_release.py` 只查
  文件在不在、照样全绿放行。
- **根因（两层）**：① `vendor/runtime-source` 是 **gitignored 本地构建输入**——`git pull` 到发布
  commit 不会刷新它，仓库层面看不出陈旧；② 两把新鲜度守卫**只挂在 `release.yml`**，而 Windows 半边
  恰恰是唯一**不走 CI**、在本机 off-CI 构建的产物——**守卫没长在会踩的那条路上等于没有守卫**。
  连带确认上一条台账的「只加键纪律」在这里同样致命：`verify_vendor_runtime_sources.py` 的
  `AI_EXPORT_SETTINGS_VERSION == 50` 恒等**在陈旧树上照样绿**（上游加键不 bump 版本），
  唯一能判红的是 mirror 的**逐键覆盖**——所以两把必须都跑，缺一个就漏。
- **guard**：`sync_windows_release.py` 新增 `preflight_vendor_sources()`，在**调用 builder 之前**
  依次跑两把守卫，任一红即 `SystemExit` 并给出重灌指引（拒绝构建，而不是构建完再说）。
  回归 `tests/test_sync_windows_release.py`：两把都被调用 / 任一红都拒绝 / **preflight 必须早于
  builder**（顺序断言——闸开在 builder 之后等于没开）。
- **法则**：新增任何「只在 CI 跑」的守卫时，问一句**这条路径 CI 走得到吗**；Windows/离线 runtime
  这类 off-CI 产物必须在其**本机入口脚本**里复跑同一把守卫。

- 🔴 **那 4 条 live 红被误判成「本机无 Mongo」整整几个版本——实测是另一回事。**
  台账/交接口径一直说：本机 live 全套必有 4 红（`xiaoliuren` / `feigong` / `zhengchuan`×2），因为无
  Mongo 时 Java 侧一律 `no.register.app.in.sys`，「环境限制而非代码问题」。**本轮逐一实测推翻**：
  ① 经 skill 正规路径（`_call_remote`，带 app 注册归一化）打 Java **是通的**——`doctor issues: []`、
  两端点 reachable、382 条 live 用例通过，其中大量走 Java；② 这 4 条报的是
  `ResultCode 9999 / "begin 1, end 3, length 1"`（上游 `substring(1,3)` 打在长度 1 的串上），
  **与 `no.register.app.in.sys` 是两个完全不同的错**；③ 实测矩阵定位触发条件是「**日期 × 缺 `lat`**」
  的组合，不是单一因素：
  | 载荷 | 结果 |
  | --- | --- |
  | `2028-04-06` + 仅 lon | ok |
  | `2028-04-06` + lon&lat | ok |
  | `2026-05-20` + 仅 lon | **500 / begin 1, end 3, length 1** |
  | `2026-05-20` + lon&lat | ok |
  给这 4 条测试的载荷补上 `lat` 即全绿。**结论**：这不是 Mongo/环境问题，是上游对某些
  「日期+无纬度」组合的输入处理崩溃，skill 侧原样透传成不透明 HTTP 500。
  **未决**：上游真因需在有上游源码的机器上定位（本仓对上游只读）；skill 侧该「先问 lat」还是
  「转结构化错误」待定，故本轮**只纠正判据、不改代码**。
  **法则**：「已知非回归」这类豁免必须挂在**可复现的判据**上（此处 = 错误串 + 复现矩阵），
  不能挂在测试名单上——名单会把后来的真 bug 一起豁免掉。裸 HTTP 探针在本机不可用
  （无 Mongo 注册，任何形状都回 `no.register.app.in.sys`），**判据一律取 skill 正规路径的结果**。

- 🔴 **五个 stamper 可以「一致地错」——N 路互证够不到源头常量**（同轮补 Windows 半边时发现）。
  **症状**：装完新构建的 v0.26.0 runtime，内嵌 manifest 写 `export_registry_version: 11`，而
  v0.26.0 的择日提交已把 `AI_EXPORT_SETTINGS_VERSION` 11→12。**根因**：`verify_builder_parity.py`
  的 `SHARED_MANIFEST_CONSTANTS` 只做 **stamper 之间**的 N 路交叉断言——五个 stamper 全停在 11 时
  它们彼此完全一致，守卫必绿。这是 v0.16.1（mac 单边 6→7）那条教训的**镜像面**：当年怕的是「有人漏
  bump 一个」，这次是「**没人 bump 任何一个**」，同一把守卫对后者天然失明。
  **实证**：v0.22.0~v0.25.0 两数恒等（10=10、11=11×3），v0.26.0 首次分叉。
  **guard**：`ANCHORED_CONSTANTS` —— `export_registry_version` 锚定到
  `exports/registry.py::AI_EXPORT_SETTINGS_VERSION`（源码解析），五个 stamper 必须同时等于它。
  加完先跑一遍**确认它对本次真漂移判红**（五个都报 lagging），再 bump 到 12 转绿；
  `tests/test_verify_builder_parity.py` 用假 registry 常量钉死锚定生效。
  **法则**：交叉断言只证明「彼此一致」；凡有**源码里的权威常量**，守卫必须锚到它，否则一致地错=绿。
  **本次处置**：v0.26.0 的 darwin 半边已发布且 stamp 11，故 Windows 半边**照 11 出货**（同版内两平台
  一致优先——该字段无运行时消费方，只是元数据）；stamper 已改 12，v0.27.0 起两边都对。

### v0.26.0 / 2026-08-04 — 上游 v3.7.x 同步：三个**机制**缺口比内容缺口更贵

本轮真正的发现不是「少了两个技法」，而是**四把守卫全绿的情况下少了两个技法**。内容一天补完，
机制缺口不堵会以同样的形状再来一次。

- 🔴 **上游会「只加技法键、不动版本闸」——版本恒等永远测不出新技法。**
  上游 `aiExport.js:306` 把纪律写死了：「新技法键只加键、两把版本闸恒不动——老用户本无自定义走
  preset 全量」。那是针对 localStorage **迁移闸**的正确纪律，但下游拿版本号当「上游有没有变」的
  探针就此失效：`tianxing`(v3.7.0) 与 `qimenzeri`(v3.7.1) 都在 `AI_EXPORT_SETTINGS_VERSION = 50`
  不变的情况下到货。
  → 唯一可能的信号是**技法键集合差分**。`verify_upstream_sync.py` 新增 check 1b，把上游 preset 键集
  与 `contracts/upstream_provenance.json` 记录的键集相比，报「upstream gained N technique key(s): …」。
  两个方向的基线**不同**：gained 要并上「skill 已登记的键」（登记即已处理，让检查在登记后自愈），
  lost 只能对着 recorded（skill 合法持有 `acg`/`astrodata`/`wangji` 这些上游无对应的键，并进去必误报）。

- 🔴 **`_upstream_preset.py` 看不见对象字面量之外的 preset 条目 —— 20 段整键隐形。**
  上游 `AI_EXPORT_PRESET_SECTIONS.qimenzeri = [...AI_EXPORT_PRESET_SECTIONS.qimen, …]`
  写在字面量**闭合之后**（aiExport.js:735）。`_object_block` 只做花括号匹配，于是整个 `qimenzeri`
  从未进入解析结果——段级欠账棘轮一边报「0 absent keys」，一边漏着一个 20 段的技法。
  这是该 docstring 已记的两个陷阱（注释里引段名 / `...JIEQI_SETTING_PRESETS` spread）的**同族第三个**。
  → 补一趟成员赋值扫描，且必须跑在字面量+spread 之后（它的 spread 要对着已解析的 `qimen` 求值），
  token 按**源码顺序**走，spread 段与字面段才能正确交织。`tests/test_upstream_preset_parser.py` 钉死。

- 🔴 **`revendor_core_js.py` 的落地路径靠猜，会分叉出重复树。**
  它按上游父目录名推断 vendor 子目录，但本树是按技法分目录的：`utils/balbillus.js` 的真身在
  `vendor/astroextra/`。实测不带 `--vendor-subdir` 驱动全树，会造出 `vendor/utils/balbillus.js`
  与真身并存，且 relocate 还会把别的文件的 import 指回**新造的那棵**。
  → `contracts/vendor_manifest.json`：显式 upstream↔vendor 路径对 + 声明式偏离（`stub_import` /
  `import_redirect`），三种 mode（verbatim / curated / bespoke）各有可断言的判据。此后
  `--from-manifest --check` 全树 `unchanged` 就是「已同步」的机械结论，不再靠考古。

- 🔴 **`--write-state` 在守卫失败时照写 —— 把失败洗成一条持久的「已核对」声明。**
  写入在 `:145`、失败 raise 在 `:162`。本轮实测复现：sync 脚本跑完守卫 FAIL，`vendor_sync_state.json`
  仍被写成「最近一次核对过的上游状态」。**红着写比不写更糟**——没有记录只是不知道，错误记录是被骗。
  → 写入移到 raise 之后，并由 `tests/test_verify_upstream_sync.py` 断言源码顺序。

- **裸 sha256 对未变换的上游比对，注定永远红。** vendored 文件个个带 headless 变换，raw 比对报 133/257
  漂移，其中大半是变换本身。**永远红的检查等于没有检查**——人会学会略过它。
  → check 3 改用 manifest 作 oracle：按声明的偏离重渲染上游，再比对。可达到的绿才是有意义的绿。

- **中文措辞躲过了英文正则。** `verify_docs_sync` 只认 `badge/tools-(\d+)-`；中文 README 用
  `badge/技法-83-`，于是在注册表已到 89 时陈旧了整整一个版本，**同一行的 `alt="89 tools"` 就在旁边**。
  同类漏网还有 `manifest.json`、`banner.svg`、以及**发给每个 MCP 客户端**的 `_SERVER_INSTRUCTIONS`
  （两处 83，此前无任何守卫读它）。旧闸报 0 处，新闸一次报出 16 处。
  → 教训不是「数字写错了」，而是**守卫的覆盖面被措辞的偶然决定**。计数检查一律做成语言无关，
  并对「同一行 badge 与 alt 自相矛盾」单独设断言——那种自相矛盾任何时候都是 bug。

- **上游工作树是活的。** 本轮进行中上游连提交两次（`afdac78` → `8fe5771` 二十八宿六处算法勘误
  → `23aa38e`），中途还出现过未提交的 WIP。守卫按**磁盘文件**比对，于是别人的未提交编辑会读成
  「上游漂移」，而照着 re-vendor 等于把**未评审的半成品**打进发布物；provenance 记的又是 commit，
  脏树让那条记录自相矛盾。→ 新增 check 0：脏树在本地只提示，`--require-upstream`（发布链）判红。

- **「已 vendored」≠「是当前的」。** `qimenzeri` 依赖的 `DunJiaCalc`/`DunJiaBaGongRules`/`baziLunarLocal`
  三个文件都在树里，但都是旧版，缺的正是新模块要 import 的符号。查依赖要查**具体符号**，不是查文件在不在。

- **`gua/liuyaoTianshi.js` 从未 vendor —— `liuyaoFacade.js` 一直 import 着一个不存在的模块。**
  上游 v3.6.0「六爻天时占法五家」，本仓漏了整整一个文件。同类：`taiyi/core/taiyiSchool.js` 的
  `../../../utils/dateStrSafe.js` 是死链，只因无人 import 才没炸。两者都是 `loadcheck.mjs`（新增，
  `import()` 全部 264 个 vendored 模块）当场抓到的。**AGENTS §5 说得对：load 过 ≠ 真盘不崩——
  但 load 不过一定崩，而这一层此前完全没有。**

- **`selfcheck.mjs` 断言的是形状不是值 —— 三传重排能静默通过。** 六壬只断言
  `sanChuanBranches.length === 3`。上游 v3.7.1 两处勘正（#46 八专/遥克判定序、#62 伏吟末传子卯互刑）
  恰好改的就是三传。
  → **穷举分桶把「是不是回归」从判断题变成计数题**：60 日干支 × 12 月将 × 12 时 = 8640 课全跑，
  新旧差分 336 条，三传变 120 / 仅课名 216；伏吟桶恰为 **丁卯/己卯/辛卯** 三日（上游自述
  「全域仅此 3/720 课变」），非伏吟桶恰为 **己未/庚申/甲寅** 三个八专日，上游点名的
  「甲寅日戌将丑时/午时」2/2 命中，**桶外 0 条**。桶闭合即证明「改动恰好是上游那两处修复」。
  ⚠️ 上游自述当年「并用金标锁死」了**错**答案——这个文件上「golden 变了」不构成回归证据。
  → 两个具名课式已值级钉进 `selfcheck.mjs`。

- **一次 re-vendor 抹掉两处蓄意偏离，都是被测试当场抓到的。**
  ① `tarot/engine/shuffle.js` 上游 v3.7.x 把 sha256 从 `node:crypto` 换成 `node-forge`，整棵
  `tarot/engine` 因缺包加载失败（loadcheck 抓到）→ 改用 `stub_import` 提供 forge 形状的 shim，
  上游函数体保持逐字。② `zhengchuanTiebanLocal.js` 的**动态** `import('./x.json')` 也需要
  `with { type: 'json' }`，而变换的正则只覆盖静态 import（selfcheck 抓到——loadcheck 抓不到，
  因为那是懒加载路径）。后者是通用规则，已并入 `transform()`。
  → 蓄意偏离必须**声明**（manifest）或**机械化**（transform），写在文件里的偏离下一次重 vendor 必被抹掉。

- **`_reexport_required` 只认 `export function`，不认尾部 `export { … }` 清单。** 上游给
  `baziLunarLocal` 的 `buildFlowDays/buildFlowHours` 补了尾部清单，于是自动补 export 变成
  "Duplicate export"，模块整个加载不了。loadcheck 抓到。

- **两个同名 `AstroConst.js` 是一个真陷阱。** `src/constants/`（151 行共享 shim，**有** `SignsProp`/
  `LIST_SIGNS`）与 `src/vendor/constants/`（32 行 Uranian 子集，**没有**）。上游写
  `'../constants/AstroConst'`，在 vendor 树里恰好解析到**后者**，relocate 因此认为无需重指——
  `SignsProp` 静默变 `undefined`，`buildTriplicityPeriods` 真机抛 `reading 'Gemini'`。
  → 三个 astroextra 文件 + `tianxingSnapshot` 都用 `import_redirect` 钉死到共享 shim。

- **条件树用 passthrough，不建模。** 上游两套条件表共 60+ 类，各自 `params` 形状/`validate`/`compile`
  都不同。在 skill 侧重编一遍 = 造第二份真值源，上游一加条件类就烂。让 vendored `compileTree`/
  `compileQimenTree` 跑各叶子自己的 `validate`，错误信息还是本地化的。可发现性放 `agent_guidance`。

- **`scanQimen` 吃的是编译后的树，不是 UI 树。** UI 树 `{kind:'group', joiner, children}` 供快照渲染，
  编译树 `{type:'all', conditions}` 供求值。传错**不会报错**——它安静地匹配不到任何东西，
  产出一个看起来完全合理的「零命中」。真机实测 0 命中才发现（同窗同条件正解是 11 命中）。

- **零命中不是缺段。** 两个新技法的段头都是**无条件 push**，零命中时上游写的是「时间段内无满足条件的
  时辰。」这类真话。所以它们**不进** `AI_EXPORT_OPTIONAL_SECTIONS`——登记成 optional 等于拿一个真实的
  回归探测器（builder 哪天不产该段了）换零收益。判据是**读 builder 源码**，不是猜「搜索可能没结果」。

- **`/electionscan/scan` 属「HTTP 200 带失败信封」家族。** 失败包成
  `{"ResultCode": -1, "Result": {"err": …}}`，而 `XuanshuPlainJsonClient` 只看顶层 `err` → 不加守卫
  时 `span_too_large` 会**静默退化成零命中**。新增 `_require_electionscan_ok`，与 `_require_ken_pan` 同族。

- 🔴 **第四个机制缺口：点哨兵永远覆盖不全整棵引擎树（同批复盘时才发现）。**
  以为 v3.7.x 已经同步干净，再审一遍才发现 `vendor/kintaiyi/src/kintaiyi/jieqi.py`
  **卡在有 bug 的首版**：`datetime.datetime(year,…)` 只支持公元 1–9999，而太乙服务的是全年份域
  （前 12999 ~ 16799），域外直接 `ValueError` —— 上游自己的注释写着这会「炸掉整个 taiyi/pan
  （kentang 极端年矩阵三例转红）」，它已改为全程走 `ephem.Date`。
  漏掉的原因很具体：**7 个哨兵一个都不在 ken 引擎目录内部**（`vendor/` 下唯一那个
  `kin_year_domain.py` 是根级共享件），而 `verify_vendor_runtime_sources` 只查
  `REQUIRED_PATHS` 是否**存在**、不查内容。于是「引擎文件在、但是旧的」这一整类漂移无人看管。
  → 新增 check 2b **整棵子树逐文件比对**（`Horosa-Web/vendor` ken 引擎 / `astropy/astrostudy` /
  `astropy/websrv`），三个方向都报：内容改了、vendored 有而上游没了、上游有而 vendored 缺。
  两条实现纪律：① **比对口径必须等于同步口径**——排除集要逐条对齐 sync 脚本的 RSYNC_FILTERS 与
  kinastro 裁剪，否则守卫会对着「本就故意没拷」的文件恒红（README.md / .github 就这么先红了一轮）；
  ② 「上游有而 vendored 缺」只在**已 vendor 的顶层目录内部**判，根级杂项不算欠账，
  但上游**整个新增的顶层目录**单独报一行——那才是「新引擎/新能力」的信号。
  已做负向对照：故意改脏 jieqi.py，守卫精确报出该文件；还原即绿。不是空绿。

- **一次「已经同步完了」之后再审一遍是值的。** 本条就是在宣布 v3.7.x 同步完成、三个提交都落地
  之后，重跑同一套审计发现的。守卫全绿只等于「守卫覆盖到的部分是绿的」——覆盖面本身要被质疑。

- **上游 UI 层改动不必跟。** 同批 `ZeriMain/DunJiaMain/SanShiUnitedMain/models/astro/perfFlags`
  五个文件共 +75 行，全是 `requestIdleCallback` 预挂载 / `forceRender` / kill-switch 之类的
  响应性改造，零引擎逻辑（逐行核过），且五个文件本仓一个都没 vendor（都是 React 页面壳）。
  判据：本仓 vendor 的是**引擎**（DunJiaCalc / sanshi/core/*），不是页面壳。

- **契约版本该不该跟着上游不动？不。** 上游那个数是 localStorage 迁移闸（新键无存档，迁移本就是
  no-op）；skill 这个数是**内容版本**，进每个信封的 `settings_used.version`，是下游判断「段目录变了」
  的依据。24 个新段正是该事件，故 11 → 12（仓内先例：v8 三技法入册、v11 五技法入册）。
  `MIRRORED_UPSTREAM_AIEXPORT_VERSION` 保持 50——上游数字确实没动。两个数字语义不同，别「修」成一致。

### v0.25.1+ / 2026-08 — 被指定为「唯一能做真」的那条发布闸，20 次里一次都没跑过

**症状**：v0.25.1 发完复查，发现 `Release Runtime`（`release.yml`）那次 run 卡在 `queued`。翻历史：
**从 v0.9.2（2026-06）到 v0.25.0，20 次 tag 触发的 run 全部 `cancelled`**。抽查 v0.25.0 那次：
created `08/01 17:08:57` → updated `08/02 17:09:04`，正好 24 小时，`build-release` job
`conclusion=cancelled`、**一个 step 都没执行**。

**根因**：`release.yml` 是 `runs-on: self-hosted`，而 `gh api repos/.../actions/runners` 回
`total_count: 0`——仓库**从来没有注册过 self-hosted runner**。于是每次推 tag 都排队到 GitHub 的
24h 上限被自动取消。而这条流水线**独占**着三样东西：① `verify_upstream_sync.py --require-upstream`
② `verify_export_section_baseline.py --source upstream --require-upstream` ③ SBOM + 构建 provenance
attestation。`ci.yml` 里虽然也调前两个脚本，但**不带 `--require-upstream`**，GitHub runner 上没有上游
checkout，脚本自报 `{"skipped": true}` 直接放行（那个 step 名字本身就写着 "skipped without an upstream
checkout"）。两处合起来 = **「vendored 树 vs 上游 HEAD」这一类漂移在任何自动化环境里都从未被断言过**，
而 runs 页面上显示得像有覆盖。

**同一次排查里还揪出第二个空转的**：`verify_export_section_baseline.py` 的 docstring 白纸黑字写着
vendored 模式 "works with no upstream checkout, e.g. GitHub CI"，ci.yml 的注释也跟着说「基线本身的
自洽在这里就能红」——**两句都是假的**。它读的 `vendor/runtime-source` 是 **gitignored** 的，CI 全新
checkout 上根本没有，实测输出 `::notice::export-section-baseline skipped`。于是段级欠账棘轮
（「只减不增」那道）在 CI 里同样零断言。**注释写「这里能红」不等于真会红——要去 run 的注解里看。**

旁证：`contracts/vendor_sync_state.json` 至今记着
`skill_mirrored_version: 48`（v0.24.0 手工跑时写的），而 registry 常量从 v0.25.0 起已是 **50**——
那个专门用来「避免 vendored 树静默落后」的文件，自己静默落后了两个版本。

这是 v0.24.0「守卫结构性失明」的**第四例**，也是最讽刺的一例：为了堵住失明而新建的守卫，本身从不执行。
前三例是守卫射程不够（比对自己的 vendored 拷贝 / 只比键不比段 / 正则只认英文标签），这一例是**守卫压根
没运行**——比射程不够更难发现，因为射程可以读代码看出来，「有没有真跑」只能去翻 runs 历史。

**守卫/法则**：

- **判一个守卫是否有效，先问「它上一次真跑是什么时候」，再问「它断言了什么」。** `runs-on: self-hosted`
  + 零注册 runner = 永久排队后取消，颜色是灰的不是红的，谁都不会注意。
- `release.yml` 去掉 `push: tags` 触发，改为**仅 `workflow_dispatch`**——宁可明确没有，也不要一条看起来
  在跑、实际每次都被取消的流水线。
- 跨树两闸落地为**本机 pre-tag 步骤** `scripts/preflight_release.py`（须 `XUANSHU_SOURCE_ROOT` 指向
  xuanshu-engine，否则直接拒绝运行），写进 AGENTS §7 发布协议。成功会重写
  `vendor_sync_state.json`，**该 diff 即「跨树核对真发生过」的 git 证据**。
  （v0.26.0 起该文件已被 `contracts/upstream_provenance.json` 取代——超集，另记上游 commit /
  应用版本 / preset 键集 / core-js 树摘要；`tests/test_verify_upstream_sync.py` 断言旧文件必须不存在。）
- `verify_upstream_sync.py` 在无上游树时**不再纯 skip**：改为断言 state 里的 `skill_mirrored_version`
  是否仍等于 registry 常量，落后就打 `::warning`（当前就在报 48 vs 50）。CI 保持绿（避免 v0.25.0 那种
  带红上 main），但漂移从此在每次 run 里可见，而不是无声无息。
- `verify_export_section_baseline.py` 同样不再纯 skip：无 aiExport 源时改为断言**基线 vs 仓内 registry
  自洽**（`_assert_baseline_coherent`——基线里的键必须都还在 `AI_EXPORT_PRESET_SECTIONS` 里），抓
  「技法改名/删了而基线还留着旧键」。已用反向测试确认它**真会红**（往基线塞一个不存在的键 → FAIL）。
  docstring 与 ci.yml 里那两句不实描述一并改掉。
- **`::warning::` 是单行命令**：消息里带 `\n` 会被 GitHub 在第一个换行处截断，注解结尾留个悬空冒号
  （第一版就是这样，补救命令整条没进注解）。补救指令必须写在同一行。

### v0.25.1 / 2026-08 — 第一次真跑全套 live：7 红里 4 个是本机无 Mongo、2 个是真段缺陷、1 个是隔离没做全

**症状**：在 v0.25.0 runtime（独立 root `rt-verify`，心跳 `pdSyncRev = pd_method_sync_v15` 与当前 rev 一致）
上跑全套 `uv run pytest` → **7 failed / 332 passed / 1 skipped**；而同一棵树在服务未起时是
**278 passed / 62 skipped / 0 failed**。更迷惑的是 `doctor` 同时报 `status: ready` + 双端点 reachable。

**根因分三类（别混为一谈）**：

1. **4 条死在 `/nongli/time`** ：`xiaoliuren` / `feigong` / `zhengchuan_tieban` / `zhengchuan_dading`。

   > 🔴 **本条的归因在 v0.26.1 被推翻，保留原文供对照。** 当时判为「Java 聚合层的 app 注册在 Mongo 里，
   > 本机无 Mongo → 这一族路由恒 9999（`no.register.app.in.sys.forapp`）」。v0.26.1 复审实测：**Mongo
   > 在跑**、日志里**零** `no.register.app`、真实错误码是 **`200001 param error`**。真因是**本仓的产品
   > bug**：这五个占时工具（还有无测试覆盖的 `xiaochengtu`/`guice`）用 `payload.get("lat")` 取值，而
   > schema 把 `lat` 列为可选 → 把 **`lat: null`** 发给要求 lon+lat 均非空的 `/nongli/time`。
   > 对照 `qimen`/`taiyi` 用的是 `payload["lat"]`（必填），所以它们从来不犯。
   >
   > **为什么会误诊成环境问题**：Java 的农历结果按**年**缓存。任何一次带 lat 的请求都会把该年焐热，
   > 此后同年的无 lat 请求**全部成功**。于是它表现为「有时好有时坏、换台机器就好了」。决定性实验：
   > 同一 commit 下先对 1998 年发一次带 lat 的请求，两个原本红的 zhengchuan 测试立刻转绿。
   > **诊断这类「时好时坏」务必换一个冷年份**，否则你在测一个已经被自己焐热的缓存。
   > 修复见 `service.py::_require_cast_geo`（缺 lon/lat 提前报结构化错误，不再把 null 发出去）。

   下面这段关于 doctor / selfcheck 的结论**仍然成立**，与归因无关：**`doctor` 探的是 `/common/time`，根本不碰这族路由——
   所以 `status: ready` 不构成「Java 侧技法可用」的证据。`selfcheck` 更迷惑：它的 `compute` 步骤
   报 `tool: nongli_time, ok: true`，但那是 issue #14 加的 **chart 侧回退探针**在答题——同一时刻
   直接 POST `/nongli/time` 仍是 500 / 9999（v0.25.1 装完新 runtime 实测）。
   **doctor 绿 + selfcheck 绿 都不等于这族路由活着。**
2. **2 条是 v0.25.0 段级回填留下的「陈旧断言」，不是产品缺陷**——第一直觉判成段缺陷是错的，
   判据是**去 preset 里查这个段名到底还在不在**：
   - **`taiyi`**：断言写 `assert "[起盘]" not in snapshot`（"no doubled 起盘"）。但上游 v50 起
     `起盘` 已是**注册在 taiyi preset 里的正式透传段**，与 builder 的 `[起盘信息]` 并存是对的。
     旧断言编码的是 v50 之前「后端 起盘 段被丢弃」的行为。
   - **`acg`**：断言写 `assert "[行星线经度]" in snapshot`。但该旧段名在 v50 已**并入单段
     `占星地图`**（`registry.map_legacy_section_title` 里就写着这条映射），preset 里只有 `占星地图`。
   两者都是「registry 改了、live 断言没跟着改」，而 live 测试**进不了 CI**，于是无人发现。
3. **1 条是隔离没做全**：`test_error_paths_return_a_conformant_envelope`——v0.25.0 之后新加的 autouse
   fixture 把 `XUANSHU_RUNTIME_ROOT` 钉到空目录，本意是与 CI 同形；但**默认端口上有活服务**时它照样失败，
   因为只钉了 runtime root、没钉 service endpoint，请求照样打通 → 本该失败的错误路径成功了
   （`assert True is False`）。CI（无服务）绿、维护机（服务在）红，正是 v0.25.0 那条教训的**镜像**。

**法则/守卫**：

- **「live 全绿」在无 Mongo 的机器上不可达**——干净 Windows 机的最强信号只有 chart 半边。README 的测试数
  因此改按**离线 CI 形状**标注（278 passed / 62 skipped），不再声称一个没人真验过的 `N / N pass`。
- **改 export preset / 段名映射时，必须同步 grep live 测试里的段名断言**。段级回填（v0.25.0 那种
  216→7 的大批量）只跑得动 CI 里的离线契约；`@requires_runtime` 的段名断言在 CI 里恒 skip，
  改错了要等下一次有人真起服务才炸。判据永远是 **preset 里有没有这个段名**，不是凭印象说「重复/缺失」。
- 想把 `requires_*` 测试真正钉成 CI 形状，**必须同时把 service root 指到不可达地址**——只钉 runtime root
  不够（本条是 `XUANSHU_RUNTIME_ROOT=<空目录>` 复现法的补丁：那招只在服务也没起时成立）。
- 判 Java 侧是否真可用，别看 `doctor`，直接打 `/nongli/time` 看是不是 `ResultCode 9999`。

### v0.25.1 / 2026-08 — 中文首页的数字漂了两代，因为守卫的徽章正则只认英文标签

**症状**：`verify_docs_sync.py` 全程绿，而 `README.md`（中文首页 = 默认落地页）上：徽章写
`技法-83`（同一行的 `alt` 却写着 "89 tools"）、验收表写 `可调用工具 83 / 83`、`已建模 63 个导出
technique`；测试数四处写 `326` 而 `README_EN.md` 的代码块写 `315`；`📦 Release runtime` 行还写着
「Windows (x64) 由构建机补传（补传前 win 用户拿到上一版 runtime）」——而 v0.25.0 的 Windows 半边
早在 2026-08-02 就已补齐，`sync_windows_release.py --check` 判定 in-sync。即：中文首页在劝退
Windows 用户，并把工具数少报了 6 个。

**根因**：`check_tool_coverage()` 的徽章正则是 `badge/tools-(\d+)-`，只能匹配 EN 侧的
`badge/tools-89-`；zh 侧标签是中文的 `badge/技法-83-`，**整个漏出守卫射程**。于是 83→89 那次 bump
只有被守卫盯着的 EN 侧被迫改对，中文首页无人拦。同源问题一串：验收表的 `可调用工具 N / N` 与
`已建模 N 个导出 technique` 都是 registry 的纯函数，却从来没人断言。测试数更糟——它**无法从代码静态
推出**，于是五处提及各写各的，分叉成 326×7 + 315×1 谁也没发现。这是 v0.24.0「守卫结构性失明」的第三例：
守卫不是不存在，是**射程比它自称的窄**。

**守卫**：① 徽章正则拓宽为 `badge/(?:tools|技法)-(\d+)-`；② 新增 zh/EN 两侧「可调用工具 N / N」行
断言 == `len(TOOL_DEFINITIONS)`；③ 新增「已建模 N 个导出 technique」断言 == `len(AI_EXPORT_TECHNIQUES)`；
④ 测试数不可静态推导 → 新增 `check_test_count_consistency()`，只守「两份 README 的所有提及必须是同一个
数」，首跑即抓出 315/326 分叉；⑤ `本地 memory / report 83 / 83` 这类**既推不出、也没有测试覆盖的手测
计数**直接改写成结构性陈述（「每次技法调用写 1 条 run 记录 + 1 份 JSON artifact」），不再留一个会腐烂
的数字。

**法则**：README 里的每个数字，要么**能从代码断言**（那就当场加断言），要么**改写成不含数字的结构性
陈述**——绝不留「只能靠人记得更新」的计数。双语文档的守卫正则**必须覆盖两种语言的标签**，只写英文
pattern 等于只守了一半。

### v0.25.0+ / 2026-08 — 一个 em dash 打死整个 Windows runtime（无 BOM 的 .ps1 + PowerShell 认花引号）

- **症状**：v0.25.0 Windows 半边刚建完，装进独立 runtime root 跑 `selfcheck` → `runtime.start_failed`，
  stderr 是启动器自己的 **4 个 parse error**：`Missing closing '}' in statement block`、
  `Unexpected token 'chartpy:'`、`The string is missing the terminator: "`——启动器**一行都没跑**就死，
  Java/chart 双半边全不起。zip 里文件一个不少、`verify_runtime_release.py` 全绿。
- **根因链**：① runtime manager 用 `powershell`（**Windows PowerShell 5.1**，见
  `manager._platform_command`）跑 `.ps1`；② 5.1 对**无 BOM** 的 `.ps1` 按**系统 ANSI 代码页**解码
  （本机 ACP=1252）；③ UTF-8 的 `—`(U+2014, `E2 80 94`) 于是解成 `â` `€` + **U+201D**；
  ④ PowerShell 词法分析器**把 U+201D 当字符串定界符**——`Write-Host "…without them — it may…"` 的字符串
  就地截断，后半行变成代码，级联炸穿整个文件。
- **为什么以前没炸**：`—` 早就在这两个模板里（v0.12.0 加固时进的注释），但**都在注释行**——注释到行尾
  为止，混进一个花引号也无所谓。issue #14（`3706c94`）把降级提示写进了一个 **`Write-Host` 字符串字面量**，
  这是第一次让非 ASCII 落进可执行的字符串里；而那之后**第一次 Windows 构建**就是本次 v0.25.0 补建。
  实证：同一文件去掉 BOM + 把 `—` 放回字符串 → 4 errors；去掉 BOM 但字符串里用 ASCII `-` → parse OK。
- **修复**：两个模板改为 **UTF-8 with BOM**（正解，连注释里的 `格局/神煞` 也不再 mojibake）+ 那条
  `Write-Host` 里的 `—` 换成 ASCII `-`（第二层：BOM 万一被工具剥掉也不会炸成 parse error）。
  `manager._apply_runtime_overrides` 与 builder 都是 `shutil.copy2`，BOM 逐字节随行。
- **守卫**（三层）：① `tests/test_runtime_launcher_templates.py`——BOM 断言 + 「非 ASCII 只许出现在注释行」
  （到处跑，含 Linux CI）；② 同文件里 Windows-only 用 `powershell`
  `[Parser]::ParseFile` **真解析**，CI 的 `windows-smoke` job 会执行；③ 发布闸
  `verify_runtime_release.py::_assert_windows_launchers_are_bom_encoded`——直接读 zip 里那两个 `.ps1`
  的前三字节，上传前拦住（配套 fake-zip 正反测试）。
- **横切教训**：`verify_runtime_release.py` 查的是「文件在不在」，查不出「文件能不能跑」。**跨引擎升级版的
  Windows 补建必须真装真跑**（AGENTS §7 的 native-verify 一步不能省）——这次正是靠它逮住的，否则上传的
  就是一颗谁也起不来的 runtime，而所有绿灯都会说没问题。

### v0.25.0+ / 2026-08 — 维护机装着 runtime，把「其实要 runtime」的线材契约测试藏到了 CI 才炸

- **症状**：v0.25.0 发布 commit 的门禁本地 254 passed 全绿，push 后 main 上 `CI` 的 `test` 与
  `windows-smoke` **两个 job 同时红**——`tests/test_mcp_contract.py` 的
  `test_numeric_coordinates_reach_normalization_instead_of_being_rejected` 与
  `test_request_escape_hatch_works_over_the_wire` 断言 `ok is True`，实收
  `error.code == runtime.not_installed`。两平台同一原因，红了一整天没人发现（发布当天没人再看 CI）。
- **根因**：这两条是**线材契约**测试（考 MCP 面广告的 schema / 归一化 / `request` 逃生通道），却用
  「算成功」当判据 → 走 `call_tool` 一路真算。维护机装着离线 runtime，所以本地恒绿；CI runner 上没有
  runtime，`_require_runtime` 直接抛 `runtime.not_installed`。**「本地全绿」在这类测试上不构成证据——
  维护机与 CI 的形状不同**，而 CI 是唯一无 runtime 的环境。
- **顺带挖出的第二个真 bug**：`ToolEnvelope` 的顶层镜像三键（`code`/`message`/`details`，
  `schemas/common.py` 明写「使既有按 code/message/details 读的调用方零改动」）**只在 MCP 面构造的错误
  信封上填**（闸门 / pydantic 校验），`service.run_tool` 自己构造的错误信封一个都没填 → 最常见的失败
  （`runtime.not_installed` / `tool.ken_compute_failed` / `transport.*` / `tool.internal_error`）在顶层
  `code` 上读到 `None`。既有测试只覆盖闸门那条路径，所以「信封契约」看起来是有守卫的。
- **守卫**：① `test_mcp_contract.py` 加 autouse fixture 把 `XUANSHU_RUNTIME_ROOT` 钉到空临时目录——
  整个文件**一律在「runtime 未安装」形状下跑**，维护机与 CI 同形，此类依赖当场暴露（新写的线材测试
  再想偷偷依赖 runtime 也会本地就红）；② 两条测试改为断言真正要考的东西（`input_normalized` 里
  数字经纬度已被吸收成 `39n54`/`116e24`；逃生通道的内层字段确实到了归一化），并共用
  `_assert_passed_the_mcp_surface`（只否掉 `tool.invalid_payload` / `agent_guidance.required` 两个
  「归一化之前就被打回」的 code），与本机有没有 runtime 解耦；③ `run_tool` 两条错误路径 + dispatch
  解析失败路径补齐镜像三键，`test_error_paths_return_a_conformant_envelope` 扩到闸门**之后**的失败
  信封，逐键断言 `顶层 == error.*`。
- **可复现判据**（没有 CI 也能在维护机上验）：`XUANSHU_RUNTIME_ROOT=<空目录> uv run pytest` —— 这条
  等价于 CI 的形状；发版前值得跑一遍。

### v0.25.0-dev / 2026-08 — 段级欠账回填（批 1 起）

- **印占 53 段：verbatim vendor 胜过 Python 移植。** 上游 `buildJyotishSnapshotLines`（IndiaChart.js:479，
  578 行）是**纯格式化**函数——读后端已算好的 `chartObj.jyotish`（30 个子树）产 51 个具名段。闭包极小
  （只依赖 7 行 `gfmTable`，`PCN` 是块内局部量，零 AstroConst 依赖），逐字 vendor 后真盘一次跑通 57 段。
  若手抄成 Python 是 600 行抄写面，任一措辞漂移都会与桌面端不一致。**判据**：纯格式化 + 小闭包 = vendor；
  只有需要发 HTTP 或依赖 Python 侧数据时才移植。
- **`js_client.run()` 已解包 envelope 的 `data`**，返回的就是 runner 结果对象。照 `_attach_natal_extras`
  的样子写成 `js.get("data")` 会恒为 None → 段静默不出（本轮踩了一次，表现为「挂载了但段数没变」）。
- **上游用占位段名登记动态段族**：印占 11 个 `座运·<变体>` 在 preset 里是单个 `座运·X`（同 horary 的
  `专题深化·X`）。折叠规则加进 `map_legacy_section_title`，否则实产段全成 unknown。
- **段名折叠方向要跟上游走**：canping/heluo 早期把上游长名（`大运·歲運`/`先天卦·元堂爻辞`）折叠成短名，
  而上游 preset 现已正式声明长名 → 反转映射（canonical=长名，短名留作向后兼容）。
- **主限法语义变更（v3.6.0）**：`pdSyncRev` v12→**v15**，方位法从「核 5 + legacy」开放到全谱 13 法，
  **placidus 已是真方位法、不再回退 core_alchabitius**（实测 114 行 vs 64 行）。原测试断言「两法逐位
  一致」在新引擎下必红，而且方向危险——引擎真回退时它反而会绿。已改为「都产真行集且彼此不同」。
- **整文件重 vendor 会抹掉手工加的 `export`。** 上游把 `normalizeBackendPan` 一类叠加函数留作模块私有
  （组件内部自用），skill 的 headless 工具层却要 import 它——旧 vendored 副本是人手加的 export，一次
  全文件重 vendor 就把它抹了，症状是 `SyntaxError: does not provide an export named …`（太乙栽过）。
  `revendor_core_js.py` 现按「skill tools 谁在 import 它」反查自动补 export，不写死函数名清单。
- **vendor 树布局 ≠ 上游 src 布局**：上游 `../../utils/baziLunarLocal` 在 vendor 树里是 `../bazi/…`。
  重 vendor 器按 basename 自动重定位；**找不到唯一匹配就大声报 UNRESOLVED**，绝不留坏 import——
  留着的话模块加载直接失败，而那比「load 过但真盘崩」还早一步，必须显式暴露给人决定补 vendor 还是写 shim。
- **剥 `fetch*Pan` 会留下孤儿 import**（`cachedKentangFetch` 等网络层助手），同样让模块加载失败；
  按「符号是否仍被引用」判定删除，不按文件名黑名单。
- **本命增补段的门控本就该覆盖整个 chart 家族**：`_attach_natal_extras` 只开给 `{chart, mundane}`，
  而上游给 13 宫/希腊化盘也出 12分度/主宰星链/寿命格局 —— 放开门控即得 3 段（chart13/hellen_chart）。
- **上游有行内段头写法：`[段名] 正文` 同行**（演禽演法五段就是），而 skill 的导出解析器要求
  **段头独占一行**——同行写法会被整体误解析成一个空标题段，于是「文本里明明有这些段、却全部报
  missing」。修法是在 JS 侧只在段头后断行（`/^(\[[^\]]+\])[ \t]+/gm` → `$1\n`），正文逐字不动，
  快照仍与上游同源。**排查判据**：段出现在 `sections` 里但同时出现在 `missing` 里 = 解析形态问题，
  不是缺 builder。
- **preset / optional 之外还有第三态**：上游 `AI_EXPORT_DEFAULT_OFF_SECTIONS` 的语义是「登记进
  preset（可勾、勾了永久尊重），但用户未自定义时默认不导出」——doctrine 型大段（判语库/古籍全文）
  专用。skill 侧并入 optional（对解析器同义：缺席不算漏）并在契约里单列 `default_off_sections`。
  **注意上游的 migration union 也排除这些段**，否则升级会把它们硬并进已自定义用户的选择 = 变相默认开。
- **抽 AstroConst 子集做 shim 有两条边界规则**（都踩过）：① 块的终点是「下一个顶层 `export const`」
  而非分号——上游多数常量**不带结尾分号**，按分号切会把后续所有声明卷进来（`Identifier already
  declared`）；② 必须保持**上游原序**，`LIST_URANIAN` 这类聚合常量引用了排在其后的符号，重排即
  `ReferenceError: before initialization`。宁可逐值抽取也不手写猜值——这类表以 AstroConst.* 为键。
- **重 vendor 一个技法要按「上游文件清单」而不是本地清单**：按本地 `ls` 拼参数会漏掉上游**新增**的
  文件（tarot 的 `openingOfKey.js`/`reversalModes.js` 就这样被漏了），随后重 vendor 报「0 个文件变化」
  却依旧运行失败——同名文件也可能不同源。判据：报 0 变化但功能仍缺 = 清单取错了，不是已同源。
- **shell 里 `cd` 到上游树后不要再跑仓内脚本**：相对路径会解析到上游目录（本轮出现过
  `can't open .../xuanshu-engine/.../scripts/revendor_core_js.py`）。命令一律从包根起。
- **回填铁律的实操顺序**：先 live 跑出**实产段名**，再拿它与上游 preset 做三向差（都有 → 进 preset；
  上游有实产无 → preset+optional 双登记；实产有上游无 → 查是 skill 自有基础段还是占位名族）。
  绝不能照抄上游 preset 了事——那会造出死条目，让每次真实导出都报 missing。


### v0.24.0 / 2026-07-31 — 守卫「结构性失明」+ MCP 面三处静默破损

- **守卫全绿却漏掉 8 个上游版本：同源校验必须比对上游 HEAD，不能比对自己的 vendored 拷贝。**
  症状：`verify_export_contract_mirror.py` 与 `verify_vendor_runtime_sources.py` 全绿，而上游已 v50、
  skill 镜像仍 48。根因：前者读 `vendor/runtime-source/...aiExport.js`（本地 vendored），后者用
  `MIN_AIEXPORT_SETTINGS_VERSION = 48` 的**下界**断言 —— 两棵 vendor 树都 gitignore，没人 re-sync
  就永远自洽；`xuanshu-core-js/src/vendor`（受 git 跟踪）更是**零守卫**。守卫：新增
  `scripts/verify_upstream_sync.py`（`XUANSHU_SOURCE_ROOT` 定位上游 → aiExport 版本恒等 + 哨兵文件
  sha256 + core-js 按 basename 逐文件比对；无上游树时输出 `{"skipped":true}` + `::notice` 而**不装绿**，
  `--require-upstream` 在 release 链硬失败）；下界断言改为与 registry 常量**恒等**。首跑即抓出
  112 个 core-js 文件漂移 + 4 个哨兵漂移（含 `perpredict.py`/`perchart.py` —— 正是主限法 13 法白名单所在）。
- **键级对齐 ≠ 段级对齐：v0.23.0 的「整版对齐 v48」是虚账。** 实测 skill 653 段 vs 上游 v48 的 843 段。
  原 mirror 守卫自述 "Deliberately NOT a per-section diff"，于是 180 段欠账藏在全绿背后。守卫：新增
  `scripts/verify_export_section_baseline.py` + 受 git 跟踪的 `contracts/export_section_debt.json`
  **棘轮**（新增欠账 fail；还清了也 fail 并提示 `--update-baseline` 收紧，使欠账只减不增、每次回填在
  git 里可见）。重同步到 v50 后真实欠账 = **314 段 / 51 多余 / 8 缺键，跨 62 技法**（印占 53 段最大）。
  同时把 `MIRRORED_UPSTREAM_AIEXPORT_VERSION` 的语义写死在注释里：**它表示「对账基准版本」，不表示
  「该版段全有了」**——两个数字必须一起读。
- **`__signature__` 漏设 = 工具静默不可调用（P0）。** `xuanshu_tool_run` 只设了 `__doc__`/`__annotations__`
  没设 `__signature__` → FastMCP 内省 `**kwargs` 生成 `{"kwargs":{"type":"string"},"required":["kwargs"]}`，
  而它是 `XUANSHU_MCP_COMPACT=1` 下抵达全部技法的**唯一**通道。连带 bug：`request` 存在时
  `_merge_mcp_arguments` 整体改用 request 作载荷，把兄弟参数 `tool_name` 丢了。测试之所以没抓到，是因为
  `test_mcp_server.py` **从不走 `srv.call_tool`**（直接调 service 层）——守卫：新增 `tests/test_mcp_contract.py`
  按「客户端真正看到什么」断言（list_tools 每个工具有描述/title/无 `kwargs` 参数/无残留 `$ref`；
  call_tool 跑通闸门/成功/畸形/request 通道/数字经纬度五路）。
- **`__signature__` 优先级高于 `__annotations__` → structured output 全线失效。** 9 处
  `__annotations__ = {"return": ToolEnvelope}` 是死代码，91 个工具 `outputSchema` 全 None；讽刺的是唯一
  拿到 outputSchema 的恰是那个坏掉的 `xuanshu_tool_run`（因为它没有 `__signature__`）。修法：签名带
  `return_annotation`。**但开启前必须先统一错误载荷**——出参被 server+client 两侧校验，而闸门返回的是
  5 键裸 dict，声明 outputSchema 后会被打成协议级 ToolError，**整个澄清闸当场报废**（实测复现）。
  故先给 `ToolEnvelope`/`DispatchEnvelope` 加可选顶层镜像 `code/message/details`、把闸门/elicit/校验
  三条错误路径全部转成合规信封，再接 `return_annotation`；且因 claude-code#25081（带 outputSchema 时
  工具列表静默消失，stale-closed 未确认修复）**默认关闭**，`XUANSHU_OUTPUT_SCHEMA=1` 显式开启。
- **FastMCP 注册时 `validate_input=False`——广告 schema 与实际校验解耦，这是解开死结的钥匙。**
  据此把签名改成「广告保真、校验放松」：字段描述/枚举/`[required]` 标记照登，但全部 `default=None` +
  `Annotated[Any, WithJsonSchema(...)]` → MCP 层零必填。一次修好三处：文档承诺的 `request={…}` 逃生通道
  此前**永远走不到**（必填字段先被 arg model 拒）、`{"lat": 39.9}`（模型极高频）在归一化之前就被拒、
  以及两者都绕过 `agent_recovery` 回裸 pydantic 错误。**坑**：把 property 摘出来单独广告时 `#/$defs/…`
  解析不到根，且模型间存在自引用（嵌套 BirthInput）——`WithJsonSchema` 里残留 `$ref` 会让 pydantic
  `KeyError` 到整个服务器起不来。内联必须「遇环/超深/缺失一律降级为无约束对象，绝不留下 `$ref`」。
- **仓库搬家后 `.venv/bin/*` 的 shebang 仍指旧路径** → `uv run pytest` 静默回退到全局 pytest（旧依赖，
  报 `mcp.types 无 Icon`），而 `uv run python -m pytest` 正常。判据：直接跑 `.venv/bin/pytest` 报
  `bad interpreter`。修法 = §8 标准 venv 重建。
- **log4j 的 `${env:HOME:-${sys:user.home}}` 带默认值形态未被替换** → 日志按**字面量目录名**落在启动
  CWD，在用户工作目录里留下一个名字诡异的目录，且没人知道日志在哪。`_rewrite_runtime_log4j` 原来只处理
  `${env:HOME}` 一种写法，现两种都归位。
- **生态基准变了（2026-07-31 核实）**：MCP **2026-07-28 规范已发布**、python-sdk **v2.0.0 已上 PyPI**
  （v2 是破坏性重写，钉 `mcp[cli]>=1.28.1,<2` 不迁）；本仓**未使用** logging/roots/sampling 三项废弃 API，
  且 `_maybe_elicit_gate` 本就在 `service.run_tool` 之前 → 天然满足 v2 的「工具函数会被整体重放」要求。
  **Claude Code 的工具搜索已默认开启**，83 工具的上下文膨胀在该客户端已由平台解决，ROI 重心移到
  server `instructions`（此前只用了 164/2048 字节）与 `_meta["anthropic/alwaysLoad"]` 入口标记；
  Cursor 仍有较紧工具数上限 → 新增 `XUANSHU_TOOLSETS` 分组白名单（registry 的 domain 天然可用）。
  **官方 Registry 可不发 PyPI 上架**：`registryType: "mcpb"` + GitHub Release 的 .mcpb + `fileSha256`，
  正好绕开 xuanshu-core-js 在 wheel 之外的分发归属难题（`registryType: "github"` **不是**合法通道）。

### v0.23.0+ / 2026-07-22 — issue #14：Java 后端被环境杀死时全盘卡死 → chart-only 降级 + 诊断透传

- **症状**（用户报告，Windows 11 + Clash Verge/安全软件）：`selfcheck` 挂死、`doctor` 只报
  `services:not_running` 不说原因；Java(:9999) 启动即静默退出、无自身日志。**根因（环境层）**：jar 的
  `AIAnalysisProxyService` bean 构造期 `new HttpClient()` → `Selector.open()` → JDK-17 `PipeImpl`
  在 Windows 上**硬编码优先 AF_UNIX** 做内部 loopback（`PipeImpl(sp)` 写死 `this(sp,true,false)`），
  且 **connect 失败无 TCP 回退**（只有 bind 失败才回退）——代理/VPN/安全软件的 WFP 过滤拦
  `UnixDomainSockets.connect0` 即整跳崩；报告者机器连 java.exe 的 TCP loopback 也被拦（WFP 驻留内核，
  停服务不够、需禁用+重启），Java 侧无解。**根因（我们的放大器）**：manager 就绪门要求 8899+9999 双活；
  chart-up/java-down 触发 partial-recovery 把**健康的 chart 也停掉**重试，二次同败后 raise——只需 :8899
  的三式/神数/地占等全被连坐；Java 崩溃栈无处可看（log4j appender 随进程死，doctor 不读启动器捕获的 std 流）。
- **fix/guard（同一 change 全落）**：① 启动器降级门（Windows 模板 + `manager._run_start_command`
  **锁步**）：java 进程死 → 秒级 exit 0 降级 + marker `java backend process exited` + java 日志尾进
  stdout；java 慢 → 窗尽头 exit 0 降级；chart 死 → 照旧 throw。实测损坏 jar 场景 **5s** 降级退出
  （旧行为 300s throw + 全锁）。② manager 接受 chart-only 为降级成功：`runtime.start_degraded_chart_only`
  warning + runtime_state `degraded_chart_only`；见 marker 时等待截短 ≤20s；degraded ready **不再**触发
  破坏性 stop+retry。③ doctor 分半报 `services:{java_backend,chart}_not_running`，java 死时附
  `java_diagnostics`（读最新 `.xuanshu-local-logs/*/astrostudyboot.std{err,out}.log` 提取
  `Application run failed`/`Caused by:` 链，best-effort 永不 crash doctor）。④ selfcheck：`nongli_time`
  （java 面）失败自动回退 chart 侧 `wangji` 探针——降级机器上 ok=true + `degraded: chart_only` +
  定向 next_action，不再挂死。⑤ README×2 排障：受限网络 assets-API 安装法（github.com:443 不通时）+
  WFP 干扰判据。回归测试：`test_runtime_manager.py` 降级三测（`_run_start_command` 降级判定 /
  start 不破坏性重试 / doctor 摘录）+ 分半 issue 命名测。

### v0.23.0+ / 2026-07-22 — Temurin「releases/latest」半发布窗口打空 JDK 下载（Windows 补建时踩中）

- **症状**：v0.23.0 Windows 半边补建时 `build_runtime_release_windows.py` 第一步即死：
  `could not resolve Temurin asset for OpenJDK17U-jdk_x64_windows_hotspot_.zip`。**根因**：builder 从
  GitHub `temurin17-binaries/releases/latest` 按资产名匹配下载 JDK；GitHub 的 `releases/latest` 按
  **tag 提交日期**取，Adoptium 刚打 GA tag（jdk-17.0.20-ga）而平台二进制尚未传完的窗口内，该 release
  资产为空/不全 → 匹配空手。且其 `/releases` 列表顺序按 release 对象创建时间（老版本重发会插队到最前，
  实测 2023 年的 17.0.9+9.1 排第一），「遍历列表取第一个含资产的」同样不可靠。linux builder 同模式同病。
  **fix/guard**：两个下载 JDK 的 builder（win/linux）改走 Adoptium 官方分发 API
  `api.adoptium.net/v3/binary/latest/17/ga/<os>/x64/jdk/hotspot/normal/eclipse`（307 只指向**已存在**的
  最新 GA 二进制，`download()` 的 `curl -fL` 跟随重定向；实测解析到 17.0.19+10、正确跳过无资产的
  17.0.20）；`verify_builder_parity.py` 新增断言：JDK-downloading builders（win/linux）必含 Adoptium
  API URL、禁再引用 `temurin17-binaries/releases/latest`；mac builder 不下载 JDK（vendored
  runtime/mac/java）豁免。
- **kintaiyi `game_theory` 的 scipy 缺失是两平台一致的良性 prewarm 噪音**：symptom = bundled chart 服务
  启动日志出现 `prewarm_kentang_modules → kintaiyi/game_theory.py → ModuleNotFoundError: No module named
  'scipy'` 整段 traceback，看似 taiyi 引擎坏了。root cause = 上游 kintaiyi 新增 **opt-in** 博弈论模块
  （`pan(..., enable_game_theory=False)` 默认关、`if enable_game_theory` 内懒 import），scipy 既不在 ken
  依赖集（§6 只有 bidict/numpy/kerykeion/ephem/pendulum）也不在**任何**平台 bundle 内——实测 v0.23.0
  darwin tar 同样含 `game_theory.py` 且无 scipy，两平台行为一致；skill 调用面永不置 True。判据 =
  `/taiyi/pan` 返 `ResultCode 0 + source kintaiyi` 即健康，该 traceback 无需处置；**勿为它加 scipy**
  （~40MB，瘦身红线，服务于永不触发的功能）。守卫：CI 起不了 runtime（§7），无廉价断言点，按 §8 症状表
  + 本条documentation 处置。顺带观察：darwin tar 混入 `._game_theory.py`（AppleDouble，inert，
  mac 侧滤网漏网，无碍）。

### v0.23.0 / 2026-07 — 全面重同步至上游 v3.5.1（全年份域 + 地占大改 + 六爻扩充 + 5 新技法）

- **导出契约三层脱节收口（40<44<48 → 48）+ mirror 守卫**：`MIRRORED_UPSTREAM_AIEXPORT_VERSION` 40→48、
  `AI_EXPORT_SETTINGS_VERSION` 10→11（5 新技法 + geomancy/primarydirect 对齐）。新守卫
  `verify_export_contract_mirror.py`：①版本锁步——vendored aiExport 的 `AI_EXPORT_SETTINGS_VERSION` 必须
  == skill `MIRRORED_UPSTREAM_AIEXPORT_VERSION`（堵「同步旧树」与「改一个忘改另一个」）；②技法键覆盖——
  每个 skill 导出键须在 vendored 上游 `AI_EXPORT_TECHNIQUES` 内，或走 `KEY_ALIAS`（wangji↔huangji、
  acg↔locastro 键名分叉）/`DIVERGENCE_WHITELIST`（astrodata skill-only、generic、astrochart_like）。
  jieqi 分点子键经 JIEQI_SPLIT_TECHNIQUES spread 入上游，按字符串字面识别。守卫需 vendored 树 → 跑在
  self-hosted release runner（release.yml），非 GitHub CI（后者无 vendored 树）。**逐技法对齐、非整版盲抄**：
  skill-extra 段（起卦信息）、UI-only 死段（主限天球）、收缩契约由白名单显式豁免。

- **`kin_year_domain.py` 同步漏拷（sync 脚本枚举陷阱）**：symptom = 从上游 v3.5.0+ 重同步
  `vendor/runtime-source` 后，每个 ken/神数 引擎在**首个域外（BC/远期）请求**上 500。root cause =
  上游 v3.5.0「全年份域」把域外四柱回退逻辑抽成**顶层共享模块**
  `Horosa-Web/vendor/kin_year_domain.py`，被 16 个引擎 `config.py`/`jieqi.py`/`shenyishu.py` 懒
  `from kin_year_domain import solar_term_name/extreme_pillars`。`sync_vendored_runtime_sources.sh`
  的 require+rsync 清单**逐引擎目录枚举**，漏了这个**平级的顶层单文件** → 重同步静默丢弃它，域内请求
  照常、域外静默炸。guard = sync 脚本显式拷 `kin_year_domain.py`（+ 其兄弟 `test_month_pillar_boundary.py`）；
  `verify_vendor_runtime_sources.py` REQUIRED_PATHS 断言该文件 + geomancy `data/ifa_odu.json` + xuanshi
  `public_data.sqlite` 真文件，并加**内容断言 vendored aiExport `AI_EXPORT_SETTINGS_VERSION >= 48`**
  （通用拦「同步了旧树」，堵住三层版本脱节 skill<vendored<上游 的静默复发）。教训 = 上游把子逻辑上提为
  vendor 根级共享件时，逐目录枚举的 sync 清单必须同步补顶层单文件。
- **kentang registry 已懒挂载 → raw-vendor hard-fail 警告过时**：AGENTS §5/§8 旧警告「raw vendor 直接起
  chart 服务时 registry 列了未 vendor 引擎会 hard-fail（graceful patch 只在打包 staged 拷贝）」在
  vendored v44 与上游 v48 都已不成立——`astropy/websrv/kentang/registry.py` 现用 `_LazyMountedService`
  （默认 `XUANSHU_KENTANG_LAZY=1`）：缺引擎只在**首请求**时响亮 500 + 下次重试，启动不炸。18 个 mount 的
  引擎全在 vendored 集合内。影响 live 验证法：不能再靠「启动即知」，改为**启动后逐 mount 打真请求**强制加载。
  （按 §2 compaction 蒸馏进 AGENTS §5/§8。）
- **v3.3.6「有情/无情」purity 是 UI-only，不进 AI 导出链（防后人重查）**：上游 astroPatternOverview.js 的
  purity 只被 `AstroInfo.js` 消费；`astroAiSnapshot.js::buildPatternOverviewLines` 与 [古典] 接纳/互容行
  **都不渲染 purity**。故 skill 镜像导出契约**无需移植 purity**。真正落后的是 pre-v44 的一处快照可见细节：
  [古典] 正/邪接纳行缺 FIX-15 `（拒绝）` 标（supplier 在 beneficiary 座为 exile/fall = 凶接纳）——已补
  `_reception_reject_mark`（镜像 astroAiSnapshot.isReject）。
- **geomancy v3.5.1 地占大改版接入**：`_build_geomancy_snapshot_text` 对齐上游 v48 builder —— [判定] 补
  首母中止/sikidy 三道校验+列比对/hakata 四片盘；[解读技法] 补 points_parity 取样域/黄道宫三方/数量+判官之数；
  新增 [转宫派生]/[定局落星·甲乙]；十二宫·图形入宫 与 十六图形 改 **markdown 表**（印度派多支名/曜两列）。
  ifa（西非同族）为**结构对照模式、不产占断**：schema 白名单 8 家占断传本、明确拒绝 ifa
  （`tool.geomancy_structural_only_unsupported` + 文化声明），换来 判定/十二宫/十六图形 可作**必出段**的强契约；
  [图形释义]（doctrine 默认关）与 [边界声明]（ifa）skill 不产，仅进 preset 作 export_parse 识别面（同 fengshui）。
- **primarydirect 段名对齐**：上游 v48 判 `主/界限法设置|表格` 为死名、真名 `主限法设置|表格`；skill builder/
  preset/report-payload-map 同步改真名，旧名走 `map_legacy_section_title`。UI-only 新段
  `主限天球·当前动画所指`（3D 动画所指）headless 不产，**故意不进 preset**（§5 UI-only 段过滤）。
- **live 0-skip 需 Mongo：干净机器只能验 chart 半边**：
  > 🔴 **本条归因在 v0.36.0 收尾被推翻，原文保留供对照**（见 v0.36.0 段「Java 族 live 从来不需要 Mongo」）。
  > 实锤：app 注册读的是 jar 内 `data/rsakey.json`（`RequestHeaderInterceptor`），本机 Mongo 里根本没有注册表；
  > 9999 的真因是 vendored 实例脚本**裸 `java -jar`** → jar 内写死的 `mongodb.host` 解析不到 → 每个碰库请求
  > 30s 连接超时。按上游桌面模式起（`--mongodb.ip` + `XUANSHU_DESKTOP_MONGO_OPTIONAL=1` + 文件回退目录）后，
  > Mongo/Redis 都不在也全 Java 族真数据；本 Mac 首次 0-skip 全量 live：678 passed。
  vendored chart 服务（`:8896`）**完全独立**，
  geomancy/predict/astroextra/ken-formatter 全可验；但 Java 聚合层（`:9996`）的 app 注册在 Mongo 里，
  无 Mongo 时 `/nongli/time`·`/bazi/birth`·`/ziwei/birth`·`/liureng/*` 一律返 `ResultCode 9999
  "no.register.app.in.sys"`（不是启动慢、是缺注册）。连带 qimen/taiyi/jinkou（需 `/nongli/time` 脚手架）
  与 5 新技法的**占时**路径在无 Mongo 机器上跑不了 live。判据 = 这类 500/9999 全落在 java 端点、chart 端点
  全绿 → 环境限制而非代码问题；这些路径的离线覆盖 = FakeClient 全形状 `/nongli/time` 桩 + FakeJsClient +
  node golden，占时派生纯 Python 亦离线可测。完整 0-skip 留给带 Mongo/Redis 的发布机。
- **core-js 重 vendor（baziLunarLocal 全年份域守卫 + gua 六爻大扩充）**：
  ① `baziLunarLocal.js` 重拷带入 v3.5.0 **全年份域守卫**——`lunarDomainGuard.isLunarJsYearReliable`（AD1~9999
  外 lunar-js 节气静默错位 → 月柱错，比崩溃更危险，故域外 throw 让上层走后端星历）+ `dateStrSafe.parseDateParts`
  （`'-7040-07-19'` 裸 split 撕成 NaN 年）两个新 import-free 兄弟依赖随拷；公共 export 面不变（canping/heluo/
  yizhangjing/zhengchuan 链零改）。
  ② **gua 六爻整子树重 vendor**：14 引擎模块 + 6 data（tianjiDoctrine 9581 行纯数据）统一 sed 变换
  （`./X`→`./X.js`、`../../utils/helper`→`./guaHelper`、`../../utils/safeStorage`→`./safeStorage` no-op shim）。
  新增 liuyaoDuanJue/GuFa/YingQi/ShenShaEx 引擎 → `analyzeLiuyao` 新出 `duanJue`/`yingqi` 等键（旧键全保留=
  向后兼容）；`tools/liuyao.js` 把「断诀命中」（金锁玉关/随官入墓/随金伏…命中项，**空 render 过滤**）+「应期」
  折进已有 [断卦结构]（optional）段，不新增段名、契约零变。closure 干净（引擎只 import 兄弟+data+2 shim，
  无 React/canvas）；golden + analyzeLiuyao real-chain 验证。
  ③ **本轮 core-js 已完成 = bazi + gua**；ken formatter（DunJia/JinKou/TaiYi 各 4~23 行极端年 clockTime/BC-safe
  显示微漂）、tarot engine（cardSchema/reportText/verdict 微漂）、tongshefa 三十二观、calendar 4→14 段（黄历
  四页签，需审 fengshui/zeri.js headless）**列为后续专项**——ken 引擎全年份域已由 Phase 0 runtime 重同步覆盖，
  这些是极端年显示 polish 与能力增补，非在域正确性缺口，留待专项验证 pass。

### v0.22.0 / 2026-07-16 — parity lint 常量交叉扩到全部 manifest-stamping 脚本（Windows 侧）

- **症状**：`export_registry_version` 在 linux builder + 两个 scaffold 曾滞留 6 而 mac/win 已到 10
  （上一条台账已记），CI 全绿放行。**根因**：`verify_builder_parity.py` 的
  `SHARED_MANIFEST_CONSTANTS` 交叉只读 mac/win 两个文件——第三平台 builder 与 scaffold 不在射程。
- **守卫（本条完成上条教训的机器守卫件）**：lint 新增 `CONSTANT_STAMPERS` 清单
  （mac/win/linux 三 builder + windows/linux 两 scaffold），三常量
  （`schema_version`/`runtime_layout_version`/`export_registry_version`）N 路交叉断言；
  清单中不存在的文件跳过（容忍 repo 演进），存在但缺常量 = 错。已 mutation 验证：
  临时把 `scaffold_windows_runtime.py` 改 6 → FAIL 并点名 `Windows scaffold=[6]`，还原 → PASS。
- 注：协议第 3 件（CHANGELOG）不可执行——本仓当前不存在 `CHANGELOG.md`（文档重构后未保留），
  §2 协议文本与树的这一处不一致留待 mac 侧裁定。

### v0.21.0+ / 2026-07-16 — MCP 面顶级化 + 三方审计（上游基线/用户路径/前沿调研）

- **上游同步基线纠偏**：上游 xuanshu-engine 实际已到 **v3.4.0 / aiExport v48**（UPGRADE_LOG 最新条目在文件**顶部**，
  用 tail 看会误读旧版本）；skill 导出契约整版镜像 ≈ **v40** + 零散摘取 v44 个别段（拼接式而非整版对齐）。
  约 20+ 技法有段级缺口；一档必同步清单（indiachart ~40 Jyotish 段、guolao 四段、星运族×12 起盘信息、
  tongshefa/jinkou/tieban 计算层、sanshi 紫微四化、horary/election/relative/ziwei 补段、taiyi「起盘」段
  ——旧「kintaiyi 不产此段」判定已过期（上游 `webtaiyisrv.py:306` 现由后端产）、qimen 八宫克应、
  zhengchuan 新技法）与二/三档全表见本轮审计 agent 报告（要点已录入本条）；`wangji` vs 上游导出键
  `huangji` 存在**键名分叉**（外部 huangji 导出 parse 不识别，需 alias）。守卫：`exports/registry.py`
  新增机读常量 `MIRRORED_UPSTREAM_AIEXPORT_VERSION = 40`，整批同步后必须更新。
- **构建常量三平台漂移**：`export_registry_version` win builder=10 而 **linux builder + 两个 scaffold=6**
  （verify_builder_parity 只交叉 mac/win，linux/scaffold 不在其射程）。已统一为 10；教训 = 新增第三平台
  builder/scaffold 时，`SHARED_MANIFEST_CONSTANTS` 类常量的锁步检查范围要同步扩。
- **venv shebang 陷阱（仓库搬家后必踩）**：仓从 `Downloads/` 移到 `Desktop/` 后，`.venv/bin/*` console-script
  的 shebang 仍指旧绝对路径 → `uv run pytest` 静默回退到**全局** pytest（环境里是旧 mcp，无 Icon）报
  `module 'mcp.types' has no attribute 'Icon'`，而 `uv run python -m pytest` 正常。症状 = 直接执行
  `.venv/bin/pytest` 报 `bad interpreter: …旧路径…`。修复 = AGENTS §8 标准 venv 重建。
- **MCP 面升级（服务器侧）**：78+8 工具全量 **tool annotations**（口径：全部 openWorldHint=False；
  查询类 readOnly+idempotent；计算类 readOnly=False/destructive=False/idempotent=False——会追加本地 run 行，
  如实标注）；**elicitation 双轨澄清闸**（客户端有能力→原生表单：按默认一跳闭环 / 补充设置→备注回带给
  agent 不代答参数；无能力/异常→逐字节回落旧 agent_recovery 错误往返；`XUANSHU_MCP_ELICIT=0` 总闸）；
  **3 prompts**（quick_cast/annual_fortune/export_report → Claude Code 斜杠命令）+ **2 resources**
  （技法目录/导出注册表）；server icons + website_url；compact/dispatch/factory 路径补 pydantic
  `ValidationError` → `build_validation_recovery` 兜底。**实测澄清**：动态 `__annotations__` 并未激活
  FastMCP structured output（`outputSchema: False`）——此前审计担心的「错误分支违约」不存在；structured
  output 保持未来 opt-in（Claude Code 曾有带 outputSchema 掉工具的事故，开启前必须实测 `tools/list`）。
- **registry 合规**：`server.json` 按官方 2025-12-11 schema 重写（reverse-DNS name `io.github.xuanshu-project/
  xuanshu-skill`、`homepage`→`websiteUrl`、非 schema 字段收进 `_meta`、`$schema` 钉 static URL、transport
  对象化）；`verify_server_json.py` 从「字段存在性」升级为**严格 schema 结构断言**。README 的 Changelog
  徽章链接 gitignored 的 CHANGELOG.md（公开仓 404）→ 已删（EN），docs-sync 加「README 禁引用 CHANGELOG.md」
  守卫。CITATION.cff 在 v0.20/v0.21 又双叒停在 0.19.0（checker 未进 CI 前的积欠）→ 已修，CI 已有守卫。
- **接入面**：`client config` 新增 **cursor / vscode** 格式（输出官方 install deep link / `vscode:mcp/install`
  链接 + `code --add-mcp`，真实路径注入）；`--write` 改为 **mcpServers 按键合并**（原来整文件覆盖会清掉用户
  已有的其他 MCP server）；新增 **Claude Code plugin/marketplace 三件套**（`.claude-plugin/{plugin,marketplace}.json`
  + 根 `.mcp.json` 用 `${CLAUDE_PLUGIN_ROOT}`，`/plugin marketplace add xuanshu-project/xuanshu-skill` 一步接入）；
  SKILL.md frontmatter 补 agentskills.io 规范字段（license/compatibility/metadata.version，随版本锁步进
  docs-sync）；README×2 补 Cursor/VS Code/Plugin 行与 `calendar_month`（v0.20 新工具漏档 EN/SKILL）。
  依赖钉板 `mcp[cli]>=1.27,<2`（SDK v2 于 2026-07-27 发稳定版、7-28 新规范废弃 sampling/roots/logging——
  本仓未用，迁移窗口 12 个月）。
- **前沿调研结论存档（2026-07-15 逐页核实）**：elicitation Claude Code≥2.1.76/Cursor/VS Code 已支持（Claude
  Desktop/Codex/OpenWebUI 未支持→双轨必要）；llms.txt 有实证证据不值得做（97% 无人读取，Google 明确不用）；
  MCPB(.mcpb) 可给 Claude Desktop 一键安装（uv 型 manifest，待打包）；MCP Registry 发布需 PyPI 包 +
  `mcp-publisher login github`（PyPI README 放 `mcp-name:` 行验证）；MCP Apps 扩展值得盯（Claude Code 尚未支持，
  支持后可做盘面可视化）。

### 开源栈上不可得的段 —— 明确排除项台账（回填时先查这里，别当缺口重查一遍）

判据统一是：**上游 builder 依赖的数据在开源 xuanshu-engine 栈上取不到**（后端无该路由 / 依赖 canvas
渲染 / 依赖交互点位），而不是「本仓还没写」。每条都附可复核的证据，下次审计直接引用。

**另有一类不是「取不到」，而是「上游自己就不当它是可导出技法」——同样别当缺口重查（v0.26.0 记）：**

- **kentang 服务 `qizhengelection`（七政四余择日）与 `xuanshi`（玄学史）** —— 两者都在上游
  `integrations/kentang/serviceRoot.js` 的 21 个服务里，本仓无对应工具。判据：**两者都不在
  `aiExport.js` 的 `AI_EXPORT_TECHNIQUES` / `AI_EXPORT_PRESET_SECTIONS` 里**（grep 零命中）——
  即上游自身没把它们登记为 AI 可导出技法，没有 preset 段表，也就不存在「缺段」。
  `xuanshi` 是 ECharts 驱动的史料检索/地图页（`XuanShiCelestial/XuanShiMap`），非排盘技法；
  其 SQLite 数据仍在 `REQUIRED_PATHS` 里（打包需要），**有数据 ≠ 有技法**，别据此判缺口。
  → 沿用 AGENTS §5 审计前置的老结论：**权威清单是 `aiExport.js` 的技法表，不是服务注册表、
  也不是组件目录**。「上游有 engine/服务 ≠ 可进公开 skill」。

- **`guolao` 的 `[虚实]` / `[本命化曜]` / `[流年流曜]`（3 段）** —— 三者读 `moiraRules.weakSolid`
  与 `moiraRules.yearStars`，该对象来自后端 **`/qizheng/moira`**（上游 `services/qizheng.js:10`
  `fetchMoiraQizhengRules`）。开源 astropy 的 `websrv/` 只挂了 `webqizhengelectionsrv` 与
  `webqizhengkinsrv`，**没有这条路由**（仓内 vendored 实例实测 POST `/qizheng/moira` → 500）；
  【v0.36.0 更正：上一行的「没有这条路由」是**测错了服务**——`/qizheng/moira` 挂在 Java 聚合层（astrostudycn
  `QizhengMoiraController`），Python chart 服务 500 不能证明路由不存在；C1 已按 Java 契约接活。】
  上游的本地回退 `buildLocalMoiraRules` 只产 `houses/patterns/godHits`，不产这两个字段。
  → 同批的 `[星曜庙旺与星点动态]` **可得**（纯表查询、只吃 `/chart` 响应），已于 v0.25 补上；
  别因为「guolao 还欠 4 段」就以为整批同因。
  这也顺带裁掉了历史矛盾：registry 里「headless 未移植」的旧注释与 LESSONS 早期「已 DONE」的
  记录互斥 —— 实际是 `政余格局` 早已 DONE（走 vendored Moira DSL），欠的是另外三段且不可得。

- **`primarydirect` 的 `[主限天球·当前动画所指]`** —— 段名即语义：它指的是 3D 天球**动画当前所指**，
  没有动画就没有「所指」。UI-only，不进 preset。

- **`fengshui` 的 `[风水·玄空六法]` / `[风水·命理派]` / `[风水·综合罗经]`（3 段）** —— 整个 fengshui
  技法本就是仓内**早已明文的排除项**（canvas + 户型图上传 + 交互点位驱动，`new FengShuiEngine(canvas,…)`，
  无 birth/time 输入；SKILL.md 与 README×2 都写了「明确排除·风水未完成 headless 化」）。这三段只是该
  排除面下新增的页签，不改变结论。**别因为「上游 preset 里有」就重新当缺口查一遍**——这已是第四轮踩它。

- **从上游 React 文件抽纯函数：闭包必须连 `const` 箭头助手一起走，且别整份 vendor。** 本轮四个
  「功能缺口」段全部落地，路上踩了三次同一形态的坑：
  1. 只按 `function` 声明做传递闭包 → 漏掉 `const luckHouseName = …` 这类箭头助手，症状是段**恒空**
     而不报错（我的 wrapper 有静默 catch）；
  2. 漏掉跨文件的**别名导入**（`houseName as luckHouseName`），同样恒空；
  3. 图省事整份 vendor `ZWLuckPanel.js` → 把 JSX 带进来，Node 直接 `Unexpected token '<'`。
  做法：闭包同时扫 `function` 与 `const … =>`，从**目标函数**反向传递求闭包，只搬闭包内的东西；
  调试期先把静默 catch 换成打印，否则「段恒空」这个症状指向不了任何具体原因。

- 对比一条**看起来像**排除项、实际不是的：`jieqi` 的 `[X3D盘]` 曾被我判为 3D 渲染而搁置，
  读码后发现上游 astro3d 页签走的是 `buildAstroSnapshotContent(one, flds, {headerless:true})`
  —— 与 `[X星盘]` 逐字同一份文本。**「名字里有 3D」不等于不可 headless**，一律以 builder 实际取数为准。

### v0.25.0 段级回填（上游 v50，216 → 141 段）— 四条会反复咬人的坑

- **🔴 上游前端源不在 `vendor/runtime-source`。** 该树的 `astrostudyui/src/` 只镜像了 `utils/`（供 aiExport
  对账），**只有 1 个文件**；`components/` 与 `divination/` 整个不在。在那棵树上 grep 段头会得到「上游根本
  没有这段」的**错误结论**。真身在 `xuanshu-engine/Horosa-Web/astrostudyui/src`（12712 文件）。
  判据：`find <树>/astrostudyui/src -type f | wc -l` —— 个位数就是镜像树，别在上面找 builder。

- **🔴 桩比真实响应「更简单」＝ 把 bug 盖住。** 本轮抓到两处同一形态，都是线上真坏、离线恒绿：
  1. `/astroextra/harmonic` 真实响应把整个 chart-wrap 放在 `chart` 键下（比通用段构建器预期深一层），
     调波盘 14 段全是占位存根；FakeClient 的桩**根本没有 chart 字段**。
  2. `/predict/*` 的交叉相位是 `chart.aspects` **数组**；FakeClient 在**顶层**塞了本命形状的 aspects，
     于是推运族 5 键的 `[相位]` 段在真机上只有三个空子标题、零条相位，而测试还断言着 `"标准相位" in text`
     —— 等于在断言 bug 的产物。
  **规则**：写桩时以真实响应的**嵌套层级与容器类型**为准，宁可繁琐；桩每简化一层，就等于给自己关掉一层守卫。
  改完桩顺手加反向断言（如 `assert "标准相位" not in text`）锁住方向。

- **段在 `sections` 里 ≠ 真的产出了。** 导出层会给 preset 里没产出的段注入占位存根
  （「本次本地计算结果未返回「X」细项…」）。看产出要看 **`section_titles_detected`**；`sections` 含存根。
  「某段同时出现在 `sections` 和 `missing_selected_sections`」是这个信号的典型形态。

- **工具自带 `snapshot_text` 会短路自动渲染器。** 统一出口是 `if not snapshot_text:` 才调
  `_auto_snapshot_text_for_tool`。工具里回填一份「只含自家几段」的文本，会把整套通用盘面段挡在门外
  （调波盘就是这么丢了 12 段）。要合并通用段 + 技法段，就**不要**在 `_run_*_tool` 里回填。

- **`revendor_core_js.py` 的落点默认值会丢嵌套层级。** 旧实现取 `Path(rel).parent.name`，于是
  `divination/data/x.js` 落到 `vendor/data/`，与既有的 `vendor/divination/data/` 形成**同名重复树**，
  且 relocate 还会把 import 指回旧树 —— 同一模块两份、改一份不生效。已改为「vendor 里存在完整相对父
  路径就用它」。

- **从上游 React 文件抽函数，记得扫模块级 const。** 抽 `buildJinKouSnapshotText` 时漏了 `MD_DASH`，
  运行期才炸。做法：抽完用正则把上游所有 `^const X =` 与新文件里已定义的符号做差集，一次补齐。

- **往 registry 插条目时，正则必须锚定字典起点。** `"liureng":` 在 PRESET 与 OPTIONAL 两个字典里都有，
  `re.search` 命中第一个 → optional 条目被插进了 PRESET（重复键被后一条覆盖，行为无害但语义错、且
  下次读代码会误判）。先 `t.index("AI_EXPORT_OPTIONAL_SECTIONS = {")` 再在其后找锚点。

- **上游把一族盘按「哪个页面出的」拆成独立导出键**（`aiExport.js` 的 `ASTRO_LIKE_EXPORT_KEYS`：
  astrochart_like / hellenastro / dwadasamsa / harmonic / draconic / relocation / locastro）。段单同构，
  所以 `locastro`(=本仓 acg) 这种「看起来是独立技法」的键，导出其实是 **astrochart 全套盘段 + 尾部地图段**。
  判据：技法在该常量里 → 它的 builder 应复用通用盘面渲染器，而不是自建几段线表。

### v0.14.0 sync lessons (古典占星 [古典] + [古典格局] 补到 chart 家族 — vendor 源 = xuanshu-engine, 72 工具不变)

- **新增任何到 chart 服务的 `_call_remote(endpoint)` 必须把 endpoint 加进 `_PYTHON_CHART_ENDPOINTS`。** `[古典格局]` 经
  `_attach_classical_analysis` 调 `/astroextra/analysis`；最初漏登记该 endpoint → `use_chart_server=False` 落到 **Java** 通路，
  读 `_java_runtime_ready`（仍 False）→ 二次探针 + 二次 `start_local_services`，直接打挂 `test_service_*runtime*`（`started==1`/`probe_calls==1`）。
  判据：chart 服务族（`/chart`·`/predict/*`·`/astroextra/*`·`/*/pan`…）一律进该 set，才会复用 `_chart_runtime_ready` 缓存、首调后不再探针。
- **段补到「既有工具」≠ 新工具**：古典两段挂在 chart 家族导出上，工具数仍 72。版本仍要全量 bump（pyproject/uv.lock/__init__/
  package.json+lock/server.json/README×2/JSON 例），但 badge/句子/全景标题的 **72 不动**；测试数 260→263 要同步。
- **`_attach_*` 增补走「gated + try/except graceful + 顶层 stash」**：`_CLASSICAL_ANALYSIS_TOOLS={chart,chart13,hellen_chart}`
  控制 `[古典格局]` 只挂本命三盘；india/mundane 走 `_build_astro_snapshot_text` 自带 `[古典]`（来自 `/chart` objects），但不挂
  `[古典格局]`——preset 必须**逐工具对齐**（astrochart/astrochart_like 双段；indiachart/mundane 仅 `[古典]`），否则挂不上的段进 preset 会成「死条目」。
- **离线 vs live 覆盖分层**：`[古典]` 的 Melothesia 段离线即出（FakeClient objects 带 `sign`），但**逐曜古典状态/围攻/围绕**需富集
  per-object 字段（outOfBounds/phase/joy/mansion…），仅 live 出；故离线测试断言 stub 驱动的 `[古典格局]` + Melothesia，富集 `[古典]`
  交 live 测试 + export-fixture（用真 live 快照 `astrochart_classical_live_snapshot.txt` 锁解析契约）。FakeClient 要加 `/astroextra/analysis` 桩。


### v0.13.0 sync lessons (4 未同步 AI 技法 + 太乙/八字 段口径 — vendor 源 = xuanshu-engine, 68→72)

- **审计前先查自家「明确排除项」+ 过 headless-readiness 闸。** 第三轮把 `fengshui` 误当可补缺口——它是 canvas +
  户型图上传 + 交互点位驱动（`new FengShuiEngine(canvas,…)`，无 birth/time 输入），无法 headless；仓内 SKILL.md/README×2
  早有「明确排除·风水未完成 headless 化」政策。教训：上游有 engine 文件 ≠ 可进公开 skill；每个候选先 grep 排除政策，
  再确认其 `buildXxxSnapshotText` 是纯 `chart/data→text`（无 canvas/DOM/上传/点击依赖）。
- **AI-export 技法的权威清单 = `aiExport.js` 的 `EXPORT_TECHNIQUES` + `EXPORT_PRESET_SECTIONS`**（不是组件目录）。本轮
  4 个缺口（triplicityrulers/keypoints/lunationphase/extrareturns）都在该表里却无 skill 工具。`utils/triplicityRulers.js`
  用 `AstroConst.SignsProp` → shim 必须补该表（v0.11 闭合教训复发点：load 过、真盘崩）。
- **请求型 builder（如 extrareturns 逐体拉 `/astroextra/planetreturn`）不能塞进 headless JS**（JS 层不发 HTTP）——
  后端调用放 Python（`_run_*_tool` 循环 `_call_remote`），JS 只做纯格式化；或直接 Python 拼段（extrareturns 即此）。
- **后端「整段 sections」可能被旧 vendor 层 strip 掉**：太乙的 13 段解读 kintaiyi 后端本就返回（top-level `sections`），
  但 `tools/taiyi.js` 历史上 `sections: undefined` 整体丢弃。排查法：抓 `js_client.run` 实际收到的 `ken_response`，
  grep `sections`/段名，再决定是「透传」还是「重 vendor builder」。条件出现的段：**同时进 preset（present 不 unknown）
  + optional（absent 不 missing）**——单进 optional 不够（parser 的 unknown 只减 preset，见 `exports/parser.py:130`）。
- **CI 起不了后端**：GitHub Linux runner 无 Linux 运行时（Linux PR 已拒；运行时 macOS/Windows-only + gitignore）。
  别造「boot runtime」假 job；CI 网 = offline FakeClient 契约 + export-fixture 契约，全套 live 在本机 vendored 实例发布前跑。
- **`04caa37`（Windows v0.12.0）带来的两道闸**：`release-completeness.yml`（发布后查 latest 是否双平台——darwin-only latest
  过渡期必红=预期信号）+ `verify_builder_parity.py`（mac/win builder 锁步 + REQUIRED_ENTRIES 对称）。新技法是 xuanshu-core-js
  内的 JS+Python（随包带入，不改 payload/REQUIRED_ENTRIES），故 parity 不受影响——但发布前要跑 `verify_builder_parity.py`。


### v0.12.0 sync lessons (主限法 v12 核5收敛 + 排盘修正批 + faRelatedPeople — vendor 源 = xuanshu-engine)

- **vendor 源 = 开源仓 xuanshu-engine**（`XUANSHU_SOURCE_ROOT=/Users/dev/Desktop/xuanshu-engine`；
  sync 脚本默认根是 Desktop、其下无 Horosa-Web，必须显式传）。Public 的 PD 引擎天然就是核5+legacy 白名单
  （perchart 白名单 ↔ `_PD_METHOD_REGISTRY` 6 键锁步），v12 核 kernel 完整（Vertex/多圈/每盘钥匙/显示窗）。
  同步后核法：vendored astropy 与 xuanshu-engine 逐文件 `diff -q` 全同 + `PD_SYNC_REV==pd_method_sync_v12`
  + golden v266 在位。**同步与核对一律以 xuanshu-engine 为唯一来源。**
- **`/predict/pd` 的 params 回显是原样输入，不是引擎解析值**：送 `placidus` 回显仍 `placidus`，但引擎内已
  回退 core_alchabitius（行集与显式 core 逐位一致，live 测试钉死）。skill 快照对白名单外键如实标注
  「未核验，引擎回退 Alcabitius 半弧法」，不静默换标签。
- **live 验证必须打 skill 自己 vendored 的引擎实例，不是 :8899/:9999 上恰好在跑的东西**——默认端口上
  常驻的服务不保证与 vendored 引擎同版本（陈旧实例会掩盖白名单/钥匙问题）。本轮把 tests 的
  gate+`make_service` 从写死 `:8899/:9999` 改为尊重 `XUANSHU_CHART_SERVER_ROOT`/`XUANSHU_SERVER_ROOT`
  （此前 env 覆盖静默无效，一次「带覆盖的全绿」实际测的是默认端口上的旧实例）。
  起 vendored 实例：chart 要 `PYTHONPATH=<vendor>/Horosa-Web/astropy`
  + `HOROSA_CHART_PORT`（脚本只自动解析 flatlib，不解析自身包根）；java 用 vendored
  `runtime/mac/java/bin/java -jar runtime/mac/bundle/astrostudyboot.jar --server.port=… --astrosrv=…`
  （root 500 = 正常无路由）。
- **防陈旧进程门已制度化为 live 测试**：chart 心跳 `GET /` 回显 `pdSyncRev`，断言 ==`pd_method_sync_v12`
  再信任结果（v12 注记坑#6：陈旧引擎把未知时间钥匙静默按 Ptolemy 算）。**钥匙分叉探针别用 Kündig**（静态
  标度 1.0 与 Ptolemy 同日期）——用每盘真算的 Kepler（live：321/321 行日期分叉）。
- **pd 表行是列表不是字典**：`[arc, prom, sig, type, date]`；3000 年多圈 = 同 (prom,sig) 弧 +360°×n
  （live 实测 168 组复发对，max arc 2995.5°）。宿命点行 id `N_Vertex_0` 仅 In-Zodiaco；skill 侧
  `ASTRO_TEXT_MAP["Vertex"]="宿命点"`（主短两表都要）。
- **faRelatedPeople 透传**：vendored `computeProtect` 吃 `pan.faRelatedPeople=[{name, yearGan}]`（显式数组
  为准，缺省不出行）。skill 在 Python 侧把 `{name, birth}` 经 `/nongli/time` 的 `yearJieqi`（立春界）归一化
  为年干（1991-02-03 → 庚，立春前归前一年，live 钉死），JS 保持上游 verbatim 只 stamp。上游的
  `birthToYearGan` 依赖 lunar-javascript，skill 不引这个依赖——走自家 nongli 后端同口径。
- **排盘修正批随重同步自动带入**（日返/月返种子、合盘/组合盘归一化、恒星跨0°、围攻 orb、均时差等，上游
  pytest 60 + golden byte-perfect 已验）；skill 结构断言型测试全绿，无需改动。
- 界 (term) promissor row id = `T_<ruler>_<sign-name>`（非经度）；上游 dial 的 `_PD_CHART_METHOD_HSYS`
  只在 skill 暴露 dial 时才相关（目前只暴露 PD 表）。


> ↓ 附录：v0.12.0 当轮的同步清单原文（自述「留作历史核对参照」）。

## 主限法 v12 批(upstream 玄枢 v2.6.6 — ✅ 已于 v0.12.0 同步完成,vendor 源=xuanshu-engine)

> 下面 7 条是当时的同步清单,留作历史核对参照;实际执行结论与坑见上方「v0.12.0 sync lessons」节
> (全部逐条核到:核5白名单/22钥匙/Vertex/3000多圈/golden v266/pdSyncRev 心跳门/钥匙分叉 live 测试)。

1. **显示窗口径换了**:行星对显示窗 = 「弧 pre-norm 原值 |Δ| < 107.5」单参数判据(`_passesCoreDisplayWindow`),旧三分支 λ 窗 + EPS 已删。世俗(In-Mundo)核旧窗符号错配修复 → **In-Mundo 行星对行显著增多是修复非回归**,skill 的 golden/selfcheck 若按旧行数断言会假红。
2. **宿命点(Vertex)应星新增**(仅黄道向运;世俗核不出):行 id `N_Vertex_0`,闭式直算。snapshot/导出段如列方向行,新应星会出现。
3. **时间钥匙修真**:Simmonite/Kepler/Brahe 由常数改**每盘真算**(本命太阳日速);新增 `Kündig`(静态 1.0)与 `SymbolicSolarArc`(动态,逐弧查星历)。同步时 `STATIC_TIME_KEY_SCALES` 集合与 `PER_CHART_TIME_KEY_FALLBACK` 一起带。
4. **pdYears 上限 360→3000**:`perchart.py` 夹断 3000;`perpredict._extendCorePdRecurrences` 统一旧「180+ 互补行」与多圈复发(基弧+360m)。≤360 逐位等价旧式;skill 侧若有 pdYears 校验/文档要同步上限。
5. **golden 改名** `golden_alcabitius_ptolemy_v266.ndjson.gz`(v253 删),manifest 同步;`PD_SYNC_REV = pd_method_sync_v12`(helper.py/webchartsrv.py + 前端 + Java 4 控制器——skill 只 vendor Python 也要带 rev,响应 params.pdSyncRev 会回显)。
6. **坑·陈旧 Python 进程静默吞新钥匙**:长驻 webchartsrv 不重启时,新动态钥匙会**静默按 Ptolemy 算日期**(未知 key 不报错走默认 scale)。skill 打包运行时若复用旧进程同坑;验证法 = 直接 POST 对比 Ptolemy vs 新键日期是否分叉。
7. 同步自检建议:vendored 引擎跑 `pdYears=3000` 应出多圈行(同 (prom,sig) 链上 arc+360k、日期逐圈递增);`pdYears=100` 行集与 v2.6.5 vendor 比对 — 仅显示窗/宿命点差异属预期。


### v0.11.0 sync lessons (Xuanshu v2.6.3→v2.6.5 parity + 2 v0.10.0 deferrals — no new tools, still 68)

- **Sidereal ayanāṃśa is pure Python passthrough.** `perchart.py` reads `data.get('siderealAyanamsa')` and emits
  `chart.siderealAyanamsa` + `chart.nakshatras` (sidereal only). `BirthInput` has `extra="allow"` so the param already
  flows via `model_dump(exclude_none=True)`; declaring it is for discoverability + guidance only. **Real bug fixed:** the
  skill's `ASTRO_MSG["Sidereal"]` was hardcoded `恒星黄道，岁差:Lahiri` → mislabelled Raman/Fagan charts; de-hardcode it,
  read the ayanāṃśa from `chart.siderealAyanamsa` (西占) / `chart.siderealModeKey`+`ayanamsaValue` (印占, **different field
  names**), and put the real name on its own line. `chart.zodiacal` is a *localized string* ("恒星黄道"), not an int — don't
  gate on `== 1`. Nakshatras read from `response.chart.nakshatras`, NOT top-level.
- **India is Python (`/india/chart` in `_PYTHON_CHART_ENDPOINTS`), reads `indiaHsys`/`indiaAyanamsa`** (aliases hsys/ayanamsa/
  siderealMode). Golden = ayanāṃśa *differences* are stable astronomical constants (Raman−Lahiri Sun lon = +1.446°,
  Lahiri−Fagan = +0.88°) — robust without pinning fragile absolute lon.
- **JS vendor dependency-closure is the whole game (六壬毕法 D + 政余格局 E).** Both are pure module-level closures
  (zero `this.`/React) — extract by transitive-call analysis, but **CONST refs are caught separately from function refs**
  (missing `JiaZiList`/`ERFAN_SU_TO_BRANCH` → silent `ReferenceError` swallowed by try/catch → null result). The 六壬 三传
  engine is a plain `ChuangChart` class — vendor it with draw-only imports (GraphHelper/helper/LRShenJiangDoc) replaced by
  no-op stubs (only `genCuangs` runs). `SZConst.js` reads `localStorage` at *module load* → **hardcode a no-op shim** (node
  25's experimental global `localStorage` throws without `--localstorage-file`; don't probe `globalThis.localStorage`).
  `AstroText.js` keys its maps on `AstroConst.*` constants → extend the `constants/AstroConst.js` shim with every planet/
  node/point the closure looks up, or the lookups return `undefined`-keyed.
- **政余格局 honest limitation:** 七政神煞 (官/福/疾/天贵/玉贵/岁驾) come from a *separate* kinastro qizheng engine
  (`fetchKinastroQizheng`) the western-`/chart` guolao path never calls → `guolaoGods` absent → god-dependent patterns
  can't fire (chart-object ones do). The 神煞 section was already empty for the same reason. `能接多少接多少、跑不通如实标出`.
- **紫微 P0–P2 data is all in the jar response** (re-synced): top-level `patterns` (命中格局: name/category/duanyi/broken),
  `houses[].starsOthersGood/Bad/Small` (杂曜), `direction`/`smallDirection` (大限/小限). Just surface it in
  `_build_ziwei_snapshot_text`. 来因宫 + rich 流曜运限 are frontend-only (ZiWeiHelper) → not in the response, honestly skipped.
- **Offline contract (`test_all_callable_techniques...`) forbids bare `无` sections.** Any new JS-fed or jar-fed section
  needs a `FakeJsClient`/`FakeClient` handler returning real content (guolao_moira; `/ziwei/{birth,rules}` patterns), AND
  the section in both preset + `AI_EXPORT_OPTIONAL_SECTIONS` (conditional → no false `missing`).


### v0.10.0 sync lessons (Xuanshu v2.5.4/v2.6.x parity — no new tools, still 68)

- **PD full-house params flow through `PerChart`, not the web layer.** `webpredictsrv.py:pd()` is just
  `PerChart(data) → getPredict() → getPrimaryDirection()`; `perchart.py` reads `pdMethod/pdDirect/pdAntiscia/...`
  from the request, `perpredict.py` reads them via `getattr(self.perchart, ...)`. So A only needed schema fields
  + a vendor re-sync (`input_normalized` is `model_dump(exclude_none=True)` → unset params fall back to the
  upstream defaults: direct/converse on, antiscia/terms off). Don't grep the web srv for the param — grep `perchart.py`.
- **JS re-vendor dependency closure is the #1 trap.** The jinkou 解读层 crashed on `LRConst.TaiXuanNum` undefined —
  the curated `vendor/liureng/LRConst.js` (131-line, AstroConst-free) was missing 6 new constants
  (`TaiXuanNum/ZiCong/ZiHai/ZiPo/ZiSangHe/ZiXing`). Do NOT re-vendor the full upstream `LRConst.js` (it `import`s
  `AstroConst` from a path that doesn't exist headless); append only the new pure constants. Always do a
  `node -e "import('...')"` load-check AND a real-data run after vendoring, not just a load-check.
- **qimen 法奇门 = surgical add, not a 2086-line re-vendor.** `DunJiaFaDoc.js` is pure; `DunJiaFaCalc.js` imports
  only `DunJiaFaDoc`. The existing `DunJiaCalc.js` works, so just add `import { buildFaQimenAnalysis }` + the +8-section
  block before its `return`. `buildFaQimenAnalysis(pan)` is compatible with the skill's kinqimen pan (live-verified);
  all 8 法 headers emit when `fa` is truthy. Preset = the builder's actual sections (14: skill has no `九宫与宫内星体`).
- **liureng `毕法/占断向导` — DONE in v0.11.0** (was deferred in v0.10.0): the ~40-field layout context IS assemblable
  headless. `buildLiuRengReferenceContext` + `buildLiuRengLayout`/`buildKeData`/`buildSanChuanData` are pure
  module-level functions (20-fn / ~570-LOC closure, zero `this.`/React) — extracted verbatim into
  `vendor/liureng/liurengRefContext.js`. The 三传 engine is `ChuangChart.genCuangs()` (plain class; vendored with
  the 3 draw-only imports — GraphHelper/helper/LRShenJiangDoc — replaced by no-op stubs since only genCuangs runs).
  Deps: full `LRConst.js` (re-vendored 21→52 exports superset; has GanJiZi/GuiRengs/GanZiWuXing/getGuiZi), `LRPanStyle.js`,
  a 12-LOC `constants/AstroConst.js` shim (LIST_SIGNS + Sun/Moon). Wired in `tools/liureng.js`: `[毕法（已命中）]` always
  (refCtx success), `[占断向导]` only when `payload.zhanCategory` ∈ {hunyin/taichan/jibing/caiyun/…}. Both in the liureng
  preset + `AI_EXPORT_OPTIONAL_SECTIONS["liureng"]` (conditional → no false missing). **坑**: missing a module-level const
  in the closure (JiaZiList/ERFAN_SU_TO_BRANCH) → silent `ReferenceError` caught by try/catch → refCtx null → 毕法 absent;
  and a missing `ChuangChart` import → 三传 null → only non-三传 毕法 fire. Always trace refCtx + sanChuan on a real 盘.
- **guolao `政余格局` — DONE in v0.11.0** (was deferred): `buildLocalMoiraPatterns` (Moira DSL) + its 34-fn/~600-LOC
  pure closure (zero `this.`) extracted verbatim into `vendor/guolao/guolaoMoira.js`; runs via `js_client.run("guolao_moira")`
  in `_run_guolao_chart_tool`, appended as the `[政余格局]` section. Deps chained out: `vendor/suzhan/SZConst.js` (with a
  hardcoded `localStorage` no-op shim — node 25's experimental global localStorage throws without a flag), the real
  `constants/AstroText.js` (name maps) + an extended `constants/AstroConst.js` shim (planets/nodes/points the maps key on),
  and inline `GUOLAO_LIFE_MODE_*` + `getStored*` default stubs (headless has no UI prefs → ASC 命度 / su28=2).
  **Honest limitation** (`能接多少接多少、跑不通如实标出`): the 七政神煞 (官/福/疾/天贵/玉贵/岁驾) come from a *separate*
  kinastro qizheng engine (`fetchKinastroQizheng`), which the skill's western-`/chart`-only guolao path never fetches — so
  `guolaoGods` is absent and the **god-dependent patterns** (八杀朝天/日月拱官/官福失垣/…) can't fire. The **chart-object
  patterns** (孛犯太阳/罗犯太阳/金水相涵/日月失所/命坐两歧/孤月独明) DO fire (golden: 1985-03-21 → 金水相涵 + 孛犯太阳).
  The 神煞 section was already empty for the same reason (pre-existing). Closing it = wiring the qizhengkin gods in (future).
- **Live services make the @requires_* tests run.** When `:8899` (chart/ken) and `:9999` (Java) are up, pytest runs
  the integration tests for real (233 passed, 0 skipped). That validated B/C/A against real Python compute and the
  qimen/jinkou 解读层 against the real ken backend — the best signal available. CI (services down) skips them.


### v0.9.2 hardening lessons (audit pass — tests/robustness/fidelity/runtime)

- **`f"{response.get('snapshot')}"` produces the literal string `"None"` when the key is absent** (a truthy
  6-char string → a garbage "None" export that silently passed). Always guard `raw = response.get("snapshot")`
  then `f"{raw}".strip() if raw else ""`. This bit `_run_shenshu_tool`; the same `f"{...or ''}"` idiom is safe
  only because of the explicit `or ''`.
- **Don't silently fall back in compute runners.** `_split_birth_ymdhm` used to substitute `2025-01-01` on an
  unparseable date (wrong-moment chart, no error). Now it raises `tool.shenshu_bad_date`; `_run_shenshu_tool`
  raises `transport.shenshu_snapshot_unavailable` on a no-snapshot (old-backend) response; horary/election/
  progextra log + attach `snapshot_error` instead of a bare `except: pass`.
- **persiandirected dates differ from 玄枢 by ≤1 day** (~40% of rows). Root cause: 玄枢's moment
  `add(N,'days')` TRUNCATES the fractional day (JS `Date.setDate` floors), AND `arc % 360` has JS↔Python
  float noise that rounds to the same 2-dp age but flips a day at the integer boundary. Matching the truncation
  made it worse (float noise dominates). The ages/aspects/targets are byte-identical; the ≤1-day 应期 date is
  astrologically negligible and documented (`docs/v091-fidelity-spotcheck.md`). To verify a hand-port's
  fidelity, extract the 玄枢 builder's pure functions + run them on the same fixture and diff — but mind
  `moment` (CJS, `createRequire`) and the React-class lines.
- **Runtime-slim reality: `pyarrow`(119M)/`pandas`(40M) are astropy deps, NOT streamlit-only.** kintaiyi needs
  `import astropy.units` → astropy needs pyarrow+pandas. Stripping them breaks taiyi. streamlit is imported
  pervasively across `kinastro/astro/*` (st.markdown ×1817 …) so it can't be stripped without a fragile stub.
  **Only `plotly`(40M) is safely strippable** (streamlit-only + lazily imported for `st.plotly_chart`, never hit
  headless). Verified `import streamlit` + cetian snapshot + `astropy.units` all OK without it.
- **Export presets are a SUPERSET; some sections are 玄枢-UI-only or conditional.** `AI_EXPORT_OPTIONAL_SECTIONS`
  (registry) lists sections a preset names but the headless snapshot may not emit (检索/查询 panels, mode/topic
  conditional). The parser excludes them from `missing_selected_sections` so real exports read clean; strict
  techniques keep an empty optional set. Also: a preset copied from `aiExport.js` can MISS sections the backend
  actually emits (qizhengkin 今制宿度/古制宿度) → they surface as `unknown_detected_sections`; add them to the preset.


> ↓ v0.9.0 暂缓、v0.9.1 全部补齐的神数家族整合记录原文。

### 神数 family (14) — ALL SHIPPED (v0.9.1)

The kentang registry (`astropy/websrv/kentang/registry.py`) mounts **14 神数 engines on the chart
service (:8899)**: wangji / wuzhao / taixuan / jingjue / shenyishu (5 standalone engines) + shaozi /
tieban / fendjing / beiji / nanji / chunzi / xianqin / cetian / qizhengkin (9 sharing the **`kinastro`**
engine). Both groups are now integrated — the wiring is identical (backend `snapshot` → export), the
only difference is which engine dir is vendored:

- **Tier 1 — 5 standalone engines: SHIPPED.** `vendor/{kinwangji,kinwuzhao,taixuanshifa,jingjue,shenyishu}`
  (~5.2 MB total). Each `web{key}srv.py` builds a `response["snapshot"]` whose `[小节]` headers already
  match 玄枢's `aiExport.js` preset, so the skill needs **no snapshot builder** — just POST `/{key}/pan`
  and export `response.snapshot`. Wiring: one shared `_run_shenshu_tool(payload, key)` + `_split_birth_ymdhm`
  (神数 take split year/month/day/hour/minute, not date/time strings) + a `ShenShuInput` (FlexibleModel:
  date + optional time + 晚子时 switches + an `options` passthrough for engine-specific overrides like
  wuzhao mode/number). **CRITICAL routing gotcha:** kentang mounts only reach :8899 if the endpoint is in
  `_PYTHON_CHART_ENDPOINTS` — otherwise `_call_remote` sends them to the Java :9999 server and they 500.
  Add `/wangji/pan` … `/shenyishu/pan` there (alongside `/qimen/pan`).
- **Tier 2 — 9 kinastro-* engines: SHIPPED (v0.9.1).** All 9 share the `kinastro` engine
  (`from astro.{shaozi,fendjing,chunzi,cetian_ziwei,…} import …`). Same shared `_run_shenshu_tool`;
  cetian/qizhengkin/xianqin also forward `gender` + place. **The v0.9.0 "deferred" call was WRONG:** the
  live :8899 returned `basic`-only data only because the user's *running* app was an older build — the
  current source's `web{key}srv.py` all set `pan["snapshot"] = build_snapshot(pan)`, and the engine
  imports + computes cleanly under the bundled Python. Vendor the **engine only**: `vendor/kinastro`
  with `--exclude=tools` (the 26 MB `tools/cities` geocoding DB is not needed for ganzhi 神数) +
  `--exclude={ui,frontend,docs,wiki,examples,tests,styles,scripts,.streamlit,…}` → ~31 MB (`astro/` is
  32 MB raw). `ensure_kinastro_path()` puts `vendor/kinastro` on `sys.path` so `import astro.shaozi`
  resolves; `streamlit` is a kinastro import but it's already in the bundled site-packages (the
  `@cache_data`-without-runtime warning is harmless). **Validate offline by invoking each
  `web{key}srv` class's `pan()` with a mocked `cherrypy.request` from a NEUTRAL CWD** (NOT `cd $HW`, or
  the local `Horosa-Web/astropy/__init__.py` shadows PyPI astropy → `No module named astropy.units`).
- **The 9 kinastro-* have NO live `@requires_chart` test** — the user's running app is an older build
  without their snapshots, so a live test would red. They're covered by the offline FakeClient contract
  suite (the fake synthesizes a preset-covering snapshot) + the in-process srv validation.
- **Some kinastro presets have conditional sections** (tieban/chunzi/cetian emit fewer than the full
  `aiExport.js` preset for a given input). The FakeClient emits the FULL preset so the offline contract
  is clean; real exports may show a few `missing_selected_sections` — that's expected (like election).
- **NATIVELY CONFIRMED on Windows (v0.9.1 release build).** Booting the bundled `win32-x64` chart service
  and POSTing to each `/{key}/pan`, **all 14 神数 returned `ResultCode 0` with a real `Result.snapshot`** —
  the 5 standalone (`source` `kinwangji`/`kinwuzhao`/`taixuanshifa`/`jingjue`/`shenyishu`) and all 9
  kinastro-* (`source: kinastro`, snapshots 540–6000 chars). So the engine-only kinastro trim (above)
  is sufficient and the "deferred" worry is fully retired on Windows too — not just structurally.
- **Native-probe gotcha: the snapshot is nested at `Result.snapshot`, not top-level.** The raw chart-service
  response is `{ResultCode, Result:{source, engine, snapshot, raw, …}}` (the skill's `_call_remote` unwraps
  `Result` for `_run_shenshu_tool`, which then reads `response["snapshot"]`). If you probe `/{key}/pan` with
  raw HTTP and read a top-level `snapshot`/`engine`, you'll wrongly see "empty" and think the engine failed.
  Read `Result.snapshot` / `Result.source`.


> ↓ ≈skill v0.8.x 时代：上游玄枢 v2.5.0 批的整合记录原文。

### v2.5.0 推运 (7) + 卜卦/择日 — JS-vendor vs Python-port decision tree

玄枢 v2.5.0 added 7 推运 (jaynesprog / vedicprog / planetaryarc / planetaryages / balbillus /
yearsystem129 / persiandirected) plus the **horary (卜卦)** and **election (择日)** divination engines.
The integration rule that emerged:

- **Backend-computed (has a `/predict/*` or `/astroextra/*` endpoint) → Python.** jaynesprog
  (`/astroextra/jaynesprog`), vedicprog (`/astroextra/progressions` zodiacal=1), planetaryarc
  (`/predict/planetaryarc`) — `_call_remote` + a Python snapshot builder. Add the endpoint to
  `_PYTHON_CHART_ENDPOINTS`. **These 3 endpoints did NOT exist in the v2.4.0 `vendor/runtime-source`** —
  they need the v2.5.0 re-sync (`sync_vendored_runtime_sources.sh`) before the bundled runtime can serve
  them; the LIVE 玄枢 app (:8899) already has them, which is why the live `@requires_chart` tests pass
  pre-rebuild.
- **Frontend, reads pre-computed chart data → Python.** planetaryages (reads `chart.objects` +
  `params.birth`), yearsystem129 (reads `predictives.yearsystem129`, which `/chart` only emits when cast
  with `predictive` truthy — `getPredictivesObj`), persiandirected (pure 1°/年 arithmetic off
  `chart.objects`/`houses`/`birth`). Ported to Python reusing `_astro_msg` / `_aspect_label` /
  `_split_degree`.
- **Frontend, algorithm-heavy / risky to re-derive → vendor the JS verbatim.** balbillus (247-line
  129年旺距削减 with recursive sub-periods). Vendored `astrostudyui/src/utils/balbillus.js` →
  `xuanshu-core-js/src/vendor/astroextra/balbillus.js`, redirecting its `AstroConst`/`AstroText` imports to
  a tiny **`progConst.js` stub** (7 classical planet ids + `LIST_SIGNS` + `AstroTxtMsg` — avoids vendoring
  the 1128-line AstroConst). Needs `moment` (added to `xuanshu-core-js/package.json`). Dispatched through a
  new **`progextra` JS tool** (`technique` → builder map) called from `_run_progextra_js_tool`.
- **卜卦/择日 = vendor the whole `divination/` tree.** It's ~3200 lines of **pure logic with only relative
  imports** (no React/antd). Copy the entire `astrostudyui/src/divination/` into
  `xuanshu-core-js/src/vendor/divination/` (this also re-syncs the v0.8.0 lifespan subset to upstream), then
  **add `.js` to every relative import** (Node ESM needs explicit extensions; a one-shot regex over
  `from '…'` does it — 22 files). Two thin JS tools `horary.js` / `election.js` call
  `runHorary(chartResp, category)`+`buildHorarySnapshot` / `runElection(chartResp, topicId)`+
  `buildElectionSnapshot`. Python `_run_horary_tool` / `_run_election_tool` cast a **traditional**
  (`tradition:1`, `predictive:0`) chart at the question/candidate moment, pass the `/chart` response as
  `payload.chart`, and read back the JS-resolved `category`/`topicId` (the engine falls back unknown →
  `general`/`marriage`).

Gotchas that bit us here:
- **`buildFacts(result)` wants the full `/chart` response** (it reads `result.chart.objects`, `result.objectMap`,
  `result.aspects`, …), so pass the whole response object as `chart`, not just `chart.objects`.
- **election preset has dead/conditional sections.** 玄枢's `aiExport.js` election preset lists `应期`
  (its builder **never** emits it) and `用事专属` (only when the topic rule-pack produced items). We mirror the
  preset for fidelity, but `_assert_clean_export` (which requires `missing_selected_sections == []`) is too
  strict for election — assert `missing ⊆ {用事专属, 应期}` instead. horary's 9 sections are all reliably
  emitted (描述 is technically conditional but present for normal charts), so horary keeps strict clean-export.
- **Router: 卜卦 also contains the generic 卦.** The 梅花易数/卦 branch (`["梅易","卦","gua"]`) must exclude
  horary phrasing (`卜卦/horary/起卦/占问`) or `卜卦问婚姻` mis-routes to `gua_desc`.
- **Offline test fakes must cover the new JS tools.** `FakeJsClient.run` needs `progextra` (balbillus snapshot),
  `horary`, `election` handlers, and `FakeClient` `/chart` needs `predictives.yearsystem129`, or the offline
  export-contract suite falls back to `generated_template` and fails.


> ↓ ≈skill v0.7.x 时代：上游玄枢 v2.4.0 批的整合记录原文。

### v2.4.0 西占 (Western) techniques — agepoint / distributions / mundane / natal extras

These are 玄枢 v2.4.0 additions; integrating them required **re-vendoring `vendor/runtime-source` from
玄枢 v2.4.0** (the bundled chart service then carries `/predict/agepoint`, `/predict/dist`,
`/astroextra/greatconj`, and the enriched `/chart`). Patterns:

- **`agepoint` / `distributions` are simple backend predict tools** (like harmonic): `_call_remote`
  (`/predict/agepoint` → `{agepoint:{points:[…]}}`; `/predict/dist` → `{dist:[…]}`) + a Python snapshot
  builder (`_build_agepoint_snapshot_text` / `_build_distributions_snapshot_text`, ports of 玄枢's frontend
  builders). Both endpoints are in `_PYTHON_CHART_ENDPOINTS`. Each has a single-section export contract.
- **本命增补 (12分度 / 主宰星链 / 寿命格局) is JS-computed, Python-formatted.** 玄枢 computes these in the
  frontend (`astroAiSnapshot.js`), reading the chart object. The skill vendored the needed 玄枢
  `divination/` engine subtree into `xuanshu-core-js/src/vendor/divination/` (chartFacts + the Ptolemy
  **lifespan** engine + `data/{signs,dignities,planets,houseMeanings}` + `engine/utils` — a clean 8-file
  closure, no npm deps) and wrote `src/vendor/astroextra/natalExtras.js` + the `astroextra` JS tool that
  return **structured** data (dodeca pairs / dispositor chains / the runLifespan res). `service.py`'s
  `_attach_natal_extras` (only for `chart` + `mundane`) calls it via `js_client`, and
  `_build_natal_extra_sections` formats the 3 sections with `_astro_msg` — so the JS does compute, Python
  does the Chinese formatting (no `AstroText`/`whichTerm` vendored). They are inserted into the astrochart
  snapshot before `可能性`; the `astrochart` preset gained the 3 sections.
- **`mundane` (世俗入宫盘) is a composite** local tool: `/jieqi/year` (seedOnly, `jieqis:[term]`) → find
  the `jieqi24` entry whose `jieqi==term` → its `time` is the precise ingress moment → `/chart` at that
  instant → `_attach_natal_extras('mundane', …)` → prepend a `[世俗入宫]` head to the astrochart snapshot.
  Input is **year + 入宫节气 + place** (date/time are derived, not user input).
- **Re-vendoring `vendor/runtime-source` (the skill's copy) is allowed and READ-ONLY on 玄枢.**
  `sync_vendored_runtime_sources.sh` with `XUANSHU_SOURCE_ROOT=<玄枢 tree>` does it. After it, re-apply the
  graceful-kentang-mount patch to the vendor's `astropy/websrv/kentang/registry.py` if you run the chart
  service directly from `vendor/` (the **build** scripts patch the staged copy automatically; the raw
  vendor hard-fails on `mount_kentang_services` because the kentang registry lists engines like `kinwangji`
  that the skill doesn't vendor).


### 发布完整性编年（v0.10.0–v0.18.0）— 原文

> ↓ 原为 AGENTS.md 打包 gotcha 大 bullet；现行「三失效模式 + 检测 + 修复」法则已蒸馏进 `AGENTS.md` §7，这里保存完整案例史。

- **A new release published as `latest` is repeatedly missing its Windows half — ALWAYS check the release
  manifest first. The CI guard now catches this automatically.** The mac side has shipped this incomplete on
  **every minor since v0.10.0**: v0.10.0 had **no** `runtime-manifest.json` at all (`releases/latest/download/runtime-manifest.json`
  404 → `install` broke on BOTH platforms); v0.11.0 through **v0.16.0** shipped a **darwin-only** manifest +
  no win32 zip (mac installs, **Windows** install finds no `win32-x64` entry / 404s the zip). **Auto-caught
  since v0.13.0**: `release-completeness.yml` fires on the release event and fails, exactly as designed —
  so rely on that red check instead of noticing by hand (it flagged v0.14.0/v0.15.0/v0.16.0 too).
  **v0.16.1 (2026-07-01) broke the streak: the first mac-shipped COMPLETE dual-platform `latest`.** The mac
  side repacked the Windows-built v0.16.0 zip with a corrected embedded manifest (version 0.16.1 +
  `export_registry_version` 7 — confirmed by range-reading the published zip; sizes differed from the
  v0.16.0 archives by only ~50 bytes) and the guard went green on the release event with zero Windows-side
  action. A repack like this is only valid when the release diff has **no payload-affecting changes**
  (xuanshu-core-js source, vendored engines, wheels, launchers — skill-layer Python/docs are fine); when a
  suspiciously same-size win zip appears on a new release, verify the embedded manifest (version +
  `export_registry_version`) and that diff condition before trusting it.
  **v0.17.0 / v0.18.0 introduced a THIRD, stealthier mode — "pin-forward":** the new release's manifest
  lists `win32-x64` but points it at the *previous* version's win zip (v0.17.0/v0.18.0 both pinned
  `.../download/v0.16.1/xuanshu-runtime-win32-x64-v0.16.1.zip`). **The guard stays GREEN and `install` does
  NOT break** — both platforms are present, the URL resolves 200, and the sha matches — but Windows users
  silently get a runtime **N versions stale** (missing every feature since the pinned version). The guard
  can't catch this (it only checks presence + resolvability, not version match). **`sync_windows_release.py
  --check` IS the reliable detector**: it looks for the version-specific `xuanshu-runtime-win32-x64-vX.Y.Z.zip`
  asset, which is absent under pin-forward, so it reports `[GAP]` even while the guard is green. Treat a
  `--check` GAP as authoritative regardless of guard colour; the remediation (build + upload the real win
  zip, re-pointing the manifest) is identical. **Freshness caveat for these jumps:** v0.17.0 was an "引擎全面
  升级" that added real chart-service endpoints (`/location/acg` 占星地图, `/astroextra/relative`) and new
  bundled data (`astrostudyui/dist-file/astrodata/astrodata-aa.sqlite.gz` for 名人库, ~50 MB) — a pin-forward
  jump can span such changes, so re-populate `vendor/runtime-source` from the **current** Windows workspace
  (check astropy / dist-file mtimes are newer than the target release) and native-verify the new endpoints
  return real data before shipping. The Windows runtime is built off-repo on a Windows box, so a mac-only
  release publish leaves it out. **First diagnostic when
  "check sync" / a new version appears:** `gh release view vX.Y.Z --json assets` (expect darwin tar.gz +
  win32 zip + runtime-manifest.json + SHA256SUMS.txt) and confirm
  `releases/latest/download/runtime-manifest.json` has **both** `darwin-arm64` and `win32-x64` platforms.
  If the win half is missing: build it, regenerate the **dual-platform** manifest + SHA256SUMS, and upload —
  the release is usually already `latest`, so the upload alone (no flip) restores Windows `install`.
  **Automated since v0.12.0:** `.github/workflows/release-completeness.yml` (schedule + dispatch + release
  events) fails if the published `latest` lacks either platform / an archive 404s, and
  `scripts/verify_builder_parity.py` (CI `test` job) fails if the two builders or the verifier contract
  drift. If either alarms, the fix is this same build-the-Windows-half flow.
  **One-command remediation (v0.14.0):** on the Windows build box, `python scripts/sync_windows_release.py`
  detects whether the current `latest` is missing its Windows half and (when run with `--upload`) runs the
  whole build → download-darwin → dual-platform manifest + SHA256SUMS → `verify_runtime_release.py` →
  upload pipeline. Safe by default (no `--upload` = build + verify only, no irreversible action), idempotent
  (no-op + exit 0 when already in sync), and it gates the upload behind `verify_runtime_release.py`. It
  reads the version from `pyproject.toml`, so `git pull` to the release commit first. This is the canonical
  way to clear a `release-completeness` red — prefer it over doing the steps by hand. **Battle-tested
  end-to-end on v0.16.0 (2026-07-01):** re-populate `vendor/runtime-source` from the Windows workspace,
  build, native-verify (chart `:8899` compute — the new `/geomancy/reading` + `/astroextra/*` mundane
  endpoints returned real data, confirming the source tree was fresh), then the sync tool packaged +
  uploaded and the guard went green + a public `install --force` matched the sha.


> ↓ 上游玄枢 v2.2.1 的 SSE 陷阱原文；不影响 skill 计算路径，仅供替用户排障玄枢桌面端时参考。

### Bonus upstream trap (v2.2.1) — AI-analysis SSE Issue #8

The skill talks to its own ken backend, not 玄枢's `chat/stream` SSE proxy, so this does NOT affect
skill compute paths. It's documented here because if a user ever debugs 玄枢 desktop and asks "why did
my Ollama chat just go silent and then die", the answer is upstream:

- **Catch block in `AIAnalysisProxyService.chatStream` used to swallow the first-cause exception**:
  `sendEvent` inside catch rethrew `ClientAbortException` as `RuntimeException`, killing the
  `ai-analysis-chat-stream` thread, and the original Ollama error went only into a
  `safeErrorMessage(...)` SSE frame that never reached the client. Upstream fix: `QueueLog.error(...)`
  first, then nested try around `sendEvent` + `completeWithError`.
- **The three `stream***` methods used to send zero bytes until the first delta**: with a local Ollama
  TTFT of 10–60 s, browsers/Chromium/middleware time the SSE socket out as idle. Upstream fix: each
  stream method is now wrapped in `withHeartbeat`, which emits `: keep-alive` every 15 s.

If a skill user reports flaky 玄枢 AI streaming, point them at upstream v2.2.1 and the
`release_preflight.sh` sentinel `[7]` that gates both lines (`QueueLog.error(AppLoggers.ErrorLogger` and
`keep-alive`) in `AIAnalysisProxyService.java`.
