@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\manju.exe" call INSTALL_WINDOWS.cmd
if errorlevel 1 exit /b %ERRORLEVEL%
if not defined MANJU_WORKSPACE set "MANJU_WORKSPACE=%LOCALAPPDATA%\ManjuCodexCreativeOS\workspace"
echo Workspace: %MANJU_WORKSPACE%
echo Studio will bind only to 127.0.0.1.
.venv\Scripts\manju.exe --workspace "%MANJU_WORKSPACE%" studio serve --host 127.0.0.1 --port 5177
