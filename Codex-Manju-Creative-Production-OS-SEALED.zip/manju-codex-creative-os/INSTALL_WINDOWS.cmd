@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto install
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  py -3 -m venv .venv
) else (
  python -m venv .venv
)
if errorlevel 1 exit /b 1
:install
for %%F in (dist\*.whl) do set "MANJU_WHEEL=%%F"
if not defined MANJU_WHEEL (
  echo Package wheel not found.
  exit /b 2
)
.venv\Scripts\python.exe -m pip install --no-deps --force-reinstall "%MANJU_WHEEL%"
if errorlevel 1 exit /b 3
echo INSTALL_OK
