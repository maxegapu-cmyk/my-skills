from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = REPO_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from manju_os.app import ManjuApp
from manju_os.backup import restore_backup
from manju_os.errors import LockedError


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="manju-prod-verify-") as tmp:
        root = Path(tmp)
        ws = root / "workspace"
        with ManjuApp.open(ws) as app:
            project = app.create_project("Verification Project")
            shot_a = app.create_production_unit(project.project_id, "shot", "SH-A")
            shot_b = app.create_production_unit(project.project_id, "shot", "SH-B")
            asset = app.create_asset(project.project_id, "character", "Verification Hero")
            first_file = root / "first.png"; first_file.write_bytes(b"first")
            first = app.ingest_revision(asset.asset_id, first_file)
            app.submit_review(first.revision_id, "pass")
            app.promote_master(first.revision_id)
            app.set_asset_lock(asset.asset_id, True, reason="freeze")

            second_file = root / "second.png"; second_file.write_bytes(b"second")
            second = app.ingest_revision(asset.asset_id, second_file)
            app.add_provenance(first.revision_id, second.revision_id, "derived_from")
            app.submit_review(second.revision_id, "pass")
            try:
                app.promote_master(second.revision_id)
                raise RuntimeError("lock gate failed")
            except LockedError:
                pass
            app.set_asset_lock(asset.asset_id, False, reason="verified change")
            app.promote_master(second.revision_id)

            task = app.create_task(project.project_id, "verify task", production_unit_id=shot_b.production_unit_id)
            for state in ("ready", "running", "waiting_review", "done"):
                task = app.transition_task(task.task_id, state)

            snap_a = app.create_continuity_snapshot(project.project_id, shot_a.production_unit_id, {"door": "closed"})
            snap_b = app.create_continuity_snapshot(project.project_id, shot_b.production_unit_id, {"door": "open"}, inherited_from=snap_a.snapshot_id)
            if app.diff_continuity(snap_a.snapshot_id, snap_b.snapshot_id)["changed"]["door"]["to"] != "open":
                raise RuntimeError("continuity diff failed")
            if not app.search("Verification Hero"):
                raise RuntimeError("search failed")
            backup = app.create_backup()
            if not app.health_check().ok:
                raise RuntimeError("source health failed")

        restored_ws = root / "restored"
        restore_backup(Path(backup.path), restored_ws)
        with ManjuApp.open(restored_ws) as restored:
            if not restored.health_check().ok:
                raise RuntimeError("restore health failed")
            if restored.get_asset(asset.asset_id).active_revision_id != second.revision_id:
                raise RuntimeError("restored master mismatch")

    print("PRODUCTION_CONTROL_VERIFICATION_PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
