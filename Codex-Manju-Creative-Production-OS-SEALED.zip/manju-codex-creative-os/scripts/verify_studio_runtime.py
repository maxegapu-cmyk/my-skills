from __future__ import annotations

import json
import sys
import tempfile
import threading
import urllib.request
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = REPO_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from manju_os.app import ManjuApp
from manju_os.studio_server import create_server


def request_json(base: str, token: str, path: str) -> dict:
    req = urllib.request.Request(base + path, headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(req, timeout=5) as response:
        return json.loads(response.read())["data"]


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="manju-studio-verify-") as tmp:
        root = Path(tmp)
        ws = root / "workspace"
        media = root / "frame.png"
        media.write_bytes(b"studio-runtime-frame")
        with ManjuApp.open(ws) as app:
            project = app.create_project("Studio Verification")
            shot = app.create_production_unit(project.project_id, "shot", "SH-VERIFY")
            task = app.create_task(project.project_id, "Render", production_unit_id=shot.production_unit_id)
            asset = app.create_asset(project.project_id, "image", "Verification Frame")
            prompt = app.register_text_asset(project.project_id, "prompt", "Verification Prompt", "night hero")
            prompt_revision = prompt["revision"].revision_id
            revision = app.ingest_task_output(task.task_id, asset.asset_id, media, prompt_revision_id=prompt_revision)
            app.record_generator_run(
                project.project_id,
                "mock",
                task_id=task.task_id,
                prompt_revision_id=prompt_revision,
                output_revision_ids=(revision.revision_id,),
                parameters={"seed": 1},
            )
            app.submit_review(revision.revision_id, "pass")
            app.promote_master(revision.revision_id)
            app.create_continuity_snapshot(project.project_id, shot.production_unit_id, {"frame": "approved"})
            if not app.search("Verification Frame"):
                raise RuntimeError("runtime search failed")

        server = create_server(ws, port=0)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f"http://127.0.0.1:{server.server_port}"
        try:
            with urllib.request.urlopen(base + "/", timeout=5) as response:
                if b"Codex" not in response.read():
                    raise RuntimeError("studio UI did not load")
            dashboard = request_json(base, server.token, "/api/v1/dashboard")
            packet = request_json(base, server.token, f"/api/v1/tasks/{task.task_id}/packet")
            health = request_json(base, server.token, "/api/v1/health")
            if dashboard["active_masters"] != 1:
                raise RuntimeError("dashboard master count mismatch")
            if packet["task"]["task_id"] != task.task_id:
                raise RuntimeError("task bridge packet mismatch")
            if not health["ok"]:
                raise RuntimeError("studio health failed")
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)

    print("STUDIO_RUNTIME_VERIFICATION_PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
