from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"


def run_cli(workspace: Path, *args: str) -> dict:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(SRC) + (
        os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else ""
    )
    result = subprocess.run(
        [sys.executable, "-m", "manju_os", "--workspace", str(workspace), "--json", *args],
        cwd=ROOT,
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        raise AssertionError(
            f"CLI failed ({result.returncode}): {' '.join(args)}\nstdout={result.stdout}\nstderr={result.stderr}"
        )
    payload = json.loads(result.stdout)
    assert payload["ok"] is True, payload
    return payload["data"]


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="manju-core-verify-") as tmp:
        root = Path(tmp)
        workspace = root / "workspace"
        same_a = root / "same-a.bin"
        same_b = root / "same-b.bin"
        derived = root / "derived.bin"
        same_a.write_bytes(b"same-source")
        same_b.write_bytes(b"same-source")
        derived.write_bytes(b"derived-output")

        source_before = same_a.read_bytes()
        project = run_cli(workspace, "project", "create", "--name", "Verification Project")
        scene = run_cli(
            workspace,
            "unit",
            "create",
            "--project",
            project["project_id"],
            "--kind",
            "scene",
            "--name",
            "SC01",
        )
        shot = run_cli(
            workspace,
            "unit",
            "create",
            "--project",
            project["project_id"],
            "--kind",
            "shot",
            "--name",
            "SH001",
            "--parent",
            scene["production_unit_id"],
        )
        assert shot["parent_id"] == scene["production_unit_id"]

        asset_a = run_cli(
            workspace,
            "asset",
            "create",
            "--project",
            project["project_id"],
            "--type",
            "other",
            "--name",
            "Source A",
        )
        asset_b = run_cli(
            workspace,
            "asset",
            "create",
            "--project",
            project["project_id"],
            "--type",
            "other",
            "--name",
            "Source B",
        )
        asset_out = run_cli(
            workspace,
            "asset",
            "create",
            "--project",
            project["project_id"],
            "--type",
            "other",
            "--name",
            "Derived",
        )
        rev_a = run_cli(workspace, "asset", "ingest", str(same_a), "--asset", asset_a["asset_id"])
        rev_b = run_cli(workspace, "asset", "ingest", str(same_b), "--asset", asset_b["asset_id"])
        rev_out = run_cli(workspace, "asset", "ingest", str(derived), "--asset", asset_out["asset_id"])
        assert rev_a["blob_hash"] == rev_b["blob_hash"]
        assert same_a.read_bytes() == source_before

        run_cli(
            workspace,
            "provenance",
            "add",
            "--from",
            rev_a["revision_id"],
            "--to",
            rev_out["revision_id"],
            "--type",
            "derived_from",
        )
        lineage = run_cli(workspace, "asset", "lineage", asset_out["asset_id"])
        lineage_ids = {node["revision_id"] for node in lineage["nodes"]}
        assert rev_a["revision_id"] in lineage_ids
        assert rev_out["revision_id"] in lineage_ids

        vault_files = [p for p in (workspace / "vault" / "sha256").rglob("*") if p.is_file()]
        assert len(vault_files) == 2, vault_files

        health = run_cli(workspace, "health", "check")
        assert health["ok"] is True, health

    print("CORE_VERIFICATION_PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
