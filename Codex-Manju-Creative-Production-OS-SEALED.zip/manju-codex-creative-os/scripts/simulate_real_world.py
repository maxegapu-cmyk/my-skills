#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
import threading
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SRC = REPO_ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from manju_os.app import ManjuApp
from manju_os.backup import restore_backup
from manju_os.studio_server import create_server


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def _post(base: str, token: str, path: str, payload: dict, key: str) -> dict:
    req = urllib.request.Request(
        base + path,
        data=json.dumps(payload).encode("utf-8"),
        method="POST",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Idempotency-Key": key,
        },
    )
    with urllib.request.urlopen(req, timeout=15) as response:
        _assert(response.status == 200, f"POST {path} returned {response.status}")
        return json.loads(response.read().decode("utf-8"))["data"]


def _get(base: str, token: str, path: str):
    req = urllib.request.Request(base + path, headers={"Authorization": f"Bearer {token}"})
    with urllib.request.urlopen(req, timeout=15) as response:
        _assert(response.status == 200, f"GET {path} returned {response.status}")
        return json.loads(response.read().decode("utf-8"))["data"]


def scenario_a(root: Path) -> dict:
    root.mkdir(parents=True, exist_ok=True)
    with ManjuApp.open(root / "ws") as app:
        film = app.create_project("Simulation Film")
        other = app.create_project("Simulation Trailer")
        seq = app.create_production_unit(film.project_id, "sequence", "SQ01")
        scene = app.create_production_unit(film.project_id, "scene", "SC01", parent_id=seq.production_unit_id)
        sh1 = app.create_production_unit(film.project_id, "shot", "SH010", parent_id=scene.production_unit_id)
        sh2 = app.create_production_unit(film.project_id, "shot", "SH020", parent_id=scene.production_unit_id)
        app.create_production_unit(other.project_id, "shot", "TR010")
        prompt = app.register_text_asset(film.project_id, "prompt", "SH010 Prompt", "pilot crossing rain")
        identity = app.create_asset(film.project_id, "image", "Pilot Identity", classification="identity")
        identity_file = root / "identity.png"; identity_file.write_bytes(b"identity")
        identity_rev = app.ingest_revision(identity.asset_id, identity_file)
        shot = app.create_asset(film.project_id, "image", "SH010 Candidate", classification="shot")
        shot_file = root / "shot.png"; shot_file.write_bytes(b"shot")
        shot_rev = app.ingest_revision(shot.asset_id, shot_file)
        task = app.create_task(film.project_id, "Generate SH010", production_unit_id=sh1.production_unit_id, acceptance=("identity stable",))
        app.link_task_asset(task.task_id, identity.asset_id, "input")
        app.link_task_asset(task.task_id, shot.asset_id, "output")
        for state in ("ready", "running", "waiting_review"):
            app.transition_task(task.task_id, state)
        run = app.record_generator_run(
            film.project_id, "mock", task_id=task.task_id, model="mock-v1",
            prompt_revision_id=prompt["revision"].revision_id,
            input_revision_ids=(identity_rev.revision_id,), output_revision_ids=(shot_rev.revision_id,),
            parameters={"seed": 7},
        )
        app.submit_review(shot_rev.revision_id, "pass", note="approved")
        app.promote_master(shot_rev.revision_id)
        app.transition_task(task.task_id, "done")
        c1 = app.create_continuity_snapshot(film.project_id, sh1.production_unit_id, {"hand": "empty", "weather": "rain"})
        c2 = app.create_continuity_snapshot(film.project_id, sh2.production_unit_id, {"hand": "helmet", "weather": "rain"}, inherited_from=c1.snapshot_id)
        _assert(app.get_asset(shot.asset_id).active_revision_id == shot_rev.revision_id, "master promotion failed")
        _assert(app.get_generator_run(run.run_id).status == "succeeded", "generator run missing")
        _assert(app.diff_continuity(c1.snapshot_id, c2.snapshot_id)["changed"]["hand"]["to"] == "helmet", "continuity diff failed")
        _assert(len(app.list_projects()) == 2, "project isolation failed")
        return {"ok": True, "projects": 2, "master_revision": shot_rev.revision_id, "task": task.task_id}


def scenario_b(root: Path) -> dict:
    source = root / "source"; source.mkdir(parents=True, exist_ok=True)
    shots = source / "shots"; shots.mkdir()
    a = shots / "a.png"; a.write_bytes(b"same")
    b = shots / "b.png"; b.write_bytes(b"same")
    voice = source / "voice.wav"; voice.write_bytes(b"voice")
    ignored = source / "ignore.exe"; ignored.write_bytes(b"ignore")
    outside = root / "outside.png"; outside.write_bytes(b"outside")
    link = source / "escape.png"
    symlink = False
    try:
        link.symlink_to(outside)
        symlink = True
    except OSError:
        pass
    before_voice = voice.read_bytes(); before_outside = outside.read_bytes()
    with ManjuApp.open(root / "ws") as app:
        project = app.create_project("Local Intake")
        managed = app.register_managed_root(project.project_id, source)
        first = app.sync_managed_root(managed.root_id, full_hash=True)
        _assert(first.new == 3, "mixed local intake did not register expected files")
        _assert(first.skipped >= 1, "unsupported file was not skipped")
        if symlink:
            _assert(any(i.source_relpath == "escape.png" and i.state == "skipped" for i in first.items), "symlink escape was not skipped")
        _assert(app.conn.execute("SELECT COUNT(*) FROM blobs").fetchone()[0] == 2, "duplicate content was not deduplicated")
        binding = next(x for x in app.list_source_bindings(managed.root_id) if x.source_relpath == "shots/a.png")
        asset_id = binding.asset_id
        a.write_bytes(b"changed-v2")
        changed = app.sync_managed_root(managed.root_id, full_hash=True)
        _assert(changed.changed == 1, "changed source was not detected")
        current = next(x for x in app.list_source_bindings(managed.root_id) if x.source_relpath == "shots/a.png")
        _assert(current.asset_id == asset_id and app.get_revision(current.revision_id).revision_number == 2, "source identity/revision tracking failed")
        b.unlink()
        missing = app.sync_managed_root(managed.root_id, full_hash=True)
        _assert(missing.missing == 1, "missing source was not retained as missing")
    _assert(voice.read_bytes() == before_voice and outside.read_bytes() == before_outside and ignored.exists(), "local takeover modified unrelated sources")
    return {"ok": True, "new": first.new, "changed": changed.changed, "missing": missing.missing, "symlink_checked": symlink}


def scenario_c(root: Path) -> dict:
    root.mkdir(parents=True, exist_ok=True)
    server = create_server(root / "ws", port=0)
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    base = f"http://127.0.0.1:{server.server_port}"
    token = server.token
    try:
        with ThreadPoolExecutor(max_workers=10) as pool:
            projects = list(pool.map(lambda _: _post(base, token, "/api/v1/projects", {"name": "Concurrent Film"}, "same-project"), range(10)))
        ids = {p["project_id"] for p in projects}
        _assert(len(ids) == 1, "idempotent project POST created duplicates")
        project_id = ids.pop()

        def work(index: int):
            if index % 2:
                return _get(base, token, "/api/v1/health")
            return _post(base, token, "/api/v1/assets", {"project_id": project_id, "asset_type": "image", "display_name": f"asset-{index}"}, f"asset-{index}")

        with ThreadPoolExecutor(max_workers=16) as pool:
            results = list(pool.map(work, range(40)))
        _assert(len(results) == 40, "concurrent request set was incomplete")
        assets = _get(base, token, f"/api/v1/assets?project={project_id}")
        _assert(len(assets) == 20, "concurrent writes were lost or duplicated")
        _assert(_get(base, token, "/api/v1/health")["ok"] is True, "workspace unhealthy after concurrent API load")
        return {"ok": True, "concurrent_requests": 50, "assets": len(assets)}
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=5)


def scenario_d(root: Path) -> dict:
    root.mkdir(parents=True, exist_ok=True)
    with ManjuApp.open(root / "ws") as app:
        project = app.create_project("Corruption Drill")
        asset = app.create_asset(project.project_id, "video", "Master")
        source = root / "master.mp4"; source.write_bytes(b"0123456789")
        rev = app.ingest_revision(asset.asset_id, source)
        row = app.conn.execute("SELECT vault_relpath FROM blobs WHERE blob_hash=?", (rev.blob_hash,)).fetchone()
        blob = app.paths.root / row["vault_relpath"]
        blob.write_bytes(b"XXXXXXXXXX")
        report = app.health_check()
        _assert(not report.ok, "corrupt vault silently passed health check")
        codes = {i.code for i in report.issues}
        _assert("corrupt_blob" in codes, "corrupt vault did not produce corrupt_blob diagnosis")
        return {"ok": True, "detected": sorted(codes)}


def scenario_e(root: Path) -> dict:
    root.mkdir(parents=True, exist_ok=True)
    with ManjuApp.open(root / "source-ws") as app:
        project = app.create_project("Restore Film")
        ref_asset = app.create_asset(project.project_id, "image", "Amber Navigator Identity")
        ref_file = root / "ref.png"; ref_file.write_bytes(b"ref")
        ref = app.ingest_revision(ref_asset.asset_id, ref_file)
        shot_asset = app.create_asset(project.project_id, "image", "Amber Navigator SH030")
        shot_file = root / "shot.png"; shot_file.write_bytes(b"shot")
        shot = app.ingest_revision(shot_asset.asset_id, shot_file)
        app.add_provenance(ref.revision_id, shot.revision_id, "derived_from", role="identity")
        app.submit_review(shot.revision_id, "pass")
        app.promote_master(shot.revision_id)
        backup = app.create_backup(root / "backup.mjbk")
    restore_backup(Path(backup.path), root / "restored-ws")
    with ManjuApp.open(root / "restored-ws") as app:
        _assert(app.get_asset(shot_asset.asset_id).active_revision_id == shot.revision_id, "master not restored")
        _assert(any(h.revision_id == shot.revision_id for h in app.search("Amber Navigator SH030")), "search index did not survive restore")
        lineage = app.asset_lineage(shot_asset.asset_id)
        _assert(any(e["from_revision_id"] == ref.revision_id and e["to_revision_id"] == shot.revision_id for e in lineage["edges"]), "lineage did not survive restore")
        _assert(app.health_check().ok, "restored workspace is unhealthy")
        return {"ok": True, "master": shot.revision_id, "lineage_edges": len(lineage["edges"])}


def run(base_dir: Path) -> dict:
    base_dir = Path(base_dir).expanduser().resolve()
    if base_dir.exists():
        shutil.rmtree(base_dir)
    base_dir.mkdir(parents=True)
    funcs = {"A": scenario_a, "B": scenario_b, "C": scenario_c, "D": scenario_d, "E": scenario_e}
    results = {}
    for key, fn in funcs.items():
        try:
            results[key] = fn(base_dir / key)
        except Exception as exc:
            results[key] = {"ok": False, "error": f"{exc.__class__.__name__}: {exc}"}
    return {"ok": all(value.get("ok") is True for value in results.values()), "scenarios": results}


def main() -> int:
    parser = argparse.ArgumentParser(description="Run Manju OS real-world production simulations")
    parser.add_argument("--base-dir", type=Path, default=None)
    args = parser.parse_args()
    if args.base_dir is None:
        with tempfile.TemporaryDirectory(prefix="manju-real-world-") as tmp:
            summary = run(Path(tmp) / "simulation")
    else:
        summary = run(args.base_dir)
    print("SIMULATION_SUMMARY=" + json.dumps(summary, ensure_ascii=False, sort_keys=True))
    if summary["ok"]:
        print("REAL_WORLD_SIMULATION_PASS")
        return 0
    print("REAL_WORLD_SIMULATION_FAIL")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
