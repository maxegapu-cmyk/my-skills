@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" call INSTALL_WINDOWS.cmd
if errorlevel 1 exit /b %ERRORLEVEL%
.venv\Scripts\python.exe scripts\verify_core.py
if errorlevel 1 exit /b 10
.venv\Scripts\python.exe scripts\verify_production_control.py
if errorlevel 1 exit /b 11
.venv\Scripts\python.exe scripts\verify_studio_runtime.py
if errorlevel 1 exit /b 12
.venv\Scripts\python.exe scripts\simulate_real_world.py
if errorlevel 1 exit /b 13
echo RELEASE_RUNTIME_VERIFICATION_PASS
