from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from . import projects
from .db import transaction
from .errors import NotFoundError, ValidationError
from .events import record_event
from .ids import new_id
from .models import LocalScanItem, LocalScanReport, ManagedRoot, SourceBinding
from .vault import sha256_file

DEFAULT_INCLUDE = (
    ".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".tif", ".tiff",
    ".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v",
    ".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg",
    ".txt", ".md", ".json", ".yaml", ".yml", ".srt", ".vtt", ".csv",
    ".obj", ".fbx", ".gltf", ".glb",
)
DEFAULT_EXCLUDE = (".git", ".svn", "node_modules", "__pycache__", ".cache", ".pytest_cache")

_IMAGE = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".tif", ".tiff"}
_VIDEO = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}
_AUDIO = {".mp3", ".wav", ".flac", ".m4a", ".aac", ".ogg"}
_DOCUMENT = {".txt", ".md", ".json", ".yaml", ".yml", ".srt", ".vtt", ".csv"}
_MODEL = {".obj", ".fbx", ".gltf", ".glb"}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _normalize_exts(values) -> tuple[str, ...]:
    result = []
    for raw in values:
        value = str(raw).strip().lower()
        if not value:
            continue
        if not value.startswith("."):
            value = "." + value
        if value not in result:
            result.append(value)
    return tuple(result)


def _normalize_excludes(values) -> tuple[str, ...]:
    return tuple(dict.fromkeys(str(v).strip() for v in values if str(v).strip()))


def _managed_root_from_row(row: sqlite3.Row) -> ManagedRoot:
    return ManagedRoot(
        root_id=row["root_id"],
        project_id=row["project_id"],
        path=row["path"],
        include=tuple(json.loads(row["include_json"])),
        exclude=tuple(json.loads(row["exclude_json"])),
        enabled=bool(row["enabled"]),
        last_scan_at=row["last_scan_at"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


def _binding_from_row(row: sqlite3.Row) -> SourceBinding:
    return SourceBinding(
        binding_id=row["binding_id"],
        root_id=row["root_id"],
        project_id=row["project_id"],
        source_relpath=row["source_relpath"],
        source_filename=row["source_filename"],
        asset_id=row["asset_id"],
        revision_id=row["revision_id"],
        file_hash=row["file_hash"],
        file_size=int(row["file_size"]) if row["file_size"] is not None else None,
        mtime_ns=int(row["mtime_ns"]) if row["mtime_ns"] is not None else None,
        status=row["status"],
        first_seen_at=row["first_seen_at"],
        last_seen_at=row["last_seen_at"],
    )


def _overlaps(a: Path, b: Path) -> bool:
    return a == b or a in b.parents or b in a.parents


def _asset_type(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in _IMAGE:
        return "image"
    if ext in _VIDEO:
        return "video"
    if ext in _AUDIO:
        return "audio"
    if ext in _DOCUMENT:
        return "document"
    if ext in _MODEL:
        return "3d"
    return "binary"


def register_root(app, project_id: str, path: Path, *, include=DEFAULT_INCLUDE, exclude=DEFAULT_EXCLUDE) -> ManagedRoot:
    projects.get_project(app.conn, project_id)
    raw = Path(path).expanduser()
    if raw.is_symlink():
        raise ValidationError("managed root must not be a symlink", details={"path": str(raw)})
    if not raw.exists() or not raw.is_dir():
        raise ValidationError("managed root must be an existing directory", details={"path": str(raw)})
    root = raw.resolve()
    if _overlaps(root, app.paths.root.resolve()):
        raise ValidationError(
            "managed root must not overlap the workspace",
            details={"path": str(root), "workspace": str(app.paths.root)},
        )
    include_values = _normalize_exts(include)
    if not include_values:
        raise ValidationError("managed root include list must not be empty")
    exclude_values = _normalize_excludes(exclude)
    now = _utc_now()
    root_id = new_id("root")
    with transaction(app.conn):
        try:
            app.conn.execute(
                """
                INSERT INTO managed_roots(
                  root_id,project_id,path,include_json,exclude_json,enabled,last_scan_at,created_at,updated_at
                ) VALUES (?,?,?,?,?,1,NULL,?,?)
                """,
                (root_id, project_id, str(root), json.dumps(include_values), json.dumps(exclude_values), now, now),
            )
        except sqlite3.IntegrityError as exc:
            raise ValidationError(
                "managed root is already registered for this project",
                details={"project_id": project_id, "path": str(root)},
            ) from exc
        record_event(
            app.conn,
            entity_kind="managed_root",
            entity_id=root_id,
            action="register",
            after_summary={"project_id": project_id, "path": str(root)},
        )
    return get_root(app, root_id)


def get_root(app, root_id: str) -> ManagedRoot:
    row = app.conn.execute("SELECT * FROM managed_roots WHERE root_id=?", (root_id,)).fetchone()
    if row is None:
        raise NotFoundError("managed root not found", details={"root_id": root_id})
    return _managed_root_from_row(row)


def list_roots(app, project_id: str | None = None) -> list[ManagedRoot]:
    if project_id is None:
        rows = app.conn.execute("SELECT * FROM managed_roots ORDER BY created_at,root_id").fetchall()
    else:
        projects.get_project(app.conn, project_id)
        rows = app.conn.execute(
            "SELECT * FROM managed_roots WHERE project_id=? ORDER BY created_at,root_id", (project_id,)
        ).fetchall()
    return [_managed_root_from_row(row) for row in rows]


def list_bindings(app, root_id: str) -> list[SourceBinding]:
    get_root(app, root_id)
    rows = app.conn.execute(
        "SELECT * FROM source_bindings WHERE root_id=? ORDER BY source_relpath,binding_id", (root_id,)
    ).fetchall()
    return [_binding_from_row(row) for row in rows]


def _iter_source_entries(root_path: Path, exclude: set[str]):
    for current, dirnames, filenames in os.walk(root_path, topdown=True, followlinks=False):
        current_path = Path(current)
        kept_dirs = []
        for name in sorted(dirnames):
            candidate = current_path / name
            if name in exclude or candidate.is_symlink():
                continue
            kept_dirs.append(name)
        dirnames[:] = kept_dirs
        for name in sorted(filenames):
            yield current_path / name


def scan_root(app, root_id: str, *, full_hash: bool = False) -> LocalScanReport:
    root = get_root(app, root_id)
    root_path = Path(root.path)
    if root_path.is_symlink() or not root_path.is_dir():
        raise ValidationError("managed root is unavailable", details={"root_id": root_id, "path": root.path})
    include = set(root.include)
    exclude = set(root.exclude)
    binding_rows = app.conn.execute("SELECT * FROM source_bindings WHERE root_id=?", (root_id,)).fetchall()
    bindings = {row["source_relpath"]: _binding_from_row(row) for row in binding_rows}
    seen: set[str] = set()
    items: list[LocalScanItem] = []
    counts = {"new": 0, "changed": 0, "unchanged": 0, "missing": 0, "skipped": 0, "error": 0}
    scanned = 0

    for source in _iter_source_entries(root_path, exclude):
        rel = source.relative_to(root_path).as_posix()
        seen.add(rel)
        scanned += 1
        try:
            if source.is_symlink():
                item = LocalScanItem(rel, source.name, "binary", "skipped", None, 0, 0, reason="symlink")
                counts["skipped"] += 1
                items.append(item)
                continue
            stat = source.stat()
            ext = source.suffix.lower()
            if ext not in include:
                item = LocalScanItem(rel, source.name, _asset_type(source), "skipped", None, stat.st_size, stat.st_mtime_ns, reason="unsupported_extension")
                counts["skipped"] += 1
                items.append(item)
                continue
            binding = bindings.get(rel)
            file_hash: str | None
            state: str
            if binding and not full_hash and binding.file_size == stat.st_size and binding.mtime_ns == stat.st_mtime_ns and binding.file_hash:
                file_hash = binding.file_hash
                state = "unchanged"
            else:
                file_hash, _ = sha256_file(source)
                if binding is None:
                    state = "new"
                elif binding.file_hash == file_hash:
                    state = "unchanged"
                else:
                    state = "changed"
            counts[state] += 1
            items.append(
                LocalScanItem(
                    rel,
                    source.name,
                    _asset_type(source),
                    state,
                    file_hash,
                    int(stat.st_size),
                    int(stat.st_mtime_ns),
                    asset_id=binding.asset_id if binding else None,
                    revision_id=binding.revision_id if binding else None,
                )
            )
        except OSError as exc:
            counts["error"] += 1
            items.append(LocalScanItem(rel, source.name, _asset_type(source), "error", None, 0, 0, reason=exc.__class__.__name__))

    for rel, binding in bindings.items():
        if rel in seen:
            continue
        counts["missing"] += 1
        items.append(
            LocalScanItem(
                rel,
                binding.source_filename,
                "binary",
                "missing",
                binding.file_hash,
                binding.file_size or 0,
                binding.mtime_ns or 0,
                asset_id=binding.asset_id,
                revision_id=binding.revision_id,
                reason="source_missing",
            )
        )

    items.sort(key=lambda item: item.source_relpath)
    return LocalScanReport(
        root_id=root.root_id,
        project_id=root.project_id,
        root_path=root.path,
        scanned=scanned,
        new=counts["new"],
        changed=counts["changed"],
        unchanged=counts["unchanged"],
        missing=counts["missing"],
        skipped=counts["skipped"],
        errors=counts["error"],
        items=tuple(items),
        scanned_at=_utc_now(),
    )


def sync_root(app, root_id: str, *, full_hash: bool = False) -> LocalScanReport:
    report = scan_root(app, root_id, full_hash=full_hash)
    root = get_root(app, root_id)
    root_path = Path(root.path)
    now = _utc_now()
    updated_items: list[LocalScanItem] = []

    for item in report.items:
        source = root_path / Path(item.source_relpath)
        if item.state == "new":
            asset = app.create_asset(
                root.project_id,
                item.asset_type if item.asset_type in {"image", "video", "audio", "document", "3d"} else "other",
                Path(item.source_filename).stem or item.source_filename,
                classification="local_source",
                role="source",
            )
            try:
                revision = app.ingest_revision(
                    asset.asset_id,
                    source,
                    change_summary=f"local intake: {item.source_relpath}",
                )
                stat = source.stat()
                with transaction(app.conn):
                    app.conn.execute(
                        """
                        INSERT INTO source_bindings(
                          binding_id,root_id,project_id,source_relpath,source_filename,asset_id,revision_id,
                          file_hash,file_size,mtime_ns,status,first_seen_at,last_seen_at
                        ) VALUES (?,?,?,?,?,?,?,?,?,?, 'active',?,?)
                        """,
                        (
                            new_id("bind"), root.root_id, root.project_id, item.source_relpath,
                            item.source_filename, asset.asset_id, revision.revision_id, revision.blob_hash,
                            int(stat.st_size), int(stat.st_mtime_ns), now, now,
                        ),
                    )
                    record_event(
                        app.conn,
                        entity_kind="managed_root",
                        entity_id=root.root_id,
                        action="source_bind",
                        after_summary={"source_relpath": item.source_relpath, "asset_id": asset.asset_id, "revision_id": revision.revision_id},
                    )
                updated_items.append(
                    LocalScanItem(
                        item.source_relpath, item.source_filename, item.asset_type, item.state,
                        revision.blob_hash, int(stat.st_size), int(stat.st_mtime_ns),
                        asset_id=asset.asset_id, revision_id=revision.revision_id,
                    )
                )
            except Exception:
                # Keep metadata coherent if ingestion/binding fails. Immutable blobs may remain
                # unreferenced and are intentionally detectable by the health checker.
                with transaction(app.conn):
                    app.conn.execute("DELETE FROM assets WHERE asset_id=?", (asset.asset_id,))
                raise
            continue

        if item.state == "changed":
            if not item.asset_id:
                raise ValidationError("changed source binding is missing asset identity", details={"source_relpath": item.source_relpath})
            revision = app.ingest_revision(
                item.asset_id,
                source,
                change_summary=f"local source changed: {item.source_relpath}",
            )
            stat = source.stat()
            with transaction(app.conn):
                app.conn.execute(
                    """
                    UPDATE source_bindings
                    SET revision_id=?,file_hash=?,file_size=?,mtime_ns=?,status='active',source_filename=?,last_seen_at=?
                    WHERE root_id=? AND source_relpath=?
                    """,
                    (
                        revision.revision_id, revision.blob_hash, int(stat.st_size), int(stat.st_mtime_ns),
                        item.source_filename, now, root.root_id, item.source_relpath,
                    ),
                )
                record_event(
                    app.conn,
                    entity_kind="managed_root",
                    entity_id=root.root_id,
                    action="source_revision",
                    after_summary={"source_relpath": item.source_relpath, "asset_id": item.asset_id, "revision_id": revision.revision_id},
                )
            updated_items.append(
                LocalScanItem(
                    item.source_relpath, item.source_filename, item.asset_type, item.state,
                    revision.blob_hash, int(stat.st_size), int(stat.st_mtime_ns),
                    asset_id=item.asset_id, revision_id=revision.revision_id,
                )
            )
            continue

        if item.state == "unchanged":
            with transaction(app.conn):
                app.conn.execute(
                    """
                    UPDATE source_bindings
                    SET file_hash=?,file_size=?,mtime_ns=?,status='active',source_filename=?,last_seen_at=?
                    WHERE root_id=? AND source_relpath=?
                    """,
                    (
                        item.file_hash, item.file_size, item.mtime_ns, item.source_filename, now,
                        root.root_id, item.source_relpath,
                    ),
                )
            updated_items.append(item)
            continue

        if item.state == "missing":
            with transaction(app.conn):
                app.conn.execute(
                    "UPDATE source_bindings SET status='missing',last_seen_at=? WHERE root_id=? AND source_relpath=?",
                    (now, root.root_id, item.source_relpath),
                )
                record_event(
                    app.conn,
                    entity_kind="managed_root",
                    entity_id=root.root_id,
                    action="source_missing",
                    after_summary={"source_relpath": item.source_relpath, "asset_id": item.asset_id},
                )
            updated_items.append(item)
            continue

        if item.state == "skipped" and item.asset_id:
            with transaction(app.conn):
                app.conn.execute(
                    "UPDATE source_bindings SET status='blocked',last_seen_at=? WHERE root_id=? AND source_relpath=?",
                    (now, root.root_id, item.source_relpath),
                )
        updated_items.append(item)

    with transaction(app.conn):
        app.conn.execute(
            "UPDATE managed_roots SET last_scan_at=?,updated_at=? WHERE root_id=?",
            (report.scanned_at, now, root.root_id),
        )
        record_event(
            app.conn,
            entity_kind="managed_root",
            entity_id=root.root_id,
            action="sync",
            after_summary={
                "new": report.new, "changed": report.changed, "unchanged": report.unchanged,
                "missing": report.missing, "skipped": report.skipped, "errors": report.errors,
            },
        )

    return LocalScanReport(
        root_id=report.root_id,
        project_id=report.project_id,
        root_path=report.root_path,
        scanned=report.scanned,
        new=report.new,
        changed=report.changed,
        unchanged=report.unchanged,
        missing=report.missing,
        skipped=report.skipped,
        errors=report.errors,
        items=tuple(updated_items),
        scanned_at=report.scanned_at,
    )
