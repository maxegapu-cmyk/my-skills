from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone

from .assets import get_asset
from .db import transaction
from .errors import ConflictError, NotFoundError, ValidationError
from .events import record_event
from .ids import new_id
from .models import Task
from .projects import get_project

ALLOWED_TRANSITIONS = {
    "draft": {"ready"},
    "ready": {"running"},
    "running": {"waiting_review", "failed", "blocked", "canceled"},
    "waiting_review": {"done"},
    "done": set(),
    "failed": set(),
    "blocked": set(),
    "canceled": set(),
}
RELATIONS = {"input", "output", "in_scope", "out_of_scope", "reference"}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _from_row(row: sqlite3.Row) -> Task:
    return Task(
        task_id=row["task_id"],
        project_id=row["project_id"],
        production_unit_id=row["production_unit_id"],
        name=row["name"],
        status=row["status"],
        acceptance=tuple(json.loads(row["acceptance_json"])),
        locked_fields=tuple(json.loads(row["locked_fields_json"])),
        note=row["note"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


def create_task(
    conn: sqlite3.Connection,
    project_id: str,
    name: str,
    *,
    production_unit_id: str | None = None,
    acceptance: tuple[str, ...] | list[str] = (),
    locked_fields: tuple[str, ...] | list[str] = (),
) -> Task:
    get_project(conn, project_id)
    name = name.strip()
    if not name:
        raise ValidationError("task name must not be blank")
    if production_unit_id is not None:
        row = conn.execute(
            "SELECT project_id FROM production_units WHERE production_unit_id=?",
            (production_unit_id,),
        ).fetchone()
        if row is None:
            raise NotFoundError("production unit not found", details={"production_unit_id": production_unit_id})
        if row["project_id"] != project_id:
            raise ConflictError("production unit belongs to another project")
    if len(name) > 1000 or any(len(v) > 4000 for v in (*acceptance, *locked_fields)):
        raise ValidationError("task metadata is too large")
    now = _utc_now()
    task_id = new_id("tsk")
    with transaction(conn):
        conn.execute(
            """
            INSERT INTO tasks(task_id, project_id, production_unit_id, name, status,
              acceptance_json, locked_fields_json, note, created_at, updated_at)
            VALUES (?, ?, ?, ?, 'draft', ?, ?, '', ?, ?)
            """,
            (
                task_id,
                project_id,
                production_unit_id,
                name,
                json.dumps(list(acceptance), ensure_ascii=False),
                json.dumps(list(locked_fields), ensure_ascii=False),
                now,
                now,
            ),
        )
        record_event(conn, entity_kind="task", entity_id=task_id, action="create", after_summary={"project_id": project_id, "name": name, "status": "draft"})
    return get_task(conn, task_id)


def get_task(conn: sqlite3.Connection, task_id: str) -> Task:
    row = conn.execute("SELECT * FROM tasks WHERE task_id=?", (task_id,)).fetchone()
    if row is None:
        raise NotFoundError("task not found", details={"task_id": task_id})
    return _from_row(row)


def list_tasks(conn: sqlite3.Connection, project_id: str | None = None, status: str | None = None) -> list[Task]:
    sql = "SELECT * FROM tasks WHERE 1=1"
    params: list[object] = []
    if project_id is not None:
        get_project(conn, project_id)
        sql += " AND project_id=?"
        params.append(project_id)
    if status is not None:
        normalized = status.strip().lower()
        if normalized not in ALLOWED_TRANSITIONS:
            raise ValidationError("invalid task status", details={"status": status})
        sql += " AND status=?"
        params.append(normalized)
    sql += " ORDER BY updated_at DESC,task_id DESC"
    return [_from_row(row) for row in conn.execute(sql, params).fetchall()]


def transition_task(conn: sqlite3.Connection, task_id: str, to_status: str, *, note: str = "") -> Task:
    task = get_task(conn, task_id)
    to_status = to_status.strip().lower()
    if to_status not in ALLOWED_TRANSITIONS:
        raise ValidationError("invalid task status", details={"status": to_status})
    if to_status not in ALLOWED_TRANSITIONS[task.status]:
        raise ConflictError("illegal task transition", details={"from": task.status, "to": to_status})
    now = _utc_now()
    with transaction(conn):
        conn.execute("UPDATE tasks SET status=?, note=?, updated_at=? WHERE task_id=?", (to_status, note, now, task_id))
        record_event(conn, entity_kind="task", entity_id=task_id, action="transition", before_summary={"status": task.status}, after_summary={"status": to_status, "note": note})
    return get_task(conn, task_id)


def link_task_asset(conn: sqlite3.Connection, task_id: str, asset_id: str, relation: str) -> None:
    task = get_task(conn, task_id)
    asset = get_asset(conn, asset_id)
    relation = relation.strip().lower()
    if relation not in RELATIONS:
        raise ValidationError("invalid task asset relation", details={"relation": relation})
    if asset.project_id != task.project_id:
        raise ConflictError("task and asset belong to different projects")
    with transaction(conn):
        conn.execute(
            "INSERT OR IGNORE INTO task_assets(task_id, asset_id, relation) VALUES (?, ?, ?)",
            (task_id, asset_id, relation),
        )
        record_event(conn, entity_kind="task", entity_id=task_id, action="asset_link", after_summary={"asset_id": asset_id, "relation": relation})
