from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol


@dataclass(frozen=True)
class AdapterRequest:
    project_id: str
    task_id: str | None
    prompt_revision_id: str | None
    input_revision_ids: tuple[str, ...]
    parameters: dict
    output_dir: Path


@dataclass(frozen=True)
class AdapterResult:
    output_files: tuple[Path, ...]
    model: str | None
    metadata: dict


class GeneratorAdapter(Protocol):
    adapter_id: str

    def run(self, request: AdapterRequest) -> AdapterResult: ...


class MockAdapter:
    adapter_id = "mock"

    def run(self, request: AdapterRequest) -> AdapterResult:
        payload = {
            "project_id": request.project_id,
            "task_id": request.task_id,
            "prompt_revision_id": request.prompt_revision_id,
            "input_revision_ids": list(request.input_revision_ids),
            "parameters": request.parameters,
        }
        encoded = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        digest = hashlib.sha256(encoded).hexdigest()
        request.output_dir.mkdir(parents=True, exist_ok=True)
        path = request.output_dir / f"mock-{digest}.txt"
        path.write_bytes(encoded)
        return AdapterResult(output_files=(path,), model="mock-deterministic-v1", metadata={"sha256": digest})
