from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone

from .assets import get_asset, get_revision
from .db import transaction
from .errors import ConflictError, LockedError, NotFoundError, ValidationError
from .events import record_event
from .ids import new_id
from .models import Asset, Review, Revision

OUTCOMES = {"pass", "pass_with_notes", "patch_required", "reject"}
SEVERITIES = {"P0", "P1", "P2", "P3"}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _review_from_row(row: sqlite3.Row) -> Review:
    return Review(
        review_id=row["review_id"],
        revision_id=row["revision_id"],
        outcome=row["outcome"],
        severity=row["severity"],
        note=row["note"],
        findings=tuple(json.loads(row["findings_json"])),
        created_at=row["created_at"],
    )


def submit_review(
    conn: sqlite3.Connection,
    revision_id: str,
    outcome: str,
    *,
    severity: str = "P3",
    note: str = "",
    findings: tuple[str, ...] | list[str] = (),
) -> Review:
    revision = get_revision(conn, revision_id)
    outcome = outcome.strip().lower()
    severity = severity.strip().upper()
    if outcome not in OUTCOMES:
        raise ValidationError("invalid review outcome", details={"outcome": outcome})
    if severity not in SEVERITIES:
        raise ValidationError("invalid review severity", details={"severity": severity})
    if revision.status in {"master", "superseded", "archived"}:
        raise ConflictError("revision is no longer reviewable", details={"status": revision.status})
    if len(note) > 20000 or any(len(item) > 4000 for item in findings):
        raise ValidationError("review metadata is too large")
    review_id = new_id("rvw")
    now = _utc_now()
    status = "approved" if outcome in {"pass", "pass_with_notes"} else "rejected" if outcome == "reject" else "candidate"
    with transaction(conn):
        conn.execute(
            "INSERT INTO reviews(review_id, revision_id, outcome, severity, note, findings_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (review_id, revision_id, outcome, severity, note, json.dumps(list(findings), ensure_ascii=False), now),
        )
        conn.execute("UPDATE revisions SET status=? WHERE revision_id=?", (status, revision_id))
        record_event(
            conn,
            entity_kind="revision",
            entity_id=revision_id,
            action="review_submit",
            before_summary={"status": revision.status},
            after_summary={"status": status, "outcome": outcome, "severity": severity, "note": note},
        )
    row = conn.execute("SELECT * FROM reviews WHERE review_id=?", (review_id,)).fetchone()
    return _review_from_row(row)


def latest_review(conn: sqlite3.Connection, revision_id: str) -> Review | None:
    row = conn.execute(
        "SELECT * FROM reviews WHERE revision_id=? ORDER BY created_at DESC, review_id DESC LIMIT 1",
        (revision_id,),
    ).fetchone()
    return None if row is None else _review_from_row(row)


def promote_master(conn: sqlite3.Connection, revision_id: str, *, note: str = "") -> Revision:
    revision = get_revision(conn, revision_id)
    review = latest_review(conn, revision_id)
    if review is None or review.outcome not in {"pass", "pass_with_notes"}:
        raise ConflictError("master promotion requires a passing review", details={"revision_id": revision_id})
    asset = get_asset(conn, revision.asset_id)
    if asset.active_revision_id == revision_id and revision.status == "master":
        return revision
    if asset.locked and asset.active_revision_id is not None:
        raise LockedError("asset is locked", details={"asset_id": asset.asset_id})
    now = _utc_now()
    with transaction(conn):
        if asset.active_revision_id:
            conn.execute(
                "UPDATE revisions SET status='superseded' WHERE revision_id=? AND revision_id<>?",
                (asset.active_revision_id, revision_id),
            )
        conn.execute("UPDATE revisions SET status='master' WHERE revision_id=?", (revision_id,))
        conn.execute(
            "UPDATE assets SET active_revision_id=?, updated_at=? WHERE asset_id=?",
            (revision_id, now, asset.asset_id),
        )
        record_event(
            conn,
            entity_kind="asset",
            entity_id=asset.asset_id,
            action="master_promote",
            before_summary={"active_revision_id": asset.active_revision_id},
            after_summary={"active_revision_id": revision_id, "note": note},
        )
    return get_revision(conn, revision_id)


def set_asset_lock(conn: sqlite3.Connection, asset_id: str, locked: bool, *, reason: str = "") -> Asset:
    asset = get_asset(conn, asset_id)
    now = _utc_now()
    with transaction(conn):
        conn.execute("UPDATE assets SET locked=?, updated_at=? WHERE asset_id=?", (int(bool(locked)), now, asset_id))
        if locked:
            conn.execute(
                "INSERT INTO asset_locks(asset_id, reason, locked_at) VALUES (?, ?, ?) ON CONFLICT(asset_id) DO UPDATE SET reason=excluded.reason, locked_at=excluded.locked_at",
                (asset_id, reason, now),
            )
        else:
            conn.execute("DELETE FROM asset_locks WHERE asset_id=?", (asset_id,))
        record_event(
            conn,
            entity_kind="asset",
            entity_id=asset_id,
            action="lock" if locked else "unlock",
            before_summary={"locked": asset.locked},
            after_summary={"locked": bool(locked), "reason": reason},
        )
    return get_asset(conn, asset_id)


def review_queue(conn: sqlite3.Connection, project_id: str | None = None) -> list[Revision]:
    sql = """
        SELECT r.revision_id
        FROM revisions r
        JOIN assets a ON a.asset_id=r.asset_id
        WHERE r.status IN ('candidate','in_review')
          AND NOT EXISTS (SELECT 1 FROM reviews rv WHERE rv.revision_id=r.revision_id)
    """
    params: list[object] = []
    if project_id is not None:
        sql += " AND a.project_id=?"
        params.append(project_id)
    sql += " ORDER BY r.created_at, r.revision_id"
    rows = conn.execute(sql, params).fetchall()
    return [get_revision(conn, row["revision_id"]) for row in rows]
