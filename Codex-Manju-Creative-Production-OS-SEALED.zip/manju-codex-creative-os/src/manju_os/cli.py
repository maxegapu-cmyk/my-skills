from __future__ import annotations

import argparse
import json
import os
import sys
import traceback
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

from .app import ManjuApp
from .backup import restore_backup
from .config import bootstrap_workspace
from .errors import AppError, ValidationError
from .studio_auth import load_or_create_token
from .studio_server import create_server


def _jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return {k: _jsonable(v) for k, v in asdict(value).items()}
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    return value


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="manju")
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--json", action="store_true", dest="json_output")
    root = parser.add_subparsers(dest="group", required=True)

    project = root.add_parser("project")
    project_cmd = project.add_subparsers(dest="command", required=True)
    project_create = project_cmd.add_parser("create")
    project_create.add_argument("--name", required=True)
    project_cmd.add_parser("list")

    unit = root.add_parser("unit")
    unit_cmd = unit.add_subparsers(dest="command", required=True)
    unit_create = unit_cmd.add_parser("create")
    unit_create.add_argument("--project", required=True)
    unit_create.add_argument("--kind", required=True)
    unit_create.add_argument("--name", required=True)
    unit_create.add_argument("--parent")
    unit_create.add_argument("--order", type=int, default=0)

    asset = root.add_parser("asset")
    asset_cmd = asset.add_subparsers(dest="command", required=True)
    asset_create = asset_cmd.add_parser("create")
    asset_create.add_argument("--project", required=True)
    asset_create.add_argument("--type", required=True, dest="asset_type")
    asset_create.add_argument("--name", required=True)
    asset_create.add_argument("--classification")
    asset_create.add_argument("--role")
    asset_create.add_argument("--priority", type=int, default=0)

    asset_ingest = asset_cmd.add_parser("ingest")
    asset_ingest.add_argument("file", type=Path)
    asset_ingest.add_argument("--asset", required=True)
    asset_ingest.add_argument("--summary", default="initial ingest")

    asset_show = asset_cmd.add_parser("show")
    asset_show.add_argument("asset_id")

    asset_lineage = asset_cmd.add_parser("lineage")
    asset_lineage.add_argument("asset_id")

    asset_lock = asset_cmd.add_parser("lock")
    asset_lock.add_argument("asset_id")
    asset_lock.add_argument("--reason", default="")
    asset_unlock = asset_cmd.add_parser("unlock")
    asset_unlock.add_argument("asset_id")
    asset_unlock.add_argument("--reason", default="")

    provenance = root.add_parser("provenance")
    provenance_cmd = provenance.add_subparsers(dest="command", required=True)
    provenance_add = provenance_cmd.add_parser("add")
    provenance_add.add_argument("--from", required=True, dest="from_revision")
    provenance_add.add_argument("--to", required=True, dest="to_revision")
    provenance_add.add_argument("--type", required=True, dest="edge_type")
    provenance_add.add_argument("--role")
    provenance_add.add_argument("--weight", type=float)
    provenance_add.add_argument("--notes")

    review = root.add_parser("review")
    review_cmd = review.add_subparsers(dest="command", required=True)
    review_queue = review_cmd.add_parser("queue")
    review_queue.add_argument("--project")
    review_submit = review_cmd.add_parser("submit")
    review_submit.add_argument("revision_id")
    review_submit.add_argument("--outcome", required=True)
    review_submit.add_argument("--severity", default="P3")
    review_submit.add_argument("--note", default="")
    review_submit.add_argument("--finding", action="append", default=[])
    review_promote = review_cmd.add_parser("promote")
    review_promote.add_argument("revision_id")
    review_promote.add_argument("--note", default="")

    task = root.add_parser("task")
    task_cmd = task.add_subparsers(dest="command", required=True)
    task_create = task_cmd.add_parser("create")
    task_create.add_argument("--project", required=True)
    task_create.add_argument("--name", required=True)
    task_create.add_argument("--unit")
    task_create.add_argument("--accept", action="append", default=[])
    task_create.add_argument("--locked-field", action="append", default=[])
    task_transition = task_cmd.add_parser("transition")
    task_transition.add_argument("task_id")
    task_transition.add_argument("--to", required=True, dest="to_status")
    task_transition.add_argument("--note", default="")

    continuity = root.add_parser("continuity")
    continuity_cmd = continuity.add_subparsers(dest="command", required=True)
    continuity_snapshot = continuity_cmd.add_parser("snapshot")
    continuity_snapshot.add_argument("--project", required=True)
    continuity_snapshot.add_argument("--unit", required=True)
    continuity_snapshot.add_argument("--state", required=True)
    continuity_snapshot.add_argument("--inherit")
    continuity_snapshot.add_argument("--note", default="")
    continuity_diff = continuity_cmd.add_parser("diff")
    continuity_diff.add_argument("snapshot_a")
    continuity_diff.add_argument("snapshot_b")

    search = root.add_parser("search")
    search.add_argument("query")
    search.add_argument("--project")
    search.add_argument("--type", dest="asset_type")
    search.add_argument("--status")
    search.add_argument("--limit", type=int, default=50)

    legacy = root.add_parser("legacy")
    legacy_cmd = legacy.add_subparsers(dest="command", required=True)
    legacy_plan = legacy_cmd.add_parser("plan")
    legacy_plan.add_argument("registry", type=Path)
    legacy_plan.add_argument("--base-dir", type=Path)
    legacy_apply = legacy_cmd.add_parser("apply")
    legacy_apply.add_argument("plan_file", type=Path)

    backup = root.add_parser("backup")
    backup_cmd = backup.add_subparsers(dest="command", required=True)
    backup_create = backup_cmd.add_parser("create")
    backup_create.add_argument("--destination", type=Path)
    backup_restore = backup_cmd.add_parser("restore")
    backup_restore.add_argument("backup_file", type=Path)

    registry = root.add_parser("registry")
    registry_cmd = registry.add_subparsers(dest="command", required=True)
    registry_add = registry_cmd.add_parser("add")
    registry_add.add_argument("--project", required=True)
    registry_add.add_argument("--kind", required=True, choices=("prompt", "skill"))
    registry_add.add_argument("--name", required=True)
    registry_add.add_argument("--content", required=True)
    registry_add.add_argument("--metadata", default="{}")
    registry_new = registry_cmd.add_parser("new")
    registry_new.add_argument("asset_id")
    registry_new.add_argument("--content", required=True)
    registry_new.add_argument("--metadata", default="{}")
    registry_list = registry_cmd.add_parser("list")
    registry_list.add_argument("--project")
    registry_show = registry_cmd.add_parser("show")
    registry_show.add_argument("revision_id")

    bridge = root.add_parser("bridge")
    bridge_cmd = bridge.add_subparsers(dest="command", required=True)
    bridge_packet = bridge_cmd.add_parser("task-packet")
    bridge_packet.add_argument("task_id")
    bridge_ingest = bridge_cmd.add_parser("ingest-output")
    bridge_ingest.add_argument("task_id")
    bridge_ingest.add_argument("--asset", required=True)
    bridge_ingest.add_argument("--file", required=True, type=Path)
    bridge_ingest.add_argument("--input", action="append", default=[])
    bridge_ingest.add_argument("--prompt")
    bridge_ingest.add_argument("--summary", default="task output")

    generator = root.add_parser("generator")
    generator_cmd = generator.add_subparsers(dest="command", required=True)
    generator_record = generator_cmd.add_parser("record")
    generator_record.add_argument("--project", required=True)
    generator_record.add_argument("--adapter", required=True)
    generator_record.add_argument("--model")
    generator_record.add_argument("--task")
    generator_record.add_argument("--prompt")
    generator_record.add_argument("--input", action="append", default=[])
    generator_record.add_argument("--output", action="append", default=[])
    generator_record.add_argument("--parameters", default="{}")
    generator_record.add_argument("--status", default="succeeded")
    generator_list = generator_cmd.add_parser("list")
    generator_list.add_argument("--project")

    local = root.add_parser("local")
    local_cmd = local.add_subparsers(dest="command", required=True)
    local_add = local_cmd.add_parser("root-add")
    local_add.add_argument("--project", required=True)
    local_add.add_argument("--path", required=True, type=Path)
    local_roots = local_cmd.add_parser("roots")
    local_roots.add_argument("--project")
    local_scan = local_cmd.add_parser("scan")
    local_scan.add_argument("root_id")
    local_scan.add_argument("--full-hash", action="store_true")
    local_sync = local_cmd.add_parser("sync")
    local_sync.add_argument("root_id")
    local_sync.add_argument("--full-hash", action="store_true")

    studio = root.add_parser("studio")
    studio_cmd = studio.add_subparsers(dest="command", required=True)
    studio_cmd.add_parser("token")
    studio_serve = studio_cmd.add_parser("serve")
    studio_serve.add_argument("--host", default="127.0.0.1")
    studio_serve.add_argument("--port", type=int, default=5177)

    health = root.add_parser("health")
    health_cmd = health.add_subparsers(dest="command", required=True)
    health_cmd.add_parser("check")
    return parser


def _json_object(raw: str, *, label: str) -> dict:
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValidationError(f"{label} must be valid JSON") from exc
    if not isinstance(value, dict):
        raise ValidationError(f"{label} must be a JSON object")
    return value


def _dispatch(app: ManjuApp, args: argparse.Namespace) -> Any:
    if args.group == "project" and args.command == "create":
        return app.create_project(args.name)
    if args.group == "project" and args.command == "list":
        return app.list_projects()
    if args.group == "unit" and args.command == "create":
        return app.create_production_unit(
            args.project,
            args.kind,
            args.name,
            parent_id=args.parent,
            sort_order=args.order,
        )
    if args.group == "asset" and args.command == "create":
        return app.create_asset(
            args.project,
            args.asset_type,
            args.name,
            classification=args.classification,
            role=args.role,
            priority=args.priority,
        )
    if args.group == "asset" and args.command == "ingest":
        return app.ingest_revision(args.asset, args.file, change_summary=args.summary)
    if args.group == "asset" and args.command == "show":
        return app.get_asset(args.asset_id)
    if args.group == "asset" and args.command == "lineage":
        return app.asset_lineage(args.asset_id)
    if args.group == "asset" and args.command == "lock":
        return app.set_asset_lock(args.asset_id, True, reason=args.reason)
    if args.group == "asset" and args.command == "unlock":
        return app.set_asset_lock(args.asset_id, False, reason=args.reason)
    if args.group == "review" and args.command == "queue":
        return app.review_queue(project_id=args.project)
    if args.group == "review" and args.command == "submit":
        return app.submit_review(args.revision_id, args.outcome, severity=args.severity, note=args.note, findings=args.finding)
    if args.group == "review" and args.command == "promote":
        return app.promote_master(args.revision_id, note=args.note)
    if args.group == "task" and args.command == "create":
        return app.create_task(args.project, args.name, production_unit_id=args.unit, acceptance=args.accept, locked_fields=args.locked_field)
    if args.group == "task" and args.command == "transition":
        return app.transition_task(args.task_id, args.to_status, note=args.note)
    if args.group == "continuity" and args.command == "snapshot":
        try:
            state = json.loads(args.state)
        except json.JSONDecodeError as exc:
            raise ValidationError("continuity --state must be valid JSON") from exc
        return app.create_continuity_snapshot(args.project, args.unit, state, inherited_from=args.inherit, note=args.note)
    if args.group == "continuity" and args.command == "diff":
        return app.diff_continuity(args.snapshot_a, args.snapshot_b)
    if args.group == "search":
        return app.search(args.query, project_id=args.project, asset_type=args.asset_type, status=args.status, limit=args.limit)
    if args.group == "legacy" and args.command == "plan":
        return app.plan_legacy_import(args.registry, base_dir=args.base_dir)
    if args.group == "legacy" and args.command == "apply":
        try:
            plan = json.loads(args.plan_file.read_text(encoding="utf-8"))
        except (OSError, UnicodeError, json.JSONDecodeError) as exc:
            raise ValidationError("legacy plan file is invalid") from exc
        return app.apply_legacy_import(plan)
    if args.group == "backup" and args.command == "create":
        return app.create_backup(destination=args.destination)
    if args.group == "provenance" and args.command == "add":
        return app.add_provenance(
            args.from_revision,
            args.to_revision,
            args.edge_type,
            role=args.role,
            weight=args.weight,
            notes=args.notes,
        )
    if args.group == "registry" and args.command == "add":
        return app.register_text_asset(
            args.project, args.kind, args.name, args.content,
            metadata=_json_object(args.metadata, label="registry --metadata"),
        )
    if args.group == "registry" and args.command == "new":
        return app.new_text_revision(
            args.asset_id, args.content,
            metadata=_json_object(args.metadata, label="registry --metadata"),
        )
    if args.group == "registry" and args.command == "list":
        return app.list_registry(project_id=args.project)
    if args.group == "registry" and args.command == "show":
        return app.get_text_revision(args.revision_id)
    if args.group == "bridge" and args.command == "task-packet":
        return app.task_packet(args.task_id)
    if args.group == "bridge" and args.command == "ingest-output":
        return app.ingest_task_output(
            args.task_id, args.asset, args.file,
            input_revision_ids=tuple(args.input),
            prompt_revision_id=args.prompt,
            summary=args.summary,
        )
    if args.group == "generator" and args.command == "record":
        return app.record_generator_run(
            args.project, args.adapter, model=args.model, task_id=args.task,
            prompt_revision_id=args.prompt, input_revision_ids=tuple(args.input),
            output_revision_ids=tuple(args.output),
            parameters=_json_object(args.parameters, label="generator --parameters"),
            status=args.status,
        )
    if args.group == "generator" and args.command == "list":
        return app.list_generator_runs(project_id=args.project)
    if args.group == "local" and args.command == "root-add":
        return app.register_managed_root(args.project, args.path)
    if args.group == "local" and args.command == "roots":
        return app.list_managed_roots(project_id=args.project)
    if args.group == "local" and args.command == "scan":
        return app.scan_managed_root(args.root_id, full_hash=args.full_hash)
    if args.group == "local" and args.command == "sync":
        return app.sync_managed_root(args.root_id, full_hash=args.full_hash)
    if args.group == "health" and args.command == "check":
        return app.health_check()
    raise RuntimeError("unreachable CLI command")


def _emit_success(data: Any, json_output: bool) -> None:
    serial = _jsonable(data)
    if json_output:
        print(json.dumps({"ok": True, "data": serial}, ensure_ascii=False, sort_keys=True))
    else:
        if isinstance(serial, (dict, list)):
            print(json.dumps(serial, ensure_ascii=False, indent=2, sort_keys=True))
        else:
            print(serial)


def _emit_error(error: AppError, json_output: bool) -> None:
    if json_output:
        print(json.dumps({"ok": False, "error": error.envelope()}, ensure_ascii=False, sort_keys=True))
    else:
        print(f"{error.code}: {error.message}", file=sys.stderr)


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    try:
        if args.group == "backup" and args.command == "restore":
            result = restore_backup(args.backup_file, args.workspace)
        elif args.group == "studio" and args.command == "token":
            paths = bootstrap_workspace(args.workspace)
            result = {"token": load_or_create_token(paths)}
        elif args.group == "studio" and args.command == "serve":
            server = create_server(args.workspace, host=args.host, port=args.port)
            host, port = server.server_address[:2]
            startup = {"host": host, "port": port, "url": f"http://{host}:{port}/?token={server.token}"}
            _emit_success(startup, args.json_output)
            sys.stdout.flush()
            try:
                server.serve_forever()
            except KeyboardInterrupt:
                pass
            finally:
                server.server_close()
            return 0
        else:
            with ManjuApp.open(args.workspace) as app:
                result = _dispatch(app, args)
        _emit_success(result, args.json_output)
        return 0
    except AppError as exc:
        _emit_error(exc, args.json_output)
        return 2
    except Exception as exc:
        error = AppError("unexpected internal error")
        if args.json_output:
            _emit_error(error, True)
        else:
            print(f"internal_error: {exc}", file=sys.stderr)
        if os.getenv("MANJU_DEBUG") == "1":
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
