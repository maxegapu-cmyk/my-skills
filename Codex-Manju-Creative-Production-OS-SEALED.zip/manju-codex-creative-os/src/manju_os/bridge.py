from __future__ import annotations

from dataclasses import asdict
from pathlib import Path

from .assets import get_asset
from .continuity import get_snapshot
from .db import transaction
from .errors import ConflictError, NotFoundError
from .provenance import add_edge
from .tasks import get_task, link_task_asset


def task_packet(app, task_id: str) -> dict:
    task = get_task(app.conn, task_id)
    project = app.conn.execute("SELECT * FROM projects WHERE project_id=?", (task.project_id,)).fetchone()
    unit = None
    if task.production_unit_id:
        unit = app.conn.execute("SELECT * FROM production_units WHERE production_unit_id=?", (task.production_unit_id,)).fetchone()
    linked_rows = app.conn.execute(
        "SELECT asset_id, relation FROM task_assets WHERE task_id=? ORDER BY relation, asset_id",
        (task_id,),
    ).fetchall()
    assets: list[dict] = []
    for row in linked_rows:
        asset = app.get_asset(row["asset_id"])
        constraints = app.get_constraints(asset.asset_id)
        master = app.get_revision(asset.active_revision_id) if asset.active_revision_id else None
        constraint_data = asdict(constraints)
        for key in ("allow", "deny", "locked_fields", "assumptions", "tool_limits"):
            constraint_data[key] = list(constraint_data[key])
        assets.append(
            {
                "relation": row["relation"],
                "asset": asdict(asset),
                "active_master": None if master is None else asdict(master),
                "constraints": constraint_data,
            }
        )
    continuity: list[dict] = []
    if task.production_unit_id:
        rows = app.conn.execute(
            "SELECT snapshot_id FROM continuity_snapshots WHERE production_unit_id=? ORDER BY created_at DESC, snapshot_id DESC",
            (task.production_unit_id,),
        ).fetchall()
        continuity = [asdict(get_snapshot(app.conn, row["snapshot_id"])) for row in rows]
    return {
        "task": asdict(task),
        "project": None if project is None else dict(project),
        "production_unit": None if unit is None else dict(unit),
        "assets": assets,
        "continuity": continuity,
    }


def ingest_task_output(
    app,
    task_id: str,
    asset_id: str,
    source: Path,
    *,
    input_revision_ids: tuple[str, ...] | list[str] = (),
    prompt_revision_id: str | None = None,
    summary: str = "task output",
):
    task = get_task(app.conn, task_id)
    asset = get_asset(app.conn, asset_id)
    if asset.project_id != task.project_id:
        raise ConflictError("task output asset belongs to another project")
    for revision_id in input_revision_ids:
        row = app.conn.execute(
            "SELECT a.project_id FROM revisions r JOIN assets a ON a.asset_id=r.asset_id WHERE r.revision_id=?",
            (revision_id,),
        ).fetchone()
        if row is None:
            raise NotFoundError("input revision not found", details={"revision_id": revision_id})
        if row["project_id"] != task.project_id:
            raise ConflictError("input revision belongs to another project")
    if prompt_revision_id is not None:
        row = app.conn.execute(
            "SELECT a.project_id FROM revisions r JOIN assets a ON a.asset_id=r.asset_id WHERE r.revision_id=?",
            (prompt_revision_id,),
        ).fetchone()
        if row is None:
            raise NotFoundError("prompt revision not found", details={"revision_id": prompt_revision_id})
        if row["project_id"] != task.project_id:
            raise ConflictError("prompt revision belongs to another project")
    with transaction(app.conn):
        revision = app.ingest_revision(asset_id, Path(source), change_summary=summary, source_task_id=task_id)
        link_task_asset(app.conn, task_id, asset_id, "output")
        for input_revision_id in input_revision_ids:
            add_edge(app.conn, input_revision_id, revision.revision_id, "task_output", role="input")
        if prompt_revision_id is not None:
            add_edge(app.conn, prompt_revision_id, revision.revision_id, "prompt_source", role="prompt")
    return revision
