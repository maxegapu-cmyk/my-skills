from __future__ import annotations

import threading
import time
import uuid

_lock = threading.Lock()
_last_ms = 0
_counter = 0


def new_id(prefix: str) -> str:
    if not prefix or not prefix.replace("_", "").isalnum():
        raise ValueError("prefix must be non-empty alphanumeric/underscore")
    global _last_ms, _counter
    with _lock:
        now = int(time.time() * 1000)
        if now < _last_ms:
            now = _last_ms
        if now == _last_ms:
            _counter += 1
        else:
            _last_ms = now
            _counter = 0
        suffix = uuid.uuid4().hex[:12]
        return f"{prefix}_{now:013d}_{_counter:04d}_{suffix}"
