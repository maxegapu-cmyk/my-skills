from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

from .db import transaction
from .errors import NotFoundError, ValidationError
from .events import record_event
from .ids import new_id
from .models import ProductionUnit, Project

UNIT_KINDS = {
    "series",
    "season",
    "episode",
    "sequence",
    "scene",
    "shot",
    "beat",
    "deliverable",
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _project_from_row(row: sqlite3.Row) -> Project:
    return Project(
        project_id=row["project_id"],
        name=row["name"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


def _unit_from_row(row: sqlite3.Row) -> ProductionUnit:
    return ProductionUnit(
        production_unit_id=row["production_unit_id"],
        project_id=row["project_id"],
        parent_id=row["parent_id"],
        kind=row["kind"],
        name=row["name"],
        sort_order=row["sort_order"],
        created_at=row["created_at"],
    )


def create_project(conn: sqlite3.Connection, name: str) -> Project:
    name = name.strip()
    if not name:
        raise ValidationError("project name must not be blank")
    now = _utc_now()
    project = Project(new_id("prj"), name, now, now)
    with transaction(conn):
        conn.execute(
            "INSERT INTO projects(project_id, name, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (project.project_id, project.name, project.created_at, project.updated_at),
        )
        record_event(conn, entity_kind="project", entity_id=project.project_id, action="create", after_summary={"name": project.name})
    return project


def list_projects(conn: sqlite3.Connection) -> list[Project]:
    return [
        _project_from_row(row)
        for row in conn.execute("SELECT * FROM projects ORDER BY created_at, project_id")
    ]


def get_project(conn: sqlite3.Connection, project_id: str) -> Project:
    row = conn.execute(
        "SELECT * FROM projects WHERE project_id = ?", (project_id,)
    ).fetchone()
    if row is None:
        raise NotFoundError("project not found", details={"project_id": project_id})
    return _project_from_row(row)


def create_production_unit(
    conn: sqlite3.Connection,
    project_id: str,
    kind: str,
    name: str,
    parent_id: str | None = None,
    sort_order: int = 0,
) -> ProductionUnit:
    kind = kind.strip().lower()
    name = name.strip()
    if kind not in UNIT_KINDS:
        raise ValidationError("unsupported production unit kind", details={"kind": kind})
    if not name:
        raise ValidationError("production unit name must not be blank")
    get_project(conn, project_id)
    if parent_id is not None:
        parent = conn.execute(
            "SELECT project_id FROM production_units WHERE production_unit_id = ?",
            (parent_id,),
        ).fetchone()
        if parent is None:
            raise ValidationError("parent production unit does not exist", details={"parent_id": parent_id})
        if parent["project_id"] != project_id:
            raise ValidationError(
                "parent production unit belongs to another project",
                details={"parent_id": parent_id, "project_id": project_id},
            )
    now = _utc_now()
    unit = ProductionUnit(
        production_unit_id=new_id("unit"),
        project_id=project_id,
        parent_id=parent_id,
        kind=kind,
        name=name,
        sort_order=int(sort_order),
        created_at=now,
    )
    with transaction(conn):
        conn.execute(
            """
            INSERT INTO production_units(
                production_unit_id, project_id, parent_id, kind, name, sort_order, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                unit.production_unit_id,
                unit.project_id,
                unit.parent_id,
                unit.kind,
                unit.name,
                unit.sort_order,
                unit.created_at,
            ),
        )
        record_event(conn, entity_kind="production_unit", entity_id=unit.production_unit_id, action="create", after_summary={"project_id": unit.project_id, "kind": unit.kind, "name": unit.name, "parent_id": unit.parent_id})
    return unit


def list_children(
    conn: sqlite3.Connection, project_id: str, parent_id: str | None = None
) -> list[ProductionUnit]:
    if parent_id is None:
        rows = conn.execute(
            """
            SELECT * FROM production_units
            WHERE project_id = ? AND parent_id IS NULL
            ORDER BY sort_order, created_at, production_unit_id
            """,
            (project_id,),
        )
    else:
        rows = conn.execute(
            """
            SELECT * FROM production_units
            WHERE project_id = ? AND parent_id = ?
            ORDER BY sort_order, created_at, production_unit_id
            """,
            (project_id, parent_id),
        )
    return [_unit_from_row(row) for row in rows]
