from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone

from .assets import get_revision
from .db import transaction
from .errors import ConflictError, NotFoundError, ValidationError
from .events import record_event
from .ids import new_id
from .models import GeneratorRun
from .projects import get_project
from .provenance import add_edge
from .tasks import get_task

STATUSES = {"queued", "running", "succeeded", "failed", "canceled"}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _from_row(row: sqlite3.Row) -> GeneratorRun:
    return GeneratorRun(
        run_id=row["run_id"],
        project_id=row["project_id"],
        task_id=row["task_id"],
        adapter_id=row["adapter_id"],
        model=row["model"],
        prompt_revision_id=row["prompt_revision_id"],
        input_revision_ids=tuple(json.loads(row["input_revision_ids_json"])),
        output_revision_ids=tuple(json.loads(row["output_revision_ids_json"])),
        parameters=json.loads(row["parameters_json"]),
        status=row["status"],
        created_at=row["created_at"],
    )


def _validate_revision_project(conn: sqlite3.Connection, revision_id: str, project_id: str) -> None:
    row = conn.execute(
        "SELECT a.project_id FROM revisions r JOIN assets a ON a.asset_id=r.asset_id WHERE r.revision_id=?",
        (revision_id,),
    ).fetchone()
    if row is None:
        raise NotFoundError("revision not found", details={"revision_id": revision_id})
    if row["project_id"] != project_id:
        raise ConflictError("generator revision belongs to another project", details={"revision_id": revision_id})


def record_generator_run(
    conn: sqlite3.Connection,
    project_id: str,
    adapter_id: str,
    *,
    model: str | None = None,
    task_id: str | None = None,
    prompt_revision_id: str | None = None,
    input_revision_ids: tuple[str, ...] | list[str] = (),
    output_revision_ids: tuple[str, ...] | list[str] = (),
    parameters: dict | None = None,
    status: str = "succeeded",
) -> GeneratorRun:
    get_project(conn, project_id)
    adapter_id = adapter_id.strip()
    status = status.strip().lower()
    if not adapter_id:
        raise ValidationError("adapter_id must not be blank")
    if status not in STATUSES:
        raise ValidationError("invalid generator run status", details={"status": status})
    if task_id is not None:
        task = get_task(conn, task_id)
        if task.project_id != project_id:
            raise ConflictError("generator task belongs to another project")
    all_ids = list(input_revision_ids) + list(output_revision_ids)
    if prompt_revision_id is not None:
        all_ids.append(prompt_revision_id)
    for revision_id in all_ids:
        _validate_revision_project(conn, revision_id, project_id)
    parameters = dict(parameters or {})
    try:
        parameters_json = json.dumps(parameters, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    except (TypeError, ValueError) as exc:
        raise ValidationError("generator parameters must be JSON serializable") from exc
    if len(parameters_json.encode("utf-8")) > 200_000:
        raise ValidationError("generator parameters are too large")
    run_id = new_id("run")
    now = _utc_now()
    with transaction(conn):
        conn.execute(
            """
            INSERT INTO generator_runs(run_id,project_id,task_id,adapter_id,model,prompt_revision_id,
              input_revision_ids_json,output_revision_ids_json,parameters_json,status,created_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                run_id, project_id, task_id, adapter_id, model, prompt_revision_id,
                json.dumps(list(input_revision_ids)), json.dumps(list(output_revision_ids)),
                parameters_json, status, now,
            ),
        )
        for output_revision_id in output_revision_ids:
            if prompt_revision_id is not None:
                add_edge(conn, prompt_revision_id, output_revision_id, "prompt_source", role="prompt")
            for input_revision_id in input_revision_ids:
                add_edge(conn, input_revision_id, output_revision_id, "generation_input", role="input")
        record_event(
            conn,
            entity_kind="generator_run",
            entity_id=run_id,
            action="record",
            after_summary={"project_id": project_id, "adapter_id": adapter_id, "status": status, "outputs": list(output_revision_ids)},
        )
    return get_generator_run(conn, run_id)


def get_generator_run(conn: sqlite3.Connection, run_id: str) -> GeneratorRun:
    row = conn.execute("SELECT * FROM generator_runs WHERE run_id=?", (run_id,)).fetchone()
    if row is None:
        raise NotFoundError("generator run not found", details={"run_id": run_id})
    return _from_row(row)


def list_generator_runs(conn: sqlite3.Connection, project_id: str | None = None) -> list[GeneratorRun]:
    if project_id is None:
        rows = conn.execute("SELECT * FROM generator_runs ORDER BY created_at DESC, run_id DESC").fetchall()
    else:
        rows = conn.execute("SELECT * FROM generator_runs WHERE project_id=? ORDER BY created_at DESC, run_id DESC", (project_id,)).fetchall()
    return [_from_row(row) for row in rows]
