from __future__ import annotations

import sqlite3
from datetime import datetime, timezone


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


MIGRATION_1 = r'''
CREATE TABLE IF NOT EXISTS schema_migrations(
  version INTEGER PRIMARY KEY,
  applied_at TEXT NOT NULL
);
CREATE TABLE projects(
  project_id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE production_units(
  production_unit_id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  parent_id TEXT REFERENCES production_units(production_unit_id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  name TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  UNIQUE(project_id, parent_id, sort_order, production_unit_id)
);
CREATE TABLE assets(
  asset_id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  asset_type TEXT NOT NULL,
  display_name TEXT NOT NULL,
  canonical_status TEXT NOT NULL DEFAULT 'active',
  classification TEXT,
  role TEXT,
  priority INTEGER NOT NULL DEFAULT 0,
  locked INTEGER NOT NULL DEFAULT 0 CHECK(locked IN (0,1)),
  active_revision_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE asset_constraints(
  asset_id TEXT PRIMARY KEY REFERENCES assets(asset_id) ON DELETE CASCADE,
  allow_json TEXT NOT NULL DEFAULT '[]',
  deny_json TEXT NOT NULL DEFAULT '[]',
  locked_fields_json TEXT NOT NULL DEFAULT '[]',
  assumptions_json TEXT NOT NULL DEFAULT '[]',
  tool_limits_json TEXT NOT NULL DEFAULT '[]',
  exclusive_group TEXT,
  positive_generation_input INTEGER NOT NULL DEFAULT 1 CHECK(positive_generation_input IN (0,1))
);
CREATE TABLE blobs(
  blob_hash TEXT PRIMARY KEY,
  vault_relpath TEXT NOT NULL UNIQUE,
  file_size INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE revisions(
  revision_id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES assets(asset_id) ON DELETE CASCADE,
  revision_number INTEGER NOT NULL,
  blob_hash TEXT NOT NULL REFERENCES blobs(blob_hash),
  original_filename TEXT NOT NULL,
  media_type TEXT NOT NULL,
  file_size INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'candidate',
  change_summary TEXT NOT NULL,
  source_task_id TEXT,
  created_at TEXT NOT NULL,
  UNIQUE(asset_id, revision_number)
);
CREATE TABLE provenance_edges(
  edge_id TEXT PRIMARY KEY,
  from_revision_id TEXT NOT NULL REFERENCES revisions(revision_id) ON DELETE CASCADE,
  to_revision_id TEXT NOT NULL REFERENCES revisions(revision_id) ON DELETE CASCADE,
  edge_type TEXT NOT NULL,
  role TEXT,
  weight REAL,
  notes TEXT,
  created_at TEXT NOT NULL,
  CHECK(from_revision_id <> to_revision_id)
);
CREATE TABLE events(
  event_id TEXT PRIMARY KEY,
  entity_kind TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  action TEXT NOT NULL,
  before_summary TEXT,
  after_summary TEXT,
  actor TEXT NOT NULL,
  idempotency_key TEXT UNIQUE,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_units_project_parent ON production_units(project_id, parent_id, sort_order);
CREATE INDEX idx_assets_project_type ON assets(project_id, asset_type);
CREATE INDEX idx_revisions_asset_number ON revisions(asset_id, revision_number DESC);
CREATE INDEX idx_prov_from ON provenance_edges(from_revision_id);
CREATE INDEX idx_prov_to ON provenance_edges(to_revision_id);
'''


def migrate(conn: sqlite3.Connection) -> int:
    conn.execute(
        "CREATE TABLE IF NOT EXISTS schema_migrations(version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)"
    )
    row = conn.execute("SELECT COALESCE(MAX(version), 0) FROM schema_migrations").fetchone()
    current = int(row[0])
    if current < 1:
        conn.executescript(MIGRATION_1)
        conn.execute(
            "INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES (?, ?)",
            (1, _utc_now()),
        )
        conn.commit()
        current = 1
    if current < 2:
        conn.executescript(MIGRATION_2)
        _create_search_table(conn)
        conn.execute(
            "INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES (?, ?)",
            (2, _utc_now()),
        )
        conn.commit()
        current = 2
    if current < 3:
        conn.executescript(MIGRATION_3)
        conn.execute(
            "INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES (?, ?)",
            (3, _utc_now()),
        )
        conn.commit()
        current = 3
    if current < 4:
        conn.executescript(MIGRATION_4)
        conn.execute(
            "INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES (?, ?)",
            (4, _utc_now()),
        )
        conn.commit()
        current = 4
    if current < 5:
        conn.executescript(MIGRATION_5)
        conn.execute(
            "INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES (?, ?)",
            (5, _utc_now()),
        )
        conn.commit()
        current = 5
    return current

MIGRATION_2 = r'''
CREATE TABLE reviews(
  review_id TEXT PRIMARY KEY,
  revision_id TEXT NOT NULL REFERENCES revisions(revision_id) ON DELETE CASCADE,
  outcome TEXT NOT NULL,
  severity TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  findings_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL
);
CREATE TABLE asset_locks(
  asset_id TEXT PRIMARY KEY REFERENCES assets(asset_id) ON DELETE CASCADE,
  reason TEXT NOT NULL DEFAULT '',
  locked_at TEXT NOT NULL
);
CREATE TABLE tasks(
  task_id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  production_unit_id TEXT REFERENCES production_units(production_unit_id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  acceptance_json TEXT NOT NULL DEFAULT '[]',
  locked_fields_json TEXT NOT NULL DEFAULT '[]',
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE task_assets(
  task_id TEXT NOT NULL REFERENCES tasks(task_id) ON DELETE CASCADE,
  asset_id TEXT NOT NULL REFERENCES assets(asset_id) ON DELETE CASCADE,
  relation TEXT NOT NULL,
  PRIMARY KEY(task_id, asset_id, relation)
);
CREATE TABLE continuity_snapshots(
  snapshot_id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  production_unit_id TEXT NOT NULL REFERENCES production_units(production_unit_id) ON DELETE CASCADE,
  inherited_from TEXT REFERENCES continuity_snapshots(snapshot_id) ON DELETE SET NULL,
  state_json TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
CREATE TABLE legacy_imports(
  import_id TEXT PRIMARY KEY,
  project_id TEXT REFERENCES projects(project_id) ON DELETE SET NULL,
  legacy_external_id TEXT,
  asset_id TEXT REFERENCES assets(asset_id) ON DELETE SET NULL,
  source_path TEXT,
  source_hash TEXT,
  imported_at TEXT NOT NULL,
  UNIQUE(legacy_external_id, project_id)
);
ALTER TABLE assets ADD COLUMN legacy_external_id TEXT;
CREATE INDEX idx_reviews_revision ON reviews(revision_id, created_at DESC);
CREATE INDEX idx_tasks_project_status ON tasks(project_id, status);
CREATE INDEX idx_continuity_unit ON continuity_snapshots(production_unit_id, created_at DESC);
CREATE INDEX idx_assets_legacy_external ON assets(legacy_external_id);
'''


def _create_search_table(conn: sqlite3.Connection) -> None:
    try:
        conn.execute(
            """
            CREATE VIRTUAL TABLE IF NOT EXISTS asset_search USING fts5(
              asset_id UNINDEXED,
              revision_id UNINDEXED,
              project_id UNINDEXED,
              asset_type UNINDEXED,
              status UNINDEXED,
              blob_hash UNINDEXED,
              content
            )
            """
        )
    except sqlite3.OperationalError:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS asset_search(
              asset_id TEXT NOT NULL,
              revision_id TEXT,
              project_id TEXT NOT NULL,
              asset_type TEXT NOT NULL,
              status TEXT,
              blob_hash TEXT,
              content TEXT NOT NULL
            )
            """
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_asset_search_asset ON asset_search(asset_id)")

MIGRATION_3 = r'''
CREATE TABLE api_idempotency(
  idempotency_key TEXT PRIMARY KEY,
  route TEXT NOT NULL,
  response_json TEXT NOT NULL,
  status_code INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE text_revision_contents(
  revision_id TEXT PRIMARY KEY REFERENCES revisions(revision_id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK(kind IN ('prompt','skill')),
  content TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);
CREATE TABLE generator_runs(
  run_id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  task_id TEXT REFERENCES tasks(task_id) ON DELETE SET NULL,
  adapter_id TEXT NOT NULL,
  model TEXT,
  prompt_revision_id TEXT REFERENCES revisions(revision_id) ON DELETE SET NULL,
  input_revision_ids_json TEXT NOT NULL DEFAULT '[]',
  output_revision_ids_json TEXT NOT NULL DEFAULT '[]',
  parameters_json TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX idx_generator_runs_project ON generator_runs(project_id, created_at DESC);
CREATE INDEX idx_generator_runs_task ON generator_runs(task_id, created_at DESC);
'''


MIGRATION_4 = r'''
CREATE TABLE managed_roots(
  root_id TEXT PRIMARY KEY,
  project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  path TEXT NOT NULL,
  include_json TEXT NOT NULL DEFAULT '[]',
  exclude_json TEXT NOT NULL DEFAULT '[]',
  enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
  last_scan_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(project_id, path)
);
CREATE TABLE source_bindings(
  binding_id TEXT PRIMARY KEY,
  root_id TEXT NOT NULL REFERENCES managed_roots(root_id) ON DELETE CASCADE,
  project_id TEXT NOT NULL REFERENCES projects(project_id) ON DELETE CASCADE,
  source_relpath TEXT NOT NULL,
  source_filename TEXT NOT NULL,
  asset_id TEXT REFERENCES assets(asset_id) ON DELETE SET NULL,
  revision_id TEXT REFERENCES revisions(revision_id) ON DELETE SET NULL,
  file_hash TEXT,
  file_size INTEGER,
  mtime_ns INTEGER,
  status TEXT NOT NULL DEFAULT 'active',
  first_seen_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  UNIQUE(root_id, source_relpath)
);
CREATE INDEX idx_managed_roots_project ON managed_roots(project_id, enabled);
CREATE INDEX idx_source_bindings_root_status ON source_bindings(root_id, status, source_relpath);
CREATE INDEX idx_source_bindings_asset ON source_bindings(asset_id);
'''


MIGRATION_5 = r'''
ALTER TABLE api_idempotency ADD COLUMN request_hash TEXT;
'''
