from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from typing import Any

from .errors import ConflictError
from .ids import new_id


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _json(value: Any) -> str | None:
    if value is None:
        return None
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def record_event(
    conn: sqlite3.Connection,
    *,
    entity_kind: str,
    entity_id: str,
    action: str,
    before_summary: Any = None,
    after_summary: Any = None,
    actor: str = "local",
    idempotency_key: str | None = None,
) -> str:
    if idempotency_key:
        previous = conn.execute(
            "SELECT event_id, entity_kind, entity_id, action FROM events WHERE idempotency_key = ?",
            (idempotency_key,),
        ).fetchone()
        if previous is not None:
            if (
                previous["entity_kind"] == entity_kind
                and previous["entity_id"] == entity_id
                and previous["action"] == action
            ):
                return previous["event_id"]
            raise ConflictError(
                "idempotency key already used for another mutation",
                details={"idempotency_key": idempotency_key},
            )
    event_id = new_id("evt")
    conn.execute(
        """
        INSERT INTO events(
          event_id, entity_kind, entity_id, action, before_summary,
          after_summary, actor, idempotency_key, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            event_id,
            entity_kind,
            entity_id,
            action,
            _json(before_summary),
            _json(after_summary),
            actor,
            idempotency_key,
            _utc_now(),
        ),
    )
    return event_id
