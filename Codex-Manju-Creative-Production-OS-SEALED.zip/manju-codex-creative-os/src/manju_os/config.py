from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class WorkspacePaths:
    root: Path
    database_dir: Path
    database_file: Path
    backup_dir: Path
    vault_sha256_dir: Path
    cache_dir: Path
    exports_dir: Path
    logs_dir: Path
    runtime_dir: Path


def bootstrap_workspace(root: Path) -> WorkspacePaths:
    root = root.expanduser().resolve()
    database_dir = root / "database"
    paths = WorkspacePaths(
        root=root,
        database_dir=database_dir,
        database_file=database_dir / "manju.sqlite3",
        backup_dir=database_dir / "backups",
        vault_sha256_dir=root / "vault" / "sha256",
        cache_dir=root / "cache",
        exports_dir=root / "exports",
        logs_dir=root / "logs",
        runtime_dir=root / "runtime",
    )
    for directory in (
        paths.database_dir,
        paths.backup_dir,
        paths.vault_sha256_dir,
        paths.cache_dir,
        paths.exports_dir,
        paths.logs_dir,
        paths.runtime_dir,
    ):
        directory.mkdir(parents=True, exist_ok=True)
    return paths
