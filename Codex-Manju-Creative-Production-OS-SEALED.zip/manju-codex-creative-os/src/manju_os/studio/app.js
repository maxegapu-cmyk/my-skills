(() => {
  'use strict';

  const params = new URLSearchParams(location.search);
  const queryToken = params.get('token');
  if (queryToken) {
    sessionStorage.setItem('manju_token', queryToken);
    history.replaceState({}, '', location.pathname);
  }

  const state = {
    token: sessionStorage.getItem('manju_token') || '',
    view: 'command',
    project: '',
    projects: [],
    assetQuery: '',
    intakePreview: null,
  };

  const el = {
    stage: document.getElementById('stage'),
    nav: document.getElementById('nav'),
    title: document.getElementById('view-title'),
    route: document.getElementById('route-context'),
    project: document.getElementById('project-context'),
    search: document.getElementById('global-search'),
    apiState: document.getElementById('api-state'),
    refresh: document.getElementById('refresh'),
    toast: document.getElementById('toast'),
    drawer: document.getElementById('detail-drawer'),
    drawerTitle: document.getElementById('drawer-title'),
    drawerBody: document.getElementById('drawer-body'),
    drawerClose: document.getElementById('drawer-close'),
  };

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[ch]));
  const fmt = (value) => value ? new Date(value).toLocaleString() : '—';
  const mono = (value) => `<span class="mono">${esc(value || '—')}</span>`;
  const status = (value) => `<span class="status ${esc(String(value || '').toLowerCase())}">${esc(value || '—')}</span>`;
  const empty = (title, text='') => `<div class="empty-state"><div><strong>${esc(title)}</strong>${esc(text)}</div></div>`;
  const projectQuery = () => state.project ? `project=${encodeURIComponent(state.project)}` : '';
  const withQuery = (path, parts=[]) => {
    const query = parts.filter(Boolean).join('&');
    return query ? `${path}?${query}` : path;
  };

  function notify(message) {
    el.toast.textContent = message;
    el.toast.classList.add('show');
    clearTimeout(notify.timer);
    notify.timer = setTimeout(() => el.toast.classList.remove('show'), 2200);
  }

  function setOnline(ok) {
    el.apiState.className = `link-state ${ok ? 'online' : 'error'}`;
    el.apiState.innerHTML = `<span></span>${ok ? 'LOCAL ONLINE' : 'LOCAL ERROR'}`;
  }

  async function api(path, options={}) {
    const headers = Object.assign({}, options.headers || {}, {Authorization: `Bearer ${state.token}`});
    const request = Object.assign({}, options, {headers});
    if (request.body && typeof request.body !== 'string') {
      headers['Content-Type'] = 'application/json';
      request.body = JSON.stringify(request.body);
    }
    const response = await fetch(path, request);
    const payload = await response.json().catch(() => ({ok:false,error:{message:'响应不是有效 JSON'}}));
    if (!response.ok || !payload.ok) throw new Error(payload.error?.message || `HTTP ${response.status}`);
    setOnline(true);
    return payload.data;
  }

  async function post(path, body={}) {
    return api(path, {method:'POST', headers:{'Idempotency-Key': crypto.randomUUID()}, body});
  }

  function panel(title, body, meta='', cls='') {
    return `<section class="panel ${cls}"><div class="panel-head"><span class="panel-title">${esc(title)}</span><span class="panel-meta">${esc(meta)}</span></div><div class="panel-body">${body}</div></section>`;
  }

  function intro(kicker, title, copy, actions='') {
    return `<div class="stage-intro"><div><div class="eyeline">${esc(kicker)}</div><h1>${esc(title)}</h1><p>${esc(copy)}</p></div><div class="action-cluster">${actions}</div></div>`;
  }

  function signal(label, value, note, cls='') {
    return `<div class="signal ${cls}"><div class="signal-label">${esc(label)}</div><div class="signal-value">${esc(value)}</div><div class="signal-note">${esc(note)}</div></div>`;
  }

  function openDrawer(title, body) {
    el.drawerTitle.textContent = title;
    el.drawerBody.innerHTML = body;
    el.drawer.classList.add('open');
    el.drawer.setAttribute('aria-hidden', 'false');
  }

  function closeDrawer() {
    el.drawer.classList.remove('open');
    el.drawer.setAttribute('aria-hidden', 'true');
  }

  async function loadProjects() {
    state.projects = await api('/api/v1/projects');
    const current = state.project;
    el.project.innerHTML = `<option value="">全部项目</option>${state.projects.map((p) => `<option value="${esc(p.project_id)}">${esc(p.name)}</option>`).join('')}`;
    if (current && state.projects.some((p) => p.project_id === current)) el.project.value = current;
    else if (current) state.project = '';
  }

  function projectName(projectId) {
    return state.projects.find((p) => p.project_id === projectId)?.name || projectId || '全部项目';
  }

  function renderTree(nodes) {
    if (!nodes?.length) return empty('生产树为空', '先建立 Episode / Scene / Shot 等生产单元。');
    return `<ul class="production-tree">${nodes.map((node) => `<li><div class="tree-node"><span class="unit-kind">${esc(node.kind)}</span><strong>${esc(node.name)}</strong><span class="mono">${esc(node.production_unit_id)}</span></div>${node.children?.length ? renderTree(node.children) : ''}</li>`).join('')}</ul>`;
  }

  async function renderCommand() {
    el.title.textContent = '生产指挥中心';
    el.route.textContent = 'COMMAND';
    const [dashboard, roots, projects] = await Promise.all([
      api('/api/v1/dashboard'),
      api(withQuery('/api/v1/local/roots', [projectQuery()])),
      api('/api/v1/projects'),
    ]);
    const activity = dashboard.recent_activity?.length
      ? `<div class="activity-list">${dashboard.recent_activity.map((item) => `<div class="activity-row"><span class="activity-code">${esc(item.entity_kind?.slice(0,4).toUpperCase())}</span><div class="row-main"><strong>${esc(item.action)}</strong><small>${esc(item.entity_id)}</small></div><span class="timestamp">${fmt(item.created_at)}</span></div>`).join('')}</div>`
      : empty('尚无生产事件');
    const projectCards = projects.length
      ? projects.slice(0,6).map((p) => `<button class="task-card project-jump" data-project="${esc(p.project_id)}"><strong>${esc(p.name)}</strong><span class="mono">${esc(p.project_id)}</span></button>`).join('')
      : empty('还没有项目', '创建第一个项目后，所有资产和任务都会挂到项目 SSoT。');
    const rootSummary = roots.length
      ? `<div class="root-list">${roots.slice(0,6).map((root) => `<div class="root-row"><span class="activity-code">ROOT</span><div class="row-main"><strong>${esc(projectName(root.project_id))}</strong><small class="mono">${esc(root.path)}</small></div>${status(root.enabled ? 'active' : 'disabled')}</div>`).join('')}</div>`
      : empty('尚未接管本地目录', '在“接管”视图登记一个只读源目录。');

    el.stage.innerHTML = intro('REAL-TIME PRODUCTION PULSE', '指挥中心', '一眼看清生产阻塞、待审版本、正式母版和本地接管状态。') +
      `<div class="signal-grid">${signal('PROJECTS', dashboard.projects, '本地项目')}${signal('PENDING REVIEW', dashboard.pending_reviews, '等待人工裁决', dashboard.pending_reviews ? 'alert' : '')}${signal('ACTIVE MASTERS', dashboard.active_masters, '已晋升正式母版', 'good')}${signal('BLOCKED TASKS', dashboard.blocked_tasks, '需要处理的任务', dashboard.blocked_tasks ? 'alert' : '')}</div>` +
      `<div class="grid two">${panel('最近活动', activity, 'EVENT JOURNAL', 'flush')}${panel('本地接管', rootSummary, `${roots.length} ROOTS`, 'flush')}</div>` +
      `<div class="grid">${panel('项目快速入口', `<div class="task-columns" style="grid-template-columns:repeat(3,minmax(180px,1fr))">${projectCards}</div>`, `${projects.length} PROJECTS`)}</div>`;
    document.querySelectorAll('.project-jump').forEach((button) => button.onclick = () => {
      state.project = button.dataset.project;
      el.project.value = state.project;
      switchView('production');
    });
  }

  async function renderProduction() {
    el.title.textContent = '生产作战台';
    el.route.textContent = 'PRODUCTION';
    if (!state.project && state.projects.length) {
      state.project = state.projects[0].project_id;
      el.project.value = state.project;
    }
    if (!state.project) {
      el.stage.innerHTML = intro('PROJECT TREE / TASK STATE', '生产作战台', '建立项目后，这里会把生产树与任务状态并排呈现。') + panel('生产状态', empty('需要一个项目'));
      return;
    }
    const [tree, tasks] = await Promise.all([
      api(`/api/v1/projects/${encodeURIComponent(state.project)}/tree`),
      api(`/api/v1/tasks?project=${encodeURIComponent(state.project)}`),
    ]);
    const groups = {draft:[], ready:[], running:[], review:[]};
    for (const task of tasks) {
      if (task.status === 'draft') groups.draft.push(task);
      else if (task.status === 'ready') groups.ready.push(task);
      else if (task.status === 'running') groups.running.push(task);
      else groups.review.push(task);
    }
    const column = (label, rows) => `<div class="task-column"><div class="column-head">${esc(label)} · ${rows.length}</div>${rows.length ? rows.map((task) => `<div class="task-card task-inspect" data-task="${esc(task.task_id)}"><strong>${esc(task.name)}</strong>${status(task.status)}<span class="mono">${esc(task.task_id)}</span></div>`).join('') : '<div class="empty-state">0</div>'}</div>`;
    el.stage.innerHTML = intro('PROJECT TREE / TASK STATE', projectName(state.project), '把 Sequence / Scene / Shot 与 Agent 任务放在同一个生产上下文里。') +
      `<div class="production-layout">${panel('生产树', `<div class="tree-board">${renderTree(tree)}</div>`, 'SSoT', 'flush')}${panel('任务流', `<div class="task-columns">${column('DRAFT',groups.draft)}${column('READY',groups.ready)}${column('RUNNING',groups.running)}${column('REVIEW / DONE',groups.review)}</div>`, `${tasks.length} TASKS`)}</div>`;
    document.querySelectorAll('.task-inspect').forEach((button) => button.onclick = () => inspectTask(button.dataset.task));
  }

  async function renderAssets() {
    el.title.textContent = '资产与版本库';
    el.route.textContent = 'ASSETS';
    const query = state.assetQuery.trim();
    const parts = [projectQuery()];
    if (query) parts.push(`q=${encodeURIComponent(query)}`);
    const rows = query ? await api(withQuery('/api/v1/search', parts)) : await api(withQuery('/api/v1/assets', parts));
    const normalized = rows.map((row) => ({
      asset_id: row.asset_id,
      display_name: row.display_name || row.content || row.asset_id,
      asset_type: row.asset_type,
      canonical_status: row.canonical_status || row.status || 'active',
      active_revision_id: row.active_revision_id || row.revision_id,
      classification: row.classification || '',
      locked: row.locked,
    }));
    const table = normalized.length ? `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>Asset</th><th>Type</th><th>Status</th><th>Class</th><th>Active Revision</th></tr></thead><tbody>${normalized.map((a) => `<tr class="interactive asset-open" data-asset="${esc(a.asset_id)}"><td><strong>${esc(a.display_name)}</strong><div class="mono">${esc(a.asset_id)}</div></td><td>${esc(a.asset_type)}</td><td>${status(a.locked ? 'locked' : a.canonical_status)}</td><td>${esc(a.classification || '—')}</td><td>${mono(a.active_revision_id)}</td></tr>`).join('')}</tbody></table></div>` : empty('没有匹配资产');
    el.stage.innerHTML = intro('ASSET / REVISION / LINEAGE', '资产与版本库', '文件只是载体；Asset ID、Revision、Master 与 Provenance 才是正式生产身份。') +
      `<section class="panel flush"><div class="filter-bar"><input id="asset-search" class="input grow" value="${esc(query)}" placeholder="搜索资产、约束、审核文本…"><button id="asset-search-go" class="button primary">搜索</button><button id="asset-search-clear" class="button subtle">清空</button><span class="panel-meta">${normalized.length} RESULTS</span></div><div class="panel-body">${table}</div></section>`;
    document.querySelectorAll('.asset-open').forEach((row) => row.onclick = () => inspectAsset(row.dataset.asset));
    document.getElementById('asset-search-go').onclick = () => { state.assetQuery = document.getElementById('asset-search').value; renderAssets(); };
    document.getElementById('asset-search-clear').onclick = () => { state.assetQuery = ''; renderAssets(); };
    document.getElementById('asset-search').onkeydown = (event) => { if (event.key === 'Enter') document.getElementById('asset-search-go').click(); };
  }

  async function inspectAsset(assetId) {
    const detail = await api(`/api/v1/assets/${encodeURIComponent(assetId)}`);
    const asset = detail.asset;
    const revisions = detail.revisions?.length ? detail.revisions.map((rev) => `<div class="revision-row"><span class="revision-number">v${esc(rev.revision_number)}</span><div><div>${status(rev.status)}</div><div class="mono">${esc(rev.revision_id)}</div></div>${rev.status === 'approved' ? `<button class="button positive promote-rev" data-rev="${esc(rev.revision_id)}">晋升 Master</button>` : ''}</div>`).join('') : empty('没有版本');
    const lockLabel = asset.locked ? '解除锁定' : '锁定资产';
    openDrawer(asset.display_name, `
      <section class="drawer-section"><div class="action-cluster">${status(asset.locked ? 'locked' : asset.canonical_status)}<button id="drawer-lock" class="button">${lockLabel}</button></div></section>
      <section class="drawer-section"><h3>身份</h3><dl class="kv-grid"><dt>Asset ID</dt><dd>${mono(asset.asset_id)}</dd><dt>类型</dt><dd>${esc(asset.asset_type)}</dd><dt>Active Revision</dt><dd>${mono(asset.active_revision_id)}</dd><dt>谱系</dt><dd>${detail.lineage.nodes.length} nodes · ${detail.lineage.edges.length} edges</dd></dl></section>
      <section class="drawer-section"><h3>约束合同</h3><dl class="kv-grid"><dt>ALLOW</dt><dd>${esc(detail.constraints.allow.join(' · ') || '—')}</dd><dt>DENY</dt><dd>${esc(detail.constraints.deny.join(' · ') || '—')}</dd><dt>LOCKED FIELDS</dt><dd>${esc(detail.constraints.locked_fields.join(' · ') || '—')}</dd><dt>TOOL LIMITS</dt><dd>${esc(detail.constraints.tool_limits.join(' · ') || '—')}</dd></dl></section>
      <section class="drawer-section"><h3>版本</h3>${revisions}</section>`);
    document.getElementById('drawer-lock').onclick = async () => {
      await post(`/api/v1/assets/${encodeURIComponent(asset.asset_id)}/lock`, {locked: !asset.locked, reason: 'Studio operator'});
      notify(asset.locked ? '资产已解锁' : '资产已锁定');
      inspectAsset(asset.asset_id);
    };
    document.querySelectorAll('.promote-rev').forEach((button) => button.onclick = async () => {
      await post(`/api/v1/revisions/${encodeURIComponent(button.dataset.rev)}/promote`, {note:'Studio promotion'});
      notify('已晋升为 Master');
      inspectAsset(asset.asset_id);
    });
  }

  async function renderReview() {
    el.title.textContent = '审核闸门';
    el.route.textContent = 'REVIEW';
    const queue = await api(withQuery('/api/v1/reviews/queue', [projectQuery()]));
    const rows = queue.length ? `<div class="review-list">${queue.map((rev) => `<div class="review-row"><span class="activity-code">v${esc(rev.revision_number)}</span><div class="row-main"><strong>${esc(rev.original_filename)}</strong><small class="mono">${esc(rev.revision_id)}</small></div><div class="row-actions"><button class="button positive review-action" data-outcome="pass" data-rev="${esc(rev.revision_id)}">通过</button><button class="button danger review-action" data-outcome="reject" data-rev="${esc(rev.revision_id)}">拒绝</button></div></div>`).join('')}</div>` : empty('审核队列已清空', '审核通过不等于自动晋升 Master，两个动作保持分离。');
    el.stage.innerHTML = intro('HARD GATE BEFORE MASTER', '审核闸门', '审核只做裁决，不偷偷改稿；Master 晋升在资产详情中单独执行。') + panel('待审版本', rows, `${queue.length} PENDING`, 'flush');
    document.querySelectorAll('.review-action').forEach((button) => button.onclick = async () => {
      const outcome = button.dataset.outcome;
      await post(`/api/v1/reviews/${encodeURIComponent(button.dataset.rev)}/submit`, {outcome, severity: outcome === 'reject' ? 'P1' : 'P3', note:'Studio review'});
      notify(outcome === 'pass' ? '审核通过' : '审核拒绝');
      renderReview();
    });
  }

  async function renderContinuity() {
    el.title.textContent = '连续性状态板';
    el.route.textContent = 'CONTINUITY';
    const rows = await api(withQuery('/api/v1/continuity', [projectQuery()]));
    const table = rows.length ? `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>Production Unit</th><th>Inherited</th><th>State</th><th>Created</th></tr></thead><tbody>${rows.map((snap) => `<tr><td>${mono(snap.production_unit_id)}</td><td>${mono(snap.inherited_from)}</td><td class="clip mono">${esc(JSON.stringify(snap.state))}</td><td>${fmt(snap.created_at)}</td></tr>`).join('')}</tbody></table></div>` : empty('还没有连续性快照', '每个镜头结束时记录“上一秒留下了什么”。');
    el.stage.innerHTML = intro('STATE INHERITANCE / DIFF', '连续性状态板', '角色、道具、伤痕、站位和环境状态按镜头继承，而不是靠 Agent 临场记忆。') + panel('连续性快照', table, `${rows.length} SNAPSHOTS`, 'flush');
  }

  async function renderIntake() {
    el.title.textContent = '本地接管';
    el.route.textContent = 'INTAKE';
    const roots = await api(withQuery('/api/v1/local/roots', [projectQuery()]));
    const rootRows = roots.length ? `<div class="root-list">${roots.map((root) => `<div class="root-row"><span class="activity-code">ROOT</span><div class="row-main"><strong>${esc(projectName(root.project_id))}</strong><small class="mono">${esc(root.path)}</small><small>Last scan: ${fmt(root.last_scan_at)}</small></div><div class="row-actions"><button class="button intake-scan" data-root="${esc(root.root_id)}">预扫描</button><button class="button primary intake-sync" data-root="${esc(root.root_id)}">同步入库</button></div></div>`).join('')}</div>` : empty('没有托管目录', '登记的是“只读源目录”：系统不会删除、覆盖、移动原文件。');
    const preview = state.intakePreview ? renderIntakePreview(state.intakePreview) : empty('等待预扫描', '先预扫描，再决定是否同步。');
    const options = state.projects.map((p) => `<option value="${esc(p.project_id)}" ${p.project_id === state.project ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
    el.stage.innerHTML = intro('READ-ONLY SOURCE / MANAGED VAULT', '本地接管', '扫描用户指定目录，把新文件和变化登记为不可变 Revision；源目录始终保持原样。') +
      `<div class="grid two">${panel('托管目录', rootRows, `${roots.length} ROOTS`, 'flush')}${panel('新增托管目录', `<div class="form-grid"><select id="intake-project" class="select">${options}</select><input id="intake-path" class="input" placeholder="本地绝对路径"><div class="span-2 hint">安全规则：不得与工作区重叠；不跟随符号链接；只读取允许的创作资产扩展名。</div><button id="intake-add" class="button primary span-2" ${state.projects.length ? '' : 'disabled'}>登记目录</button></div>`)}</div>` +
      `<div class="grid">${panel('扫描预览', preview, state.intakePreview ? state.intakePreview.root_id : 'NO PREVIEW', 'flush')}</div>`;
    document.getElementById('intake-add').onclick = async () => {
      const projectId = document.getElementById('intake-project').value;
      const path = document.getElementById('intake-path').value.trim();
      if (!projectId || !path) return notify('请选择项目并填写路径');
      await post('/api/v1/local/roots', {project_id: projectId, path});
      notify('托管目录已登记');
      state.project = projectId; el.project.value = projectId;
      renderIntake();
    };
    document.querySelectorAll('.intake-scan').forEach((button) => button.onclick = async () => {
      state.intakePreview = await api(`/api/v1/local/roots/${encodeURIComponent(button.dataset.root)}/scan`);
      renderIntake();
    });
    document.querySelectorAll('.intake-sync').forEach((button) => button.onclick = async () => {
      state.intakePreview = await post(`/api/v1/local/roots/${encodeURIComponent(button.dataset.root)}/sync`, {});
      notify('同步完成，源目录未被修改');
      renderIntake();
    });
  }

  function renderIntakePreview(report) {
    const chips = ['new','changed','unchanged','missing','skipped','errors'].map((key) => `<span class="count-chip">${key.toUpperCase()} ${esc(report[key])}</span>`).join('');
    const rows = report.items?.length ? `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>State</th><th>Source</th><th>Type</th><th>Asset</th></tr></thead><tbody>${report.items.slice(0,200).map((item) => `<tr><td>${status(item.state)}</td><td class="mono">${esc(item.source_relpath)}</td><td>${esc(item.asset_type)}</td><td>${mono(item.asset_id)}</td></tr>`).join('')}</tbody></table></div>` : empty('目录中没有可管理文件');
    return `<div class="panel-body"><div class="count-strip">${chips}</div></div>${rows}`;
  }

  async function renderRegistry() {
    el.title.textContent = 'Prompt / Skill Registry';
    el.route.textContent = 'REGISTRY';
    const rows = await api(withQuery('/api/v1/registry', [projectQuery()]));
    const table = rows.length ? `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>Name</th><th>Kind</th><th>Version</th><th>Status</th><th>Revision</th></tr></thead><tbody>${rows.map((row) => `<tr><td>${esc(row.name)}</td><td>${status(row.kind)}</td><td>v${esc(row.revision_number)}</td><td>${status(row.status)}</td><td>${mono(row.revision_id)}</td></tr>`).join('')}</tbody></table></div>` : empty('Registry 为空');
    const options = state.projects.map((p) => `<option value="${esc(p.project_id)}" ${p.project_id === state.project ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
    el.stage.innerHTML = intro('VERSIONED KNOWLEDGE ASSET', 'Prompt / Skill Registry', '提示词和 Skill 不是散落文本，而是有项目归属、有版本、有谱系的正式资产。') +
      `<div class="grid two">${panel('Registry', table, `${rows.length} REVISIONS`, 'flush')}${panel('登记新资产', `<div class="form-grid"><select id="reg-project" class="select">${options}</select><select id="reg-kind" class="select"><option value="prompt">Prompt</option><option value="skill">Skill</option></select><input id="reg-name" class="input span-2" placeholder="名称"><textarea id="reg-content" class="textarea span-2" placeholder="正文"></textarea><button id="reg-add" class="button primary span-2" ${state.projects.length ? '' : 'disabled'}>登记版本 1</button></div>`)}</div>`;
    document.getElementById('reg-add').onclick = async () => {
      const body = {project_id:document.getElementById('reg-project').value,kind:document.getElementById('reg-kind').value,name:document.getElementById('reg-name').value.trim(),content:document.getElementById('reg-content').value};
      if (!body.project_id || !body.name || !body.content) return notify('项目、名称和正文不能为空');
      await post('/api/v1/registry', body); notify('Registry 资产已登记'); renderRegistry();
    };
  }

  async function renderAgents() {
    el.title.textContent = 'Agent / Generator Bridge';
    el.route.textContent = 'AGENTS';
    const [tasks, runs] = await Promise.all([
      api(withQuery('/api/v1/tasks', [projectQuery()])),
      api(withQuery('/api/v1/generator-runs', [projectQuery()])),
    ]);
    const taskRows = tasks.length ? `<div class="task-list">${tasks.map((task) => `<div class="task-row"><span class="activity-code">TASK</span><div class="row-main"><strong>${esc(task.name)}</strong><small class="mono">${esc(task.task_id)}</small></div><div class="row-actions">${status(task.status)}<button class="button task-packet" data-task="${esc(task.task_id)}">Packet</button></div></div>`).join('')}</div>` : empty('没有 Agent 任务');
    const runRows = runs.length ? `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>Adapter</th><th>Model</th><th>Status</th><th>Task</th><th>Run</th></tr></thead><tbody>${runs.map((run) => `<tr><td>${esc(run.adapter_id)}</td><td>${esc(run.model || '—')}</td><td>${status(run.status)}</td><td>${mono(run.task_id)}</td><td>${mono(run.run_id)}</td></tr>`).join('')}</tbody></table></div>` : empty('还没有 Generator Run');
    el.stage.innerHTML = intro('CODEX TASK PACKET / GENERATOR TRACE', 'Agent / Generator Bridge', 'Codex 读取结构化任务包，生成结果回写 Revision，并留下模型、参数和输入输出关系。') + `<div class="grid two">${panel('Agent Tasks', taskRows, `${tasks.length} TASKS`, 'flush')}${panel('Generator Runs', runRows, `${runs.length} RUNS`, 'flush')}</div>`;
    document.querySelectorAll('.task-packet').forEach((button) => button.onclick = () => inspectTask(button.dataset.task));
  }

  async function inspectTask(taskId) {
    const packet = await api(`/api/v1/tasks/${encodeURIComponent(taskId)}/packet`);
    const jsonText = JSON.stringify(packet, null, 2);
    openDrawer(packet.task.name, `<section class="drawer-section"><div class="action-cluster">${status(packet.task.status)}<button id="copy-packet" class="button">复制 Packet</button></div></section><section class="drawer-section"><h3>Task Packet</h3><pre class="mono" style="white-space:pre-wrap">${esc(jsonText)}</pre></section>`);
    document.getElementById('copy-packet').onclick = async () => { await navigator.clipboard.writeText(jsonText); notify('Task Packet 已复制'); };
  }

  async function renderHealth() {
    el.title.textContent = '系统健康';
    el.route.textContent = 'HEALTH';
    const report = await api('/api/v1/health');
    const issues = report.issues?.length ? `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>Severity</th><th>Code</th><th>Message</th><th>Entity</th></tr></thead><tbody>${report.issues.map((issue) => `<tr><td>${status(issue.severity)}</td><td class="mono">${esc(issue.code)}</td><td>${esc(issue.message)}</td><td>${mono(issue.entity_id || issue.path)}</td></tr>`).join('')}</tbody></table></div>` : empty('没有发现完整性问题');
    el.stage.innerHTML = intro('DATABASE / VAULT / REFERENTIAL INTEGRITY', '系统健康', '这里不是“看起来正常”，而是检查 SQLite、Vault 内容哈希和活动版本引用是否真的一致。') + `<div class="health-banner ${report.ok ? '' : 'bad'}"><strong>${report.ok ? '核心完整性检查通过' : '检测到阻断级问题'}</strong><p>${report.ok ? '数据库、Vault 与活动版本引用当前一致。' : '先处理错误，再继续生产或发布。'}</p></div><div class="grid">${panel('Health Issues', issues, `${report.issues.length} ISSUES`, 'flush')}</div>`;
  }

  const renderers = {command:renderCommand, production:renderProduction, assets:renderAssets, review:renderReview, continuity:renderContinuity, intake:renderIntake, registry:renderRegistry, agents:renderAgents, health:renderHealth};

  async function switchView(view) {
    state.view = renderers[view] ? view : 'command';
    document.querySelectorAll('[data-view]').forEach((button) => button.classList.toggle('active', button.dataset.view === state.view));
    closeDrawer();
    el.stage.innerHTML = empty('正在读取本地生产状态…');
    try {
      await renderers[state.view]();
    } catch (error) {
      setOnline(false);
      el.stage.innerHTML = `<div class="error-box"><strong>视图加载失败</strong><br>${esc(error.message)}<br><span class="hint">Studio 只接受本机令牌连接；重新通过启动命令打开即可刷新令牌上下文。</span></div>`;
    }
  }

  el.nav.querySelectorAll('[data-view]').forEach((button) => button.onclick = () => switchView(button.dataset.view));
  el.project.onchange = () => { state.project = el.project.value; state.intakePreview = null; switchView(state.view); };
  el.search.onkeydown = (event) => {
    if (event.key !== 'Enter') return;
    state.assetQuery = el.search.value.trim();
    switchView('assets');
  };
  el.refresh.onclick = () => switchView(state.view);
  el.drawerClose.onclick = closeDrawer;

  (async () => {
    try {
      await loadProjects();
      await switchView('command');
    } catch (error) {
      setOnline(false);
      el.stage.innerHTML = `<div class="error-box">${esc(error.message)}<br><span class="hint">缺少有效本地令牌时，界面不会读取任何生产数据。</span></div>`;
    }
  })();
})();
