from __future__ import annotations

import json
from pathlib import Path

from .assets import get_asset
from .db import transaction
from .errors import NotFoundError, ValidationError
from .events import record_event

MAX_TEXT_BYTES = 2_000_000


def _validate(kind: str, content: str, metadata: dict | None) -> tuple[str, dict]:
    kind = kind.strip().lower()
    if kind not in {"prompt", "skill"}:
        raise ValidationError("registry kind must be prompt or skill", details={"kind": kind})
    if not isinstance(content, str) or not content.strip():
        raise ValidationError("registry content must not be blank")
    if len(content.encode("utf-8")) > MAX_TEXT_BYTES:
        raise ValidationError("registry content is too large")
    metadata = dict(metadata or {})
    try:
        encoded = json.dumps(metadata, ensure_ascii=False, sort_keys=True)
    except (TypeError, ValueError) as exc:
        raise ValidationError("registry metadata must be JSON serializable") from exc
    if len(encoded.encode("utf-8")) > 100_000:
        raise ValidationError("registry metadata is too large")
    return kind, metadata


def _store_content(app, asset_id: str, kind: str, content: str, metadata: dict, summary: str):
    suffix = ".prompt.txt" if kind == "prompt" else ".skill.txt"
    temp = app.paths.runtime_dir / f"registry-{asset_id}-{len(content)}{suffix}"
    temp.write_text(content, encoding="utf-8")
    try:
        revision = app.ingest_revision(asset_id, temp, change_summary=summary)
    finally:
        temp.unlink(missing_ok=True)
    with transaction(app.conn):
        app.conn.execute(
            "INSERT INTO text_revision_contents(revision_id, kind, content, metadata_json) VALUES (?, ?, ?, ?)",
            (revision.revision_id, kind, content, json.dumps(metadata, ensure_ascii=False, sort_keys=True)),
        )
        record_event(app.conn, entity_kind="revision", entity_id=revision.revision_id, action="registry_content_attach", after_summary={"kind": kind})
    return revision


def register_text_asset(app, project_id: str, kind: str, name: str, content: str, *, metadata: dict | None = None) -> dict:
    kind, metadata = _validate(kind, content, metadata)
    asset = app.create_asset(project_id, kind, name, classification=kind, role="registry")
    revision = _store_content(app, asset.asset_id, kind, content, metadata, "initial registry version")
    return {"asset": app.get_asset(asset.asset_id), "revision": revision, "kind": kind, "metadata": metadata}


def new_text_revision(app, asset_id: str, content: str, *, metadata: dict | None = None) -> dict:
    asset = get_asset(app.conn, asset_id)
    kind, metadata = _validate(asset.asset_type, content, metadata)
    revision = _store_content(app, asset_id, kind, content, metadata, "registry version update")
    return {"asset": app.get_asset(asset_id), "revision": revision, "kind": kind, "metadata": metadata}


def get_text_revision(app, revision_id: str) -> dict:
    row = app.conn.execute("SELECT kind, content, metadata_json FROM text_revision_contents WHERE revision_id=?", (revision_id,)).fetchone()
    if row is None:
        raise NotFoundError("text registry revision not found", details={"revision_id": revision_id})
    revision = app.get_revision(revision_id)
    return {"revision": revision, "kind": row["kind"], "content": row["content"], "metadata": json.loads(row["metadata_json"])}


def list_registry(app, project_id: str | None = None) -> list[dict]:
    sql = """
        SELECT a.asset_id,a.project_id,a.asset_type,a.display_name,a.active_revision_id,
               r.revision_id,r.revision_number,r.status,t.kind,t.metadata_json
        FROM assets a
        JOIN revisions r ON r.asset_id=a.asset_id
        JOIN text_revision_contents t ON t.revision_id=r.revision_id
        WHERE a.asset_type IN ('prompt','skill')
    """
    params: list[object] = []
    if project_id is not None:
        sql += " AND a.project_id=?"
        params.append(project_id)
    sql += " ORDER BY a.display_name, r.revision_number DESC"
    rows = app.conn.execute(sql, params).fetchall()
    return [
        {
            "asset_id": row["asset_id"], "project_id": row["project_id"], "kind": row["kind"],
            "name": row["display_name"], "revision_id": row["revision_id"],
            "revision_number": int(row["revision_number"]), "status": row["status"],
            "metadata": json.loads(row["metadata_json"]),
        }
        for row in rows
    ]
