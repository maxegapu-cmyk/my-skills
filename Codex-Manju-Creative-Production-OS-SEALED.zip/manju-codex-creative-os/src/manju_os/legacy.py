from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .errors import IntegrityError, ValidationError
from .vault import sha256_file

if TYPE_CHECKING:
    from .app import ManjuApp

_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".tif", ".tiff"}
_VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v"}
_AUDIO_EXTS = {".wav", ".mp3", ".flac", ".aac", ".m4a", ".ogg"}
_DOC_EXTS = {".pdf", ".txt", ".md", ".doc", ".docx", ".json", ".csv"}


def _infer_type(path: Path, row: dict[str, Any]) -> str:
    classification = str(row.get("classification") or "").lower()
    role = str(row.get("role") or "").lower()
    if "prompt" in classification or "prompt" in role:
        return "prompt"
    if "skill" in classification or "skill" in role:
        return "skill"
    suffix = path.suffix.lower()
    if suffix in _IMAGE_EXTS:
        return "image"
    if suffix in _VIDEO_EXTS:
        return "video"
    if suffix in _AUDIO_EXTS:
        return "audio"
    if suffix in _DOC_EXTS:
        return "document"
    return "other"


def _load_registry(registry_path: Path) -> dict[str, Any]:
    try:
        raw = json.loads(registry_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValidationError("malformed legacy registry", details={"path": str(registry_path)}) from exc
    if not isinstance(raw, dict) or not isinstance(raw.get("assets"), list):
        raise ValidationError("legacy registry must contain an assets array")
    return raw


def plan_legacy_import(
    app: "ManjuApp", registry_path: Path, base_dir: Path | None = None
) -> dict[str, Any]:
    registry_path = Path(registry_path).expanduser().resolve()
    raw = _load_registry(registry_path)
    root = Path(base_dir).expanduser().resolve() if base_dir is not None else registry_path.parent
    project_external = str(raw.get("project_id") or "legacy-import")
    items: list[dict[str, Any]] = []
    hashes: dict[str, int] = {}
    missing = mismatch = ready = 0
    for index, row in enumerate(raw["assets"]):
        if not isinstance(row, dict):
            raise ValidationError("legacy asset row must be an object", details={"index": index})
        rel = row.get("path")
        if not isinstance(rel, str) or not rel.strip():
            raise ValidationError("legacy asset row requires path", details={"index": index})
        candidate = (root / rel).resolve() if not Path(rel).is_absolute() else Path(rel).resolve()
        try:
            candidate.relative_to(root)
        except ValueError as exc:
            raise ValidationError("legacy path escapes import root", details={"path": rel}) from exc
        exists = candidate.is_file() and not candidate.is_symlink()
        expected_hash = str(row.get("sha256") or "").lower()
        actual_hash = None
        hash_match = None
        size = None
        if exists:
            actual_hash, size = sha256_file(candidate)
            hashes[actual_hash] = hashes.get(actual_hash, 0) + 1
            if expected_hash:
                hash_match = actual_hash == expected_hash
            else:
                hash_match = True
        status = "ready"
        if not exists:
            status = "missing"
            missing += 1
        elif hash_match is False:
            status = "hash_mismatch"
            mismatch += 1
        else:
            ready += 1
        items.append(
            {
                "index": index,
                "legacy_external_id": str(row.get("asset_id") or "") or None,
                "legacy_project_id": str(row.get("project_id") or project_external),
                "source_path": str(candidate),
                "source_relpath": rel,
                "exists": exists,
                "expected_sha256": expected_hash or None,
                "actual_sha256": actual_hash,
                "hash_match": hash_match,
                "file_size": size,
                "duplicate_content": bool(actual_hash and hashes.get(actual_hash, 0) > 1),
                "asset_type": _infer_type(candidate, row),
                "display_name": str(row.get("display_name") or row.get("asset_id") or Path(rel).stem),
                "role": row.get("role"),
                "classification": row.get("classification"),
                "priority": int(row.get("priority") or 0),
                "allow": list(row.get("allow") or []),
                "deny": list(row.get("deny") or []),
                "exclusive_group": row.get("exclusive_group"),
                "positive_generation_input": bool(row.get("positive_generation_input", True)),
                "status": status,
            }
        )
    # Recompute duplicate flag after every hash count is known.
    for item in items:
        digest = item["actual_sha256"]
        item["duplicate_content"] = bool(digest and hashes.get(digest, 0) > 1)
    return {
        "dry_run": True,
        "registry_path": str(registry_path),
        "base_dir": str(root),
        "project_external_id": project_external,
        "summary": {"total": len(items), "ready": ready, "missing": missing, "hash_mismatch": mismatch},
        "items": items,
    }


def apply_legacy_import(app: "ManjuApp", plan: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(plan, dict) or plan.get("dry_run") is not True or not isinstance(plan.get("items"), list):
        raise ValidationError("legacy import requires a dry-run plan")
    blocked = [item for item in plan["items"] if item.get("status") != "ready"]
    if blocked:
        raise IntegrityError(
            "legacy import plan contains unresolved files",
            details={"blocked": [{"index": i.get("index"), "status": i.get("status")} for i in blocked]},
        )
    project_name = str(plan.get("project_external_id") or "Legacy Import")
    existing = next((p for p in app.list_projects() if p.name == project_name), None)
    project = existing or app.create_project(project_name)
    imported_ids: list[str] = []
    for item in plan["items"]:
        source = Path(item["source_path"])
        digest, _ = sha256_file(source)
        if item.get("actual_sha256") and digest != item["actual_sha256"]:
            raise IntegrityError("legacy source changed after dry run", details={"path": str(source)})
        legacy_id = item.get("legacy_external_id")
        row = None
        if legacy_id:
            row = app.conn.execute(
                "SELECT asset_id FROM assets WHERE project_id=? AND legacy_external_id=?",
                (project.project_id, legacy_id),
            ).fetchone()
        if row is not None:
            imported_ids.append(row["asset_id"])
            continue
        asset = app.create_asset(
            project.project_id,
            item["asset_type"],
            item["display_name"],
            classification=item.get("classification"),
            role=item.get("role"),
            priority=int(item.get("priority") or 0),
        )
        app.conn.execute("UPDATE assets SET legacy_external_id=? WHERE asset_id=?", (legacy_id, asset.asset_id))
        app.conn.commit()
        app.set_constraints(
            asset.asset_id,
            allow=tuple(item.get("allow") or ()),
            deny=tuple(item.get("deny") or ()),
            exclusive_group=item.get("exclusive_group"),
            positive_generation_input=bool(item.get("positive_generation_input", True)),
        )
        revision = app.ingest_revision(asset.asset_id, source, change_summary="legacy registry import")
        app.conn.execute(
            "INSERT INTO legacy_imports(import_id, project_id, legacy_external_id, asset_id, source_path, source_hash, imported_at) VALUES (?, ?, ?, ?, ?, ?, datetime('now'))",
            (f"imp_{revision.revision_id}", project.project_id, legacy_id, asset.asset_id, item.get("source_relpath"), digest),
        )
        app.conn.commit()
        imported_ids.append(asset.asset_id)
    return {"imported": len(imported_ids), "asset_ids": imported_ids, "project_id": project.project_id}
