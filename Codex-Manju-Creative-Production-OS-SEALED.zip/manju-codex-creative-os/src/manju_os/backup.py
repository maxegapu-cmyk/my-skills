from __future__ import annotations

import json
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

from .config import bootstrap_workspace
from .db import connect
from .errors import ConflictError, IntegrityError, StorageError, ValidationError
from .migrations import migrate
from .models import BackupReport

FORMAT_VERSION = 1


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def _integrity(conn: sqlite3.Connection) -> bool:
    row = conn.execute("PRAGMA integrity_check").fetchone()
    return bool(row and str(row[0]).lower() == "ok")


def create_backup(app, destination: Path | None = None) -> BackupReport:
    destination = Path(destination) if destination is not None else app.paths.backup_dir / f"manju-backup-{_stamp()}.mjbk"
    destination = destination.expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise ConflictError("backup destination already exists", details={"path": str(destination)})
    created_at = _utc_now()
    tmp_db = app.paths.runtime_dir / f"backup-{_stamp()}.sqlite3"
    try:
        if tmp_db.exists():
            tmp_db.unlink()
        target = sqlite3.connect(tmp_db)
        try:
            app.conn.backup(target)
            target.commit()
            if not _integrity(target):
                raise IntegrityError("backup database failed integrity check")
        finally:
            target.close()
        temp_archive = destination.with_name(destination.name + ".tmp")
        with zipfile.ZipFile(temp_archive, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
            zf.writestr(
                "manifest.json",
                json.dumps({"format": "manju-backup", "version": FORMAT_VERSION, "created_at": created_at}, sort_keys=True),
            )
            zf.write(tmp_db, "database/manju.sqlite3")
            vault_root = app.paths.vault_sha256_dir
            if vault_root.exists():
                for path in sorted(p for p in vault_root.rglob("*") if p.is_file()):
                    rel = path.relative_to(app.paths.root).as_posix()
                    zf.write(path, rel)
        temp_archive.replace(destination)
        return BackupReport(path=str(destination), integrity_ok=True, created_at=created_at)
    except (OSError, zipfile.BadZipFile) as exc:
        raise StorageError("failed to create backup", details={"path": str(destination)}) from exc
    finally:
        tmp_db.unlink(missing_ok=True)


def _safe_member(name: str) -> bool:
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts:
        return False
    if name in {"manifest.json", "database/manju.sqlite3"}:
        return True
    return len(path.parts) >= 2 and path.parts[0] == "vault" and path.parts[1] == "sha256"


def restore_backup(backup_file: Path, workspace: Path) -> BackupReport:
    backup_file = Path(backup_file).expanduser().resolve()
    workspace = Path(workspace).expanduser().resolve()
    paths = bootstrap_workspace(workspace)
    if paths.database_file.exists():
        raise ConflictError("restore target database already exists", details={"path": str(paths.database_file)})
    created_at = _utc_now()
    try:
        with tempfile.TemporaryDirectory(prefix="manju-restore-") as tmp:
            temp_root = Path(tmp)
            with zipfile.ZipFile(backup_file, "r") as zf:
                names = zf.namelist()
                if "manifest.json" not in names or "database/manju.sqlite3" not in names:
                    raise IntegrityError("backup archive is missing required entries")
                if any(not _safe_member(name) for name in names):
                    raise IntegrityError("backup archive contains unsafe paths")
                manifest = json.loads(zf.read("manifest.json").decode("utf-8"))
                if manifest.get("format") != "manju-backup" or manifest.get("version") != FORMAT_VERSION:
                    raise ValidationError("unsupported backup format")
                zf.extractall(temp_root)
            source_db = temp_root / "database" / "manju.sqlite3"
            source_conn = sqlite3.connect(source_db)
            try:
                if not _integrity(source_conn):
                    raise IntegrityError("backup database failed integrity check")
            finally:
                source_conn.close()
            # Copy immutable vault first; if database copy fails, metadata never points to partial new blobs.
            source_vault = temp_root / "vault" / "sha256"
            if source_vault.exists():
                for path in sorted(p for p in source_vault.rglob("*") if p.is_file()):
                    rel = path.relative_to(source_vault)
                    target = paths.vault_sha256_dir / rel
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(path, target)
            shutil.copy2(source_db, paths.database_file)
        conn = connect(paths.database_file)
        try:
            migrate(conn)
            ok = _integrity(conn)
        finally:
            conn.close()
        if not ok:
            raise IntegrityError("restored database failed integrity check")
        return BackupReport(path=str(backup_file), integrity_ok=True, created_at=created_at)
    except (zipfile.BadZipFile, OSError, json.JSONDecodeError) as exc:
        raise IntegrityError("invalid or unreadable backup archive", details={"path": str(backup_file)}) from exc
