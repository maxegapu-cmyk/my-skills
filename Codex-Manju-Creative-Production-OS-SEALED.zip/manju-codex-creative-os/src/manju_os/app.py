from __future__ import annotations

import sqlite3
from pathlib import Path

from . import assets, backup, bridge, continuity, generators, legacy, local_intake, projects, provenance, registry, reviews, search as search_service, tasks, vault
from .config import WorkspacePaths, bootstrap_workspace
from .db import connect
from .health import run_health_check
from .migrations import migrate
from .models import Asset, BackupReport, ConstraintContract, ContinuitySnapshot, GeneratorRun, HealthReport, LocalScanReport, ManagedRoot, ProductionUnit, Project, ProvenanceEdge, Review, Revision, SearchHit, Task


class ManjuApp:
    def __init__(self, paths: WorkspacePaths, conn: sqlite3.Connection):
        self.paths = paths
        self.conn = conn

    @classmethod
    def open(cls, workspace: Path) -> "ManjuApp":
        paths = bootstrap_workspace(Path(workspace))
        conn = connect(paths.database_file)
        migrate(conn)
        return cls(paths, conn)

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> "ManjuApp":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def create_project(self, name: str) -> Project:
        return projects.create_project(self.conn, name)

    def list_projects(self) -> list[Project]:
        return projects.list_projects(self.conn)

    def create_production_unit(
        self,
        project_id: str,
        kind: str,
        name: str,
        parent_id: str | None = None,
        sort_order: int = 0,
    ) -> ProductionUnit:
        return projects.create_production_unit(
            self.conn,
            project_id,
            kind,
            name,
            parent_id=parent_id,
            sort_order=sort_order,
        )

    def create_asset(
        self,
        project_id: str,
        asset_type: str,
        display_name: str,
        classification: str | None = None,
        role: str | None = None,
        priority: int = 0,
    ) -> Asset:
        return assets.create_asset(
            self.conn,
            project_id,
            asset_type,
            display_name,
            classification=classification,
            role=role,
            priority=priority,
        )

    def get_asset(self, asset_id: str) -> Asset:
        return assets.get_asset(self.conn, asset_id)

    def ingest_revision(
        self,
        asset_id: str,
        source: Path,
        change_summary: str = "initial ingest",
        source_task_id: str | None = None,
    ) -> Revision:
        return vault.ingest_revision(
            self.conn,
            self.paths,
            asset_id,
            Path(source),
            change_summary=change_summary,
            source_task_id=source_task_id,
        )

    def add_provenance(
        self,
        from_revision_id: str,
        to_revision_id: str,
        edge_type: str,
        role: str | None = None,
        weight: float | None = None,
        notes: str | None = None,
    ) -> ProvenanceEdge:
        return provenance.add_edge(
            self.conn,
            from_revision_id,
            to_revision_id,
            edge_type,
            role=role,
            weight=weight,
            notes=notes,
        )

    def asset_lineage(self, asset_id: str) -> dict[str, object]:
        return provenance.lineage_for_asset(self.conn, asset_id)


    def get_revision(self, revision_id: str) -> Revision:
        return assets.get_revision(self.conn, revision_id)

    def submit_review(self, revision_id: str, outcome: str, *, severity: str = "P3", note: str = "", findings: tuple[str, ...] | list[str] = ()) -> Review:
        return reviews.submit_review(self.conn, revision_id, outcome, severity=severity, note=note, findings=findings)

    def promote_master(self, revision_id: str, *, note: str = "") -> Revision:
        return reviews.promote_master(self.conn, revision_id, note=note)

    def set_asset_lock(self, asset_id: str, locked: bool, *, reason: str = "") -> Asset:
        return reviews.set_asset_lock(self.conn, asset_id, locked, reason=reason)

    def review_queue(self, project_id: str | None = None) -> list[Revision]:
        return reviews.review_queue(self.conn, project_id=project_id)


    def create_task(self, project_id: str, name: str, *, production_unit_id: str | None = None, acceptance: tuple[str, ...] | list[str] = (), locked_fields: tuple[str, ...] | list[str] = ()) -> Task:
        return tasks.create_task(self.conn, project_id, name, production_unit_id=production_unit_id, acceptance=acceptance, locked_fields=locked_fields)

    def get_task(self, task_id: str) -> Task:
        return tasks.get_task(self.conn, task_id)

    def list_tasks(self, project_id: str | None = None, status: str | None = None) -> list[Task]:
        return tasks.list_tasks(self.conn, project_id=project_id, status=status)

    def transition_task(self, task_id: str, to_status: str, *, note: str = "") -> Task:
        return tasks.transition_task(self.conn, task_id, to_status, note=note)

    def link_task_asset(self, task_id: str, asset_id: str, relation: str) -> None:
        return tasks.link_task_asset(self.conn, task_id, asset_id, relation)


    def create_continuity_snapshot(self, project_id: str, production_unit_id: str, state: dict, *, inherited_from: str | None = None, note: str = "") -> ContinuitySnapshot:
        return continuity.create_snapshot(self.conn, project_id, production_unit_id, state, inherited_from=inherited_from, note=note)

    def get_continuity_snapshot(self, snapshot_id: str) -> ContinuitySnapshot:
        return continuity.get_snapshot(self.conn, snapshot_id)

    def diff_continuity(self, a_id: str, b_id: str) -> dict:
        return continuity.diff_snapshots(self.conn, a_id, b_id)


    def set_constraints(self, asset_id: str, **kwargs) -> ConstraintContract:
        return assets.set_constraints(self.conn, asset_id, **kwargs)

    def get_constraints(self, asset_id: str) -> ConstraintContract:
        return assets.get_constraints(self.conn, asset_id)

    def search(self, query: str, *, project_id: str | None = None, asset_type: str | None = None, status: str | None = None, limit: int = 50) -> list[SearchHit]:
        return search_service.search(self.conn, query, project_id=project_id, asset_type=asset_type, status=status, limit=limit)


    def plan_legacy_import(self, registry_path: Path, base_dir: Path | None = None) -> dict:
        return legacy.plan_legacy_import(self, Path(registry_path), base_dir=base_dir)

    def apply_legacy_import(self, plan: dict) -> dict:
        return legacy.apply_legacy_import(self, plan)


    def create_backup(self, destination: Path | None = None) -> BackupReport:
        return backup.create_backup(self, destination=destination)


    def register_text_asset(self, project_id: str, kind: str, name: str, content: str, *, metadata: dict | None = None) -> dict:
        return registry.register_text_asset(self, project_id, kind, name, content, metadata=metadata)

    def new_text_revision(self, asset_id: str, content: str, *, metadata: dict | None = None) -> dict:
        return registry.new_text_revision(self, asset_id, content, metadata=metadata)

    def get_text_revision(self, revision_id: str) -> dict:
        return registry.get_text_revision(self, revision_id)

    def list_registry(self, project_id: str | None = None) -> list[dict]:
        return registry.list_registry(self, project_id=project_id)


    def record_generator_run(self, project_id: str, adapter_id: str, **kwargs) -> GeneratorRun:
        return generators.record_generator_run(self.conn, project_id, adapter_id, **kwargs)

    def get_generator_run(self, run_id: str) -> GeneratorRun:
        return generators.get_generator_run(self.conn, run_id)

    def list_generator_runs(self, project_id: str | None = None) -> list[GeneratorRun]:
        return generators.list_generator_runs(self.conn, project_id=project_id)


    def task_packet(self, task_id: str) -> dict:
        return bridge.task_packet(self, task_id)

    def ingest_task_output(self, task_id: str, asset_id: str, source: Path, **kwargs) -> Revision:
        return bridge.ingest_task_output(self, task_id, asset_id, Path(source), **kwargs)


    def register_managed_root(self, project_id: str, path: Path, *, include=local_intake.DEFAULT_INCLUDE, exclude=local_intake.DEFAULT_EXCLUDE) -> ManagedRoot:
        return local_intake.register_root(self, project_id, Path(path), include=include, exclude=exclude)

    def list_managed_roots(self, project_id: str | None = None) -> list[ManagedRoot]:
        return local_intake.list_roots(self, project_id=project_id)

    def scan_managed_root(self, root_id: str, *, full_hash: bool = False) -> LocalScanReport:
        return local_intake.scan_root(self, root_id, full_hash=full_hash)

    def sync_managed_root(self, root_id: str, *, full_hash: bool = False) -> LocalScanReport:
        return local_intake.sync_root(self, root_id, full_hash=full_hash)

    def list_source_bindings(self, root_id: str):
        return local_intake.list_bindings(self, root_id)

    def health_check(self) -> HealthReport:
        return run_health_check(self.conn, self.paths)
