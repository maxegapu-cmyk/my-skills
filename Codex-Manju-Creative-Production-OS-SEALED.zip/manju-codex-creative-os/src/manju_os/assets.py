from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone

from .db import transaction
from .errors import NotFoundError, ValidationError
from .events import record_event
from .ids import new_id
from .models import Asset, ConstraintContract, Revision
from .projects import get_project

ASSET_TYPES = {
    "character",
    "wardrobe",
    "makeup_hair",
    "location",
    "set",
    "prop",
    "vehicle",
    "creature",
    "vfx",
    "palette",
    "style_rule",
    "image",
    "video",
    "audio",
    "3d",
    "script",
    "storyboard",
    "prompt",
    "skill",
    "continuity",
    "document",
    "other",
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _json(value: list[str] | tuple[str, ...]) -> str:
    return json.dumps(list(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _asset_from_row(row: sqlite3.Row) -> Asset:
    return Asset(
        asset_id=row["asset_id"],
        project_id=row["project_id"],
        asset_type=row["asset_type"],
        display_name=row["display_name"],
        canonical_status=row["canonical_status"],
        classification=row["classification"],
        role=row["role"],
        priority=int(row["priority"]),
        locked=bool(row["locked"]),
        active_revision_id=row["active_revision_id"],
        legacy_external_id=row["legacy_external_id"],
        created_at=row["created_at"],
        updated_at=row["updated_at"],
    )


def create_asset(
    conn: sqlite3.Connection,
    project_id: str,
    asset_type: str,
    display_name: str,
    classification: str | None = None,
    role: str | None = None,
    priority: int = 0,
) -> Asset:
    get_project(conn, project_id)
    asset_type = asset_type.strip().lower()
    display_name = display_name.strip()
    if asset_type not in ASSET_TYPES:
        raise ValidationError("unsupported asset type", details={"asset_type": asset_type})
    if not display_name:
        raise ValidationError("asset display name must not be blank")
    now = _utc_now()
    asset = Asset(
        asset_id=new_id("ast"),
        project_id=project_id,
        asset_type=asset_type,
        display_name=display_name,
        canonical_status="active",
        classification=classification,
        role=role,
        priority=int(priority),
        locked=False,
        active_revision_id=None,
        legacy_external_id=None,
        created_at=now,
        updated_at=now,
    )
    with transaction(conn):
        conn.execute(
            """
            INSERT INTO assets(
              asset_id, project_id, asset_type, display_name, canonical_status,
              classification, role, priority, locked, active_revision_id, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                asset.asset_id,
                asset.project_id,
                asset.asset_type,
                asset.display_name,
                asset.canonical_status,
                asset.classification,
                asset.role,
                asset.priority,
                0,
                None,
                asset.created_at,
                asset.updated_at,
            ),
        )
        conn.execute("INSERT INTO asset_constraints(asset_id) VALUES (?)", (asset.asset_id,))
        record_event(conn, entity_kind="asset", entity_id=asset.asset_id, action="create", after_summary={"project_id": project_id, "asset_type": asset_type, "display_name": display_name})
    return asset


def get_asset(conn: sqlite3.Connection, asset_id: str) -> Asset:
    row = conn.execute("SELECT * FROM assets WHERE asset_id = ?", (asset_id,)).fetchone()
    if row is None:
        raise NotFoundError("asset not found", details={"asset_id": asset_id})
    return _asset_from_row(row)


def set_constraints(
    conn: sqlite3.Connection,
    asset_id: str,
    *,
    allow: list[str] | tuple[str, ...] = (),
    deny: list[str] | tuple[str, ...] = (),
    locked_fields: list[str] | tuple[str, ...] = (),
    assumptions: list[str] | tuple[str, ...] = (),
    tool_limits: list[str] | tuple[str, ...] = (),
    exclusive_group: str | None = None,
    positive_generation_input: bool = True,
) -> ConstraintContract:
    get_asset(conn, asset_id)
    values = (
        _json(allow),
        _json(deny),
        _json(locked_fields),
        _json(assumptions),
        _json(tool_limits),
        exclusive_group,
        int(bool(positive_generation_input)),
        asset_id,
    )
    with transaction(conn):
        conn.execute(
            """
            UPDATE asset_constraints SET
              allow_json=?, deny_json=?, locked_fields_json=?, assumptions_json=?,
              tool_limits_json=?, exclusive_group=?, positive_generation_input=?
            WHERE asset_id=?
            """,
            values,
        )
        record_event(conn, entity_kind="asset", entity_id=asset_id, action="constraints_replace", after_summary={"allow": list(allow), "deny": list(deny), "locked_fields": list(locked_fields), "assumptions": list(assumptions), "tool_limits": list(tool_limits), "exclusive_group": exclusive_group, "positive_generation_input": bool(positive_generation_input)})
    return get_constraints(conn, asset_id)


def get_constraints(conn: sqlite3.Connection, asset_id: str) -> ConstraintContract:
    row = conn.execute(
        "SELECT * FROM asset_constraints WHERE asset_id = ?", (asset_id,)
    ).fetchone()
    if row is None:
        raise NotFoundError("asset constraint contract not found", details={"asset_id": asset_id})
    return ConstraintContract(
        allow=tuple(json.loads(row["allow_json"])),
        deny=tuple(json.loads(row["deny_json"])),
        locked_fields=tuple(json.loads(row["locked_fields_json"])),
        assumptions=tuple(json.loads(row["assumptions_json"])),
        tool_limits=tuple(json.loads(row["tool_limits_json"])),
        exclusive_group=row["exclusive_group"],
        positive_generation_input=bool(row["positive_generation_input"]),
    )


def next_revision_number(conn: sqlite3.Connection, asset_id: str) -> int:
    get_asset(conn, asset_id)
    row = conn.execute(
        "SELECT COALESCE(MAX(revision_number), 0) + 1 FROM revisions WHERE asset_id = ?",
        (asset_id,),
    ).fetchone()
    return int(row[0])


def insert_revision_metadata(
    conn: sqlite3.Connection,
    asset_id: str,
    blob_hash: str,
    original_filename: str,
    media_type: str,
    file_size: int,
    change_summary: str,
    source_task_id: str | None = None,
) -> Revision:
    revision_number = next_revision_number(conn, asset_id)
    now = _utc_now()
    revision_id = new_id("rev")
    conn.execute(
        """
        INSERT INTO revisions(
          revision_id, asset_id, revision_number, blob_hash, original_filename,
          media_type, file_size, status, change_summary, source_task_id, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'candidate', ?, ?, ?)
        """,
        (
            revision_id,
            asset_id,
            revision_number,
            blob_hash,
            original_filename,
            media_type,
            int(file_size),
            change_summary,
            source_task_id,
            now,
        ),
    )
    row = conn.execute(
        """
        SELECT r.*, b.vault_relpath
        FROM revisions r JOIN blobs b ON b.blob_hash = r.blob_hash
        WHERE r.revision_id = ?
        """,
        (revision_id,),
    ).fetchone()
    return _revision_from_row(row)


def get_revision(conn: sqlite3.Connection, revision_id: str) -> Revision:
    row = conn.execute(
        """
        SELECT r.*, b.vault_relpath
        FROM revisions r JOIN blobs b ON b.blob_hash = r.blob_hash
        WHERE r.revision_id = ?
        """,
        (revision_id,),
    ).fetchone()
    if row is None:
        raise NotFoundError("revision not found", details={"revision_id": revision_id})
    return _revision_from_row(row)


def _revision_from_row(row: sqlite3.Row) -> Revision:
    return Revision(
        revision_id=row["revision_id"],
        asset_id=row["asset_id"],
        revision_number=int(row["revision_number"]),
        blob_hash=row["blob_hash"],
        vault_relpath=row["vault_relpath"],
        original_filename=row["original_filename"],
        media_type=row["media_type"],
        file_size=int(row["file_size"]),
        status=row["status"],
        change_summary=row["change_summary"],
        source_task_id=row["source_task_id"],
        created_at=row["created_at"],
    )
