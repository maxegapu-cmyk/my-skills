from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from typing import Any

from .db import transaction
from .errors import ConflictError, NotFoundError, ValidationError
from .events import record_event
from .ids import new_id
from .models import ContinuitySnapshot
from .projects import get_project

MAX_STATE_BYTES = 1_000_000


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _from_row(row: sqlite3.Row) -> ContinuitySnapshot:
    return ContinuitySnapshot(
        snapshot_id=row["snapshot_id"],
        project_id=row["project_id"],
        production_unit_id=row["production_unit_id"],
        inherited_from=row["inherited_from"],
        state=json.loads(row["state_json"]),
        note=row["note"],
        created_at=row["created_at"],
    )


def get_snapshot(conn: sqlite3.Connection, snapshot_id: str) -> ContinuitySnapshot:
    row = conn.execute(
        "SELECT * FROM continuity_snapshots WHERE snapshot_id=?", (snapshot_id,)
    ).fetchone()
    if row is None:
        raise NotFoundError("continuity snapshot not found", details={"snapshot_id": snapshot_id})
    return _from_row(row)


def create_snapshot(
    conn: sqlite3.Connection,
    project_id: str,
    production_unit_id: str,
    state: dict[str, Any],
    *,
    inherited_from: str | None = None,
    note: str = "",
) -> ContinuitySnapshot:
    get_project(conn, project_id)
    unit = conn.execute(
        "SELECT project_id FROM production_units WHERE production_unit_id=?",
        (production_unit_id,),
    ).fetchone()
    if unit is None:
        raise NotFoundError("production unit not found", details={"production_unit_id": production_unit_id})
    if unit["project_id"] != project_id:
        raise ConflictError("continuity unit belongs to another project")
    if not isinstance(state, dict):
        raise ValidationError("continuity state must be an object")
    try:
        state_json = json.dumps(state, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    except (TypeError, ValueError) as exc:
        raise ValidationError("continuity state must be JSON serializable") from exc
    if len(state_json.encode("utf-8")) > MAX_STATE_BYTES or len(note) > 20000:
        raise ValidationError("continuity metadata is too large")
    if inherited_from is not None:
        parent = get_snapshot(conn, inherited_from)
        if parent.project_id != project_id:
            raise ConflictError("inherited continuity snapshot belongs to another project")
    snapshot_id = new_id("cts")
    now = _utc_now()
    with transaction(conn):
        conn.execute(
            """
            INSERT INTO continuity_snapshots(snapshot_id, project_id, production_unit_id,
              inherited_from, state_json, note, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (snapshot_id, project_id, production_unit_id, inherited_from, state_json, note, now),
        )
        record_event(
            conn,
            entity_kind="continuity_snapshot",
            entity_id=snapshot_id,
            action="create",
            after_summary={
                "project_id": project_id,
                "production_unit_id": production_unit_id,
                "inherited_from": inherited_from,
            },
        )
    return get_snapshot(conn, snapshot_id)


def _flatten(value: Any, prefix: str = "") -> dict[str, Any]:
    if not isinstance(value, dict):
        return {prefix: value}
    result: dict[str, Any] = {}
    for key in sorted(value):
        path = f"{prefix}.{key}" if prefix else str(key)
        child = value[key]
        if isinstance(child, dict):
            result.update(_flatten(child, path))
        else:
            result[path] = child
    return result


def diff_snapshots(conn: sqlite3.Connection, a_id: str, b_id: str) -> dict[str, dict[str, Any]]:
    a = get_snapshot(conn, a_id)
    b = get_snapshot(conn, b_id)
    if a.project_id != b.project_id:
        raise ConflictError("cannot diff snapshots from different projects")
    fa = _flatten(a.state)
    fb = _flatten(b.state)
    added = {key: fb[key] for key in fb.keys() - fa.keys()}
    removed = {key: fa[key] for key in fa.keys() - fb.keys()}
    changed = {
        key: {"from": fa[key], "to": fb[key]}
        for key in fa.keys() & fb.keys()
        if fa[key] != fb[key]
    }
    return {
        "added": dict(sorted(added.items())),
        "removed": dict(sorted(removed.items())),
        "changed": dict(sorted(changed.items())),
    }
