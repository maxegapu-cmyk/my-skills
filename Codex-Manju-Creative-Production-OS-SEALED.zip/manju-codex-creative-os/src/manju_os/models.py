from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Project:
    project_id: str
    name: str
    created_at: str
    updated_at: str


@dataclass(frozen=True)
class ProductionUnit:
    production_unit_id: str
    project_id: str
    parent_id: str | None
    kind: str
    name: str
    sort_order: int
    created_at: str

@dataclass(frozen=True)
class Asset:
    asset_id: str
    project_id: str
    asset_type: str
    display_name: str
    canonical_status: str
    classification: str | None
    role: str | None
    priority: int
    locked: bool
    active_revision_id: str | None
    legacy_external_id: str | None
    created_at: str
    updated_at: str


@dataclass(frozen=True)
class ConstraintContract:
    allow: tuple[str, ...]
    deny: tuple[str, ...]
    locked_fields: tuple[str, ...]
    assumptions: tuple[str, ...]
    tool_limits: tuple[str, ...]
    exclusive_group: str | None
    positive_generation_input: bool


@dataclass(frozen=True)
class Revision:
    revision_id: str
    asset_id: str
    revision_number: int
    blob_hash: str
    vault_relpath: str
    original_filename: str
    media_type: str
    file_size: int
    status: str
    change_summary: str
    source_task_id: str | None
    created_at: str

@dataclass(frozen=True)
class ProvenanceEdge:
    edge_id: str
    from_revision_id: str
    to_revision_id: str
    edge_type: str
    role: str | None
    weight: float | None
    notes: str | None
    created_at: str

@dataclass(frozen=True)
class HealthIssue:
    severity: str
    code: str
    message: str
    entity_id: str | None = None
    path: str | None = None


@dataclass(frozen=True)
class HealthReport:
    ok: bool
    issues: tuple[HealthIssue, ...]

@dataclass(frozen=True)
class Review:
    review_id: str
    revision_id: str
    outcome: str
    severity: str
    note: str
    findings: tuple[str, ...]
    created_at: str


@dataclass(frozen=True)
class Task:
    task_id: str
    project_id: str
    production_unit_id: str | None
    name: str
    status: str
    acceptance: tuple[str, ...]
    locked_fields: tuple[str, ...]
    note: str
    created_at: str
    updated_at: str


@dataclass(frozen=True)
class ContinuitySnapshot:
    snapshot_id: str
    project_id: str
    production_unit_id: str
    inherited_from: str | None
    state: dict
    note: str
    created_at: str


@dataclass(frozen=True)
class SearchHit:
    asset_id: str
    revision_id: str | None
    project_id: str
    asset_type: str
    status: str | None
    blob_hash: str | None
    content: str


@dataclass(frozen=True)
class BackupReport:
    path: str
    integrity_ok: bool
    created_at: str

@dataclass(frozen=True)
class GeneratorRun:
    run_id: str
    project_id: str
    task_id: str | None
    adapter_id: str
    model: str | None
    prompt_revision_id: str | None
    input_revision_ids: tuple[str, ...]
    output_revision_ids: tuple[str, ...]
    parameters: dict
    status: str
    created_at: str


@dataclass(frozen=True)
class ManagedRoot:
    root_id: str
    project_id: str
    path: str
    include: tuple[str, ...]
    exclude: tuple[str, ...]
    enabled: bool
    last_scan_at: str | None
    created_at: str
    updated_at: str


@dataclass(frozen=True)
class SourceBinding:
    binding_id: str
    root_id: str
    project_id: str
    source_relpath: str
    source_filename: str
    asset_id: str | None
    revision_id: str | None
    file_hash: str | None
    file_size: int | None
    mtime_ns: int | None
    status: str
    first_seen_at: str
    last_seen_at: str


@dataclass(frozen=True)
class LocalScanItem:
    source_relpath: str
    source_filename: str
    asset_type: str
    state: str
    file_hash: str | None
    file_size: int
    mtime_ns: int
    asset_id: str | None = None
    revision_id: str | None = None
    reason: str | None = None


@dataclass(frozen=True)
class LocalScanReport:
    root_id: str
    project_id: str
    root_path: str
    scanned: int
    new: int
    changed: int
    unchanged: int
    missing: int
    skipped: int
    errors: int
    items: tuple[LocalScanItem, ...]
    scanned_at: str
