from __future__ import annotations

import os
import secrets
from pathlib import Path

from .config import WorkspacePaths

TOKEN_FILENAME = "studio.token"


def token_path(paths: WorkspacePaths) -> Path:
    return paths.runtime_dir / TOKEN_FILENAME


def load_or_create_token(paths: WorkspacePaths) -> str:
    path = token_path(paths)
    if path.exists():
        token = path.read_text(encoding="utf-8").strip()
        if token:
            try:
                os.chmod(path, 0o600)
            except OSError:
                pass
            return token
    token = secrets.token_urlsafe(32)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        os.write(fd, (token + "\n").encode("utf-8"))
    finally:
        os.close(fd)
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return token
