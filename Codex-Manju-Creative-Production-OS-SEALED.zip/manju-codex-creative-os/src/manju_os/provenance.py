from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

from .assets import get_asset, get_revision
from .db import transaction
from .errors import ValidationError
from .events import record_event
from .ids import new_id
from .models import ProvenanceEdge

EDGE_TYPES = {
    "derived_from",
    "reference_of",
    "generated_from",
    "edited_from",
    "upscaled_from",
    "extracted_from",
    "replaced_by",
    "continuity_from",
    "prompt_used",
    "skill_used",
    "generator_used",
    "evidence_for",
    "rejected_against",
    "prompt_source",
    "generation_input",
    "task_output",
}


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def add_edge(
    conn: sqlite3.Connection,
    from_revision_id: str,
    to_revision_id: str,
    edge_type: str,
    role: str | None = None,
    weight: float | None = None,
    notes: str | None = None,
    *,
    actor: str = "local",
    idempotency_key: str | None = None,
) -> ProvenanceEdge:
    edge_type = edge_type.strip().lower()
    if edge_type not in EDGE_TYPES:
        raise ValidationError("unsupported provenance edge type", details={"edge_type": edge_type})
    if from_revision_id == to_revision_id:
        raise ValidationError("provenance edge cannot point to itself")
    get_revision(conn, from_revision_id)
    get_revision(conn, to_revision_id)
    created_at = _utc_now()
    edge = ProvenanceEdge(
        edge_id=new_id("edge"),
        from_revision_id=from_revision_id,
        to_revision_id=to_revision_id,
        edge_type=edge_type,
        role=role,
        weight=weight,
        notes=notes,
        created_at=created_at,
    )
    with transaction(conn):
        conn.execute(
            """
            INSERT INTO provenance_edges(
              edge_id, from_revision_id, to_revision_id, edge_type,
              role, weight, notes, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                edge.edge_id,
                edge.from_revision_id,
                edge.to_revision_id,
                edge.edge_type,
                edge.role,
                edge.weight,
                edge.notes,
                edge.created_at,
            ),
        )
        record_event(
            conn,
            entity_kind="provenance_edge",
            entity_id=edge.edge_id,
            action="create",
            after_summary={
                "from_revision_id": from_revision_id,
                "to_revision_id": to_revision_id,
                "edge_type": edge_type,
            },
            actor=actor,
            idempotency_key=idempotency_key,
        )
    return edge


def lineage_for_asset(conn: sqlite3.Connection, asset_id: str) -> dict[str, object]:
    get_asset(conn, asset_id)
    nodes = conn.execute(
        """
        WITH RECURSIVE connected(revision_id) AS (
          SELECT revision_id FROM revisions WHERE asset_id = ?
          UNION
          SELECT CASE
            WHEN p.from_revision_id = c.revision_id THEN p.to_revision_id
            ELSE p.from_revision_id
          END
          FROM provenance_edges p
          JOIN connected c
            ON p.from_revision_id = c.revision_id OR p.to_revision_id = c.revision_id
        )
        SELECT r.revision_id, r.asset_id, r.revision_number, r.status
        FROM revisions r JOIN connected c ON c.revision_id = r.revision_id
        ORDER BY r.created_at, r.revision_id
        """,
        (asset_id,),
    ).fetchall()
    revision_ids = [row["revision_id"] for row in nodes]
    edges: list[dict[str, object]] = []
    if revision_ids:
        placeholders = ",".join("?" for _ in revision_ids)
        rows = conn.execute(
            f"""
            SELECT edge_id, from_revision_id, to_revision_id, edge_type
            FROM provenance_edges
            WHERE from_revision_id IN ({placeholders})
              AND to_revision_id IN ({placeholders})
            ORDER BY created_at, edge_id
            """,
            (*revision_ids, *revision_ids),
        )
        edges = [dict(row) for row in rows]
    return {
        "asset_id": asset_id,
        "nodes": [dict(row) for row in nodes],
        "edges": edges,
    }
