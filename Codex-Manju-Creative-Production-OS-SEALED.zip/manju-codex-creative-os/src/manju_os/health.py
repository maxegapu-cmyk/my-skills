from __future__ import annotations

import sqlite3
from pathlib import Path

from .config import WorkspacePaths
from .models import HealthIssue, HealthReport
from .vault import sha256_file


def _is_hash_name(name: str) -> bool:
    return len(name) == 64 and all(ch in "0123456789abcdef" for ch in name)


def run_health_check(conn: sqlite3.Connection, paths: WorkspacePaths) -> HealthReport:
    issues: list[HealthIssue] = []

    integrity_rows = [row[0] for row in conn.execute("PRAGMA integrity_check")]
    if integrity_rows != ["ok"]:
        issues.append(
            HealthIssue(
                severity="error",
                code="database_integrity",
                message="SQLite integrity check failed",
            )
        )

    blob_rows = list(
        conn.execute("SELECT blob_hash, vault_relpath, file_size FROM blobs ORDER BY blob_hash")
    )
    registered = {row["blob_hash"] for row in blob_rows}

    for row in blob_rows:
        target = paths.root / row["vault_relpath"]
        if not target.exists() or not target.is_file() or target.is_symlink():
            issues.append(
                HealthIssue(
                    severity="error",
                    code="missing_blob",
                    message="registered blob is missing or not a regular file",
                    entity_id=row["blob_hash"],
                    path=str(target),
                )
            )
            continue
        actual_size = target.stat().st_size
        if actual_size != int(row["file_size"]):
            issues.append(
                HealthIssue(
                    severity="error",
                    code="blob_size_mismatch",
                    message="vault blob size differs from registry",
                    entity_id=row["blob_hash"],
                    path=str(target),
                )
            )
            continue
        actual_hash, _ = sha256_file(target)
        if actual_hash != row["blob_hash"]:
            issues.append(
                HealthIssue(
                    severity="error",
                    code="corrupt_blob",
                    message="vault blob SHA-256 differs from registry",
                    entity_id=row["blob_hash"],
                    path=str(target),
                )
            )

    if paths.vault_sha256_dir.exists():
        for file_path in paths.vault_sha256_dir.rglob("*"):
            if not file_path.is_file() or file_path.is_symlink() or not _is_hash_name(file_path.name):
                continue
            if file_path.name not in registered:
                issues.append(
                    HealthIssue(
                        severity="warning",
                        code="unreferenced_blob",
                        message="vault blob has no registry row",
                        entity_id=file_path.name,
                        path=str(file_path),
                    )
                )

    active_rows = conn.execute(
        """
        SELECT a.asset_id, a.active_revision_id, r.asset_id AS revision_asset_id
        FROM assets a
        LEFT JOIN revisions r ON r.revision_id = a.active_revision_id
        WHERE a.active_revision_id IS NOT NULL
        """
    )
    for row in active_rows:
        if row["revision_asset_id"] != row["asset_id"]:
            issues.append(
                HealthIssue(
                    severity="error",
                    code="invalid_active_revision",
                    message="asset active revision is missing or belongs to another asset",
                    entity_id=row["asset_id"],
                )
            )

    issues.sort(key=lambda i: (i.severity, i.code, i.path or i.entity_id or ""))
    return HealthReport(
        ok=not any(issue.severity == "error" for issue in issues),
        issues=tuple(issues),
    )
