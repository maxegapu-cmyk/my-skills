from __future__ import annotations

from typing import Any


class AppError(Exception):
    code = "internal_error"
    retryable = False

    def __init__(self, message: str, *, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}

    def envelope(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "details": self.details,
            "retryable": self.retryable,
        }


class ValidationError(AppError):
    code = "validation_error"


class NotFoundError(AppError):
    code = "not_found"


class ConflictError(AppError):
    code = "conflict"


class IntegrityError(AppError):
    code = "integrity_error"


class StorageError(AppError):
    code = "storage_error"

class LockedError(AppError):
    code = "locked"


class UnsupportedError(AppError):
    code = "unsupported"


class PermissionError(AppError):
    code = "permission_error"
