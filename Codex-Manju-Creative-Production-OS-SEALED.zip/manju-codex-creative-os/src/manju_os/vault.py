from __future__ import annotations

import hashlib
import mimetypes
import os
import shutil
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .assets import get_asset, insert_revision_metadata
from .config import WorkspacePaths
from .db import transaction
from .errors import StorageError, ValidationError
from .events import record_event
from .models import Revision

CHUNK_SIZE = 1024 * 1024


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(source: Path) -> tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    with source.open("rb") as handle:
        while True:
            chunk = handle.read(CHUNK_SIZE)
            if not chunk:
                break
            digest.update(chunk)
            size += len(chunk)
    return digest.hexdigest(), size


def vault_relpath(blob_hash: str) -> Path:
    if len(blob_hash) != 64 or any(ch not in "0123456789abcdef" for ch in blob_hash):
        raise ValidationError("invalid sha256 hash", details={"blob_hash": blob_hash})
    return Path("vault") / "sha256" / blob_hash[:2] / blob_hash[2:4] / blob_hash


def _copy_blob_atomic(source: Path, final_path: Path) -> None:
    if final_path.exists():
        return
    final_path.parent.mkdir(parents=True, exist_ok=True)
    temp = final_path.with_name(f"{final_path.name}.tmp-{uuid.uuid4().hex}")
    try:
        with source.open("rb") as src, temp.open("xb") as dst:
            shutil.copyfileobj(src, dst, length=CHUNK_SIZE)
            dst.flush()
            os.fsync(dst.fileno())
        os.replace(temp, final_path)
    except Exception as exc:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass
        if isinstance(exc, StorageError):
            raise
        raise StorageError(
            "failed to write blob to vault",
            details={"source": str(source), "target": str(final_path)},
        ) from exc


def ingest_revision(
    conn: sqlite3.Connection,
    paths: WorkspacePaths,
    asset_id: str,
    source: Path,
    change_summary: str = "initial ingest",
    source_task_id: str | None = None,
) -> Revision:
    get_asset(conn, asset_id)
    source = Path(source)
    if source.is_symlink():
        raise ValidationError("symlink sources are not accepted", details={"source": str(source)})
    if not source.is_file():
        raise ValidationError("source must be a readable regular file", details={"source": str(source)})

    blob_hash, size = sha256_file(source)
    relpath = vault_relpath(blob_hash)
    final_path = paths.root / relpath
    _copy_blob_atomic(source, final_path)
    media_type = mimetypes.guess_type(source.name)[0] or "application/octet-stream"

    with transaction(conn):
        conn.execute(
            """
            INSERT OR IGNORE INTO blobs(blob_hash, vault_relpath, file_size, created_at)
            VALUES (?, ?, ?, ?)
            """,
            (blob_hash, relpath.as_posix(), size, _utc_now()),
        )
        row = conn.execute(
            "SELECT file_size, vault_relpath FROM blobs WHERE blob_hash = ?", (blob_hash,)
        ).fetchone()
        if row is None or int(row["file_size"]) != size:
            raise StorageError("blob registry conflicts with content hash", details={"blob_hash": blob_hash})
        revision = insert_revision_metadata(
            conn,
            asset_id,
            blob_hash,
            source.name,
            media_type,
            size,
            change_summary,
            source_task_id,
        )
        record_event(conn, entity_kind="revision", entity_id=revision.revision_id, action="ingest", after_summary={"asset_id": asset_id, "revision_number": revision.revision_number, "blob_hash": blob_hash, "source_filename": source.name})
    return revision
