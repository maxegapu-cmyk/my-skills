from __future__ import annotations

import json
import sqlite3

from .models import SearchHit


def _is_fts(conn: sqlite3.Connection) -> bool:
    row = conn.execute("SELECT sql FROM sqlite_master WHERE name='asset_search'").fetchone()
    return bool(row and row[0] and "VIRTUAL TABLE" in row[0].upper())


def _content_for_asset(conn: sqlite3.Connection, asset_id: str) -> tuple[str, list[sqlite3.Row]]:
    asset = conn.execute("SELECT * FROM assets WHERE asset_id=?", (asset_id,)).fetchone()
    if asset is None:
        return "", []
    constraints = conn.execute("SELECT * FROM asset_constraints WHERE asset_id=?", (asset_id,)).fetchone()
    base_parts = [
        asset["asset_id"], asset["display_name"], asset["asset_type"], asset["classification"] or "", asset["role"] or "", asset["legacy_external_id"] or ""
    ]
    if constraints:
        for key in ("allow_json", "deny_json", "locked_fields_json", "assumptions_json", "tool_limits_json"):
            base_parts.append(constraints[key] or "")
        base_parts.extend([constraints["exclusive_group"] or "", str(constraints["positive_generation_input"])])
    revisions = conn.execute(
        "SELECT * FROM revisions WHERE asset_id=? ORDER BY revision_number", (asset_id,)
    ).fetchall()
    return " ".join(str(x) for x in base_parts if x), revisions


def reindex_asset(conn: sqlite3.Connection, asset_id: str) -> None:
    base, revisions = _content_for_asset(conn, asset_id)
    conn.execute("DELETE FROM asset_search WHERE asset_id=?", (asset_id,))
    asset = conn.execute("SELECT project_id, asset_type FROM assets WHERE asset_id=?", (asset_id,)).fetchone()
    if asset is None:
        return
    if not revisions:
        conn.execute(
            "INSERT INTO asset_search(asset_id,revision_id,project_id,asset_type,status,blob_hash,content) VALUES (?,?,?,?,?,?,?)",
            (asset_id, None, asset["project_id"], asset["asset_type"], None, None, base),
        )
        return
    for rev in revisions:
        reviews = conn.execute(
            "SELECT outcome,severity,note,findings_json FROM reviews WHERE revision_id=? ORDER BY created_at",
            (rev["revision_id"],),
        ).fetchall()
        review_text = " ".join(
            " ".join([r["outcome"], r["severity"], r["note"], r["findings_json"]]) for r in reviews
        )
        text_row = conn.execute("SELECT content, metadata_json FROM text_revision_contents WHERE revision_id=?", (rev["revision_id"],)).fetchone()
        registry_text = "" if text_row is None else f"{text_row['content']} {text_row['metadata_json']}"
        content = " ".join(
            [base, rev["revision_id"], rev["original_filename"], rev["media_type"], rev["status"], rev["change_summary"], rev["blob_hash"], review_text, registry_text]
        )
        conn.execute(
            "INSERT INTO asset_search(asset_id,revision_id,project_id,asset_type,status,blob_hash,content) VALUES (?,?,?,?,?,?,?)",
            (asset_id, rev["revision_id"], asset["project_id"], asset["asset_type"], rev["status"], rev["blob_hash"], content),
        )


def reindex_all(conn: sqlite3.Connection) -> None:
    for row in conn.execute("SELECT asset_id FROM assets ORDER BY asset_id"):
        reindex_asset(conn, row["asset_id"])
    conn.commit()


def _normalize_fts(query: str) -> str:
    tokens = [t for t in query.replace('"', ' ').split() if t]
    return " AND ".join(f'"{t}"' for t in tokens)


def search(
    conn: sqlite3.Connection,
    query: str,
    *,
    project_id: str | None = None,
    asset_type: str | None = None,
    status: str | None = None,
    limit: int = 50,
) -> list[SearchHit]:
    query = query.strip()
    if not query:
        return []
    reindex_all(conn)
    clauses: list[str] = []
    params: list[object] = []
    if _is_fts(conn):
        clauses.append("asset_search MATCH ?")
        params.append(_normalize_fts(query))
    else:
        clauses.append("content LIKE ?")
        params.append(f"%{query}%")
    if project_id is not None:
        clauses.append("project_id=?")
        params.append(project_id)
    if asset_type is not None:
        clauses.append("asset_type=?")
        params.append(asset_type)
    if status is not None:
        clauses.append("status=?")
        params.append(status)
    limit = max(1, min(int(limit), 500))
    sql = "SELECT asset_id,revision_id,project_id,asset_type,status,blob_hash,content FROM asset_search WHERE " + " AND ".join(clauses) + " LIMIT ?"
    params.append(limit)
    rows = conn.execute(sql, params).fetchall()
    return [
        SearchHit(
            asset_id=row["asset_id"],
            revision_id=row["revision_id"],
            project_id=row["project_id"],
            asset_type=row["asset_type"],
            status=row["status"],
            blob_hash=row["blob_hash"],
            content=row["content"],
        )
        for row in rows
    ]
