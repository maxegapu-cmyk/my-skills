from __future__ import annotations

import hashlib
import json
import threading
from dataclasses import asdict, is_dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from .app import ManjuApp
from .config import bootstrap_workspace
from .errors import AppError, ConflictError, PermissionError as AppPermissionError, ValidationError
from .studio_auth import load_or_create_token

LOOPBACK_HOSTS = {"127.0.0.1", "localhost", "::1"}
MAX_JSON_BODY = 1024 * 1024
MAX_SEARCH_LIMIT = 500
SECURITY_CSP = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"


def _jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return {k: _jsonable(v) for k, v in asdict(value).items()}
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    return value


class StudioHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, handler, *, workspace: Path, token: str):
        self.workspace = Path(workspace)
        self.token = token
        self.idempotency_lock = threading.Lock()
        super().__init__(address, handler)


class StudioHandler(BaseHTTPRequestHandler):
    server: StudioHTTPServer

    def log_message(self, format: str, *args) -> None:
        return

    def _send_security_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("Content-Security-Policy", SECURITY_CSP)

    def _bounded_query_int(self, query: dict[str, str], key: str, default: int, *, minimum: int = 1, maximum: int = MAX_SEARCH_LIMIT) -> int:
        raw = query.get(key)
        if raw is None or raw == "":
            return default
        try:
            value = int(raw)
        except ValueError as exc:
            raise ValidationError(f"query parameter {key} must be an integer") from exc
        if value < minimum or value > maximum:
            raise ValidationError(
                f"query parameter {key} must be between {minimum} and {maximum}",
                details={"parameter": key, "value": value},
            )
        return value

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(_jsonable(payload), ensure_ascii=False, sort_keys=True).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self._send_security_headers()
        self.end_headers()
        self.wfile.write(body)

    def _send_error(self, exc: AppError, status: int = 400) -> None:
        if exc.code == "permission_error":
            status = 401
        elif exc.code == "not_found":
            status = 404
        elif exc.code in {"conflict", "locked"}:
            status = 409
        self._send_json(status, {"ok": False, "error": exc.envelope()})

    def _authorized(self) -> bool:
        header = self.headers.get("Authorization", "")
        return header == f"Bearer {self.server.token}"

    def _require_auth(self) -> None:
        if not self._authorized():
            raise AppPermissionError("valid bearer token required")

    def _read_json(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValidationError("invalid content length") from exc
        if length < 0 or length > MAX_JSON_BODY:
            raise ValidationError("request body is too large")
        raw = self.rfile.read(length) if length else b"{}"
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValidationError("request body must be valid JSON") from exc
        if not isinstance(data, dict):
            raise ValidationError("request JSON must be an object")
        return data

    def _idempotent_post(self, route: str, action, *, request_hash: str) -> tuple[int, dict]:
        key = self.headers.get("Idempotency-Key")
        if not key:
            data = action()
            return 200, {"ok": True, "data": _jsonable(data)}
        if len(key) > 200:
            raise ValidationError("idempotency key is too long")
        with self.server.idempotency_lock:
            with ManjuApp.open(self.server.workspace) as app:
                row = app.conn.execute(
                    "SELECT route,request_hash,response_json,status_code FROM api_idempotency WHERE idempotency_key=?",
                    (key,),
                ).fetchone()
                if row is not None:
                    if row["route"] != route:
                        raise ConflictError("idempotency key was already used for another route")
                    if row["request_hash"] and row["request_hash"] != request_hash:
                        raise ConflictError("idempotency key was already used with a different request body")
                    return int(row["status_code"]), json.loads(row["response_json"])
            data = action()
            payload = {"ok": True, "data": _jsonable(data)}
            encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True)
            with ManjuApp.open(self.server.workspace) as app:
                app.conn.execute(
                    "INSERT INTO api_idempotency(idempotency_key,route,request_hash,response_json,status_code,created_at) VALUES (?,?,?,?,?,datetime('now'))",
                    (key, route, request_hash, encoded, 200),
                )
                app.conn.commit()
            return 200, payload

    def _query(self, parsed) -> dict[str, str]:
        raw = parse_qs(parsed.query, keep_blank_values=True)
        return {key: values[-1] for key, values in raw.items() if values}

    def _project_tree(self, app: ManjuApp, project_id: str) -> list[dict]:
        rows = [dict(row) for row in app.conn.execute(
            "SELECT * FROM production_units WHERE project_id=? ORDER BY sort_order,created_at,production_unit_id",
            (project_id,),
        )]
        by_parent: dict[str | None, list[dict]] = {}
        for row in rows:
            by_parent.setdefault(row["parent_id"], []).append(row)
        def build(parent_id):
            result = []
            for row in by_parent.get(parent_id, []):
                item = dict(row)
                item["children"] = build(row["production_unit_id"])
                result.append(item)
            return result
        return build(None)

    def _dashboard(self, app: ManjuApp) -> dict:
        projects = app.conn.execute("SELECT COUNT(*) FROM projects").fetchone()[0]
        blocked = app.conn.execute("SELECT COUNT(*) FROM tasks WHERE status='blocked'").fetchone()[0]
        pending = len(app.review_queue())
        masters = app.conn.execute("SELECT COUNT(*) FROM revisions WHERE status='master'").fetchone()[0]
        events = [dict(row) for row in app.conn.execute(
            "SELECT entity_kind,entity_id,action,created_at FROM events ORDER BY created_at DESC,event_id DESC LIMIT 12"
        ).fetchall()]
        health = app.health_check()
        return {
            "projects": int(projects), "blocked_tasks": int(blocked), "pending_reviews": int(pending),
            "active_masters": int(masters), "health_ok": health.ok, "recent_activity": events,
        }

    def _asset_detail(self, app: ManjuApp, asset_id: str) -> dict:
        asset = app.get_asset(asset_id)
        revisions = [dict(row) for row in app.conn.execute(
            """SELECT r.*,b.vault_relpath FROM revisions r JOIN blobs b ON b.blob_hash=r.blob_hash
               WHERE r.asset_id=? ORDER BY r.revision_number DESC""", (asset_id,)
        ).fetchall()]
        reviews = [dict(row) for row in app.conn.execute(
            """SELECT rv.* FROM reviews rv JOIN revisions r ON r.revision_id=rv.revision_id
               WHERE r.asset_id=? ORDER BY rv.created_at DESC""", (asset_id,)
        ).fetchall()]
        for row in reviews:
            row["findings"] = json.loads(row.pop("findings_json"))
        usage = [dict(row) for row in app.conn.execute(
            "SELECT task_id,relation FROM task_assets WHERE asset_id=? ORDER BY task_id,relation", (asset_id,)
        ).fetchall()]
        return {
            "asset": _jsonable(asset), "constraints": _jsonable(app.get_constraints(asset_id)),
            "revisions": revisions, "lineage": app.asset_lineage(asset_id), "reviews": reviews, "usage": usage,
        }


    def _serve_static(self, name: str, content_type: str) -> None:
        base = Path(__file__).resolve().parent / "studio"
        allowed = {"index.html", "app.css", "app.js"}
        if name not in allowed:
            self._send_json(404, {"ok": False, "error": {"code": "not_found", "message": "static asset not found", "details": {}, "retryable": False}})
            return
        body = (base / name).read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self._send_security_headers()
        self.end_headers()
        self.wfile.write(body)

    def _serve_media(self, blob_hash: str) -> None:
        self._require_auth()
        if len(blob_hash) != 64 or any(ch not in "0123456789abcdef" for ch in blob_hash):
            raise ValidationError("invalid media hash")
        with ManjuApp.open(self.server.workspace) as app:
            row = app.conn.execute(
                """SELECT b.vault_relpath,b.file_size,
                          COALESCE((SELECT r.media_type FROM revisions r WHERE r.blob_hash=b.blob_hash ORDER BY r.created_at LIMIT 1),'application/octet-stream') AS media_type,
                          COALESCE((SELECT r.original_filename FROM revisions r WHERE r.blob_hash=b.blob_hash ORDER BY r.created_at LIMIT 1),b.blob_hash) AS filename
                   FROM blobs b WHERE b.blob_hash=?""",
                (blob_hash,),
            ).fetchone()
            if row is None:
                from .errors import NotFoundError
                raise NotFoundError("media blob not found", details={"blob_hash": blob_hash})
            target = (app.paths.root / row["vault_relpath"]).resolve()
            vault_root = app.paths.vault_sha256_dir.resolve()
            try:
                target.relative_to(vault_root)
            except ValueError as exc:
                raise ValidationError("media path escaped vault") from exc
            if target.is_symlink() or not target.is_file():
                from .errors import IntegrityError
                raise IntegrityError("registered media blob is unavailable", details={"blob_hash": blob_hash})
            size = int(row["file_size"])
            if target.stat().st_size != size:
                from .errors import IntegrityError
                raise IntegrityError("registered media size mismatch", details={"blob_hash": blob_hash})
            media_type = str(row["media_type"] or "application/octet-stream").lower()
            safe_inline = (
                media_type.startswith("video/") or media_type.startswith("audio/") or
                (media_type.startswith("image/") and media_type != "image/svg+xml") or
                media_type in {"application/pdf", "text/plain"}
            )
            content_type = media_type if safe_inline else "application/octet-stream"
            range_header = self.headers.get("Range")
            start, end, status = 0, size - 1, 200
            if range_header:
                try:
                    if not range_header.startswith("bytes=") or "," in range_header:
                        raise ValueError
                    spec = range_header[6:].strip()
                    left, right = spec.split("-", 1)
                    if left == "":
                        suffix = int(right)
                        if suffix <= 0:
                            raise ValueError
                        start = max(0, size - suffix)
                        end = size - 1
                    else:
                        start = int(left)
                        end = size - 1 if right == "" else int(right)
                    if start < 0 or end < start or start >= size:
                        raise ValueError
                    end = min(end, size - 1)
                    status = 206
                except (ValueError, TypeError):
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{size}")
                    self.send_header("Content-Length", "0")
                    self._send_security_headers()
                    self.end_headers()
                    return
            length = max(0, end - start + 1)
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(length))
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Cache-Control", "private, max-age=60")
            self._send_security_headers()
            if status == 206:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            if not safe_inline:
                filename = str(row["filename"]).replace('"', "")
                self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
            self.end_headers()
            with target.open("rb") as fh:
                fh.seek(start)
                remaining = length
                while remaining > 0:
                    chunk = fh.read(min(1024 * 1024, remaining))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    remaining -= len(chunk)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/":
                self._serve_static("index.html", "text/html; charset=utf-8")
                return
            if parsed.path == "/static/app.css":
                self._serve_static("app.css", "text/css; charset=utf-8")
                return
            if parsed.path == "/static/app.js":
                self._serve_static("app.js", "text/javascript; charset=utf-8")
                return
            if parsed.path.startswith("/api/v1/media/"):
                self._serve_media(parsed.path[len("/api/v1/media/"):])
                return
            if not parsed.path.startswith("/api/v1/"):
                self._send_json(404, {"ok": False, "error": {"code": "not_found", "message": "route not found", "details": {}, "retryable": False}})
                return
            self._require_auth()
            q = self._query(parsed)
            with ManjuApp.open(self.server.workspace) as app:
                path = parsed.path
                if path == "/api/v1/dashboard":
                    data = self._dashboard(app)
                elif path == "/api/v1/projects":
                    data = app.list_projects()
                elif path.startswith("/api/v1/projects/") and path.endswith("/tree"):
                    project_id = path[len("/api/v1/projects/"):-len("/tree")]
                    # validate project through domain read
                    if not any(p.project_id == project_id for p in app.list_projects()):
                        from .errors import NotFoundError
                        raise NotFoundError("project not found", details={"project_id": project_id})
                    data = self._project_tree(app, project_id)
                elif path == "/api/v1/assets":
                    if q.get("q"):
                        data = app.search(q["q"], project_id=q.get("project"), asset_type=q.get("type"), status=q.get("status"), limit=self._bounded_query_int(q, "limit", 100))
                    else:
                        sql = "SELECT * FROM assets WHERE 1=1"
                        params = []
                        if q.get("project"):
                            sql += " AND project_id=?"; params.append(q["project"])
                        if q.get("type"):
                            sql += " AND asset_type=?"; params.append(q["type"])
                        sql += " ORDER BY updated_at DESC,asset_id DESC LIMIT 500"
                        data = [dict(row) for row in app.conn.execute(sql, params).fetchall()]
                elif path.startswith("/api/v1/assets/") and path.endswith("/lineage"):
                    asset_id = path[len("/api/v1/assets/"):-len("/lineage")]
                    data = app.asset_lineage(asset_id)
                elif path.startswith("/api/v1/assets/"):
                    asset_id = path[len("/api/v1/assets/"):]
                    data = self._asset_detail(app, asset_id)
                elif path == "/api/v1/reviews/queue":
                    data = app.review_queue(project_id=q.get("project"))
                elif path == "/api/v1/continuity":
                    sql = "SELECT snapshot_id FROM continuity_snapshots WHERE 1=1"
                    params = []
                    if q.get("project"):
                        sql += " AND project_id=?"; params.append(q["project"])
                    if q.get("unit"):
                        sql += " AND production_unit_id=?"; params.append(q["unit"])
                    sql += " ORDER BY created_at DESC,snapshot_id DESC LIMIT 500"
                    data = [app.get_continuity_snapshot(row["snapshot_id"]) for row in app.conn.execute(sql, params).fetchall()]
                elif path == "/api/v1/continuity/diff":
                    data = app.diff_continuity(q.get("a", ""), q.get("b", ""))
                elif path == "/api/v1/search":
                    data = app.search(q.get("q", ""), project_id=q.get("project"), asset_type=q.get("type"), status=q.get("status"), limit=self._bounded_query_int(q, "limit", 50))
                elif path == "/api/v1/registry":
                    data = app.list_registry(project_id=q.get("project"))
                elif path == "/api/v1/generator-runs":
                    data = app.list_generator_runs(project_id=q.get("project"))
                elif path == "/api/v1/tasks":
                    data = app.list_tasks(project_id=q.get("project"), status=q.get("status"))
                elif path == "/api/v1/local/roots":
                    data = app.list_managed_roots(project_id=q.get("project"))
                elif path.startswith("/api/v1/local/roots/") and path.endswith("/scan"):
                    root_id = path[len("/api/v1/local/roots/"):-len("/scan")]
                    data = app.scan_managed_root(root_id, full_hash=q.get("full_hash", "").lower() in {"1", "true", "yes"})
                elif path.startswith("/api/v1/tasks/") and path.endswith("/packet"):
                    task_id = path[len("/api/v1/tasks/"):-len("/packet")]
                    data = app.task_packet(task_id)
                elif path == "/api/v1/health":
                    data = app.health_check()
                else:
                    self._send_json(404, {"ok": False, "error": {"code": "not_found", "message": "route not found", "details": {}, "retryable": False}})
                    return
            self._send_json(200, {"ok": True, "data": _jsonable(data)})
        except AppError as exc:
            self._send_error(exc)
        except Exception:
            self._send_json(500, {"ok": False, "error": {"code": "internal_error", "message": "unexpected internal error", "details": {}, "retryable": False}})

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        try:
            self._require_auth()
            body = self._read_json()
            route = f"POST {parsed.path}"
            path = parsed.path
            request_hash = hashlib.sha256(
                json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
            ).hexdigest()
            action = None
            if path == "/api/v1/projects":
                def action():
                    with ManjuApp.open(self.server.workspace) as app:
                        return app.create_project(str(body.get("name", "")))
            elif path == "/api/v1/assets":
                def action():
                    with ManjuApp.open(self.server.workspace) as app:
                        return app.create_asset(str(body.get("project_id", "")), str(body.get("asset_type", "")), str(body.get("display_name", "")), classification=body.get("classification"), role=body.get("role"), priority=int(body.get("priority", 0)))
            elif path.startswith("/api/v1/assets/") and path.endswith("/lock"):
                asset_id = path[len("/api/v1/assets/"):-len("/lock")]
                def action():
                    with ManjuApp.open(self.server.workspace) as app:
                        return app.set_asset_lock(asset_id, bool(body.get("locked", True)), reason=str(body.get("reason", "")))
            elif path.startswith("/api/v1/reviews/") and path.endswith("/submit"):
                revision_id = path[len("/api/v1/reviews/"):-len("/submit")]
                def action():
                    with ManjuApp.open(self.server.workspace) as app:
                        return app.submit_review(revision_id, str(body.get("outcome", "")), severity=str(body.get("severity", "P3")), note=str(body.get("note", "")), findings=body.get("findings") or [])
            elif path.startswith("/api/v1/revisions/") and path.endswith("/promote"):
                revision_id = path[len("/api/v1/revisions/"):-len("/promote")]
                def action():
                    with ManjuApp.open(self.server.workspace) as app:
                        return app.promote_master(revision_id, note=str(body.get("note", "")))
            elif path == "/api/v1/tasks":
                def action():
                    with ManjuApp.open(self.server.workspace) as app:
                        return app.create_task(str(body.get("project_id", "")), str(body.get("name", "")), production_unit_id=body.get("production_unit_id"), acceptance=body.get("acceptance") or [], locked_fields=body.get("locked_fields") or [])
            elif path == "/api/v1/continuity":
                def action():
                    with ManjuApp.open(self.server.workspace) as app:
                        return app.create_continuity_snapshot(str(body.get("project_id", "")), str(body.get("production_unit_id", "")), body.get("state") or {}, inherited_from=body.get("inherited_from"), note=str(body.get("note", "")))
            elif path == "/api/v1/registry":
                def action():
                    with ManjuApp.open(self.server.workspace) as app:
                        return app.register_text_asset(str(body.get("project_id", "")), str(body.get("kind", "")), str(body.get("name", "")), str(body.get("content", "")), metadata=body.get("metadata") or {})
            elif path == "/api/v1/generator-runs":
                def action():
                    with ManjuApp.open(self.server.workspace) as app:
                        return app.record_generator_run(str(body.get("project_id", "")), str(body.get("adapter_id", "")), model=body.get("model"), task_id=body.get("task_id"), prompt_revision_id=body.get("prompt_revision_id"), input_revision_ids=body.get("input_revision_ids") or [], output_revision_ids=body.get("output_revision_ids") or [], parameters=body.get("parameters") or {}, status=str(body.get("status", "succeeded")))
            elif path == "/api/v1/local/roots":
                def action():
                    with ManjuApp.open(self.server.workspace) as app:
                        return app.register_managed_root(str(body.get("project_id", "")), Path(str(body.get("path", ""))))
            elif path.startswith("/api/v1/local/roots/") and path.endswith("/sync"):
                root_id = path[len("/api/v1/local/roots/"):-len("/sync")]
                def action():
                    with ManjuApp.open(self.server.workspace) as app:
                        return app.sync_managed_root(root_id, full_hash=bool(body.get("full_hash", False)))
            if action is None:
                self._send_json(404, {"ok": False, "error": {"code": "not_found", "message": "route not found", "details": {}, "retryable": False}})
                return
            status, payload = self._idempotent_post(route, action, request_hash=request_hash)
            self._send_json(status, payload)
        except AppError as exc:
            self._send_error(exc)
        except Exception:
            self._send_json(500, {"ok": False, "error": {"code": "internal_error", "message": "unexpected internal error", "details": {}, "retryable": False}})


def create_server(workspace: Path, *, host: str = "127.0.0.1", port: int = 5177) -> StudioHTTPServer:
    if host not in LOOPBACK_HOSTS:
        raise AppPermissionError("studio server may bind only to loopback", details={"host": host})
    paths = bootstrap_workspace(Path(workspace))
    token = load_or_create_token(paths)
    return StudioHTTPServer((host, int(port)), StudioHandler, workspace=paths.root, token=token)
