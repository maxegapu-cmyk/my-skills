# MJ Aesthetic Lab v2.0.0

A full Midjourney visual-development Skill built from the original MJ Casting Lab.

## What changed from v1
v1 was primarily a casting / face-selection laboratory.
v2 keeps that engine but expands it into a general aesthetic director for portraits, cinematic frames, products, architecture, concept art, illustration, anime and style-system development.

## Core loop
**Diagnose → Isolate → Search/Test → Select → Minimal Repair → Freeze → Expand**

## Why it is stronger
- updated from V8.1 baseline to current V8.2 baseline;
- adds aesthetic diagnosis and scorecard;
- adds composition, camera, light, color and material systems;
- adds Style Reference / Style Creator / Moodboard / Personalization routing;
- adds controlled A/B experiment methodology;
- adds image critique + local repair logic;
- preserves the original casting engine instead of replacing it;
- avoids giant-prompt rule stacking by loading only task-relevant references.

## Install
Install the whole `mj-aesthetic-lab-v2.0.0` directory as one Skill. Main entry: `SKILL.md`.

Run:
```bash
python scripts/selftest.py
python scripts/release_check.py
```
