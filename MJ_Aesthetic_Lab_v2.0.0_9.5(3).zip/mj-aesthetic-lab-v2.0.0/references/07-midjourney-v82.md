# Midjourney Platform Adapter — verified 2026-08-10

This file contains volatile platform facts. Re-check official docs after major Midjourney updates.

## Current version
- Current default: **V8.2**.
- V8.2 became default on 2026-07-24.
- Official description: update focused on aesthetics, image quality and Personalization.
- V8.1 remains relevant as the previous fast/prompt-adherent V8 generation.

## V8.x compatibility highlights
- Style Reference / codes: supported.
- Personalization and Moodboards: supported.
- Image Prompts and image weight: supported.
- Seed: supported; official docs describe V8.X seeds as ~99% identical.
- Raw, Stylize, Chaos, Weird: supported.
- HD 2048 images: supported for V8.1/V8.2 family per version chart.
- Multi-Prompting (`::`): **not supported in V7 or V8.x**; treat it as a V6-era route.
- Character Reference: V6 route, not V7/V8.x.
- Omni Reference: **V7-only** and forces V7.
- V8.x does not use `--quality` according to the current compatibility chart.

## Parameter meaning
### `--raw`
Reduces Midjourney's automatic styling and increases direct prompt/style control.

### `--stylize` / `--s`
Creative interpretation dial. Current docs describe 0–1000, default 100 for latest versions.
Low is more literal; high is more interpretive.

### `--chaos` / `--c`
Variety across results. 0–100; higher values can reduce prompt adherence.

### `--weird` / `--w`
Experimental/unusual aesthetic pressure. Treat it as exploration, not quality.

### `--sref`
Carries style/look rather than identity. Keep text prompts simple and content-focused.

### `--sw`
Style Reference influence, documented 0–1000, default 100. Not compatible with Moodboards.

### `--p`
Applies a Personalization profile or Moodboard code.
A Global V7 profile can work in V8.1/V8.2; V8 profiles are version-family specific.

### `--seed`
Use for controlled tests. Do not promise exact determinism.

### `--iw`
Controls Image Prompt influence. Official image-prompt docs list V8.1 range 0–3, default 1; re-check for future V8.x changes.

### `--no`
Use concrete exclusions. Remember the system reads listed words independently; avoid ambiguous phrases.

## Style Creator
- builds custom `--sref` codes by selecting preferred style samples;
- use simple probe prompts for clearer style inspection;
- official docs say most styles stabilize around 5–10 rounds, with finer changes around 10–15.

## Editor
Use for targeted modification. It combines Remix, inpainting/Vary Region, Pan and Zoom Out.
Current editor operations may use older underlying models for some operations; do not assume local edits preserve every V8.2 property perfectly.

## Sources
See `SOURCES.md` for official URLs and verification notes.
