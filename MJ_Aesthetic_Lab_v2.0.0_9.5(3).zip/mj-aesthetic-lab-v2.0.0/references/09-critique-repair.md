# Critique & Repair

## Verdict first
State: usable / repairable / restart.
Then name the highest-impact failure.

## Visual-impact order
1. wrong subject/event;
2. wrong composition/hierarchy;
3. wrong identity/shape;
4. wrong camera/perspective;
5. wrong light;
6. wrong color;
7. wrong material/style;
8. microdetail.

Do not spend a generation fixing skin pores if the composition is broken.

## Local repair vs rerun
Use local Editor/Vary Region when:
- one object is wrong;
- a hand/detail/text element is wrong;
- a small region conflicts with the rest;
- background detail needs contained change.

Rerun/recompose when:
- camera perspective is wrong;
- main silhouette is wrong;
- hierarchy is wrong;
- lighting system is globally wrong;
- style has collapsed globally.

## Repair language
Describe desired state directly.
Bad: "remove the ugly weird glossy AI look"
Good: "matte woven wool with low specular response, visible fiber variation, soft side light, no wet sheen"
