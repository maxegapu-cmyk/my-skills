# Style DNA & Consistency

## Style DNA fields
Record a reusable style in observable channels:
- composition grammar;
- shape language;
- line/edge behavior;
- palette structure;
- lighting character;
- material/texture character;
- detail density;
- medium/production process;
- finishing/grain/print/optical behavior;
- recurring asymmetry or imperfection.

## Choose the right Midjourney mechanism
### Style Reference
Use for a specific visual look. Keep text simple and non-conflicting.

### Style Creator
Use when you want to *discover and crystallize* a custom `--sref` code through selection rounds.
Run a simple probe prompt so you can see the style rather than the content.

### Moodboard
Use for a broader aesthetic field assembled from a curated image collection.
Good for project-world taste, less narrow than a single style reference.

### Personalization
Use for persistent taste profiles learned from image selection.
Do not assume a personal taste profile equals a project's art direction.

## Reference-stack discipline
When combining text + sref + personalization/moodboard + image prompt:
- name the owner of content;
- name the owner of style;
- name the owner of composition;
- remove redundant/conflicting style words.

## Style code search
Use Style Explorer or `--sref random` for discovery, then freeze promising codes and test them on the same neutral probe prompt.

## Describe-assisted vocabulary mining
Use Midjourney Describe as an idea-mining tool when a reference image contains visual qualities that are hard to name. Treat its output as vocabulary candidates, not as a faithful reconstruction of the image. Compare multiple Describe outputs, keep only recurring or visually accurate terms, then test those terms on a neutral probe prompt.

## Style archaeology loop
1. collect 3–12 references that share the desired visual DNA;
2. separate content-specific traits from reusable style traits;
3. use Describe / Style Explorer to discover vocabulary or codes;
4. test on a neutral probe;
5. freeze only traits that survive content changes;
6. store the winning style as text grammar + reference route + parameter baseline.
