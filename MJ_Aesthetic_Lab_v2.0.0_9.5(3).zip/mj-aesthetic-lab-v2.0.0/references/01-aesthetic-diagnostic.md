# Aesthetic Diagnostic

## Diagnosis order
1. Is the image's purpose readable in one second?
2. Is there a dominant focal point?
3. Is the frame organized into meaningful masses and depth?
4. Does viewpoint serve the subject?
5. Does light create form and hierarchy?
6. Is color supporting, not competing with, hierarchy?
7. Do materials behave plausibly or intentionally stylized?
8. Is the style internally coherent?
9. Is anything distinctly authored, or is it generic model taste?

## Common failure signatures

### Pretty but empty
Symptoms: expensive light, shallow depth, polished surface, no visual idea.
Repair: introduce one scene-specific relationship, gesture, prop, asymmetry, environmental consequence, or compositional tension.

### Everything is loud
Symptoms: saturated background, rim light, lens flare, ornate costume, extreme texture, dramatic sky all competing.
Repair: choose one hero system; suppress two others.

### AI luxury sludge
Symptoms: black/gold/gloss, marble, smoke, specular highlights, impossible reflections.
Repair: define real material family, finish, wear, light source, and restraint.

### Cinematic by adjective only
Symptoms: "cinematic, film still, anamorphic" but flat staging.
Repair: specify blocking, layer depth, camera height/distance, motivated practical light, foreground occlusion or negative space.

### Photoreal but synthetic
Symptoms: uniform skin/materials, perfect edges, identical microcontrast, excessive polish.
Repair: local variation, roughness differences, believable wear, optical imperfection, environmental interaction.

### Style soup
Symptoms: multiple eras/mediums/directors/photographers fighting.
Repair: keep one dominant medium/production grammar; at most one secondary influence expressed as a concrete trait.
