# Runtime Philosophy

The lab uses **diagnose → isolate → test → select → freeze**.

Core rule: a visual system becomes stronger when it knows what *not* to change.
Do not solve an uncertain problem with a larger prompt. First decide whether the failure is content, composition, camera, light, color, material, style, reference routing, or parameter routing.

## Complexity budget
A prompt has limited attention. Spend it on decisive visual variables.
- 1 dominant thesis
- 2–4 supporting systems
- a short failure guardrail
- parameters only when they materially steer the result

## Search vs convergence
Search mode permits broader `--c`, alternate style lanes, controlled `--w`, different reference strategies.
Convergence mode reduces variation and freezes successful choices.

## Freeze rule
Once a visual DNA wins, stop casually rewriting it. Record:
- composition grammar;
- camera grammar;
- lighting grammar;
- palette grammar;
- material grammar;
- style/reference route;
- parameter baseline.
