# Prompt Compiler

## Principle
Write what should be visible, not instructions about how the model should obey.

## Canonical order
`subject/event → composition → camera → lighting → color → material → style/finish → realism/imperfection → parameters`

Order is a clarity tool, not a magical syntax rule.

## Compression test
After drafting, delete every phrase that:
- repeats an earlier idea;
- is not visually testable;
- conflicts with another phrase;
- is generic praise rather than image evidence.

## Strong substitutions
Instead of `cinematic` alone, define staging + camera + light.
Instead of `luxury`, define material quality, restraint, craft, negative space, finish.
Instead of `detailed`, name the detail scale and where it matters.
Instead of `realistic skin`, name local tone variation, texture, highlight behavior, under-eye structure, lip texture.
Instead of `dramatic lighting`, name source direction, size, ratio, falloff and atmosphere.

## Negative prompting
Use `--no` for concrete unwanted nouns/features. Do not write entire aesthetic philosophy inside `--no`.
Positive replacement is usually stronger than prohibiting a vague concept.
