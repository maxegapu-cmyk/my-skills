# Controlled Experiment Protocol

## 1. State the hypothesis
Example: "The image feels generic because the camera/light grammar is generic, not because the subject prompt is weak."

## 2. Freeze constants
Keep subject, event, core composition and seed stable when testing a style/parameter variable.

## 3. Pick one experiment family
- Parameter sweep
- Composition sweep
- Camera sweep
- Light sweep
- Palette sweep
- Material sweep
- Style-reference sweep
- Moodboard/profile comparison

## 4. Use 2–4 variants
Too many variants reduce decision quality.

## 5. Score with the same criterion
Use the 8-part aesthetic scorecard, but declare 1–2 primary success metrics before generation.

## 6. Record winner DNA
Do not just save the winning prompt. Save *why* it won.

## Example: stylize sweep
Base prompt unchanged, same seed.
- A: low stylize — test fidelity
- B: medium stylize — test balance
- C: high stylize — test model-authored beauty
Winner is the lowest setting that achieves the desired aesthetic without losing intent, not automatically the most decorative image.

## Example: style-code discovery
Use one neutral probe prompt with several style codes. Keep content stable. Compare edge behavior, palette, texture, lighting, composition tendencies and subject distortion.
