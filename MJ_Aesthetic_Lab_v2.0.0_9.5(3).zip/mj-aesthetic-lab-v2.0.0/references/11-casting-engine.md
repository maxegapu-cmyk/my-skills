# Casting Engine — preserved from MJ Casting Lab v1.0.0

## Mission
Use Midjourney as a casting room: Search → Select → Minimal Repair → Freeze → Expand.

## Candidate Lattice
Create 3–4 actors who could play the same role but have different identity logic.

### MASS
Identity from facial mass distribution: cheek, jaw, chin, temple, upper/lower-face weight.

### RHYTHM
Identity from feature spacing/rhythm: brow-eye distance, eye spacing, eye length/height, nose-mouth distance, mouth width, compactness.

### TENSION
Identity from resting muscular state and gaze: lids, brow tension, mouth corners, jaw relaxation, head carriage.

### TRACE
Identity from age/history/controlled imperfection: under-eye structure, hairline, small asymmetry, marks, fatigue, environmental wear.

## Candidate score (0–2 each)
Identity / Role Readability / Non-template / Realism / Expandability / User Fit. Max 12.
10–12 winner; 8–9 repair; 0–7 discard.

## Repair
Change at most 3 variables.
KEEP / CHANGE / DO NOT DRIFT / REVISED PROMPT.

## Freeze
After identity wins, stop redesigning the face. Separate Identity / Performance / Costume / Style / Scene.

## Multi-character anti-collision
Track facial mass, rhythm, tension, asymmetry, age trace, hair mass, body presence and costume silhouette.
Two unrelated leads should not converge across most channels.

## Ancient / historical route
Face first, then map social status, labor, movement, material status, wear and ornament logic.
Avoid rental-studio costume clichés and modern influencer face templates.
