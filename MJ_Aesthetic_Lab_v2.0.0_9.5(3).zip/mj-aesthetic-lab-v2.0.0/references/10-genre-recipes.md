# Genre Routes

These are structural recipes, not fixed style prompts.

## Cinematic still
story beat → blocking → shot scale → foreground/midground/background → camera height/distance → motivated light → palette → environment consequence → finish.

## High-end portrait / fashion
identity → pose/tension → crop → lens character → key/fill/background separation → skin/material behavior → restrained palette → editorial finish.

## Product / luxury
product silhouette → hero angle → surface hierarchy → support geometry → material response → controlled reflection → negative space → brand-like palette discipline.

## Architecture / interior
program/function → dominant geometry → viewpoint → circulation/scale cues → daylight/practicals → material joins → human-scale anchors → atmosphere.

## Landscape / worldbuilding
world rule → scale anchor → terrain layers → weather/light causality → palette → geological/ecological texture → narrative anomaly.

## Sci-fi / concept
functional premise → silhouette language → construction logic → scale → wear/maintenance → light sources → environment interaction → one non-default design idea.

## Illustration / poster
message → dominant shape → hierarchy → silhouette → line/edge grammar → limited palette → texture/print behavior → typography space if needed.

## Niji / anime
character silhouette → pose → shot → shape/line language → palette → lighting → background abstraction/detail budget → version-specific adapter.
Avoid importing photographic jargon unless it improves the intended anime image.
