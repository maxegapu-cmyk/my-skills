# MJ Casting Lab v1.0.0

A broad-coverage Midjourney character sculpting / casting Skill.

## Core logic
**Search → Select → Minimal Repair → Freeze → Expand**

This is intentionally different from:
- giant anatomy checklist prompting;
- fixed "beautiful face" recipes;
- one-shot character-sheet generation.

## Best for
- anti-influencer-face character design;
- diverse cast design;
- photoreal ancient costume characters;
- modern / crime / military / sci-fi / fantasy characters;
- memorable ordinary-looking characters;
- face-training / identity reference assets.

## Files
- `SKILL.md`
- `references/00-method.md`
- `references/01-user-router.md`
- `references/02-candidate-lattice.md`
- `references/03-realism.md`
- `references/04-coverage.md`
- `references/05-midjourney-adapter.md`
- `references/06-asset-expansion.md`
- `references/07-quality-gates.md`
- `examples/`
- `scripts/selftest.py`

Run:

```bash
python scripts/selftest.py
```
