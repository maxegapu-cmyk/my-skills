# MJ Casting Lab v1.0.0
## Midjourney 广覆盖角色选角 / 捏脸 / 角色资产 Skill
### Target quality: 8.5+

---

## 0. Mission

MJ Casting Lab is not a "long face prompt generator".

Its job is to use Midjourney like a **casting room**:

1. turn a vague character idea into several controlled visual hypotheses;
2. generate a candidate field without letting Midjourney collapse everything into one beauty template;
3. select the face that has the strongest identity;
4. repair only the variables that actually need repair;
5. freeze the winner;
6. expand that identity into production-ready character assets.

The core success test is:

> If hair, makeup, costume, color and background are removed, does the character still feel like one specific person?

Second test:

> Does the character communicate role, age, temperament and life experience without becoming a stereotype?

---

# 1. Three-stage engine

## STAGE I — SEARCH
Create a controlled candidate field.

Do NOT try to solve everything in one prompt.

The system proposes 3–4 **candidate lanes** that differ in structural strategy, not merely color or hairstyle.

Each lane must vary at least three of:
- face mass distribution;
- feature rhythm;
- eye behavior;
- mouth tension;
- age/life trace;
- asymmetry;
- grooming discipline;
- physical presence.

Goal:
Find several plausible people who could all play the same role.

## STAGE II — SELECT + REPAIR
Choose the strongest candidate using the Selection Grid.

Do not rebuild the winner.

Record:
- what is already right;
- what feels generic;
- what breaks the character;
- what must never change.

Then change only 1–3 variables.

## STAGE III — FREEZE + EXPAND
Once identity is good:
- stop redesigning the face;
- move identity into a reference-based or tightly locked workflow;
- separate identity, style and costume;
- expand to turnaround, expressions, costume, action and face-training assets.

---

# 2. User onboarding: the 6-choice router

Do not interrogate the user with twenty questions.

If information is missing, guide with six compact choices.

## Choice 1 — Human category
Ask or infer:
- adult woman / adult man / older adult / mature adult / young adult;
- ethnicity / regional ancestry only if useful to the brief;
- realistic human / stylized-real / fantasy-human.

## Choice 2 — Role pressure
What does this person have to do in the story?
Examples:
- lead romance;
- command others;
- deceive;
- survive;
- protect;
- seduce;
- investigate;
- fight;
- govern;
- heal;
- teach;
- rebel;
- endure.

## Choice 3 — Emotional temperature
Choose one primary:
- warm;
- cool;
- restrained;
- volatile;
- playful;
- weary;
- dangerous;
- serene;
- nervous;
- detached.

## Choice 4 — Beauty relationship
Choose:
- conventionally beautiful;
- beautiful but unusual;
- striking rather than beautiful;
- ordinary but memorable;
- rugged;
- severe;
- elegant;
- weathered;
- deliberately imperfect.

## Choice 5 — World / styling domain
Examples:
- ancient Chinese;
- wuxia;
- xianxia;
- historical;
- modern city;
- crime;
- corporate;
- military;
- sci-fi;
- fantasy;
- post-apocalyptic;
- rural;
- period drama.

## Choice 6 — Failure to avoid
User picks the biggest enemy:
- influencer face;
- same-face syndrome;
- doll eyes;
- tiny V jaw;
- CG skin;
- over-glamour;
- costume-studio look;
- too young;
- too pretty;
- weak personality;
- stereotype.

If user already supplied these facts, do not ask again.

---

# 3. Candidate Lattice: the new face-search logic

For each character, generate 3–4 lanes.

Each lane uses a different **visual equation**.

## Lane A — MASS
Identity comes mainly from where facial mass sits.

Vary:
- upper-face vs lower-face weight;
- cheek fullness;
- midface projection;
- jaw mass;
- chin mass;
- temple fullness.

Use when:
- user complains every face has the same V-line;
- user needs mature / rugged / ordinary / powerful identities.

## Lane B — RHYTHM
Identity comes mainly from spacing and repetition.

Vary:
- brow-to-eye distance;
- eye spacing;
- eye length vs height;
- nose-to-mouth distance;
- mouth width;
- feature compactness vs facial blank space.

Use when:
- user wants elegant / unusual / aristocratic / intellectual identities.

## Lane C — TENSION
Identity comes mainly from resting muscular state and gaze.

Vary:
- eyelid openness;
- brow resting tension;
- mouth-corner tension;
- jaw relaxation;
- gaze duration and directness;
- head carriage.

Use when:
- personality must read strongly;
- face structure can remain subtle.

## Lane D — TRACE
Identity comes mainly from age, history and controlled imperfection.

Vary:
- under-eye structure;
- skin micro-variation;
- hairline irregularity;
- small asymmetry;
- old scar / mark;
- mild fatigue;
- environmental wear.

Use when:
- user wants realism;
- character must feel lived-in;
- anti-AI is critical.

Never make all four lanes simultaneously extreme.

---

# 4. Prompt architecture for candidate search

Every candidate prompt is built in six blocks only.

## Block 1 — Who
- adult identity;
- age band;
- role;
- ancestry/region if relevant.

## Block 2 — Lane thesis
One sentence:
- where identity comes from in this candidate.

## Block 3 — Structural evidence
Only 4–7 observable face/body cues.

## Block 4 — Performance baseline
- gaze;
- resting expression;
- head carriage;
- micro-tension.

## Block 5 — Reality treatment
- biological skin;
- hairline;
- microtexture;
- lighting.

## Block 6 — Avoid
Only the 5–10 highest-risk failure modes.

Do NOT dump a giant anatomy checklist into every search prompt.

---

# 5. Selection Grid

After candidate generation, score each candidate from 0–2 in six dimensions.

## S1 — Identity
0 generic
1 somewhat distinct
2 unmistakably specific

## S2 — Role readability
0 role not readable
1 partially readable
2 role/temperament reads immediately

## S3 — Non-template quality
0 influencer/model default
1 some individuality
2 clearly outside the default face basin

## S4 — Realism
0 plastic / CG / impossible
1 acceptable
2 biologically believable

## S5 — Expandability
0 depends on styling or angle
1 probably reusable
2 identity survives neutralization

## S6 — User fit
0 misses brief
1 partial fit
2 strong fit

Maximum = 12.

Selection rule:
- 10–12: winner candidate;
- 8–9: repair candidate;
- 0–7: discard, do not over-repair.

Do not keep a technically beautiful candidate if its identity score is 0.

---

# 6. Minimal Repair Protocol

A repair cycle may change at most 3 variables.

Preferred repair order:
1. silhouette / facial mass;
2. feature rhythm;
3. gaze / tension;
4. controlled asymmetry;
5. skin / hair realism;
6. styling.

Examples:

Bad:
"Make her more unique, more beautiful, more cinematic, more powerful..."

Good:
- widen lower cheek mass slightly;
- reduce vertical eye opening;
- make mouth corners more neutral and less smiling.

Every repair output must include:

### KEEP
3–7 things that stay unchanged.

### CHANGE
1–3 variables only.

### DO NOT DRIFT
3–7 explicit drift prohibitions.

### REVISED PROMPT
A concise revised candidate prompt.

---

# 7. Anti-AI Realism System

## 7.1 Face realism
Prefer:
- refined but visible microtexture;
- different highlight behavior on forehead, nose, cheeks and lips;
- subtle local tone variation;
- believable under-eye skin;
- natural facial hair / peach fuzz when visible;
- realistic lip texture;
- restrained asymmetry.

Avoid:
- perfectly uniform luminous skin;
- identical porelessness;
- beauty-filter geometry;
- symmetrical mouth corners;
- hyper-polished digital-human surfaces.

## 7.2 Hair realism
Require:
- believable hairline;
- baby hairs;
- variable strand grouping;
- weight and gravity;
- realistic accessory attachment.

## 7.3 Eye realism
Avoid:
- every adult having huge glass eyes;
- identical wet catchlights;
- perfectly white sclera;
- permanent beauty-ad gaze.

## 7.4 Makeup realism
Makeup sits on top of identity.

It must not:
- create the nose shape;
- create the jaw;
- make every role look 20;
- erase regional or age identity.

---

# 8. Broad-coverage character matrix

This Skill must work across these domains without changing its core logic.

## Beauty / romance
- white-moonlight heroine;
- glamorous heroine;
- playful lead;
- cool beauty;
- elegant noblewoman;
- romantic male lead;
- mature romantic lead.

## Power
- heiress;
- empress / royal;
- executive;
- politician;
- commander;
- crime boss;
- aristocrat;
- cult leader.

## Action
- soldier;
- mercenary;
- swordswoman;
- martial artist;
- ranger;
- survivor;
- bodyguard;
- detective.

## Intellect
- scholar;
- strategist;
- doctor;
- engineer;
- scientist;
- lawyer;
- teacher;
- archivist.

## Vulnerability
- sickly;
- exhausted;
- traumatized;
- sheltered;
- poor but dignified;
- displaced;
- elderly;
- grieving.

## Ambiguity / danger
- con artist;
- spy;
- assassin;
- schemer;
- unreliable ally;
- elegant villain;
- smiling predator;
- morally gray protector.

## Ordinary-life
- shopkeeper;
- farmer;
- office worker;
- parent;
- neighbor;
- student-age adult;
- craftsperson;
- service worker.

The system must never force all characters toward high-fashion beauty.

---

# 9. Ancient Chinese / Wuxia / Xianxia route

Ancient styling begins only after face identity has a winning candidate.

## 9.1 Face first
Search and select in a simple casting setup.

## 9.2 Then map social world
Choose:
- elite household;
- royal court;
- scholar-gentry;
- merchant household;
- martial world;
- military frontier;
- sect;
- healer;
- entertainer;
- religious / mystical;
- supernatural;
- fantasy dynasty.

## 9.3 Costume must answer
- who maintains it;
- how much labor it takes;
- how much movement it permits;
- what material status it signals;
- where it wears first;
- what ornament is functional vs ceremonial.

## 9.4 Avoid
- studio-hanfu cliché;
- universal pale-blue gauze;
- accessory overload;
- ornamental floating fabric with no gravity;
- modern influencer makeup pasted under ancient hair;
- identical white-small-face template.

---

# 10. Midjourney current adapter

This Skill separates **SCULPT**, **STYLE**, and **IDENTITY INHERITANCE**.

## 10.1 SCULPT — default current route
Use current default Midjourney model for face search.

Recommended experimental starting point:
- `--raw`
- lower `--s` than default when literal face control matters
- moderate `--c` when exploring candidate diversity
- portrait ratio such as `--ar 3:4`

These are starting points, not universal optimal values.

## 10.2 STYLE — separate channel
Use Style Reference only for:
- color;
- texture;
- lighting;
- medium;
- overall visual vibe.

Do not treat Style Reference as identity reference.

## 10.3 IDENTITY INHERITANCE
When the user has a winning face and needs the same person in new scenes:
- use the currently supported identity-reference route for the selected model version;
- keep text prompt clear;
- do not rewrite the face from scratch every time.

For V7, Omni Reference can carry a person/object from a reference image.
Do not push Omni weight excessively by default.

## 10.4 Legacy identity route
If the workflow intentionally uses V6/Niji 6 Character Reference:
- lower character weight can emphasize the face more than clothing/hair;
- treat it as a version-specific route, not a universal rule.

---

# 11. Identity / Style / Costume separation

Every production prompt must conceptually separate:

### IDENTITY
Who this person is.

### PERFORMANCE
What this person is doing / feeling now.

### COSTUME
What they are wearing now.

### STYLE
How the image is photographed / rendered.

### SCENE
Where they are.

Failure:
Using one reference or one paragraph to control all five.

Preferred:
Identity reference locks the person.
Style Reference controls visual look.
Text controls current costume, performance and scene.

---

# 12. Asset expansion pack

After identity wins, offer only assets relevant to the request.

## Face
- neutral face anchor;
- left/right 30–45°;
- profile;
- slight up/down;
- low-intensity expression pair.

## Character
- hero portrait;
- front/side/back turnaround;
- expression sheet;
- gesture/performance sheet.

## Costume
- full-body costume sheet;
- construction details;
- jewelry/headwear;
- material/wear details.

## Project
- cast comparison;
- family resemblance sheet;
- class/status comparison;
- age progression if requested.

---

# 13. Multi-character anti-collision

For each major character record:

- search lane used;
- dominant facial mass pattern;
- dominant rhythm pattern;
- resting tension;
- asymmetry cue;
- age trace;
- hair mass;
- body presence;
- costume silhouette.

Two leads should not share more than 5 of 8 channels unless deliberately related.

Family members:
share 1–3 cues, never entire faces.

Twins:
may share face, but performance, grooming, wear and body behavior must differentiate them when story requires.

---

# 14. Output contract

Default response:

## 1. ROLE BRIEF
One paragraph.

## 2. CANDIDATE LANES
3–4 concise routes:
- Lane A:
- Lane B:
- Lane C:
- optional Lane D:

## 3. MJ SEARCH PROMPTS
One prompt per lane.

## 4. SELECTION GRID
Explain what to look for in the returned grid.

## 5. ROUND-2 REPAIR TEMPLATE
KEEP / CHANGE / DO NOT DRIFT / REVISED PROMPT.

## 6. WINNER LOCK
Identity summary + recommended reference route.

## 7. ASSET PACK
Only if requested.

---

# 15. Fast mode

If user says:
"直接给我捏一个"

Internally choose:
- one role interpretation;
- three candidate lanes;
- strongest expected lane as primary;
- give one main prompt + two alternate prompts.

Do not make the user answer questions that can be safely inferred.

---

# 16. Quality gates

A result fails if:
- attractive but interchangeable;
- personality only comes from clothing;
- ethnicity is used as personality shorthand;
- face depends on makeup to exist;
- all candidates are variants of the same beauty template;
- repair rewrites the entire identity;
- skin is obviously CG/plastic;
- ancient styling looks like a rental photo studio;
- identity disappears at profile angle;
- role becomes unreadable when color is removed.

A result passes when:
- one candidate is clearly memorable;
- winner remains recognizable under neutral styling;
- repairs are minimal;
- identity/style/costume are separated;
- the face feels biologically plausible;
- the user can continue iterating without rebuilding from zero.
