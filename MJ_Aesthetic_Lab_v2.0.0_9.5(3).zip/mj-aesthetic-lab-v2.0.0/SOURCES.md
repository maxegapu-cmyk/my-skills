# SOURCES — official Midjourney baseline checked 2026-08-10

Platform facts in this package are based on official Midjourney documentation and update pages.

- Version: https://docs.midjourney.com/hc/en-us/articles/32199405667853-Version
- Parameter List: https://docs.midjourney.com/hc/en-us/articles/32859204029709-Parameter-List
- Raw: https://docs.midjourney.com/hc/en-us/articles/32634113811853-Raw
- Stylize: https://docs.midjourney.com/hc/en-us/articles/32196176868109-Stylize
- Chaos / Variety: https://docs.midjourney.com/hc/en-us/articles/32099348346765-Chaos-Variety
- Weird: https://docs.midjourney.com/hc/en-us/articles/32390120435085-Weird
- Style Reference: https://docs.midjourney.com/hc/en-us/articles/32180011136653-Style-Reference
- Style Creator: https://docs.midjourney.com/hc/en-us/articles/41308374558221-Style-Creator
- Moodboards: https://docs.midjourney.com/hc/en-us/articles/39193335040013-Moodboards
- Personalization: https://docs.midjourney.com/hc/en-us/articles/32433330574221-Personalization
- Image Prompts: https://docs.midjourney.com/hc/en-us/articles/32040250122381-Image-Prompts
- Seeds: https://docs.midjourney.com/hc/en-us/articles/32604356340877-Seeds
- Editor: https://docs.midjourney.com/hc/en-us/articles/32764383466893-Editor
- Vary Region: https://docs.midjourney.com/hc/en-us/articles/32794723105549-Vary-Region
- Omni Reference: https://docs.midjourney.com/hc/en-us/articles/36285124473997-Omni-Reference
- Describe: https://docs.midjourney.com/hc/en-us/articles/32497889043981-Describe

Volatile facts are centralized in `references/07-midjourney-v82.md` so future platform changes do not require rewriting the entire aesthetic system.
