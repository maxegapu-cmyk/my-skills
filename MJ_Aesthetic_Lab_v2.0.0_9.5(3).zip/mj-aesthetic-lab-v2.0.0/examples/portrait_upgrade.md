# Example — Portrait Aesthetic Upgrade

## Input
"A beautiful ancient Chinese heiress, cinematic, 8k, masterpiece, luxury, delicate face."

## Diagnosis
The prompt asks for quality but does not author composition, light, status, material or identity. It is highly likely to collapse into generic glamour.

## Visual thesis
A young elite woman whose authority is visible through restraint, spatial control and material confidence rather than jewelry overload.

## Aesthetic DNA
- vertical 3:4 portrait with quiet negative space;
- eye-level, medium close portrait, restrained perspective;
- broad soft window key from one side, weak fill, dark-but-detailed opposite cheek;
- warm ivory / desaturated cinnabar / deep ink palette;
- matte silk with visible weave and restrained embroidery;
- clean biological skin with regional roughness variation;
- one slight facial asymmetry; stable unsmiling gaze.

## Prompt
adult Chinese heiress in an elite historical household, calm commanding presence, medium-close portrait with quiet negative space, eye-level natural perspective, broad soft window light from camera-left with gentle falloff and restrained shadow detail, warm ivory and desaturated cinnabar against deep ink neutrals, matte silk robe with visible fine weave and sparse hand embroidery, believable hairline and baby hairs, refined biological skin texture with subtle regional roughness variation, restrained makeup, one slight brow asymmetry, premium live-action historical drama finish --ar 3:4 --raw --s 120

## Success check
Authority must still read if jewelry and background are mentally removed.
