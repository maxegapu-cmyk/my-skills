# Example — Style Discovery Lab

## Goal
Find a reusable editorial aesthetic for a fashion portrait series.

## Neutral probe prompt
adult fashion model in a simple black coat standing beside a plain concrete wall, three-quarter portrait, neutral pose, soft daylight --ar 3:4

## Lane A — restrained tactile editorial
matte surfaces, muted neutrals, soft side daylight, visible paper/film-like grain, low saturation.

## Lane B — graphic hard-light modernism
hard directional key, strong cast shadow geometry, limited black/white/red palette, crisp edges.

## Lane C — luminous romantic editorial
broad backlight, gentle halation, pale cool neutrals, soft atmospheric separation, controlled highlights.

## Workflow
1. test text-only lanes;
2. if a lane wins, search Style Explorer / Style Creator with the same neutral probe;
3. freeze the best `--sref` code;
4. test style weight at low/medium/high influence;
5. only then apply to complex fashion scenes.
