# persona-team · Hermes 岗位人格系统

给 Hermes 多 agent 团队配人格：每个岗位一张人格卡（五个工作维度 + 职责 + 禁区），编译成各 profile 的 SOUL.md；按岗位特征和 MBTI 匹配；看板协作协议；保真度探针。

## 安装

任选一种：

```bash
# 1. 本地解压后复制
mkdir -p ~/.hermes/skills/multi-agent
cp -r persona-team ~/.hermes/skills/multi-agent/

# 2. 推到你自己的 GitHub 仓库 skills/ 目录下后
hermes skills install <你的用户名>/<仓库>/skills/persona-team
```

依赖：Python 3.9+ 与 PyYAML（Hermes 环境自带）。

## 三分钟上手

在 Hermes 里直接说：

> /persona-team 帮我搭一个六岗位的团队

或者手动：

```bash
P=~/.hermes/skills/multi-agent/persona-team/scripts/persona.py
python3 $P init                 # 模板复制到 ~/.hermes/personas/
python3 $P setup                # 预演
python3 $P setup --apply --modes  # 建 profile、写 SOUL.md、写工作模式
python3 $P mbti INTJ-T          # 看某个 MBTI 适合什么岗位
python3 $P match --function review --structure high
python3 $P probe reviewer       # 生成人格保真度测试
```

## 默认六岗位

| id | 岗位 | 发散/严谨/主动/协同/警觉 | MBTI 标签 |
| --- | --- | --- | --- |
| orchestrator | 编排者 | 2/4/5/3/3 | ESTJ |
| researcher | 研究员 | 3/5/3/3/4 | ISTJ |
| ideator | 构思者 | 5/2/4/4/2 | ENFP |
| executor | 执行者 | 2/4/3/3/3 | ISTJ |
| reviewer | 审核员 | 2/5/3/2/5 | ISTJ-T |
| arbiter | 裁决者 | 2/4/2/3/3 | INTJ |

详细说明见 `SKILL.md` 和 `references/`。
