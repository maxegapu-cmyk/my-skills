# 设计依据

| 来源 | 发现 | 在本 skill 中的落点 |
| --- | --- | --- |
| Zheng 等，EMNLP Findings 2024（arXiv 2311.10054） | 加人设对客观题准确率没有稳定提升，最佳人设难以预先挑中 | 人格管行为方式，专业能力靠技能和工具；必须做对照实验 |
| Zhang 等，ACL 2024 MachineSoM（arXiv 2310.02124） | agent 群体出现从众、多数决；思考模式的排列顺序影响大 | 先独立后汇总；专设低协同的审核岗 |
| Liang 等，EMNLP 2024 MAD（arXiv 2305.19118） | 自我反思会思维退化；适度对抗 + 裁判 + 自适应终止有效 | 审核回路 + 裁决岗 + 2 轮上限 |
| Keluskar 等，2026（arXiv 2606.27443） | 低宜人性在结构化编码任务影响小，在开放协作和谈判中显著拉低结果 | 匹配规则 R1 / R2 |
| Wang 等，2026（arXiv 2607.19785） | agent 按性格挑搭档时偏差强、刻板、赢家通吃；低极形容词带负面色彩 | 编制由人定；中性措辞，一个长处一个注意点 |
| The Power of Personality，2025（arXiv 2502.20859） | 大五赋值影响推理和创意；能力相近时多样性带来收益 | 先能力达标，再追求多样 |
| MAPS，AAAI 2026 | 按人格分工打破同质化 + 独立 Critic | 人格差异 + 独立复核 |
| Ong 等，2025（arXiv 2503.12722） | 高宜人性、高尽责性促进合作，也更易被利用 | 匹配规则 R5 |
| Li 等，2024（arXiv 2402.10962） | 人设 8 轮内明显漂移，与注意力衰减有关 | 每卡新会话、短会话、结构化交接 |
| Cemri 等，NeurIPS 2025 MAST（arXiv 2503.13657） | 多 agent 失败集中在规格不清、agent 间错位、核验不足 | 底线 + 固定产出模板 + 评估用 MAST 标注 |
| Besta 等，2025 MBTI-in-Thoughts（arXiv 2509.04343） | MBTI 提示带来稳定可解释的行为偏向；F 型擅长叙事，T 型博弈策略更稳 | MBTI 入口与认知风格描写 |
| McCrae & Costa，1989 | MBTI 四轴与大五四个维度相关 | MBTI → 五维换算 |
| Hermes 文档：Personality & SOUL.md、Profiles、Kanban、Delegation | SOUL.md 占系统提示第 1 槽；profile 互相隔离；子代理不加载 SOUL.md | 落地结构与 summary 命令 |
