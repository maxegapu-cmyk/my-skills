# 18｜公开执行能力矩阵

四种工具：`none`（只做方案）、`dialogue`（对话式生图工具）、`comfyui`（实际节点环境）、`api`（已有 API）。

工具声明的 `features` 是用户**自报能力**，不是环境实测；默认全部 `unverified`，只有在任务所在宿主实际可用、对应依赖存在后才把某个具体能力记为 `supported`。若本包未实际安装工具，不能说“已实现 IP-Adapter 节点”或“直接一键出图”。

典型能力需要：`image_generation`、`image_reference`、`mask_edit`、`pose_control`、`depth_control`、`identity_adapter`、`batch_queue`。对话环境可能支持图像参考但不支持锁死 seed；节点式环境不保证所有插件都安装；用户没给清单则标注不可核实而不是假设支持。

降级优先级：身份核心 > 不可错的服装/物理接触 > 动作关系 > 构图透视 > 光场 > 装饰性风格。对“有图像工具但不支持掩膜”的返修，不谎称局部精准替换，改给低风险重出该张的建议。
