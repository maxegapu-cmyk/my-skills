# Brief Router

将任务归入以下执行型之一：
- create_single：单张新创作；
- preserve_identity：有身份参考；
- preserve_costume_object：有服装/道具参考；
- preserve_layout_pose：有姿态/构图参考；
- multi_reference：多参考分工；
- series：四张及以上或明确要求组图；
- repair：已有失败结果；
- audit：只评审，不修改。

## 必填推断
路由后补齐：主体、地点、事件、视觉重心、硬约束、可编辑维度、交付类型。
非阻断项采用保守默认值，不把选择负担甩给用户。
