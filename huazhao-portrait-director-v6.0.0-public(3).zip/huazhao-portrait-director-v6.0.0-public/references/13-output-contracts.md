# Output Contracts

## 单张创作
输出：
- Creative Verdict：一句话说明这张图真正拍什么；
- ShotSpec 摘要；
- Must Keep：不可漂移项；
- Review Checklist：成片复核点。

## 系列
输出：
- Series Charter；
- Continuity Ledger；
- Frame Table；
- 每张差异点；
- 系列复核标准。

## 返修
输出：
- 判决：能修 / 需要重做关键层 / 证据不足；
- 最大失败项；
- Keep List；
- Repair Scope；
- 复验标准。

## 审核
输出：
- 先给能用/不能用/有条件能用；
- 按视觉影响排序问题；
- 每条包含证据、后果、最小修法。

默认不输出内部候选过程和底层生成文本。
