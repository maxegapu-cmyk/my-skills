# 15｜参考仲裁与误继承阻断

最危险的多图故障不是参考不够，而是参考图偷走了不属于它的决定权：脸图的妆容覆盖服装图；服装图的模特脸覆盖身份图；构图图把其场景中的人脸/天气一起继承。

强规则：`identity / wardrobe / pose / composition / environment / lighting / visual_language` 七个独立维度，各只有**一个 primary**；清晰度、用户指定优先级用于打破歧义。用户明确指图优于模型自动推测。同维度两张同权、同清晰的主参考发生竞争：暂停该维度，要求用户只裁决一个问题，不允许随机或隐式融合。

降级：当只有一张“整体气氛图”而未注明用途时，默认仅当作 `visual_language`；不擅自锁定其人物身份、服装或动作。参考的图片标识只能证明用户有一张参考，不证明系统已经读取和校验过图像内容。

代码入口：`python scripts/huazhao.py single --input examples/multi-reference.json`。外发只报告主参考和冲突结果，不导出底层生成词库。
