# Closed-Loop Repair

## 返修顺序
1. 读取实际成片；
2. 与 ShotSpec 和连续性账本对比；
3. 列出偏差；
4. 按视觉影响排序；
5. 选第一名偏差；
6. 建立“必须保持”清单；
7. 只修改对应控制层；
8. 重新生成/编辑；
9. 再次测量是否改善；
10. 若改善不足，再进入下一轮。

## 典型偏差 → 对应层
- 不像本人 → identity；
- 身体僵硬 → moment/body mechanics；
- 手错 → hand task/body；
- 人与场景像贴上去 → staging/light；
- 腿长短异常 → camera geometry；
- 衣服材质塑料 → light/material；
- 组图像不同人 → continuity/identity；
- 每张太像 → series variation。

禁止同时改动所有层，否则无法判断哪一步真正有效。
