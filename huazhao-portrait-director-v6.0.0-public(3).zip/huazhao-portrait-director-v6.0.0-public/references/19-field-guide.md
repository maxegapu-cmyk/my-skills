# 19｜公开字段与交付语义

## 最简输入
`intent` 必填，`subject`/`scene`/`visual`/`references`/`locks`/`tool` 可选；`series` 额外 `series_count` 2–40；`repair`/`audit` 可填 `observed_issues` 和 `visual_evidence`。

- 多人物：`subjects` 数组每人必须有不同 `id`，可填 `identity_core`/`position`/`gaze_target`/`hand_task`；当一场出现两人及以上，脸与服装的参考图必须填写 `subject_id`，否则在该维度暂停等待分配；不得把 A 的脸赋给 B。
- `subject`: `identity_core` / `age_band` / `body_structure` / `hair_makeup` / `wardrobe_core`。
- `scene`: `location` / `event` / `time` / `weather` / `light_source`。
- `visual`: `aspect_ratio`（例如 `3:4`）、`shot_size`、`camera_height`、`mood`、`light_direction`。
- `references`: 数组，每项 `id` + `roles`（七个固定职责之一或多个）+ `priority`（0–10）+ `clarity`（low/medium/high）。没有实际视觉观察时，仅是职责声明。
- `locks`: 数组，锁定维度如 `identity` / `wardrobe` / `camera` 等。
- `tool`: `{ "kind": "none|dialogue|comfyui|api", "features": [] }`。如果尚未确认真实工具是否连接，请不报已部署。
- `visual_evidence`: `direct_visual|user_reported|none`；**CLI 不看像素**，`direct_visual` 表示操作者已独立实际检查图并提交观察，不是 CLI 自动检查。
- `observed_issues`: `[{"layer":"hands","evidence":"右手出现额外手指","severity":"high"}]`。severity: low/medium/high/critical。`protected_successes` 是不得破坏的成功项。

## 结果语义
- `planned`：可供图像工具或摄制人员执行，**不代表已出图**。
- `needs_decision`：参考冲突/保护项冲突或缺少关键必需信息。
- `needs_visual_review`：未获视觉观察，不能确认故障。
- `ready_for_external_visual_review`：用户提供已亲眼观察的问题并有候选修法；成片仍未由本程序审验。

## 输出职责
`shot_spec` 是分层拍摄规格；`reference_authority` 是分工与冲突报告；`tool_readiness` 是*声明能力*与真实可用能力的区别；`quality_gates` 所有状态起始为 `unverified`；`frames` 是可区分的镜头计划，不是生成图；`review` 包含返修保护项与最重要失败层，不能替代人工/视觉模型看图。

`python scripts/huazhao.py single|series|repair|audit --input ... [--out ...]`。命令参数是产品公开接口，不会拼装或输出任何私有底层生成文本。
