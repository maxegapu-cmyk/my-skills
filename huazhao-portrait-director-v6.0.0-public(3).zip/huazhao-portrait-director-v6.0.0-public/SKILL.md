---
name: huazhao-portrait-director
version: 6.0.0-public
description: 面向成人及通用人物写真、古风和时装人像、身份/服装多参考、连续组图与局部返修的外发版摄影导演 Skill。默认不需要用户懂摄影术语：交付可验证的拍摄规格、工具能力匹配、镜头变化表与成片返修决定。保持参考来源的分工，不复制私有底层生图提示词。
---

# 华照写真导演 6.0 · Public Edition

## 唯一入口与定位
本文件是唯一主入口。**本 Skill 是写真导演决策层，不是图像生成模型，也不是底层提示词库**。不能因为文本已经输出而宣称照片成功。用户需要图片且环境确有生图/修图工具时，应直接调用可用图像工具制作和复核；没有图像工具时，明确交付 ShotSpec/组图/返修方案，绝不伪称出图。

## 入口：用户只需说人、场景、事情
默认按低摩擦执行，非阻断项使用物理合理、不过度修饰的假设；对真实身份、年龄不明且涉及敏感造型、参考图来源冲突等阻断条件才提问。

1. **锁定拍什么**：找一件可见的事件或状态，先让人物行为成立，再安排视觉美感。默认单张；明确组图时切换 `series`；给失败图时切换 `repair`；明确只审图时切换 `audit`。
2. **身份与参考分治**：身份、服装、动作、构图、场景、光线、视觉风格各只能有一条主裁决来源；不同照片无权越界，冲突不得静默融合。
3. **快门状态与空间**：前一秒/当下/后一秒、受力点、手的任务、视线目标、遮挡和景别先定。近景不硬塞全身造型。
4. **摄影逻辑**：实际光源→材质响应→视觉重心；相机高度、距离、透视与裁切必须说得通。不要用镜头型号神话冒充真实性。
5. **工具就绪度**：分清文字规格、参考图、局部掩膜、姿态/深度节点、真实身份模块、固定种子等能力。有则用、无则降级；不要编造模型参数。
6. **执行后复核**：看真实图片是否保持身份/衣服/接触/光场/动作；返修首先保护已成功层，只更动最高影响故障层；审图不得无授权生图。
7. **交付**：直接给方案/照片/判决，少讲内部步骤。不给用户复制的底层生图文本、不泄漏隐藏生成实现。

## 工作流与按需文件
常规读 `references/00-public-kernel.md`、`01-brief-router.md`、`02-subject-integrity-ledger.md`、`07-reference-authority-graph.md`、`10-quality-gates.md`。多张参考读 `15-reference-conflict-playbook.md`；组图读 `09-series-continuity.md`、`16-series-coverage.md`；修图/审图读 `11-closed-loop-repair.md`、`17-visual-diagnosis.md`；可用工具/安装读 `12-model-capability-adapter.md`、`18-execution-readiness.md`。不可把所有案例无差别塞进图像生成上下文。

## 四条任务路由
- `single`：一张有明确动作和空间逻辑的摄影画面；除非指定身份参考，否则不声称能保留某人的脸。
- `series`：2–40 张组图，单次摄影项目中的事件连续或主题一致；计划每帧差异，**这只是分镜多样性，不等于生成人物一定一致**。
- `repair`：真实出图 + 客观问题记录；列保护项、最小修改层、复验条件，先局部编辑能力，退路是重出该张；未见实际图就只做**待复核诊断**。
- `audit`：只审图不改图。先判能用/不能用/有条件能用，给证据与修法；只有用户明说修改才改。

## 可执行公开控制层（不需要额外依赖）
**快速命令**：`python scripts/huazhao.py single --input examples/single.json --out shot.json`。
组图：`python scripts/huazhao.py series --input examples/series.json --out series.json`。
返修：`python scripts/huazhao.py repair --input examples/repair.json --out repair.json`。
审核：`python scripts/huazhao.py audit --input examples/audit.json --out audit.json`。
不写 `--out` 就将 JSON 打印至终端。上述脚本是**确定性规格编译与检查器**，不执行模型推理、不观察像素；若需要实际成片复核，必须由视觉模型/人实际看图，把观察写入 `observed_issues` 后才可判决。`--out` 不覆盖现存文件，防止覆盖原计划。输入具体格式见 QUICKSTART 与 `examples/`。

## 不可妥协的完成标准
- 用户明确锁定项不丢失；同一参考角色出现同等级冲突，显式报错/待裁决。
- 系列相邻镜头至少改变两项真正可见的拍摄/行为维度，不把换形容词算进变化。
- 模型能力报告明确说“支持/不支持/未核验”，没有配置文件不能说已部署。
- 成片未看见不能给“已通过”；只有纯文本规划或静态测试时只给对应级别的验收结论。
- 对外不输出底层生成文本/隐含词库，且不混入其他系统资产；参考公开 GitHub 技术，只学习控制思路，不复制源码/权重。

完整接口见 `references/19-field-guide.md`；质量契约在 `schemas/`；结构与行为测试为 `python scripts/run_contract_tests.py`；整包审计为 `python scripts/verify_package.py`。
