# 华照写真导演 6.0 · 小白入口

## A. 直接对 AI 说一句话
“帮我拍一组 6 张古风雨天写真：成年女子，穿同一件月白色衣服，人在雨廊避雨，脸按图1，衣服按图2，动作按图3；身份和衣服一定不能漂移。没图像工具就给我组图方案。”

不需要填写参数，也不需要理解 JSON。AI 按 `SKILL.md` 生成拍摄计划；有视觉工具才真正出图，成片要人工或视觉模型复核。

## B. 本地脱机检查（推荐先试）
1. 解压 ZIP，打开解压出的 `huazhao-portrait-director-v6.0.0-public` 文件夹。
2. Windows 在该文件夹地址栏输入 `cmd` 回车；输入 `python --version`，显示 Python 3.9+ 代表可执行。
3. 运行 `python scripts/verify_package.py`；看到 `PACKAGE PASS` 代表文件完整。
4. 运行 `python scripts/run_contract_tests.py`；看到 `TESTS PASS` 代表公开控制脚本在当前环境通过。
5. 运行 `python scripts/huazhao.py series --input examples/series.json --out series-output.json`；产生 `series-output.json`。
6. 如果提示 `destination exists`，改输出名或者删掉之前的实验文件再试（不会覆盖既有文件）。

**重要**：这些步骤**只生成结构化导演规格，不会生成图片**，也不会下载模型、触网、安装节点。打开生成的 JSON 可看到每张的镜头、动作、光线、参考职责与未验证事项。

## C. 任务格式（会改 JSON 时）
复制 `examples/single.json`，修改 `intent`、`subject`、`scene`、`references`、`locks`、`tool`。需要组图只需换 `series` 并给 2–40 的 `series_count`。
**参考图角色**：identity / wardrobe / pose / composition / environment / lighting / visual_language；每图的 `id` 在本包内只是用户提供的标签，不会读取图片文件，照片要由实际视觉工具检查。
**返修**：`observed_issues` 填实际视觉审查者看出的事实，不能因附加图片路径就假装脚本自己看过图。

## D. 三类常见结果
- `status: planned`：导演规格已生成，尚未生成/验收照片。
- `status: needs_decision`：多参考冲突或“锁定项”和要求修改相冲突，请先决定。
- `status: needs_visual_review`：没有可靠的视觉观察，不能认定某种缺陷确实存在。

默认不展示私有底层图像生成文本。模型升级只影响可用能力，不自动保证身份一致性。
