"""Release validation from ZIP, in a fresh temporary directory. Python stdlib only."""
import argparse
import hashlib
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tempfile
import zipfile


def main(argv=None):
    ap=argparse.ArgumentParser(description='Audit final HuaZhao ZIP from scratch')
    ap.add_argument('--zip',required=True,type=Path)
    args=ap.parse_args(argv)
    archive=args.zip.resolve()
    if not archive.is_file():
        print('RELEASE FAIL: archive missing',file=sys.stderr);return 2
    with tempfile.TemporaryDirectory(prefix='hz-release-') as temp:
        tmp=Path(temp)
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None:raise RuntimeError('ZIP CRC error')
            names=z.namelist()
            if len(names)!=len(set(names)):raise RuntimeError('ZIP contains duplicate paths')
            for entry in z.infolist():
                path=PurePosixPath(entry.filename)
                if path.is_absolute() or '..' in path.parts or '\\' in entry.filename:
                    raise RuntimeError('potential ZIP path traversal')
                if entry.create_system==3 and ((entry.external_attr >> 16)&0o170000)==0o120000:
                    raise RuntimeError('ZIP contains symlink')
            z.extractall(tmp)
        roots=[p for p in tmp.iterdir() if p.is_dir()]
        if len(roots)!=1 or roots[0].name!='huazhao-portrait-director-v6.0.0-public':
            raise RuntimeError('expected single canonical package root')
        root=roots[0]
        original_tree={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
        env={'PATH':os.environ.get('PATH',''),'HOME':str(tmp),'LANG':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1'}
        if os.name=='nt':env['SystemRoot']=os.environ.get('SystemRoot','C:\\Windows')
        for cmd in ([sys.executable,'-B',str(root/'scripts/verify_package.py')],
                    [sys.executable,'-B',str(root/'scripts/run_contract_tests.py')]):
            proc=subprocess.run(cmd,cwd=root,env=env,text=True,capture_output=True)
            if proc.returncode:
                print(proc.stdout,proc.stderr,file=sys.stderr)
                raise RuntimeError(f'failed clean-package command {cmd}')
            print(proc.stdout.strip().splitlines()[-1])
        for mode in ('single','series','repair','audit'):
            output=subprocess.run([sys.executable,'-B',str(root/'scripts/huazhao.py'),mode,
                                   '--input',str(root/'examples'/f'{mode}.json')],
                                  cwd=root,env=env,text=True,capture_output=True)
            if output.returncode:raise RuntimeError(f'public entry failed for {mode}: {output.stderr}')
            import json
            result=json.loads(output.stdout)
            if result['version']!='6.0.0-public' or result['real_image_generated']:
                raise RuntimeError('incorrect output contract')
            print('ENTRY PASS',mode,result['status'])
        final_tree={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
        if final_tree!=original_tree:raise RuntimeError('unexpected files left in extracted release package')
        print('RELEASE PASS ZIP SHA256:',hashlib.sha256(archive.read_bytes()).hexdigest())
        print('RELEASE FILES:',len(final_tree),'TREE CLEAN: YES')
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except (RuntimeError,ValueError,zipfile.BadZipFile) as e:
        print('RELEASE FAIL:',e,file=sys.stderr)
        sys.exit(1)
