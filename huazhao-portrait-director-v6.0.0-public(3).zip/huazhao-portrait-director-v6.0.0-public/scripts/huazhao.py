#!/usr/bin/env python3
"""HuaZhao public director specification compiler. Does NOT inspect/generate images."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from typing import Any

VERSION = '6.0.0-public'
ROLES = ('identity', 'wardrobe', 'pose', 'composition', 'environment', 'lighting', 'visual_language')
LOCKS = set(ROLES) | {'hands', 'camera', 'action', 'gaze', 'hand_task', 'time', 'hair_makeup', 'body', 'props'}
LAYERS = {'identity','wardrobe','pose','composition','environment','lighting','visual_language', 'camera', 'action', 'gaze', 'hands', 'body', 'material', 'spatial', 'props'}
SEVERITY = {'low':1, 'medium':2, 'high':3, 'critical':4}
EVIDENCE = ('none', 'user_reported', 'direct_visual')
FEATURES = ('image_generation', 'image_reference', 'mask_edit', 'pose_control', 'depth_control', 'identity_adapter', 'batch_queue')
GATES = ['identity','body','action','attention','space','camera','light','material','focus','series']

class InputError(ValueError):
    pass

def dictionary(val: Any, key: str) -> dict:
    if val is None: return {}
    if not isinstance(val, dict): raise InputError(f'{key}: expected object')
    return val

def lst(val: Any, key: str) -> list:
    if val is None: return []
    if not isinstance(val, list): raise InputError(f'{key}: expected array')
    return val

def strval(val: Any, key: str, default: str = '') -> str:
    if val is None: return default
    if not isinstance(val, str): raise InputError(f'{key}: expected string')
    return val.strip() or default

def check(payload: Any, mode: str) -> dict:
    p = dictionary(payload, 'input')
    intent = strval(p.get('intent'), 'intent')
    if not intent: raise InputError('intent is required and must be nonempty')
    if len(intent) > 5000: raise InputError('intent too long (>5000 characters)')
    for key in ('subject','scene','visual','tool'): dictionary(p.get(key), key)
    members = lst(p.get('subjects'), 'subjects')
    if len(members)>8: raise InputError('subjects: max 8')
    member_ids=set()
    for i,person in enumerate(members):
        m=dictionary(person,f'subjects[{i}]')
        pid=strval(m.get('id'), f'subjects[{i}].id')
        if not pid or pid in member_ids: raise InputError('subjects must have unique nonempty ids')
        member_ids.add(pid)
    refs = lst(p.get('references'), 'references')
    if len(refs)>32: raise InputError('references: max 32')
    ids=set()
    for idx, ref in enumerate(refs):
        obj = dictionary(ref, f'references[{idx}]')
        rid=strval(obj.get('id'), 'references.id')
        if not rid: raise InputError(f'references[{idx}].id required')
        if rid in ids: raise InputError(f'duplicate reference id: {rid}')
        ids.add(rid)
        sid=obj.get('subject_id')
        if sid is not None and (not isinstance(sid,str) or sid not in member_ids):
            raise InputError(f'{rid}: unknown subject_id {sid}')
        roles=lst(obj.get('roles'),f'references[{idx}].roles')
        if not roles or any(r not in ROLES for r in roles): raise InputError(f'{rid}: roles must use {ROLES}')
        if len(roles) != len(set(roles)):raise InputError(f'{rid}: duplicate role')
        priority=obj.get('priority', 5)
        if isinstance(priority, bool) or not isinstance(priority,int) or not (0 <= priority <= 10):
            raise InputError(f'{rid}: priority must be integer 0..10')
        if obj.get('clarity','medium') not in ('low','medium','high'):
            raise InputError(f'{rid}: clarity must be low/medium/high')
    for k in ('quality_targets','mutable_fields','forbidden_drift'):
        if k in p:
            entries=lst(p.get(k),k)
            if any(not isinstance(x,str) for x in entries):raise InputError(f'{k}: elements must be strings')
            if k=='quality_targets' and not entries:raise InputError('quality_targets cannot be empty')
    locks = lst(p.get('locks'), 'locks')
    if any(x not in LOCKS for x in locks): raise InputError(f'unknown locks; allowed: {sorted(LOCKS)}')
    if len(locks) != len(set(locks)):raise InputError('duplicate lock')
    tool = dictionary(p.get('tool'), 'tool')
    if tool.get('kind','none') not in ('none','dialogue','comfyui','api'):
        raise InputError('tool.kind: none/dialogue/comfyui/api')
    features = lst(tool.get('features'),'tool.features')
    if any(f not in FEATURES for f in features):raise InputError(f'tool.features must use {FEATURES}')
    if len(features)!=len(set(features)):raise InputError('duplicate tool feature')
    if mode=='series':
        count=p.get('series_count', 6)
        if isinstance(count, bool) or not isinstance(count, int) or not 2 <= count <= 40:
            raise InputError('series_count: integer 2..40')
    evidence=p.get('visual_evidence','none')
    if evidence not in EVIDENCE: raise InputError('visual_evidence: none/user_reported/direct_visual')
    issues = lst(p.get('observed_issues'),'observed_issues')
    for i,issue in enumerate(issues):
        item=dictionary(issue,f'observed_issues[{i}]')
        if item.get('layer') not in LAYERS:raise InputError(f'observed_issues[{i}].layer unsupported')
        if item.get('severity','medium') not in SEVERITY:raise InputError(f'observed_issues[{i}].severity unsupported')
        if not strval(item.get('evidence'),'issue.evidence'):raise InputError(f'observed_issues[{i}].evidence required')
    protected=lst(p.get('protected_successes'),'protected_successes')
    if any(x not in LAYERS for x in protected):raise InputError('protected_successes has unsupported layers')
    return p

def authority(p: dict) -> dict:
    by_role={}
    members=p.get('subjects',[])
    unresolved=[]
    for role in ROLES:
        group={}
        for r in p.get('references',[]):
            if role not in r['roles']:continue
            scope=r.get('subject_id','global') if (len(members)>1 and role in ('identity','wardrobe')) else 'global'
            key=f'{scope}.{role}' if scope!='global' else role
            group.setdefault(key,[]).append(r)
        for key, refs in group.items():
            active=[{'id':r['id'],'priority':r.get('priority',5),'clarity':r.get('clarity','medium')} for r in refs]
            active.sort(key=lambda z:(z['priority'],{'high':2,'medium':1,'low':0}[z['clarity']]),reverse=True)
            top=active[0]
            ties=[x['id'] for x in active if x['priority']==top['priority'] and x['clarity']==top['clarity']]
            ambiguous_group=(len(members)>1 and key in ('identity','wardrobe'))
            by_role[key]={'primary':top['id'] if len(ties)==1 and not ambiguous_group else None,
                          'conflicts':ties if len(ties)>1 else [],'candidates':[x['id'] for x in active],
                          'needs_subject_assignment':ambiguous_group,
                          'notice':'reference roles declared; image contents not inspected'}
            if len(ties)>1 or ambiguous_group:unresolved.append(key)
    return {'roles':by_role,'unresolved':unresolved,
            'observation':'Metadata-based assignment; actual reference image contents not inspected.'}

def tool_readiness(p:dict,mode:str) -> dict:
    tool=p.get('tool',{})
    kind=tool.get('kind','none')
    declared=list(tool.get('features',[]))
    need={'single':['image_generation'], 'series':['image_generation','batch_queue'],
          'repair':['mask_edit'], 'audit':[]}[mode]
    if p.get('references'): need.append('image_reference')
    return {'kind':kind,'declared_features':declared,
            'declared_but_unverified':declared,
            'requested_features':need,
            'missing_or_unconfirmed':[x for x in need if x not in declared],
            'actual_runtime_integration':'not verified; this CLI provides planning only',
            'fallback':'produce a director plan for manual/tool-assisted execution; do not claim images generated'}

def shot_spec(p:dict) -> dict:
    subj=(p.get('subjects') or [p.get('subject',{})])[0]; scene=p.get('scene',{}); visual=p.get('visual',{});
    return {
        'subject_integrity': {
            'identity_core':subj.get('identity_core','not supplied; identity cannot be guaranteed'),
            'age_band':subj.get('age_band','not specified'),
            'body_structure':subj.get('body_structure','not specified'),
            'hair_makeup':subj.get('hair_makeup','not specified'),
            'wardrobe_core':subj.get('wardrobe_core','not specified'),
            'locks':p.get('locks',[]),
            'mutable_fields':p.get('mutable_fields',[]),
            'forbidden_drift':p.get('forbidden_drift',[]),
        },
        'moment_state':{
            'before':f"{scene.get('event','日常情境')}开始前的自然准备",
            'shutter':scene.get('event','人物在场景中有自然、明确的身体状态'),
            'after':'动作按原方向自然延续，不突然定格成广告摆拍',
            'support_points':'需在实际出图时检查足、坐面和接触点',
            'hand_task':scene.get('hand_task','与当前事件对应的自然放置或扶持'),
            'gaze_target':scene.get('gaze_target','与当前事件相关的观察对象'),
        },
        'staging':{
            'participants':[{
                'id':x.get('id'), 'position':x.get('position','unspecified'),
                'gaze_target':x.get('gaze_target','must relate to the shared scene event'),
                'hand_task':x.get('hand_task','must relate to the shared scene event'),
                'contact':'must be physically plausible and independently checked'
            } for x in p.get('subjects',[])],
            'interaction':scene.get('interaction','each participant must have a readable mutual or shared-event relationship'),
            'location':scene.get('location','用户未指定场景'),
            'event':scene.get('event','用户未指定事件'),
            'weather':scene.get('weather','unspecified'),
            'spatial_risks':['support/contact','foreground occlusion','background scale'],
        },
        'camera':{
            'aspect_ratio':visual.get('aspect_ratio','3:4'),
            'shot_size':visual.get('shot_size','medium'),
            'camera_height':visual.get('camera_height','eye'),
            'perspective_rule':'near wide lenses can exaggerate nose/hands/feet; check on actual result',
            'crop_rule':'do not crop an essential joint or action-bearing prop',
        },
        'lighting_material':{
            'source':scene.get('light_source','not supplied; determine a plausible source before generating'),
            'light_direction':visual.get('light_direction','to be determined from actual environment'),
            'mood':visual.get('mood','natural and unforced'),
            'rules':['shared illumination for subject/background','skin and textiles respond differently','folds follow gravity/contact']
        },
        'reference_roles':p.get('references',[]),
        'continuity':{},
        'quality_targets':p.get('quality_targets',['identity or subject legibility','contact and anatomy','lighting coherence']),
        'repair_scope':[],
    }

def gates(mode:str)->list:
    relevant=GATES if mode=='series' else GATES[:-1]
    return [{'gate':x,'state':'unverified','requires':'visual inspection of actual image output'} for x in relevant]

SHOTS=['wide','medium','close_up','three_quarter','full_length']
HEIGHTS=['eye','slightly_low','slightly_high']
ACTIONS=['事前准备','动作启动','关键接触','身体响应','转换位置','暂时停顿','动作余韵']
GAZES=['关注事件来源','观察动作对象','顺应动作转向','短暂注意画面外事物']
HANDS=['自然放松，确认原有支撑','主动完成本次动作的手部任务','维持已有接触或握持','转移支点时手自然配合','动作结束后松开或归位']

def frames(p:dict) -> list:
    n=p.get('series_count',6); locks=set(p.get('locks',[])); visual=p.get('visual',{});scene=p.get('scene',{})
    rows=[];prev=None
    for i in range(n):
        row={
         'frame_id':f'F{i+1:02d}',
         'shot_size':visual.get('shot_size','medium') if ('camera' in locks or 'composition' in locks) else SHOTS[i%len(SHOTS)],
         'camera_height':visual.get('camera_height','eye') if ('camera' in locks or 'composition' in locks) else HEIGHTS[(i//5)%len(HEIGHTS)],
         'action_stage':scene.get('event','user-defined event') if ('action' in locks or 'pose' in locks) else f"{scene.get('event','用户设定的事件')}｜{ACTIONS[i%len(ACTIONS)]}",
         'gaze_target':scene.get('gaze_target','fixed gaze') if 'gaze' in locks else GAZES[(i//3)%len(GAZES)],
         'hand_task':scene.get('hand_task','fixed hand task') if ('hand_task' in locks or 'hands' in locks or 'pose' in locks) else f"{scene.get('hand_task','与本次事件的道具或动作发生关系')}｜{HANDS[i%len(HANDS)]}",
         'scene_event':scene.get('event','moment within an ongoing shoot'),
         'visible_scope':'computed after framing decision',
        }
        row['visible_scope']='head_and_shoulders' if row['shot_size']=='close_up' else 'respect chosen framing'
        keys=['shot_size','camera_height','action_stage','gaze_target','hand_task']
        row['frame_fingerprint']=' | '.join(str(row[k]) for k in keys)
        row['changes_from_previous']=[] if prev is None else [k for k in keys if row[k]!=prev[k]]
        row['variation_pass']=True if prev is None else len(row['changes_from_previous'])>=2
        rows.append(row);prev=row
    return rows

def review(p:dict,mode:str) -> tuple[dict,str,list]:
    warnings=[]
    evidence=p.get('visual_evidence','none')
    issues=sorted(p.get('observed_issues',[]),key=lambda x:SEVERITY[x.get('severity','medium')],reverse=True)
    protected=set(p.get('protected_successes',[]))|set(p.get('locks',[]))
    if evidence=='none' or not issues:
        return {'verdict':'insufficient_evidence','top_failure':None,
                'keep_list':sorted(protected),'repair_scope':[],
                'recheck':['review an actual image; do not infer flaws from requested concept alone'],
                'visual_evidence':evidence,'changes_applied':False},'needs_visual_review',warnings
    top=issues[0]
    collision={'hands':'hand_task','body':'body','material':'visual_language'}
    locked=(top['layer'] in protected or collision.get(top['layer']) in protected)
    if locked:
        warnings.append(f"top issue layer {top['layer']} conflicts with an explicit protect/lock list")
    review={'verdict':'needs_decision' if locked else 'conditional',
            'top_failure':top,'keep_list':sorted(protected),
            'repair_scope':[] if locked or mode=='audit' else [top['layer']],
            'recheck':[f"visually compare the {top['layer']} region before/after",
                       'confirm all protected successful layers are unchanged'],
            'visual_evidence':evidence,'changes_applied':False,
            'observation_status':'reported by external reviewer; not verified by this CLI'}
    return review,('needs_decision' if locked else 'ready_for_external_visual_review'),warnings

def compile_plan(payload:dict,mode:str) -> dict:
    p=check(payload,mode)
    a=authority(p); t=tool_readiness(p,mode)
    result={'version':VERSION,'mode':mode,'status':'planned','intent':p['intent'].strip(),
            'reference_authority':a,'tool_readiness':t,
            'quality_gates':gates(mode),'warnings':[],
            'real_image_generated':False,'real_image_audited':False}
    if a['unresolved']:
        result['status']='needs_decision';result['warnings'].append('reference conflict in '+', '.join(a['unresolved']))
    if mode in ('single','series'):
        result['shot_spec']=shot_spec(p)
        if mode=='series':
            if p.get('series_count',6)>12:
                result['warnings'].append('large series: automated variation is only a first draft; human art direction required for narrative quality')
            result['fixed_state']={
                'subject':p.get('subject',{}),
                'subjects':p.get('subjects',[]),
                'locks':p.get('locks',[]),
                'location':p.get('scene',{}).get('location','unspecified'),
                'light_source':p.get('scene',{}).get('light_source','unspecified'),
                'weather':p.get('scene',{}).get('weather','unspecified'),
            }
            result['frames']=frames(p)
            if not all(x['variation_pass'] for x in result['frames']):
                result['status']='needs_decision';result['warnings'].append('series locked attributes prevent sufficient frame variation')
            fps=[f['frame_fingerprint'] for f in result['frames']]
            if len(fps)!=len(set(fps)):
                result['warnings'].append('some nonadjacent frames repeat framing/action fingerprint; review variety')
        result['warnings'].append('planning only; all image quality gates remain unverified')
    else:
        r,status,warnings=review(p,mode)
        result['review']=r
        result['status']=status if result['status']=='planned' else result['status']
        result['warnings']+=warnings
        if mode=='audit':result['warnings'].append('audit route: no modification permitted')
        if status=='ready_for_external_visual_review' and p.get('visual_evidence')=='user_reported':
            result['warnings'].append('issue is reported, not independently visually confirmed')
    if t['missing_or_unconfirmed']:
        result['warnings'].append('declared tool capabilities insufficient/unconfirmed: '+','.join(t['missing_or_unconfirmed']))
    return result

def main(argv=None)->int:
    ap=argparse.ArgumentParser(description='HuaZhao v6 public photo director spec compiler (no image generation)')
    ap.add_argument('mode', choices=('single','series','repair','audit'))
    ap.add_argument('--input',required=True,type=Path,help='UTF-8 JSON brief')
    ap.add_argument('--out',type=Path,help='output JSON file; must not already exist')
    args=ap.parse_args(argv)
    try:
        if not args.input.is_file():raise InputError(f'input file not found: {args.input}')
        raw=json.loads(args.input.read_text(encoding='utf-8'))
        output=compile_plan(raw,args.mode)
        encoded=json.dumps(output,ensure_ascii=False,indent=2)+'\n'
        if args.out:
            args.out.parent.mkdir(parents=True,exist_ok=True)
            # mode x = atomic create; never overwrite existing file
            with args.out.open('x',encoding='utf-8') as f:f.write(encoded)
            print(f'PLAN_WRITTEN {args.out} status={output["status"]}')
        else:sys.stdout.write(encoded)
        return 0 if output['status'] not in ('needs_decision',) else 3
    except (InputError, json.JSONDecodeError, OSError, UnicodeError) as exc:
        print('INPUT_ERROR:',exc,file=sys.stderr)
        return 2

if __name__=='__main__':sys.exit(main())
