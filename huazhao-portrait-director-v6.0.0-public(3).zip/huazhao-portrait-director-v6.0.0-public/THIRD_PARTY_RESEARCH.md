# 第三方 GitHub 研究与适配裁决（2026-10-09 核验）

只记录公开思路、前提、许可证边界；**未复制第三方代码/权重/照片/提示词**。本文链接为查询入口，不保证所列模型已经安装或可商用。

| 公开项目 | 本包采纳 | 未承诺 / 风险 |
|---|---|---|
| PhotoMaker V2 https://github.com/TencentARC/PhotoMaker | 身份约束应和姿态/风格分治 | InsightFace / 权重商业条款需单独检查，不自动部署 |
| InstantID https://github.com/instantX-research/InstantID | 单张身份证明路径与视觉布置分开 | 图片相似性需真实复核 |
| PuLID https://github.com/ToTheBeginning/PuLID | 身份忠实度/编辑自由度权衡 | 身份强度不是越高越好 |
| ControlNet https://github.com/lllyasviel/ControlNet | 姿态/深度是独立控制信号 | ControlNet 的具体权重必须与基础模型兼容 |
| ComfyUI IPAdapter Plus https://github.com/cubiq/ComfyUI_IPAdapter_plus | 不同参考承担不同视觉职责 | 节点兼容版本、许可证另查 |
| ComfyUI-Photoshoot https://github.com/ralksta/ComfyUI-Photoshoot | 借鉴「人物资产固定→组图镜头变化」 | 项目主流节点写**文本**，并不提供跨模型身份保持保证 |
| ComfyUI Impact Pack https://github.com/comfyorg/comfyui-impact-pack | 局部 FaceDetailer、掩膜 Detailer 提供失败层隔离思路 | 不当作去身份漂移万能修复；Impact Subpack 另装，依赖和版本需核对 |
| comfyui_controlnet_aux https://github.com/Fannovel16/comfyui_controlnet_aux | DWPose、Depth 预处理映射到姿态/空间层 | 预处理器只是生成条件图，不是最终图像模型 |
| ComfyUI inpainting examples https://github.com/comfyanonymous/ComfyUI_examples/tree/master/inpaint | 用 masks 做局部返修的公开操作模型 | 局部重绘仍可能影响邻近脸/衣服，要对照检查 |
| BFL FLUX inference https://github.com/black-forest-labs/flux | 面向不同能力区分文本生图、修图、结构控制 | FLUX.1 dev/Kontext 等权重常有非商用条款，不能一概推广 |

**判断**：最值得落地的不是把十个仓库绑在一起，而是把“谁决定哪一层”“是否支持该控制”“做坏后只改哪里”“系列有没有信息变化”编成用户可直接用的规则与可验收契约。部署外部项目时，请查当前 README、官方模型卡和对应许可证。历史旧项目的代码或参数不要强制迁移至新模型。
