# Validation Reference

Use this file before claiming an upgraded Skill is better.

## What validation must prove

A repair is useful only if it improves the target behavior **and** keeps important existing behavior intact.

Validation answers four questions:

1. Did the known failure improve?
2. Did normal behavior remain at least as good?
3. Did the repair create a new failure?
4. How strong is the evidence behind that conclusion?

## Build the test set

Prefer real examples. When available, include:

- prompts that failed;
- prompts that previously worked well;
- user-corrected outputs;
- edge cases that stress the changed rule.

Add generated probes only to fill coverage gaps.

A compact default set for a small Skill:

- 2 target-failure cases;
- 2 normal cases;
- 1 ambiguous/missing-information case;
- 1 adversarial or boundary case;
- 1 protected-strength case.

For a large or high-cost Skill, expand by behavior family rather than multiplying near-duplicate prompts.

## Baseline vs candidate

Run the same case against the old and new versions whenever execution is possible.

Judge against task-specific criteria, not generic polish. Record:

- baseline result;
- candidate result;
- which is better, or tie;
- one concrete reason;
- any regression or side effect.

If direct execution is unavailable, perform a static scenario trace: follow the instructions as written and identify what each version would require or block. Label this as structural validation, not runtime proof.

## Holdout

When enough real examples exist, separate some before editing and do not use them to design the fix.

Use the held-out cases only after the candidate is written. Their purpose is to catch a repair that memorizes visible examples instead of improving the governing rule.

Do not force a percentage split on tiny samples. With five examples, “40% holdout” sounds scientific but gives almost no statistical meaning. Keep at least one or two representative examples unseen when feasible and describe the limitation honestly.

## No-regression gate

A candidate fails if any of these are true:

- the target failure remains reproducible;
- a protected strength is materially worse;
- the common path gains unnecessary steps or questions;
- a formerly portable Skill becomes environment-dependent;
- the output contract becomes less reliable;
- the fix relies on a capability the target environment may not have and gives no fallback;
- the repair creates a larger contradiction than the one it removed.

A minor stylistic difference is not automatically a regression. Tie every regression claim to the Intent lock or an explicit acceptance criterion.

## Cold start validation

When real samples are missing:

1. Derive probes from the Skill's purpose and trigger boundary.
2. Include both “should trigger” and “should not trigger” cases.
3. Include a normal case, a sparse-input case, and a conflict case.
4. Make conservative changes.
5. Report confidence as provisional.

Cold start can validate instruction logic and obvious failure paths. It cannot prove real-world frequency or user preference.

## Confidence labels

Use plain labels tied to evidence:

**High confidence** — target failures were reproduced, repaired, and re-tested; representative normal cases also pass; no material regression found.

**Moderate confidence** — strong structural evidence and some representative tests, but limited real failure data or no independent execution path.

**Provisional** — mostly cold-start probes or static analysis; useful for release, but real use may expose additional failures.

Do not convert these labels into fake probabilities.

## Rating when the user asks for a score

A score can be useful for communication, but it is not validation.

If asked, give one approximate score only after the evidence. Explain the main factors that limit it. Avoid false precision such as 9.37/10 unless there is an actual calibrated rubric behind the decimals.

## Final verification checklist

Before delivery, verify:

- trigger description matches the intended use;
- frontmatter parses;
- every referenced file exists;
- no referenced file is dead or missing;
- no main-path instruction contradicts another;
- failure repair is present in the actual file, not just the report;
- normal path remains direct;
- blocking questions are genuinely blocking;
- confidence wording matches the evidence;
- packaged artifact was re-opened or re-read after packaging when tools permit.
