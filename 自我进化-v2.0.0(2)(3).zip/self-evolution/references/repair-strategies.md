# Repair Strategies

Use this file after diagnosis, before a substantial rewrite.

## Strategy selection

Choose by failure shape, not by preference for a particular writing style.

| Failure shape | Strong default |
|---|---|
| One isolated bad rule | Local patch |
| Same rule repeated in several places | Consolidate into one source of truth |
| Rule applies only sometimes | Observable conditional branch |
| Output shape keeps drifting | Positive output contract |
| Agent knows rule but skips it under pressure | Hard invariant + red flags |
| Vague quality target | Concrete signals + one strong example |
| Too many questions | Safe-default policy + explicit blocking-question test |
| Missing-data paralysis | Evidence ladder + cold-start fallback |
| Platform coupling | Separate core behavior from optional environment actions |
| Many contradictions / tangled stages | Structural rewrite or full rebuild |

## 1. Positive recipe

Best for wrong-shaped outputs.

Instead of listing ten things the output must not do, define what the output is:

- first: decision or deliverable;
- then: evidence or rationale;
- then: limitations or next action if needed.

A positive shape leaves less room for negotiation than a long negative list.

## 2. Conditional routing

Best when one workflow does not fit every case.

Write branches around observable conditions:

- If the user asks only for diagnosis → do not modify.
- If a known failure is reproducible → targeted repair.
- If architecture causes several failures → full rebuild.
- If evidence is thin → cold start, conservative changes, lower confidence.

Avoid exceptions such as “usually do X unless it seems better not to.” Conditions should be visible in the task.

## 3. Single source of truth

Best for contradictions and maintenance drift.

Choose one place for each class of rule:

- trigger conditions → frontmatter;
- invariants and precedence → main Skill;
- heavy taxonomy → reference file;
- output format → one delivery contract;
- environment-specific details → optional adapter or task-local instruction.

Delete duplicate versions rather than keeping “helpful reminders” everywhere.

## 4. Precedence repair

Use when instructions conflict.

A compact default hierarchy for most Skills:

1. current explicit user request;
2. safety and irreversible-action constraints;
3. task-specific confirmed decisions;
4. Skill's declared intent and invariants;
5. reusable defaults and examples.

Do not bury precedence in prose. Put it near the conflict-prone rules.

## 5. Safe-default compression

Use when clarification becomes friction.

Replace “ask before proceeding” with:

> Ask only when the missing fact would materially change the result and cannot be inferred safely. Otherwise choose the lowest-risk reasonable default and continue.

Then list the genuinely blocking cases. This preserves control without turning every run into an interview.

## 6. Evidence-ladder repair

Use when the Skill treats ideal evidence as mandatory.

Replace one hard gate with tiers:

- real failure samples → strongest;
- user corrections → strong;
- current artifacts → moderate;
- generated probes → provisional.

The behavior adapts to evidence quality instead of refusing to work.

## 7. Example hardening

Use when abstract wording produces unstable behavior.

A good example should demonstrate one high-value pattern and vary accidental details.

Bad example design:
- every example has the same length, opening, tone, or structure;
- example content is so specific that surface details look mandatory;
- the example contradicts the written rule.

Better:
- show the decision boundary;
- explain why the example qualifies;
- make explicit which parts are essential and which are replaceable.

## 8. De-bloating

Remove content when it does not change a decision.

Candidates for deletion:

- motivational philosophy repeated after the core principle is already clear;
- multiple tables expressing the same workflow;
- ceremonial stages that add no information;
- commands that merely duplicate natural-language triggers;
- permanent state requirements for information that can be inferred from current input;
- long disclaimers where a clear confidence label would suffice.

Move long but useful material into references and load it only when needed.

## 9. Platform decoupling

Separate **what must happen** from **how one environment happens to do it**.

Core rule example:

> Validate the packaged artifact in a fresh location before declaring the release clean.

This remains valid whether the environment uses a terminal, file tool, workspace, or another execution surface. Avoid turning one implementation into the Skill's identity.

## 10. Full rebuild pattern

Use when patching would preserve the problem.

Rebuild in this order:

1. Restate the Intent lock.
2. Keep only proven strengths and essential invariants.
3. Design the shortest default path from trigger to desired outcome.
4. Add conditional branches only for materially different cases.
5. Put heavyweight reference material outside the main path.
6. Add validation and failure exits.
7. Run regression checks against the old version.
8. Remove obsolete files rather than leaving compatibility clutter unless compatibility was requested.

The new version should be explainable without telling the history of the old version.

## Anti-patterns

### Constraint stacking
Adding one more “must” for every failure eventually creates a brittle Skill. Fix the decision model instead.

### Cosmetic rewrite
Changing headings and prose while preserving the same bad gates does not count as a rebuild.

### Complexity prestige
Extra files, stages, databases, or orchestration do not make a Skill more advanced. Every component must earn its place by changing behavior.

### Hidden behavior change
A cleaner rewrite that silently narrows the user's intended capability is a regression.

### Universal best practice
Aesthetic and creative Skills often need controlled variation. Do not flatten them into one generic house style.
