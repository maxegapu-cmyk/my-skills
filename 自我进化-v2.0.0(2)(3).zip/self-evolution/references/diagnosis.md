# Diagnosis Reference

Use this file when the main Skill identifies a nontrivial failure or when the target package mixes several responsibilities.

## Classify by dominant success condition

Do not force every Skill into one category. Classify the dominant dimension and note secondary dimensions.

### Functional
Success is primarily correct action, transformation, retrieval, routing, validation, or tool use.

Check first: trigger accuracy, input assumptions, ordering, state, error paths, output schema, side effects.

### Creative
Success is primarily originality, narrative judgment, voice, ideation, or expressive quality.

Check first: generic phrasing, over-structuring, over-constraint, loss of authorial intent, repetitive devices, weak examples.

### Visual / aesthetic
Success is primarily composition, style, image direction, visual coherence, presentation, or perceptual quality.

Check first: reference fidelity, accidental feature copying, visual priorities, invariants vs freedoms, overfitting to one reference.

### Mixed
Success depends on two or more dimensions. Identify which dimension decides success and which ones act as hard gates.

Example: a storyboard Skill may be creative in shot invention but functional in format compliance. “Beautiful but unusable” still fails.

## Evidence reading

For every failure sample, separate:

- **Input:** what the user asked.
- **Expected behavior:** what should have happened.
- **Actual behavior:** what happened instead.
- **Governing text:** which instruction most likely caused or failed to prevent it.
- **Competing pressure:** what other instruction or default behavior pulled the model away.

A complaint without a reproducible example is still useful, but it is weaker evidence than a prompt/output pair.

## Failure taxonomy

### A. Trigger and scope failures

**A1 — Missed trigger**  
The Skill should activate but its description is too narrow or uses internal terminology the user never says.

**A2 — False trigger**  
The Skill activates on adjacent tasks it should leave alone.

**A3 — Scope creep**  
The Skill starts solving extra problems or modifying files outside the requested scope.

### B. Intent and precedence failures

**B1 — Intent drift**  
The process becomes more important than the user's actual goal.

**B2 — Conflicting rules**  
Two instructions imply incompatible behavior and no clear precedence resolves them.

**B3 — Stale rule dominance**  
A historical/default rule beats a newer explicit requirement.

**B4 — Hidden invariant**  
A behavior the user cares about is not written as a protected constraint and disappears during optimization.

### C. Input and context failures

**C1 — Unnecessary clarification**  
The Skill asks questions that available context or a safe default could answer.

**C2 — Missing-data paralysis**  
The Skill refuses to operate without ideal logs, references, tools, or metadata.

**C3 — Context dropout**  
Important supplied information is not carried into later decisions.

**C4 — Assumption smuggling**  
The Skill invents requirements that were never requested.

### D. Output failures

**D1 — Contract drift**  
Required sections, fields, formats, or artifacts are missing or reordered unpredictably.

**D2 — Explanation replaces delivery**  
The Skill describes how to do the work instead of producing the requested result.

**D3 — Runaway length**  
Process narration, repeated caveats, or duplicated rules bury useful output.

**D4 — Under-specification**  
The Skill gives broad advice where exact steps or decisions are needed.

### E. Rigidity and generalization failures

**E1 — Over-constraint**  
Rules written for one example are applied to every case.

**E2 — Under-constraint**  
The Skill lacks enough boundaries to protect important outcomes.

**E3 — Example overfit**  
Surface details of examples become accidental requirements.

**E4 — Branch explosion**  
Too many exceptions make the Skill hard to reason about and easy to contradict.

### F. Creative and aesthetic failures

**F1 — Generic model voice**  
Outputs repeatedly use formulaic transitions, symmetrical structures, or vague polish instead of the requested voice.

**F2 — Style drift**  
Content remains correct but the intended visual or linguistic character fades.

**F3 — Reference contamination**  
The Skill copies incidental content from a reference instead of learning the intended attributes.

**F4 — Taste flattening**  
One “best practice” style is imposed on outputs that should vary by audience, genre, scene, or purpose.

### G. Tool and environment failures

**G1 — Environment coupling**  
The Skill assumes a specific filesystem, command set, application, or execution topology when the capability itself is portable.

**G2 — Capability bluffing**  
The Skill tells the model to use tools or actions that may not exist and provides no fallback.

**G3 — Irreversible default**  
The Skill treats destructive or external actions as routine without an explicit request.

### H. Evaluation failures

**H1 — Self-confirming test**  
Tests merely restate the new wording and cannot reveal regressions.

**H2 — Synthetic overfit**  
The repair is tuned to generated test prompts but not representative use.

**H3 — Metric substitution**  
Length, structure, style similarity, or a score replaces actual task success.

**H4 — No baseline**  
The new version is judged in isolation, so “better” has no reference point.

### I. Packaging and external-release failures

**I1 — Identity residue**  
Creator names, repository references, private project names, or source-specific branding remain without functional need.

**I2 — State residue**  
Logs, caches, registries, temporary files, generated outputs, or empty state directories are shipped.

**I3 — Workflow residue**  
Build-time or maintenance rituals are exposed as user-facing requirements even though they are not needed to operate the Skill.

**I4 — Dead baggage**  
Files are included that the final Skill never references or needs.

## Root-cause test

Before editing, ask of each proposed fix:

1. If this sentence were changed, would the observed failure actually stop?
2. Would the same failure reappear through a different rule?
3. Is the problem local, or is the file structure causing it?
4. What already-good behavior could this fix damage?

If several failures point to the same governing rule or structural boundary, fix the shared cause once rather than stacking patches.
