# Release Cleanroom

Use this file when producing a pure, external, shareable, client-facing, or privacy-clean Skill package.

The cleanroom is not a cosmetic rename pass. It asks one question of every shipped item:

> Does this item help the recipient operate the Skill?

If not, it needs a specific reason to remain.

## 0. Ownership gate

Before stripping provenance or notice material, confirm from the user's request or context that they own the package or have permission to produce such a release. If that is not established, clean operational residue but preserve ownership-related material.

## 1. Identity sweep

Search all text and metadata for unnecessary:

- creator names or aliases;
- private team or project names;
- repository names and URLs;
- internal product nicknames;
- contact details;
- local usernames;
- organization-specific terminology that is not part of the Skill's public purpose.

Do not simply replace one private name with another. Rewrite the surrounding sentence so it reads naturally without provenance context.

## 2. Environment sweep

Remove or generalize nonessential assumptions about:

- local absolute paths;
- one specific editor, shell, workspace, or agent application;
- one machine's folder layout;
- private environment variables;
- maintenance commands recipients do not need;
- branch/review/release rituals that belong to the builder rather than the user.

Keep environment-specific instructions only when the Skill's actual purpose depends on that environment.

## 3. State sweep

Do not ship operational residue such as:

- logs;
- caches;
- registries;
- preference histories;
- temporary candidates;
- generated test outputs;
- session transcripts;
- empty state directories;
- local databases created during development.

If the Skill needs state at runtime, describe the required state contract in the Skill and let the operating environment create it when needed. Do not ship private or stale state as a starter kit.

## 4. Content sweep

Check for hidden internal information embedded in otherwise public files:

- comments explaining private strategy;
- examples copied from unrelated confidential projects;
- prompt fragments that reveal unnecessary internal workflows;
- changelog-style notes describing where the material came from;
- screenshots or data containing private identifiers;
- dead instructions kept “just in case.”

Rewrite examples generically where possible while preserving the behavior they teach.

## 5. Dependency sweep

Every shipped file must be one of:

- the main Skill;
- a reference the main Skill actually loads;
- a tool/template required for a declared capability;
- a user-facing guide.

Delete orphan files. Then scan references again to ensure nothing points to what was removed.

## 6. Portability sweep

Read the package as a recipient who has only the files in the archive.

The recipient should not need to know:

- how the package was developed;
- what private environment produced it;
- where earlier versions lived;
- which internal workflow maintained it;
- which historical state files used to exist.

They should be able to infer what the Skill does, when to use it, what it needs, and what it produces.

## 7. Package-level verification

Do not stop after cleaning the working directory.

1. Create the final archive.
2. Extract it into a fresh directory.
3. List every file.
4. Re-run identity, environment, state, and dead-reference scans on the extracted copy.
5. Parse the main frontmatter.
6. Confirm every reference path resolves inside the package.
7. Confirm no extra top-level files appeared during packaging.

Only the packaged copy proves what the recipient will receive.

## Clean release report

Keep the report short:

- **Identity:** clean / intentional traces retained.
- **Environment:** portable / required coupling retained.
- **State:** no development state shipped / declared runtime state only.
- **References:** all resolve / list any intentional external dependency.
- **Package re-check:** passed / list exact failure.

Do not claim “fully clean” if any category was not actually checked.
