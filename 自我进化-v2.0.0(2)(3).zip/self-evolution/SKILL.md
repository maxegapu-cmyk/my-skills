---
name: self-evolution
description: Use when a user asks to audit, diagnose, improve, simplify, rebuild, clean, externalize, or validate an agent Skill or SKILL.md, especially when outputs are weak, inconsistent, bloated, over-constrained, hard to trigger, platform-coupled, or unsafe to share.
---

# 自我进化

## Overview

自我进化（Self Evolution） improves agent Skills by finding the smallest set of changes that fixes the real failure without damaging what already works. It can also perform a full rebuild when the architecture itself is the problem.

Core principle: **protect intent, repair causes, verify behavior, ship cleanly.**

Do not confuse a longer Skill with a better Skill. Do not confuse a cleaner-looking rewrite with a verified improvement. The target is behavior under real use.

## Operating modes

Infer the mode from the user's request. Do not make the user choose a command unless the request is genuinely ambiguous.

| Mode | Use when | Default action |
|---|---|---|
| **Audit only** | User asks what is wrong, whether it is good, or wants a review | Inspect and report; do not modify files |
| **Targeted repair** | One or a few reproducible failures are known | Fix those failures with minimal collateral change |
| **Full rebuild** | Architecture is tangled, contradictory, platform-bound, or the user explicitly asks for a rebuild | Reconstruct around the same core intent |
| **Clean external release** | User asks for a pure, shareable, external, public, or privacy-clean edition | Improve if requested, then remove nonessential provenance, environment coupling, state, and private baggage |

If the user explicitly asks to create, modify, repair, rebuild, package, or clean the Skill, perform the work within the available tool scope. Do not stop at recommendations.

## Intent lock

Before changing anything, establish an **Intent lock** from the request and the current Skill:

1. **Purpose** — what problem the Skill exists to solve.
2. **Trigger** — when it should activate.
3. **Required outcomes** — what a successful run must produce or accomplish.
4. **Protected strengths** — behavior already working that must not regress.
5. **Change freedom** — what may be simplified, replaced, split, or removed.

Treat the first four as the behavioral contract. Implementation details are not sacred unless the user explicitly makes them so.

When the existing Skill and the user's current request conflict, the current request wins. State any material change of intent plainly.

## Evidence ladder

Use the strongest available evidence first. Never refuse useful work merely because high-grade evidence is missing.

**Evidence ladder, strongest to weakest:**

1. Reproducible failure cases with the prompt, output, and expected result.
2. Real outputs or user corrections showing what succeeded or failed.
3. Explicit user requirements and acceptance criteria.
4. The current Skill and its supporting files.
5. Representative probes generated from the Skill's declared purpose.

If levels 1-2 are absent, use **Cold start** mode: create representative probes, include edge cases, make conservative changes, and label behavioral conclusions as provisional rather than pretending they are field-tested.

## Whole-package scan

When a package is supplied, inspect the full package before rewriting the main file. Look for:

- duplicated or contradictory instructions;
- references that are never used;
- environment-specific paths or workflows;
- hidden state or stale generated files;
- examples that conflict with rules;
- trigger language that is too narrow or too broad;
- output contracts scattered across files;
- unnecessary confirmation gates;
- hard requirements that the target environment cannot satisfy;
- privacy, provenance, or sharing baggage not needed for operation.

Load `references/diagnosis.md` for the full failure taxonomy.

## Diagnose causes, not symptoms

For each material failure, write a compact causal chain:

**Observed failure → governing instruction → why that instruction fails → minimum repair class**

Example:

> The Skill keeps asking for logs before it will help → evidence policy treats logs as mandatory → cold-start users are blocked even when the Skill can inspect the supplied file → change the evidence policy from a gate to a confidence ladder.

Prioritize issues by **impact × frequency × blast radius**. A rare wording blemish should not outrank a rule that makes the entire Skill unusable.

## Choose the repair class

Use the least invasive class that can actually remove the root cause.

### 1. Local patch
Use when the architecture is sound and the failure is isolated: a bad trigger, missing edge case, unclear output slot, or one contradictory rule.

### 2. Structural repair
Use when multiple failures share one cause: duplicated policy, mixed responsibilities, unclear precedence, scattered output rules, or repeated exceptions.

### 3. Full rebuild
Use when the current structure itself creates the failures, when removing one issue exposes several more, when the Skill is strongly coupled to one environment, or when the user explicitly requests a clean reconstruction.

A full rebuild preserves the Intent lock, not the old wording or file layout.

Load `references/repair-strategies.md` before choosing major changes.

## Build the improved version

For nontrivial repairs, consider at least two materially different approaches internally before selecting one. Diversity must be architectural or behavioral, not cosmetic wording variation.

Good differences include:

- recipe vs prohibition;
- default path plus conditional branches vs one universal workflow;
- single orchestration file vs orchestration plus on-demand references;
- example-led guidance vs abstract adjectives;
- strict output contract vs scattered reminders;
- stateful workflow vs stateless inference from supplied evidence.

Then write the smallest coherent version that satisfies the Intent lock and addresses the diagnosed causes.

### Instruction-shaping rules

- Put trigger conditions in frontmatter; put behavior in the body.
- Lead with positive output recipes when the problem is wrong output shape.
- Use hard prohibitions only for true invariants or dangerous failure paths.
- Replace vague adjectives with observable signals or examples.
- Put precedence rules near the conflict they resolve.
- Convert repeated exceptions into conditional branches.
- Remove ritual steps that do not improve the output.
- Keep heavy taxonomies and procedures in references loaded on demand.
- Do not add dependencies merely to make the package look sophisticated.

## Validate before claiming improvement

Load `references/validation.md` and create a test set that covers the failures being repaired plus representative normal cases.

At minimum compare the baseline and candidate on:

1. **Target failure** — does the known problem stop happening?
2. **Normal path** — does the common use case still work?
3. **Boundary case** — does the Skill behave sensibly with missing or conflicting information?
4. **Protected strength** — did anything named in the Intent lock regress?
5. **Instruction economy** — did the repair introduce unnecessary friction, repetition, or output bloat?

Use a **No-regression gate**: a candidate is not accepted merely because it fixes the headline bug. If it materially damages a protected strength or common path, repair again or reject it.

If enough real examples exist, keep some examples unseen during repair and use them as a holdout check. If there are too few examples for a meaningful holdout, say so; do not invent statistical confidence.

A user-requested numerical rating is allowed as a summary, but it must sit beside concrete findings and test evidence. Never use a single number as proof.

## Clean external release

When the user asks for a clean/shareable/pure external edition, load `references/release-cleanroom.md` after functional validation.

The clean release is a separate gate. A Skill can be functionally strong and still be unsuitable to share.

Default clean-release goals:

- no creator or repository identity unless the user wants it retained;
- no private history, machine paths, temporary files, state stores, or session residue;
- no environment-specific workflow unless it is essential to the Skill's purpose;
- no dead references or files that the final Skill never loads;
- no private prompt fragments or unrelated project rules;
- no packaging artifacts that reveal internal working methods without operational value;
- no empty state folders shipped “for later.”

Only strip provenance or notice material when the user states the package is theirs or they have permission to do so. Otherwise preserve required ownership information and clean only non-protected baggage.

After cleaning, scan the packaged artifact itself, not only the working directory.

## Delivery contract

For an **audit**, lead with the verdict, then list issues by severity. Each issue should contain:

- evidence;
- consequence;
- minimum repair.

For a **repair or rebuild**, deliver the actual modified artifact first, then summarize:

- what changed;
- what was deliberately preserved;
- what verification was run;
- known limitations or unverified behavior.

For a **clean external release**, also report the cleanroom result: what categories were removed and whether any intentional environment or identity traces remain.

Do not bury the deliverable beneath process narration.

## When to ask a question

Ask only when missing information would materially change the result and cannot be safely inferred. Otherwise choose the lowest-risk reasonable default and continue.

Examples that usually do **not** require a question:

- no historical usage log;
- no numeric quality target;
- no explicit Skill type;
- no preferred file layout;
- no independent evaluator.

Examples that may require a question if unresolved:

- two plausible but incompatible core purposes;
- an irreversible external action;
- uncertain ownership when the request includes stripping provenance material.

## Red flags

If any of these appear during an upgrade, re-check the design before shipping:

- the new Skill is much longer but fixes no additional failure;
- the same rule appears in three places;
- every case is forced through one rigid workflow;
- the Skill stops when evidence is imperfect even though a conservative fallback exists;
- examples and rules disagree;
- the evaluator rewards verbosity or polish rather than task success;
- the rewrite silently changes the user's core purpose;
- “external clean” still ships private state, environment coupling, or dead files;
- the package works only in the environment where it was rebuilt.

## Quick reference

| Symptom | First move |
|---|---|
| Wrong tasks trigger the Skill | Repair frontmatter trigger boundaries |
| Correct trigger, wrong behavior | Trace governing instructions and precedence |
| Output shape varies | Define one positive output contract |
| Skill is rigid | Replace unconditional rules with observable conditions |
| Skill is bloated | Consolidate repeated policy and move heavy detail on demand |
| Creative output feels generic | Add concrete positive/negative signals; reduce abstract tone labels |
| Tool-dependent Skill breaks elsewhere | Separate essential capability from environment adapter |
| No real failure samples | Use Cold start probes and lower confidence |
| Rebuild fixes one thing but harms another | Enforce the No-regression gate |
| User wants a shareable pure version | Run the clean external release gate |

## References

Load only what the current task needs:

- `references/diagnosis.md` — Skill types, evidence reading, failure taxonomy, root-cause diagnosis.
- `references/repair-strategies.md` — repair patterns and rebuild decisions.
- `references/validation.md` — test design, comparison, holdout, confidence, regression checks.
- `references/release-cleanroom.md` — external-release sanitation and package-level privacy checks.
