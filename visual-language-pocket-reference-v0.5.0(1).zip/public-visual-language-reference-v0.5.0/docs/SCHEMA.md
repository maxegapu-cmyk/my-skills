# 数据字段

每条记录包含以下核心字段：

| 字段 | 含义 |
|---|---|
| `id` | 稳定词条编号 |
| `zh` | 中文名称 |
| `en` | 英文名称 |
| `category` | 所属分类 |
| `term_status` | `standard_term` 为基础术语，`normalized_descriptor` 为扩展描述 |
| `public_definition` | 简明中文解释 |
| `visible_effects` | 画面中可直接观察到的表现 |
| `prompt_phrases` | 可复制的英文 Prompt 表达 |
| `related_terms` | 相关检索词 |
| `opposite_direction` | 反向视觉方向 |
| `release_added` | 可选字段；标记词条首次加入的版本 |

`normalized_descriptor` 用于把位置、方向、程度、分区、路径、密度与尺度等自然语言要求整理成容易搜索和组合的表达；它们是普通描述，不宣称为行业正式术语。
