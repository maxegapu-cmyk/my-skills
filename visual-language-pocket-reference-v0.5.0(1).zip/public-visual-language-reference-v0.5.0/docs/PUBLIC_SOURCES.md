# 公开知识参考

本词典围绕构图、色彩、光线、空间、形态、节奏、视觉层级与 Gestalt 知觉等常见视觉概念整理。公开资料用于确认一般机制；词条名称、中文解释和英文 Prompt 均针对本工具重新编写。

## 构图、空间与注意路径

- Adobe — Photography Composition Basics  
  https://www.adobe.com/creativecloud/photography/technique/composition.html
- Adobe — Perspective Photography  
  https://www.adobe.com/creativecloud/photography/technique/perspective.html
- Adobe — Leading Lines in Photography  
  https://www.adobe.com/creativecloud/photography/technique/leading-lines.html
- Adobe — Negative Space Photography  
  https://www.adobe.com/creativecloud/photography/type/negative-space-photography.html
- Adobe — Emphasis in Photography  
  https://www.adobe.com/creativecloud/photography/discover/emphasis-in-photography.html
- Nikon USA — 5 Easy Composition Guidelines  
  https://www.nikonusa.com/learn-and-explore/c/tips-and-techniques/5-easy-composition-guidelines
- Getty — Understanding Formal Analysis: Principles of Design  
  https://www.getty.edu/education/teachers/building_lessons/formal_analysis2.html

## 色彩、光线与形态

- Getty — Understanding Formal Analysis: Elements of Art  
  https://www.getty.edu/education/teachers/building_lessons/formal_analysis.html
- Adobe — Colour Wheel Combinations  
  https://www.adobe.com/uk/creativecloud/design/discover/color-wheel.html
- Adobe — Colour Contrast Guide  
  https://www.adobe.com/uk/creativecloud/design/discover/color-contrast.html
- Adobe — Diffused Light Photography  
  https://www.adobe.com/creativecloud/photography/technique/diffused-light.html
- Nikon USA — Bending the Light  
  https://www.nikonusa.com/learn-and-explore/c/nikon-creators/bending-the-light
- Adobe Substance 3D — Physical Lights  
  https://helpx.adobe.com/substance-3d-stager/desktop/objects/physical-lights.html
- Blender Manual — Light Objects  
  https://docs.blender.org/manual/en/latest/render/lights/light_object.html
- Material Design — About Shape  
  https://m2.material.io/design/shape/about-shape.html

## 知觉、分组、比例与节奏

- Interaction Design Foundation — Figure/Ground, Prägnanz, Closure and Common Fate  
  https://assets.interaction-design.org/literature/article/the-laws-of-figure-ground-praegnanz-closure-and-common-fate-gestalt-principles-3
- Interaction Design Foundation — Proximity, Connectedness and Continuation  
  https://assets.interaction-design.org/literature/article/laws-of-proximity-uniform-connectedness-and-continuation-gestalt-principles-2
- Nielsen Norman Group — 5 Principles of Visual Design  
  https://www.nngroup.com/articles/principles-visual-design/
- Nielsen Norman Group — Visual Hierarchy  
  https://www.nngroup.com/articles/visual-hierarchy-ux-definition/
- Getty — Formal Analysis Resources  
  https://www.getty.edu/education/teachers/classroom_resources/formal_analysis.html
- Smarthistory — How to Do Visual Analysis  
  https://smarthistory.org/visual-analysis/

## 使用边界

- **基础术语**是视觉设计、摄影和知觉领域中常见的概念。
- **扩展描述**是为了让方向、位置、程度、密度、路径和尺度关系更方便检索与组合而整理的普通描述。
- 英文短语用于清楚表达画面意图，不是模型官方参数，也不保证不同模型产生完全相同的结果。
