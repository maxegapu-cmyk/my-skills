import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "scripts" / "wechat_group_digest.py"


class CLITests(unittest.TestCase):
    def test_prepare_file_writes_ai_ready_run(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            source = td / "input.json"
            source.write_text(json.dumps({
                "group": {"name": "测试群"},
                "messages": [
                    {"sender": "A", "timestamp": 1, "time": "2026-09-25 09:00:00", "type": "文本", "content": "决定：今晚发布"},
                    {"sender": "B", "timestamp": 2, "time": "2026-09-25 09:01:00", "type": "文本", "content": "TODO 明天补文档"},
                ],
                "stats": {"last_message_timestamp": 2},
            }, ensure_ascii=False), encoding="utf-8")
            out = td / "out"
            proc = subprocess.run([
                sys.executable, str(CLI), "prepare",
                "--input", str(source),
                "--data-root", str(out),
                "--privacy", "strict",
                "--chunk-chars", "250",
            ], capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 0, proc.stderr)
            result = json.loads(proc.stdout)
            run_dir = Path(result["run_dir"])
            self.assertTrue((run_dir / "pack.json").is_file())
            self.assertTrue((run_dir / "source.md").is_file())
            self.assertTrue((run_dir / "AI_PROMPT.md").is_file())
            self.assertTrue((run_dir / "chunks" / "chunk-001.md").is_file())
            pack = json.loads((run_dir / "pack.json").read_text(encoding="utf-8"))
            self.assertEqual(pack["group"]["name"], "测试群")
            self.assertEqual(pack["privacy"], "strict")
            self.assertEqual(pack["messages"][0]["sender"], "成员A")

    def test_commit_advances_group_state_only_after_report_exists(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            run = td / "run"
            run.mkdir()
            pack = {
                "group": {"name": "测试群", "key": "abc123"},
                "source": {"last_timestamp": 77},
                "fingerprint": "finger",
            }
            (run / "pack.json").write_text(json.dumps(pack, ensure_ascii=False), encoding="utf-8")
            report = run / "report.md"
            report.write_text("# 日报\n内容", encoding="utf-8")
            state_root = td / "state"
            proc = subprocess.run([
                sys.executable, str(CLI), "commit",
                "--run-dir", str(run),
                "--report", str(report),
                "--state-root", str(state_root),
            ], capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 0, proc.stderr)
            result = json.loads(proc.stdout)
            state_path = Path(result["state_path"])
            self.assertTrue(state_path.is_file())
            state = json.loads(state_path.read_text(encoding="utf-8"))
            self.assertEqual(state["last_timestamp"], 77)

    def test_doctor_never_requires_chat_access(self):
        proc = subprocess.run([
            sys.executable, str(CLI), "doctor", "--json"
        ], capture_output=True, text=True, encoding="utf-8")
        self.assertEqual(proc.returncode, 0, proc.stderr)
        result = json.loads(proc.stdout)
        self.assertIn("python", result)
        self.assertIn("yichen_backend", result)

    def test_snapshot_chat_id_since_last_requires_group_name(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            snapshot = td / "snapshot"
            snapshot.mkdir()
            backend = td / "backend"
            script = backend / "scripts" / "vault_cli.py"
            script.parent.mkdir(parents=True)
            script.write_text("print('{}')\n", encoding="utf-8")
            proc = subprocess.run([
                sys.executable, str(CLI), "prepare",
                "--snapshot", str(snapshot),
                "--chat-id", "abc123",
                "--since-last",
                "--yichen-root", str(backend),
                "--data-root", str(td / "out"),
            ], capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(proc.returncode, 2)
            self.assertIn("--since-last with --chat-id requires --group", proc.stderr)


if __name__ == "__main__":
    unittest.main()
