import json
import os
import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import digest_core  # noqa: E402


class DigestCoreTests(unittest.TestCase):
    def test_strict_redaction_is_stable_and_strips_private_ids(self):
        rows = [
            {
                "local_id": 1,
                "server_id": 99,
                "sender": "Alice",
                "sender_username": "wxid_secret",
                "timestamp": 100,
                "time": "2026-09-25 09:00:00",
                "type": "文本",
                "content": "项目今天发版",
                "db": "/private/a.db",
                "table": "Msg_deadbeef",
            },
            {
                "local_id": 2,
                "sender": "Alice",
                "sender_username": "wxid_secret",
                "timestamp": 101,
                "time": "2026-09-25 09:00:01",
                "type": "文本",
                "content": "收到",
            },
            {
                "local_id": 3,
                "sender": "Bob",
                "sender_username": "wxid_other",
                "timestamp": 102,
                "time": "2026-09-25 09:00:02",
                "type": "文本",
                "content": "OK",
            },
        ]
        normalized = digest_core.normalize_messages(rows, privacy="strict")
        self.assertEqual([x["sender"] for x in normalized], ["成员A", "成员A", "成员B"])
        rendered = json.dumps(normalized, ensure_ascii=False)
        self.assertNotIn("wxid_", rendered)
        self.assertNotIn("/private/", rendered)
        self.assertNotIn("Msg_deadbeef", rendered)

    def test_noise_filter_removes_system_revoke_and_empty_but_keeps_media(self):
        rows = [
            {"sender": "A", "timestamp": 1, "time": "t1", "type": "系统", "content": "A加入群聊"},
            {"sender": "A", "timestamp": 2, "time": "t2", "type": "文本", "content": "<revokemsg>撤回</revokemsg>"},
            {"sender": "A", "timestamp": 3, "time": "t3", "type": "文本", "content": "   "},
            {"sender": "A", "timestamp": 4, "time": "t4", "type": "图片", "content": "[图片]"},
            {"sender": "A", "timestamp": 5, "time": "t5", "type": "文本", "content": "有效消息"},
        ]
        normalized = digest_core.normalize_messages(rows, privacy="balanced")
        self.assertEqual([x["content"] for x in normalized], ["[图片]", "有效消息"])

    def test_duplicate_filter_collapses_same_sender_content_in_short_window(self):
        rows = [
            {"sender": "A", "timestamp": 100, "time": "t1", "type": "文本", "content": "链接来了"},
            {"sender": "A", "timestamp": 120, "time": "t2", "type": "文本", "content": "链接来了"},
            {"sender": "A", "timestamp": 400, "time": "t3", "type": "文本", "content": "链接来了"},
        ]
        normalized = digest_core.normalize_messages(rows, privacy="balanced")
        self.assertEqual(len(normalized), 2)

    def test_build_pack_assigns_evidence_ids_and_extracts_candidates(self):
        rows = [
            {"sender": "A", "timestamp": 1, "time": "2026-09-25 09:00:00", "type": "文本", "content": "决定：今晚 9 点发布"},
            {"sender": "B", "timestamp": 2, "time": "2026-09-25 09:01:00", "type": "文本", "content": "TODO @A 明天补文档 https://example.com/doc"},
            {"sender": "C", "timestamp": 3, "time": "2026-09-25 09:02:00", "type": "文本", "content": "这个问题还没解决"},
        ]
        pack = digest_core.build_digest_pack("测试群", rows, privacy="balanced", source_meta={"backend": "file"})
        self.assertEqual([m["id"] for m in pack["messages"]], ["m0001", "m0002", "m0003"])
        self.assertEqual(pack["stats"]["messages"], 3)
        self.assertEqual(pack["stats"]["speakers"], 3)
        self.assertEqual(pack["candidates"]["links"][0]["url"], "https://example.com/doc")
        self.assertTrue(pack["candidates"]["decisions"])
        self.assertTrue(pack["candidates"]["actions"])
        self.assertTrue(pack["candidates"]["open_questions"])

    def test_chunk_messages_never_splits_evidence_order(self):
        rows = [
            {"sender": "A", "timestamp": i, "time": f"t{i}", "type": "文本", "content": ("x" * 50) + str(i)}
            for i in range(1, 8)
        ]
        pack = digest_core.build_digest_pack("G", rows, privacy="balanced", source_meta={})
        chunks = digest_core.chunk_messages(pack["messages"], max_chars=160)
        flattened = [m["id"] for chunk in chunks for m in chunk]
        self.assertEqual(flattened, [f"m{i:04d}" for i in range(1, 8)])
        self.assertGreater(len(chunks), 1)

    def test_render_prompt_requires_evidence_and_separates_fact_from_inference(self):
        rows = [{"sender": "A", "timestamp": 1, "time": "t", "type": "文本", "content": "hello"}]
        pack = digest_core.build_digest_pack("G", rows, privacy="balanced", source_meta={})
        prompt = digest_core.render_ai_prompt(pack)
        self.assertIn("证据 ID", prompt)
        self.assertIn("事实", prompt)
        self.assertIn("推断", prompt)
        self.assertIn("不要编造", prompt)

    def test_commit_state_requires_nonempty_report(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            pack_path = td / "pack.json"
            report = td / "report.md"
            state = td / "state.json"
            pack_path.write_text(json.dumps({"group": {"key": "abc"}, "source": {"last_timestamp": 123}, "fingerprint": "fp"}), encoding="utf-8")
            report.write_text("", encoding="utf-8")
            with self.assertRaises(ValueError):
                digest_core.commit_state(pack_path, report, state)
            report.write_text("# 日报\n正文", encoding="utf-8")
            digest_core.commit_state(pack_path, report, state)
            saved = json.loads(state.read_text(encoding="utf-8"))
            self.assertEqual(saved["last_timestamp"], 123)
            self.assertEqual(saved["fingerprint"], "fp")


if __name__ == "__main__":
    unittest.main()
