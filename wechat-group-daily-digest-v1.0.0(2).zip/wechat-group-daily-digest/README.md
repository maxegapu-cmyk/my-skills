# 月兔爬楼 🐇 · WeChat Group Daily Digest

一个给 AI Agent 用的微信群“爬楼日报”外发 Skill。它不做机器人、不自动发消息，也不把微信账号交给群控框架；它把**用户有权读取的本地群消息**整理成一份可核验的 AI 证据包，再让 Codex / Claude Code / 其他兼容 Agent 写日报。

版本：`1.0.0`

## 它解决什么

典型场景：一天没看群，回来 1000 条消息；你只想知道真正重要的 10 件事、已经拍板的结论、谁要跟进什么、分享了哪些链接、还有哪些坑没解决。

输出不是“凭感觉总结”。每条关键信息都能回到 `[m0001]` 这样的证据编号，AI 没看到的图片/语音不会硬猜。

## 三种输入

### A. Mac：兼容 `yichen-wechat-local-vault`

本 Skill **不包含也不重新分发** `mcncarl/yichen-skills` 的代码。需要 Mac 本地微信数据时，请用户自行按原项目许可和文档单独安装、配置 `yichen-wechat-local-vault`。本 Skill 只调用它公开的只读 CLI：先 `contacts` 精确定位唯一群聊，再 `digest-source` 取指定时间段素材。

原项目：`https://github.com/mcncarl/yichen-skills/tree/main/yichen-wechat-local-vault`

如果自动定位不到，可设置：

```bash
export YICHEN_WECHAT_VAULT_DIR="$HOME/.agents/skills/yichen-wechat-local-vault"
```

或在命令里加：

```bash
--yichen-root "/path/to/yichen-wechat-local-vault"
```

### B. Windows：授权的离线明文快照

如果用户已经有原项目支持的**静止、已解密、明确授权** Windows SQLite 快照，可直接：

```bash
python scripts/wechat_group_digest.py prepare \
  --snapshot "D:/wechat-snapshot" \
  --group "群名" \
  --date "2026-09-25"
```

这里只调用原项目的只读 `snapshot ... chats/history` 接口，不自动发现快照，不修数据库，不碰运行中的微信。

如果直接传 `--chat-id` 并使用 `--since-last`，同时传入该群的**精确群名** `--group`，用于稳定绑定日报状态。

### C. 任意平台：JSON / JSONL

这是最稳的后备路线，也最适合接别的导出器：

```bash
python scripts/wechat_group_digest.py prepare --input ./chat.json
```

支持两类 JSON：

```json
{
  "group": {"name": "示例群"},
  "messages": [
    {"sender": "成员甲", "timestamp": 1790326800, "time": "2026-09-25 09:00:00", "type": "文本", "content": "决定：今晚九点发布"}
  ]
}
```

或直接消息数组；JSONL 则每行一个消息对象。

## 安装

把整个 `wechat-group-daily-digest` 目录放进 Agent 能加载的 Skills 目录，例如：

```text
~/.agents/skills/wechat-group-daily-digest/
```

Python 端只用标准库；兼容底座自身的额外依赖由底座负责。

先检查：

```bash
python3 scripts/wechat_group_digest.py doctor --json
```

然后在 Codex / Claude Code 里直接说：

```text
把「AI交流群」今天的消息爬楼总结一下，给我 30 秒版、关键话题、已确认结论、待办、资源链接和未解决问题。
```

Agent 应按 `SKILL.md` 调用本工具，而不是把整库原文直接塞进对话。

## 隐私模式

- `balanced`（默认）：保留显示昵称；移除 wxid、会话 ID、数据库表名、本机路径等底层标识。
- `strict`：再把显示昵称稳定替换成“成员A/B/C…”。准备把素材交给外部 AI 时优先用它。
- `none`：保留显示昵称，与 `balanced` 的区别只在未来扩展；**底层 ID/路径无论如何都不会进入日报证据包**。

注意：任何联网 AI 都可能意味着聊天内容离开本机。是否把 `source.md` / `pack.json` 发给某个模型，由用户自己决定；本 Skill 不承诺第三方服务的零留存。

## 日报状态：为什么要 `commit`

`prepare --since-last` 会读取该群最后一次**成功日报**的时间点。状态不会在抓完消息时立即前移，只有报告真正写完后才运行：

```bash
python3 scripts/wechat_group_digest.py commit \
  --run-dir "<run_dir>" \
  --report "<run_dir>/report.md" \
  --state-root "~/Documents/wechat-group-daily-digest/state"
```

这样 AI 中途失败、上下文爆掉、日报写空，都不会把未总结消息永久跳过去。

## 生成目录

一次运行类似：

```text
wechat-group-daily-digest/
└─ runs/
   └─ 20260925-233000-a1b2c3d4e5f6g7h8/
      ├─ manifest.json
      ├─ pack.json
      ├─ source.md
      ├─ AI_PROMPT.md
      └─ chunks/
         ├─ chunk-001.md
         └─ ...
```

`pack.json` 会保存：清洗后的消息、人数/类型统计、候选结论、候选待办、候选未解决问题、真实出现过的 URL，以及 source fingerprint。

## 风控取舍

这个外发版故意不做几件“看起来更自动”的事：

- 不常驻监听微信进程。
- 不自动发消息。
- 不模拟微信 UI。
- 不自动抓 key。
- 不把上游代码重新打包。
- 不因为模糊群名就“猜一个最像的群”。

这些限制牺牲了一点“全自动”，换来更低的账号/隐私/误操作风险。真正的定时方案见 `references/automation.md`。

## 开发验证

```bash
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

测试全部使用合成数据和假的兼容后端，不读取真实微信账号或聊天记录。

## 许可

本目录原创代码采用 MIT License，见 `LICENSE`。

`yichen-wechat-local-vault` **不包含在本包内**，其许可证由原作者决定；截至本版制作时，原仓库明确限制为个人学习/非商业个人使用，并禁止把原仓库重新打包成公开 Skill bundle。用户如使用该兼容后端，应自行遵守其当前许可。详见 `THIRD_PARTY_NOTICES.md`。
