#!/usr/bin/env python3
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import sys

from digest_core import (
    build_digest_pack,
    chunk_messages,
    commit_state,
    render_ai_prompt,
    render_source_markdown,
)
from source_bridge import (
    fetch_from_snapshot,
    fetch_from_yichen,
    load_file_source,
    locate_yichen_cli,
)

VERSION = "1.0.0"
DEFAULT_ROOT = Path("~/Documents/wechat-group-daily-digest").expanduser()


def _group_key(name: str) -> str:
    return hashlib.sha256(name.encode("utf-8")).hexdigest()[:16]


def _parse_local_time(value: str) -> int:
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            dt = datetime.strptime(value, fmt)
            return int(dt.timestamp())
        except ValueError:
            continue
    raise ValueError(f"unsupported time: {value}")


def _format_local(ts: int) -> str:
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


def resolve_window(args, state_path: Path | None = None) -> tuple[str, str]:
    now = datetime.now()
    if args.start:
        start = args.start
    elif args.since_last and state_path and state_path.is_file():
        state = json.loads(state_path.read_text(encoding="utf-8"))
        last_ts = int(state.get("last_timestamp") or 0)
        start = _format_local(last_ts + 1) if last_ts else now.strftime("%Y-%m-%d 00:00:00")
    else:
        day = args.date or now.strftime("%Y-%m-%d")
        start = f"{day} 00:00:00"

    if args.end:
        end = args.end
    elif args.date:
        end = f"{args.date} 23:59:59"
    else:
        end = now.strftime("%Y-%m-%d %H:%M:%S")
    return start, end


def _filter_rows(rows: list[dict], start: str, end: str) -> list[dict]:
    start_ts = _parse_local_time(start)
    end_ts = _parse_local_time(end)
    return [m for m in rows if not m.get("timestamp") or start_ts <= int(m["timestamp"]) <= end_ts]


def _unique_run_dir(root: Path, group_key: str) -> Path:
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    base = root / "runs" / f"{stamp}-{group_key}"
    candidate = base
    suffix = 2
    while candidate.exists():
        candidate = Path(str(base) + f"-{suffix}")
        suffix += 1
    candidate.mkdir(parents=True, exist_ok=False)
    return candidate


def _write_chunks(run_dir: Path, chunks: list[list[dict]]) -> None:
    chunk_dir = run_dir / "chunks"
    chunk_dir.mkdir(parents=True, exist_ok=True)
    for idx, chunk in enumerate(chunks, 1):
        lines = [f"# 消息分块 {idx}/{len(chunks)}", ""]
        for m in chunk:
            lines.append(f"- [{m['id']}] {m['time']} · {m['sender']} · {m['type']} · {m['content']}")
        (chunk_dir / f"chunk-{idx:03d}.md").write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")


def command_doctor(args) -> int:
    cli = locate_yichen_cli(Path(args.yichen_root).expanduser() if args.yichen_root else None)
    data = {
        "skill": "wechat-group-daily-digest",
        "version": VERSION,
        "python": sys.version.split()[0],
        "yichen_backend": {
            "found": bool(cli),
            "path": str(cli) if cli else None,
        },
        "note": "doctor only checks local paths; it does not read chat data or operate WeChat",
    }
    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        print(f"wechat-group-daily-digest {VERSION}")
        print(f"Python: {data['python']}")
        print(f"Yichen backend: {data['yichen_backend']['path'] or 'not found'}")
        print(data["note"])
    return 0


def command_prepare(args) -> int:
    data_root = Path(args.data_root).expanduser()
    data_root.mkdir(parents=True, exist_ok=True)
    source = None

    if args.input:
        source = load_file_source(Path(args.input))
        group_name = args.group or source["group_name"]
        state_path = Path(args.state_root).expanduser() / f"{_group_key(group_name)}.json" if args.state_root else data_root / "state" / f"{_group_key(group_name)}.json"
        if args.start or args.end or args.date or args.since_last:
            start, end = resolve_window(args, state_path)
            source["messages"] = _filter_rows(source["messages"], start, end)
            source["source_meta"].update({"requested_start": start, "requested_end": end})
        else:
            source["source_meta"].update({"requested_start": "file-provided", "requested_end": "file-provided"})
        source["last_timestamp"] = max((int(m.get("timestamp") or 0) for m in source["messages"]), default=0)
        source["source_meta"]["last_timestamp"] = source["last_timestamp"]
    else:
        if not args.group and not args.chat_id:
            raise ValueError("prepare requires --group unless --input supplies a group name or --chat-id is used with --snapshot")
        if args.snapshot and args.chat_id and args.since_last and not args.group:
            raise ValueError("--since-last with --chat-id requires --group so state is tied to a stable group name")
        group_name = args.group or "snapshot-chat"
        state_path = Path(args.state_root).expanduser() / f"{_group_key(group_name)}.json" if args.state_root else data_root / "state" / f"{_group_key(group_name)}.json"
        start, end = resolve_window(args, state_path)
        cli = locate_yichen_cli(Path(args.yichen_root).expanduser() if args.yichen_root else None)
        if not cli:
            raise RuntimeError("yichen-wechat-local-vault was not found; install it separately or use --input")
        if args.snapshot:
            source = fetch_from_snapshot(
                cli,
                snapshot=Path(args.snapshot),
                group=args.group,
                chat_id=args.chat_id,
                start=start,
                end=end,
                limit=args.limit,
            )
        else:
            if not args.group:
                raise ValueError("Mac/local-vault backend requires --group")
            source = fetch_from_yichen(
                cli,
                group=args.group,
                start=start,
                end=end,
                data_root=data_root / "upstream-cache",
                limit=args.limit,
            )
        group_name = source["group_name"]

    pack = build_digest_pack(group_name, source["messages"], privacy=args.privacy, source_meta=source["source_meta"])
    # The resolved group name is the canonical state identity. This matters for
    # snapshot chat-id mode, where the display name is learned from history.
    state_base = Path(args.state_root).expanduser() if args.state_root else data_root / "state"
    state_path = state_base / f"{pack['group']['key']}.json"
    run_dir = _unique_run_dir(data_root, pack["group"]["key"])
    pack_path = run_dir / "pack.json"
    source_md = run_dir / "source.md"
    prompt_md = run_dir / "AI_PROMPT.md"
    pack_path.write_text(json.dumps(pack, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    source_md.write_text(render_source_markdown(pack), encoding="utf-8")
    prompt_md.write_text(render_ai_prompt(pack), encoding="utf-8")
    chunks = chunk_messages(pack["messages"], max_chars=args.chunk_chars)
    _write_chunks(run_dir, chunks)
    manifest = {
        "version": VERSION,
        "run_dir": str(run_dir),
        "pack": str(pack_path),
        "source": str(source_md),
        "prompt": str(prompt_md),
        "chunks": len(chunks),
        "messages": pack["stats"]["messages"],
        "fingerprint": pack["fingerprint"],
        "state_path": str(state_path),
        "backend": pack["source"].get("backend"),
    }
    (run_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return 0


def command_commit(args) -> int:
    run_dir = Path(args.run_dir).expanduser()
    pack_path = run_dir / "pack.json"
    report_path = Path(args.report).expanduser()
    if not pack_path.is_file():
        raise FileNotFoundError(pack_path)
    pack = json.loads(pack_path.read_text(encoding="utf-8"))
    state_root = Path(args.state_root).expanduser()
    state_path = state_root / f"{pack['group']['key']}.json"
    state = commit_state(pack_path, report_path, state_path)
    result = {"state_path": str(state_path), "last_timestamp": state["last_timestamp"], "fingerprint": state["fingerprint"]}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Prepare privacy-aware WeChat group chat evidence packs for AI daily digests.")
    sub = parser.add_subparsers(dest="command", required=True)

    doctor = sub.add_parser("doctor", help="check dependencies without reading chats")
    doctor.add_argument("--yichen-root")
    doctor.add_argument("--json", action="store_true")
    doctor.set_defaults(func=command_doctor)

    prepare = sub.add_parser("prepare", help="prepare a digest evidence pack")
    prepare.add_argument("--group", help="group display name")
    prepare.add_argument("--input", help="existing JSON/JSONL source; bypasses local WeChat backend")
    prepare.add_argument("--snapshot", help="authorized detached Windows plaintext snapshot root")
    prepare.add_argument("--chat-id", help="exact snapshot chat_id; avoids name resolution")
    prepare.add_argument("--yichen-root", help="path to separately installed yichen-wechat-local-vault")
    prepare.add_argument("--data-root", default=str(DEFAULT_ROOT))
    prepare.add_argument("--state-root")
    prepare.add_argument("--date", help="calendar date YYYY-MM-DD")
    prepare.add_argument("--start", help="start YYYY-MM-DD [HH:MM[:SS]]")
    prepare.add_argument("--end", help="end YYYY-MM-DD [HH:MM[:SS]]")
    prepare.add_argument("--since-last", action="store_true")
    prepare.add_argument("--privacy", choices=["none", "balanced", "strict"], default="balanced")
    prepare.add_argument("--limit", type=int, default=5000)
    prepare.add_argument("--chunk-chars", type=int, default=12000)
    prepare.set_defaults(func=command_prepare)

    commit = sub.add_parser("commit", help="advance since-last state after a final report exists")
    commit.add_argument("--run-dir", required=True)
    commit.add_argument("--report", required=True)
    commit.add_argument("--state-root", required=True)
    commit.set_defaults(func=command_commit)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args) or 0)
    except (ValueError, RuntimeError, FileNotFoundError, json.JSONDecodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
