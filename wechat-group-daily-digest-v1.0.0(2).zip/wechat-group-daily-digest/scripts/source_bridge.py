from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Any


def locate_yichen_cli(explicit_root: Path | None = None) -> Path | None:
    candidates: list[Path] = []
    if explicit_root:
        candidates.append(Path(explicit_root).expanduser())
    env_root = os.environ.get("YICHEN_WECHAT_VAULT_DIR")
    if env_root:
        candidates.append(Path(env_root).expanduser())
    home = Path.home()
    candidates.extend([
        home / ".agents/skills/yichen-wechat-local-vault",
        home / ".claude/skills/yichen-wechat-local-vault",
        home / ".codex/skills/yichen-wechat-local-vault",
    ])
    for root in candidates:
        script = root / "scripts/vault_cli.py"
        if script.is_file():
            return script
    return None


def _sanitize_upstream_payload(payload: dict[str, Any], backend: str) -> dict[str, Any]:
    group = payload.get("group") or {}
    stats = payload.get("stats") or {}
    messages = payload.get("messages") or []
    safe_messages = []
    for m in messages:
        safe_messages.append({
            "sender": m.get("sender") or "未知",
            "timestamp": int(m.get("timestamp") or 0),
            "time": m.get("time") or "",
            "type": m.get("type") or "未知",
            "content": m.get("content") or "",
            # local_id is used only for deterministic ordering if available, not emitted later.
            "local_id": m.get("local_id"),
        })
    last_ts = int(stats.get("last_message_timestamp") or max((m["timestamp"] for m in safe_messages), default=0))
    return {
        "group_name": group.get("name") or payload.get("group_name") or "未命名群聊",
        "messages": safe_messages,
        "last_timestamp": last_ts,
        "source_meta": {"backend": backend, "last_timestamp": last_ts},
    }


def load_file_source(path: Path) -> dict[str, Any]:
    path = Path(path).expanduser()
    if not path.is_file():
        raise FileNotFoundError(path)
    if path.suffix.lower() == ".jsonl":
        rows = []
        with path.open(encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    rows.append(json.loads(line))
        payload = {"group": {"name": path.stem}, "messages": rows, "stats": {}}
    else:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(payload, list):
            payload = {"group": {"name": path.stem}, "messages": payload, "stats": {}}
    result = _sanitize_upstream_payload(payload, backend="file")
    result["source_meta"]["input_file"] = path.name
    return result


def fetch_from_yichen(
    cli_path: Path,
    *,
    group: str,
    start: str,
    end: str,
    data_root: Path,
    limit: int = 5000,
) -> dict[str, Any]:
    cli_path = Path(cli_path).expanduser()
    if not cli_path.is_file():
        raise FileNotFoundError(cli_path)

    resolved_group = group
    if "@chatroom" not in group:
        contacts_cmd = [
            sys.executable,
            str(cli_path),
            "contacts",
            "--query",
            group,
            "--limit",
            "50",
            "--format",
            "json",
        ]
        contacts_data = _run_json(contacts_cmd)
        candidates = [x for x in contacts_data.get("contacts", []) if x.get("is_group")]
        exact = [x for x in candidates if str(x.get("display_name") or "") == group]
        if len(exact) != 1:
            names = [str(x.get("display_name") or "") for x in candidates[:10]]
            raise RuntimeError(f"group name must match exactly one group: {group!r}; candidates={names}")
        resolved_group = str(exact[0].get("username") or "")
        if "@chatroom" not in resolved_group:
            raise RuntimeError("backend returned an invalid group username")

    cmd = [
        sys.executable,
        str(cli_path),
        "digest-source",
        resolved_group,
        "--start",
        start,
        "--end",
        end,
        "--data-root",
        str(Path(data_root).expanduser()),
        "--limit",
        str(int(limit)),
        "--format",
        "json",
    ]
    meta = _run_json(cmd)
    source_path = Path(meta.get("source_json") or "").expanduser()
    if not source_path.is_file():
        raise RuntimeError("yichen backend returned no readable source_json")
    payload = json.loads(source_path.read_text(encoding="utf-8"))
    result = _sanitize_upstream_payload(payload, backend="yichen-wechat-local-vault")
    result["source_meta"].update({
        "upstream_cli": "yichen-wechat-local-vault/scripts/vault_cli.py",
        "requested_start": start,
        "requested_end": end,
    })
    return result

SNAPSHOT_TYPE_LABELS = {
    1: "文本",
    3: "图片",
    34: "语音",
    42: "名片",
    43: "视频",
    47: "表情",
    48: "位置",
    49: "链接/文件",
    50: "通话",
    10000: "系统",
    10002: "撤回",
}


def _run_json(cmd: list[str]) -> dict[str, Any]:
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", check=False)
    if proc.returncode != 0:
        message = (proc.stderr or proc.stdout or "backend failed").strip()
        raise RuntimeError(f"backend failed ({proc.returncode}): {message}")
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise RuntimeError("backend did not return valid JSON") from exc
    if not isinstance(data, dict):
        raise RuntimeError("backend JSON root must be an object")
    return data


def fetch_from_snapshot(
    cli_path: Path,
    *,
    snapshot: Path,
    group: str | None,
    chat_id: str | None,
    start: str,
    end: str,
    limit: int = 5000,
) -> dict[str, Any]:
    cli_path = Path(cli_path).expanduser()
    snapshot = Path(snapshot).expanduser()
    if not cli_path.is_file():
        raise FileNotFoundError(cli_path)
    if not snapshot.is_dir():
        raise FileNotFoundError(snapshot)

    resolved_chat_id = chat_id
    display_name = group or "未命名群聊"
    if not resolved_chat_id:
        if not group:
            raise ValueError("snapshot backend requires --group or --chat-id")
        chats_cmd = [
            sys.executable,
            str(cli_path),
            "snapshot",
            "--snapshot",
            str(snapshot),
            "chats",
            "--query",
            group,
        ]
        chats_data = _run_json(chats_cmd)
        candidates = [x for x in chats_data.get("chats", []) if x.get("kind") == "group"]
        exact = [x for x in candidates if str(x.get("display_name") or "") == group]
        usable = exact if exact else candidates
        if len(usable) != 1:
            names = [str(x.get("display_name") or "") for x in candidates[:10]]
            raise RuntimeError(f"snapshot group query is ambiguous or empty: {group!r}; candidates={names}")
        resolved_chat_id = str(usable[0].get("chat_id") or "")
        display_name = str(usable[0].get("display_name") or group)
        if not resolved_chat_id:
            raise RuntimeError("snapshot backend returned an empty chat_id")

    history_cmd = [
        sys.executable,
        str(cli_path),
        "snapshot",
        "--snapshot",
        str(snapshot),
        "history",
        resolved_chat_id,
        "--start",
        start[:10],
        "--end",
        end[:10],
        "--limit",
        str(int(limit)),
    ]
    data = _run_json(history_cmd)
    chat = data.get("chat") or {}
    display_name = str(chat.get("display_name") or display_name)
    rows = []
    for m in data.get("messages", []):
        raw_type = m.get("type")
        try:
            type_number = int(raw_type)
        except (TypeError, ValueError):
            type_number = -1
        rows.append({
            "sender": m.get("sender") or "未知",
            "timestamp": int(m.get("timestamp") or 0),
            "time": m.get("time") or "",
            "type": SNAPSHOT_TYPE_LABELS.get(type_number, f"type={raw_type}"),
            "content": m.get("content") or "",
        })
    last_ts = max((m["timestamp"] for m in rows), default=0)
    return {
        "group_name": display_name,
        "messages": rows,
        "last_timestamp": last_ts,
        "source_meta": {
            "backend": "yichen-wechat-local-vault-snapshot",
            "last_timestamp": last_ts,
            "requested_start": start[:10],
            "requested_end": end[:10],
        },
    }
