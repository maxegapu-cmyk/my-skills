from pathlib import Path
import sys, re
root=Path(__file__).resolve().parents[1]
req=[
'SKILL.md','README.md','COURSE-MAP.md','INSTRUCTOR-GUIDE.md','LEARNER-WORKBOOK.md','ASSESSMENT.md',
'modules/01-visual-language.md','modules/02-prompt-architecture.md','modules/03-composition-camera.md','modules/04-light-color-material.md','modules/05-reference-control.md','modules/06-character-product-consistency.md','modules/07-editing-diagnosis.md','modules/08-style-system.md','modules/09-commercial-workflows.md','modules/10-capstone.md',
'references/prompt-cards.md','references/diagnostic-tree.md','references/model-adaptation.md','references/glossary.md','references/public-sources.md','references/visual-control-matrix.md','references/brief-template.md','references/quality-checklist.md','references/lesson-output-contract.md',
'tests/pressure-scenarios.md'
]
missing=[x for x in req if not (root/x).exists()]
if missing:
    print('FAIL missing:', *missing, sep='\n- '); sys.exit(1)
empty=[x for x in req if (root/x).stat().st_size < 80]
if empty:
    print('FAIL suspiciously small:', *empty, sep='\n- '); sys.exit(2)
text=(root/'SKILL.md').read_text('utf-8')
checks={
'frontmatter': text.startswith('---\nname:'),
'use_when': 'description: Use when' in text,
'learning_loop': all(k in text for k in ['观察','控制','生成','诊断','修正']),
'beginner_mode': '小白模式' in text,
'cross_model': '跨模型' in text,
'diagnostics': '诊断模式' in text,
'assessment': '课程验收' in text,
'instructor_guide': 'INSTRUCTOR-GUIDE.md' in text,
'workbook': 'LEARNER-WORKBOOK.md' in text,
'quality_checklist': 'quality-checklist.md' in text,
}
bad=[k for k,v in checks.items() if not v]
if bad:
    print('FAIL checks:', bad); sys.exit(3)
# module contract checks
for i in range(1,11):
    path=next((root/'modules').glob(f'{i:02d}-*.md'))
    s=path.read_text('utf-8')
    if '## 学习目标' not in s and i != 10:
        print('FAIL module missing learning objective', path.name); sys.exit(4)
    if len(s) < 700:
        print('FAIL module too thin', path.name, len(s)); sys.exit(5)
# reject obvious private/internal fingerprints
alltxt='\n'.join(p.read_text('utf-8',errors='ignore') for p in root.rglob('*.md'))
for forbidden in ['TOTAL-SEAL','FDE','镜域折叠','visual-authenticity-recompiler','screenwriting-master-2']:
    if forbidden.lower() in alltxt.lower():
        print('FAIL private fingerprint:', forbidden); sys.exit(6)
# modularity sanity
wc=len(text.split())
if wc>2400:
    print('FAIL SKILL too long',wc); sys.exit(7)
print('PASS', len(req),'required files; 10 modules substantive; no listed private fingerprints; SKILL words',wc)
