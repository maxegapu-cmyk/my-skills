# Threadlock Wardrobe Skill v1.0.0 — Release notes

## Release scope

A clean-room garment asset and continuity system for anime and photoreal generation. It includes original schemas, workflow rules, prompt/brief compiler, QA scoring, examples and local reports. Third-party model code and weights are not bundled.

## Verified in this release

- anime asset manifest validation;
- real asset manifest validation;
- hard/soft/free lock compilation;
- explicit unknown-region handling;
- anime and real presentation policies;
- local HTML asset report generation;
- weighted continuity review scoring;
- CLI smoke path.

## Not verified in this release

- actual inference quality of external model checkpoints;
- GPU installation for CatVTON / CatV2TON / IDM-VTON / Grounded-SAM-2 / DensePose;
- commercial licensing of any external backend or checkpoint.

Those are deliberately external dependencies and must be verified against the current backend repository when deployed.
