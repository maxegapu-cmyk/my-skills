#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python -m threadlock.cli validate examples/anime_asset.json
python -m threadlock.cli validate examples/real_asset.json
python -m threadlock.cli compile examples/anime_asset.json --mode anime --task render >/tmp/threadlock-brief.txt
grep -q "HARD-LOCK GARMENT FACTS" /tmp/threadlock-brief.txt
python -m threadlock.cli report examples/real_asset.json -o /tmp/threadlock-report.html
test -s /tmp/threadlock-report.html
python -m threadlock.cli score examples/continuity_score.json | grep -q '"verdict": "release"'
