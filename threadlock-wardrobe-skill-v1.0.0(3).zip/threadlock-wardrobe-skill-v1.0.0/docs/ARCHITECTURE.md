# Architecture

## Data flow

### A. Reference intake
Collect all images and tag them by view, crop, quality and what garment regions they actually prove.

### B. Evidence map
For every garment part, attach source regions and certainty: `observed`, `inferred`, or `unknown`.

### C. Canonical garment asset
Store only facts that should survive across generations: component identity, silhouette, construction, material class, color blocks, marks and layering.

### D. Wear state
Store temporary but meaningful states separately: jacket open/closed, shirt tucked/untucked, sleeves rolled, hood up/down, belt fastened, scarf knot state.

### E. Presentation adapter
Translate the same canonical garment into anime or photoreal execution rules.

### F. Shot contract
Add scene-local information: pose, camera, action, visible sides, occlusion and motion.

### G. QA + repair
Compare the candidate with canonical facts. Repair the smallest region that failed. Whole-frame regeneration is a last resort.

## Why five layers beat a single prompt

A prompt mixes facts of different permanence. "Red leather jacket, running, cel shaded, low angle, jacket open" contains garment identity, material, pose, style, camera and wear state in one flat sequence. When the model misses something, it is hard to know what changed.

Threadlock stores those facts in different layers, so a new camera angle does not implicitly authorize a new jacket design.

## Asset state transitions

`draft -> reviewed -> canonical -> revised`

- `draft`: incomplete or uncertain.
- `reviewed`: evidence and unknowns checked.
- `canonical`: approved authority for rendering.
- `revised`: user intentionally changed one or more hard-lock facts; increment version and re-canonicalize.

Do not let a generated candidate auto-promote itself to canonical.
