# Backend matrix

Threadlock does not require these projects. They are examples of public execution backends whose capabilities map well to parts of the workflow.

| Need | Suggested public backend | Why it fits | Caveat |
|---|---|---|---|
| Open-vocabulary garment/object isolation | Grounded-SAM-2 | combines grounding and SAM 2 segmentation/tracking | setup is heavier than a simple image editor |
| General segmentation | SAM 2 | strong interactive image/video segmentation foundation | no garment semantics by itself |
| Human/clothing parsing | SCHP | explicit clothing/body classes | older parsing taxonomy; treat as preprocessing, not truth |
| Body surface correspondence | DensePose in Detectron2 | maps body pixels to body surface coordinates | installation stack can be non-trivial |
| Real still try-on | CatVTON | lightweight virtual try-on design and practical memory target | output still needs structural QA |
| Real still try-on alternative | IDM-VTON | mature public VTON pipeline with parsing / pose preprocessing | non-commercial license on released code/checkpoints must be checked for intended use |
| Fine wear-state control | CtrlVTON | targets controllable tuck/open/closed/placement via masks | verify current code/weights availability before planning around it |
| Image + video try-on | CatV2TON | public image/video try-on pipeline | model constraints and input preparation still matter |
| Anime identity/reference conditioning | IP-Adapter family | separates image conditioning from text and can combine with ControlNet | excessive reference weight can drag composition/style |
| Anime pose control | ControlNet/OpenPose family | independent structural control | pose skeleton cannot guarantee clothing topology |

## Routing rule

Choose the smallest backend that solves the current failure. If extraction is wrong, fix segmentation. If pose is wrong, fix pose control. If clothing topology is wrong, change the try-on/edit path. Do not solve every problem by increasing reference strength.
