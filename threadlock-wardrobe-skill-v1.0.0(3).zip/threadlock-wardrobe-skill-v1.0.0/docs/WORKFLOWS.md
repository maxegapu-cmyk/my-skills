# Production workflows

## Workflow A — extract outfit from a real photo

1. Segment person and clothing regions.
2. Split actual garment layers (coat over shirt, skirt over shorts, etc.).
3. Record visible facts and unknowns.
4. Create neutral crops/masks for each garment when possible.
5. Build the canonical manifest.
6. Generate a front or 3/4 canonical verification view.
7. Compare the verification view against the references; fix only mismatched parts.

## Workflow B — turn anime clothing into a reusable anime asset

1. Use the clearest panels/screenshots for shape and marks.
2. Treat linework simplification as style, not construction.
3. Record wrap direction, asymmetry and emblem side explicitly.
4. Keep unknown back/inside regions unknown.
5. Render a neutral verification pose with independent pose control.
6. After approval, use that asset for new scenes.

## Workflow C — same clothing, different person

1. Keep person identity reference separate from clothing asset.
2. Preserve the garment cut; permit only body-fit adaptation listed as soft-lock.
3. Use try-on/editing rather than describing the outfit from scratch.
4. Check that the body was not unnaturally distorted to force the garment.

## Workflow D — anime concept to photoreal outfit

1. Preserve garment topology, layering, closure and color-block layout.
2. Convert stylized material into a plausible real material class.
3. Decide ambiguous construction details explicitly before rendering.
4. Freeze the real interpretation as a sibling asset version; do not overwrite the anime canonical.

## Workflow E — photoreal outfit to anime

1. Preserve silhouette and construction cues that remain visually important.
2. Simplify microtexture before simplifying topology.
3. Keep distinctive pocket/closure/trim geometry.
4. Let line and shading style vary freely if not part of garment identity.

## Workflow F — video demo

1. Approve a canonical still.
2. Define 3–5 test shots: front walk, 3/4 turn, arm raise, seated bend, partial occlusion.
3. Record which garment facts are visible in each shot.
4. Run video try-on/reference generation.
5. Review at keyframes and around high-deformation moments.
6. Reject drift that changes pocket count, hem length, marks, closure type, layering or fabric class.
