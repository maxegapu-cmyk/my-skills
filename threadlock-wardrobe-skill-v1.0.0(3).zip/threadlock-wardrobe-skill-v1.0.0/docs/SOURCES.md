# Public source survey

These repositories informed backend capability mapping only. No third-party source code or model weights are vendored into Threadlock.

- Grounded-SAM-2 — https://github.com/IDEA-Research/Grounded-SAM-2
  - open-vocabulary grounding + SAM 2 image/video segmentation and tracking.
- SAM 2 — https://github.com/facebookresearch/sam2
  - general image/video segmentation foundation.
- CatVTON — https://github.com/Zheng-Chong/CatVTON
  - lightweight image virtual try-on; project reports <8 GB VRAM for 1024×768 inference in its documented setup.
- CatV2TON — https://github.com/Zheng-Chong/CatV2TON
  - image/video virtual try-on using a DiT-based approach.
- IDM-VTON — https://github.com/yisol/IDM-VTON
  - public ECCV 2024 virtual try-on implementation using pose/parsing-related preprocessing.
- CtrlVTON — https://github.com/nxnai/CtrlVTON
  - 2026 controllable VTON work focused on instance segmentation and mask-conditioned wearing states.
- Detectron2 / DensePose — https://github.com/facebookresearch/detectron2
  - detection/segmentation platform; DensePose lives under Detectron2 projects.
- Original DensePose repository — https://github.com/facebookresearch/DensePose
  - archived; points users to Detectron2 for the maintained implementation.
- SCHP packaging example — https://github.com/pirocheto/schp-human-parsing
  - human/clothing parsing packaging and ONNX examples; repository was archived in 2026.
- AnyDoor — https://github.com/ali-vilab/AnyDoor
  - zero-shot object-level image customization; useful conceptual reference for region/object transfer.
- IP-Adapter documentation/code ecosystem — official/public implementations and Diffusers integrations.
  - image-prompt adapter that can be combined with ControlNet-style structural control.

## License note

Do not assume all optional backends permit the same commercial use. Check the current repository and checkpoint license before shipping a product. Threadlock's own code is MIT; that does not relicense any external backend.
