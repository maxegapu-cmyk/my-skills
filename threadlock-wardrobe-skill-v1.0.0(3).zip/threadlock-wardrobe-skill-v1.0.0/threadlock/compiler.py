from __future__ import annotations

from typing import Iterable, List
from .core import Asset, GarmentPart


def _part_line(p: GarmentPart) -> str:
    bits: List[str] = [f"{p.name} ({p.category})"]
    if p.silhouette:
        bits.append(f"silhouette={p.silhouette}")
    if p.material:
        bits.append(f"material={p.material}")
    if p.color:
        bits.append(f"color={p.color}")
    if p.construction:
        bits.append("construction=" + ", ".join(p.construction))
    if p.surface_marks:
        bits.append("surface=" + ", ".join(p.surface_marks))
    return "; ".join(bits)


def _join(items: Iterable[str], fallback: str = "none specified") -> str:
    vals = [x.strip() for x in items if x and x.strip()]
    return "; ".join(vals) if vals else fallback


def compile_brief(asset: Asset, mode: str, task: str, shot: str = "") -> str:
    if mode not in {"anime", "real"}:
        raise ValueError("mode must be anime or real")
    if task not in {"extract", "reconstruct", "render", "tryon", "video"}:
        raise ValueError("unsupported task")

    hard = [p for p in asset.parts if p.lock == "hard"]
    soft = [p for p in asset.parts if p.lock == "soft"]
    free = [p for p in asset.parts if p.lock == "free"]

    lines = [
        f"TASK: {task}",
        f"PRESENTATION DOMAIN: {mode}",
        f"ASSET: {asset.display_name} [{asset.asset_id}]",
        "",
        "HARD-LOCK GARMENT FACTS — preserve exactly unless impossible:",
    ]
    lines += [f"- {_part_line(p)}" for p in hard] or ["- none"]
    lines += ["", "SOFT-LOCK FACTS — preserve by default, may adapt to pose/body physics:"]
    lines += [f"- {_part_line(p)}" for p in soft] or ["- none"]
    lines += ["", "FREE ELEMENTS — may vary:"]
    lines += [f"- {_part_line(p)}" for p in free] or ["- none"]
    lines += [
        "",
        "GLOBAL INVARIANTS:",
        f"- {_join(asset.global_invariants)}",
        "ALLOWED VARIATIONS:",
        f"- {_join(asset.allowed_variations)}",
        "FORBIDDEN CHANGES:",
        f"- {_join(asset.forbidden_changes)}",
    ]
    unknowns = []
    for p in asset.parts:
        unknowns.extend(f"{p.name}: {u}" for u in p.unknowns)
    lines += [
        "UNKNOWN / UNPROVEN REGIONS:",
        f"- {_join(unknowns)}",
        "",
        "UNCERTAINTY POLICY:",
        "Do not convert an unknown into a new design fact. Keep hidden regions conservative, structurally plausible, and visually subordinate. If the backend supports masks or region editing, restrict reconstruction to unknown regions.",
    ]
    if mode == "anime":
        lines += [
            "",
            "ANIME RENDER POLICY:",
            "Preserve graphic shape language, trim placement, color blocking, emblem geometry and garment layering before adding stylization. Pose and line treatment may change; garment topology may not.",
        ]
    else:
        lines += [
            "",
            "REAL RENDER POLICY:",
            "Preserve cut, seams, closures, material response, thickness, drape, wrinkles caused by body pose, and true garment layering. Avoid painted-on fabric, merged layers, or texture-only substitutions.",
        ]
    if shot:
        lines += ["", "SHOT / DEMO CONTRACT:", shot.strip()]
    return "\n".join(lines) + "\n"
