from __future__ import annotations

import html
from pathlib import Path
from .core import Asset


def render_html(asset: Asset, out: str | Path) -> None:
    rows = []
    for p in asset.parts:
        unknown = "<br>".join(html.escape(x) for x in p.unknowns) or "—"
        rows.append(
            "<tr>"
            f"<td>{html.escape(p.name)}</td>"
            f"<td>{html.escape(p.category)}</td>"
            f"<td>{html.escape(p.lock)}</td>"
            f"<td>{html.escape(p.silhouette or '—')}</td>"
            f"<td>{html.escape(p.material or '—')}</td>"
            f"<td>{html.escape(p.color or '—')}</td>"
            f"<td>{unknown}</td>"
            "</tr>"
        )
    body = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(asset.display_name)} — Threadlock Asset Report</title>
<style>
body{{font-family:system-ui,-apple-system,Segoe UI,sans-serif;margin:32px;line-height:1.45;background:#111;color:#eee}}
.card{{background:#191919;border:1px solid #333;border-radius:14px;padding:20px;margin:16px 0}}
table{{width:100%;border-collapse:collapse}}th,td{{border-bottom:1px solid #333;text-align:left;padding:10px;vertical-align:top}}
.hard{{font-weight:700}}code{{background:#222;padding:2px 6px;border-radius:6px}}
</style></head><body>
<h1>{html.escape(asset.display_name)}</h1>
<p><code>{html.escape(asset.asset_id)}</code> · domain: {html.escape(asset.domain)}</p>
<div class="card"><h2>Garment ledger</h2><table><thead><tr><th>Part</th><th>Category</th><th>Lock</th><th>Silhouette</th><th>Material</th><th>Color</th><th>Unknowns</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div>
<div class="card"><h2>Global invariants</h2><ul>{''.join('<li>'+html.escape(x)+'</li>' for x in asset.global_invariants)}</ul></div>
<div class="card"><h2>Allowed variations</h2><ul>{''.join('<li>'+html.escape(x)+'</li>' for x in asset.allowed_variations)}</ul></div>
<div class="card"><h2>Forbidden changes</h2><ul>{''.join('<li>'+html.escape(x)+'</li>' for x in asset.forbidden_changes)}</ul></div>
</body></html>'''
    Path(out).write_text(body, encoding="utf-8")
