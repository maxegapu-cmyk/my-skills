# Genre Adapters

## Action / Adventure
升级来自策略、空间、资源和损失；动作场必须改变局面。

## Sci-Fi / Fantasy
世界规则必须提前建立；奇观服务选择。高潮禁止临时新能力。

## Superhero
外部能力与内部道德边界同时升级；反派命题最好挑战英雄存在方式，而非只想毁灭世界。

## Thriller / Spy
重点启用 Knowledge Warfare、Obvious Solution Killer、身份/证据/时间压力。

## Crime
重点启用资源链、秘密链、忠诚/债务、制度权力与后果不可逆。

## War
个人目标必须和指挥、资源、地形、群体后果发生真实冲突；牺牲不能只是人数统计。

## Drama
可以降低外部事件密度，但必须保持关系、选择、信息、身份或价值位置的持续变化。
