---
name: hollywood-omni-screenplay-master
description: Use when developing, outlining, writing, rewriting, diagnosing, or polishing feature-film screenplays, cinematic stories, scenes, or dialogue that require strong long-form structure, causal escalation, intelligent opposition, character-driven choices, memorable dialogue, and rigorous rewrite passes.
version: 3.0.0
---

# 好莱坞全能电影剧本大师系统 v3.0.0

> 目标不是把故事“填进模板”，而是把一部长片锻造成一台持续制造选择、代价、惊讶和回响的戏剧机器；对白必须从人物行动中长出来，而不是替作者解释剧情。

## 0. 最高宪法

1. **长片第一**：FEATURE_FILM 是主路由。短片、剧集、单场修稿和对白手术是兼容路由，不能反过来污染长片标准。
2. **单一总编剧主权**：所有 runtime 都是按需器官，不是并列作者。只有一份 Story SSoT；任何模块不得私自产生第二真源。
3. **因果高于节拍**：结构节点只有在前因逼出后果时才成立。页码、分钟数和模板只能诊断，不能替代戏剧因果。
4. **选择高于事件**：真正的转折不是“发生了大事”，而是人物因新现实改变了策略、承诺或代价。
5. **对手同样聪明**：反派、制度、环境和关系都要保护自己的利益并学习；不允许为了主角胜利突然变蠢。
6. **高潮归主角所有**：最终解决必须来自主角此前建立的能力、选择、准备、错误、关系或牺牲。
7. **对白是行动**：台词的核心问题不是“说得漂亮吗”，而是“它正在对谁做什么”。
8. **惊讶必须可回看**：第一次看意外，回头看有迹可循。隐藏作者信息不算高级反转。
9. **改稿只修失败源**：结构失败修结构；场景失败修场景；对白失败修对白。禁止一处问题触发全片无差别重写。
10. **最终标准是作品自己的天花板**：找到本片最强场景，再逼核心场景向它靠拢，而不是只求“没有烂戏”。

## 1. AUTO_ROUTE

- `FEATURE_FILM`：80–180 分钟电影长片。加载完整链路。
- `SHORT_FILM`：3–40 分钟；压缩 Sequence 数量，不降低因果/人物/结局标准。
- `SERIES`：剧集；在单集结构外增加季弧线与知识连续性。
- `SCENE_SURGERY`：只修场景；不越权重写全片。
- `DIALOGUE_SURGERY`：只修对白；不得擅改剧情事实。
- `SCRIPT_DOCTOR`：默认诊断，不自动重写。
- `VERTICAL_COMPAT`：仅兼容短剧；不把卡点、强制秒点、机械反转写回电影核心。

## 2. FEATURE MASTER PIPELINE

```text
BRIEF LOCK
→ STORY CORE
→ CHARACTER / ANTAGONIST ENGINE
→ ENDING VECTOR
→ OUTLINE FORGE
→ FEATURE ARCHITECTURE
→ SEQUENCE ENGINE
→ CINEMATIC TREATMENT
→ OUTLINE STRESS TEST
→ SCENE ENGINE
→ REHEARSAL DIALOGUE
→ STORY STATE COMMIT
→ REWRITE LAB
→ FINAL AUDIT
```

任何阶段只读自己需要的上游状态。上游发生实质改动时，把依赖输出标为 STALE，再局部重建。

## 3. BRIEF LOCK

施工前内部锁定：

```text
FORMAT / TARGET RUNTIME:
GENRE PROMISE:
AUDIENCE:
CORE PREMISE:
PROTAGONIST:
ANTAGONISTIC FORCE:
MUST KEEP:
MUST NOT CHANGE:
TONE / RATING:
KNOWN ENDING INTENT:
CURRENT TASK:
BLOCKING UNKNOWN:
SAFE DEFAULTS:
```

只问真正会改变作品方向的问题；其余用可逆默认值继续。

## 4. STORY CORE

正文前先得到五个句子：

1. **Dramatic Question**：观众真正等待答案的问题。
2. **Protagonist Want**：主角可行动、可失败的外在目标。
3. **Inner Pressure**：主角旧信念/缺陷怎样妨碍他得到真正需要的东西。
4. **Antagonistic Thesis**：对手认为世界应该如何运作，以及他为什么有资格相信它。
5. **Cost of Victory**：即使主角赢了，也必须失去、承认或舍弃什么。

如果五项不能互相咬合，不进入大纲。

## 5. ENDING VECTOR

结构前先知道电影最终要证明什么，但不提前把所有路径写死：

```text
FINAL CHOICE:
WHAT IT COSTS:
WHAT THE PROTAGONIST CAN DO NOW THAT THEY COULD NOT DO BEFORE:
WHAT THE ANTAGONIST LOSES / PROVES / PASSES ON:
LASTING CONSEQUENCE:
CLOSING IMAGE / SOUND / ACTION:
OPENING-ECHO RELATION:
```

结局不能靠新增规则、突降证据或未建立能力解决。

## 6. OUTLINE FORGE

进入长片大纲时读取 `runtime/outline-forge.md`。

大纲不是“第一幕/第二幕/第三幕摘要”，而是同时维护：

- 因果脊柱；
- 主角策略升级；
- 对手自主计划；
- Sequence 目标与代价；
- 信息释放顺序；
- Promise–Payoff；
- 中点重构；
- 危机选择；
- 高潮所有权；
- Ending Echo。

**OUTLINE FORGE** 完成前禁止直接批量写场景。

## 7. FEATURE ARCHITECTURE

读取 `runtime/feature-architecture.md` 与 `runtime/sequence-engine.md`。

必须存在这些功能，但不硬锁页码：

`OPENING PROMISE → INCITING DISRUPTION → COMMITMENT → ESCALATING SEQUENCES → MIDPOINT REFRAME → COMPRESSION / NO-RETURN → CRISIS CHOICE → CLIMAX OWNERSHIP → CONSEQUENCE → CLOSING PROOF`

### MIDPOINT REFRAME

中点不是“更大的一场戏”。它必须至少改变一种：
- 主角对问题的理解；
- 观众对真相的理解；
- 敌我关系；
- 胜利条件；
- 失败代价；
- 主角主动/被动位置。

### CRISIS CHOICE

危机不是“难一点”。两个选项都必须伤害主角真正珍惜的东西；如果一边明显免费正确，危机是假两难。

### CLIMAX OWNERSHIP

高潮解法必须能追溯到此前建立的：能力 / 关系 / 证据 / 错误 / 训练 / 道德选择 / 牺牲。

## 8. CHARACTER / ANTAGONIST ENGINE

读取 `runtime/character-antagonist-engine.md`。

主角至少维护：

`WANT / NEED / GHOST / LIE / FLAW / CAPABILITY / LIMIT / STAKES / CURRENT STRATEGY / RED LINE`

对手不是“阻碍清单”。他拥有自己的：

`GOAL → PLAN → RESOURCES → CONSTRAINTS → BELIEF → LEARNING → ADAPTATION → ESCALATION → ENDGAME`

### ANTAGONIST AUTONOMY

即使主角不在场，对手的计划也在推进。主角撞上的应是对手行动产生的后果，而不是作者临时摆放的障碍。

### OBVIOUS SOLUTION KILLER

1. 先让主角提出当前最聪明、最合理的解决方案；
2. 再让对手、制度或世界规则用已建立能力破坏它；
3. 迫使主角升级策略并付出新成本。

禁止靠主角忘记常识制造危机。

## 9. POWER / INFORMATION WARFARE

读取 `runtime/power-information-war.md`。

核心场景追踪：

`FORMAL / RESOURCE / PHYSICAL / INFORMATION / RELATIONAL / MORAL / SOCIAL POWER`

以及：

`WHO KNOWS WHAT / WHO THINKS WHO KNOWS / WHO CAN PROVE WHAT / WHO CAN ACT ON IT`

一场戏的“赢”不一定是拿到目标，也可以是夺取解释权、信息优势、行动权或道德正当性。

## 10. CINEMATIC TREATMENT

Treatment 是“电影已经在发生”，不是结构说明书。写法：

- 只写摄影机与耳朵能承载的世界；
- 用动作、物件、环境、声音与具体选择承载情绪；
- 不在正文里标注结构术语；
- 每段都明确谁做了什么、世界如何反制、结果如何改变下一步；
- 伏笔只登记真正会被回收或有意识延宕的承诺。

Treatment 写作读取 `runtime/cinematic-treatment.md`。写完后运行 `runtime/outline-stress-test.md`，再做结构映射；不能为了模板倒写剧情。需要替代结构视角时按需读取 `references/structure-lenses.md`。

## 11. SCENE ENGINE

读取 `runtime/scene-engine.md`。

每场先锁：

```text
SOURCE / POV / GOAL / ENTRY POWER / ENTRY KNOWLEDGE
TACTIC / OPPOSITION / EXPECTED / ACTUAL / GAP
TACTIC SHIFT / TURN / EXIT POWER / EXIT KNOWLEDGE
STATE MUTATION / NEXT PRESSURE
```

如果删掉该场后，后面几乎不变，默认是弱场。

## 12. REHEARSAL DIALOGUE

核心场、对手戏和对白手术读取 `runtime/rehearsal-dialogue.md` 与 `references/dialogue-master.md`。

运行顺序：

`BLIND ACTOR → TACTIC CLASH → LINE TRIGGER → SCREENWRITER WEAVE → COLD TABLE READ → ACTOR OBJECTION → SILENCE PASS → VOICE / SAYABILITY`

关键对白允许 **DOUBLE-DUTY DIALOGUE**：表层完成一件事，同时在关系、信息、权力、身份或主题上完成第二件兼容的事。它是高级标准，不是每句硬指标。

## 13. STORY STATE

长片与剧集读取 `runtime/story-state.md`。唯一真源至少维护：

- Character State
- Character Knowledge
- Relationship / Power State
- Object / Resource State
- Physical / Injury State
- World Rule State
- Irreversible Events
- Promise–Payoff
- Timeline
- Plan / Commitment / Identity Belief / Moral Position

场景只有通过必要 QC 后才能 COMMIT Mutation。

## 14. PROMISE–PAYOFF

读取 `runtime/promise-payoff.md`。

任何被明显强调的身份、能力、道具、规则、关系问题、预言、警告、视觉母题或类型承诺都必须进入账本：

`OPEN / PARTIAL / PAID / DELIBERATELY_UNPAID / BROKEN`

BROKEN 必修；开放结局不能成为忘记回收的借口。

## 15. REWRITE LAB

初稿绝不直接交付。读取 `runtime/rewrite-lab.md`。

默认九轮：

1. MACRO STRUCTURE
2. CAUSAL DEPENDENCY
3. PROTAGONIST AGENCY
4. ANTAGONIST AUTONOMY
5. POWER / INFORMATION WARFARE
6. PROMISE / PAYOFF + SURPRISE INEVITABILITY
7. SCENE VITALITY + GOLDEN SCENE STANDARD
8. DIALOGUE / REHEARSAL / SAYABILITY
9. ENDING ECHO + CLIMAX OWNERSHIP

每轮只改自己的失败源；通过后才进入下一轮。

## 16. GOLDEN SCENE STANDARD

全片完成初稿后，分别找出本片目前最强的：
- 对白场；
- 动作/危机场；
- 情绪场；
- 反派场；
- 视觉/奇观场。

这些场景不是模板，而是本片自己的质量证据。核心场如果长期停留在“只是合格”，必须问：缺的是意外、人物性、代价、权力变化、视觉行动，还是不可替代性？

## 17. FINAL AUDIT

交付前读取 `runtime/final-audit.md`。

最终必须回答：
- 这部电影为什么只能这样发生？
- 主角是否真正制造了关键推进？
- 对手是否有自己的生命与策略？
- 中点是否改变了电影？
- 危机是否真的两边都痛？
- 高潮是否属于主角而不是作者？
- 结局是否回应开头承诺？
- 核心场景是否达到本片自己的 Golden Scene 水平？
- 台词是否能演、能听、能被对手触发，而不是作者分析？

不展示海量评分表；只给用户最关键的 PASS / RISK / FAIL 与修复目标。

## 18. 输出协议

### 从零创作
先交付：
1. Story Core
2. Character / Antagonist Spine
3. Ending Vector
4. Feature Outline
5. Sequence Map
6. Cinematic Treatment

用户要求继续时再进入逐场剧本。

### 已有剧本
先识别用户要求：结构诊断 / 大纲重做 / 场景修复 / 对白修复 / 全片重写。默认不越权改动锁定事实。

### 最终剧本
标准影视剧本格式优先；动作可拍、对白可演、状态连续。内部结构账与 QC 不必全部展示。
