# CHARACTER / ANTAGONIST ENGINE

## 1. Protagonist Spine

```text
WANT:
NEED:
GHOST:
LIE:
FLAW:
CAPABILITY:
LIMIT:
STAKES:
RED LINE:
OLD STRATEGY:
WHAT THE STORY KEEPS PROVING WRONG:
CRISIS CHOICE:
CLIMAX ACTION:
```

角色弧不是“学会一个道理”，而是旧策略在现实里不断失败，人物最终用新选择承担代价。

## 2. ANTAGONIST AUTONOMY

```text
GOAL:
WORLDVIEW / THESIS:
PLAN:
RESOURCES:
CONSTRAINTS:
WHAT THEY KNOW:
WHAT THEY MISREAD:
WHAT THEY ARE WILLING TO SACRIFICE:
LEARNING LOOP:
ADAPTATION:
ENDGAME:
```

对手每次遭遇主角后更新自己的判断。没有学习能力的反派只能靠规模升级。

## 3. Villain-As-Plot-Engine
理想状态：即使删掉主角视角，仍能描述对手正在推进的一条完整行动线。主角不是“被剧情安排遭遇危机”，而是不断撞上对手行动造成的后果。

## 4. OBVIOUS SOLUTION KILLER
先写主角最合理方案，再检查：
- 为什么不能报警/求援/撤退/公开证据/调用资源？
- 若这些办法合理可行，就让角色去做；
- 对手要用已建立能力反制，而不是作者禁止角色做聪明事。

## 5. Competing Narratives
高级冲突不仅争夺资源，也争夺解释权：

```text
PROTAGONIST CLAIM ABOUT REALITY:
ANTAGONIST CLAIM ABOUT REALITY:
WHAT EVIDENCE SUPPORTS EACH:
WHO CURRENTLY CONTROLS THE NARRATIVE:
WHAT ACTION COULD FLIP PUBLIC / RELATIONAL BELIEF:
```

最有力量的台词常来自两个角色都在争夺“事情到底算什么”。
