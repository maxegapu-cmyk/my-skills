# SEQUENCE ENGINE — 长片战役单元

## Sequence Contract

```text
SEQUENCE ID:
START STATE:
OBJECTIVE:
WHY NOW:
PROTAGONIST PLAN:
ANTAGONIST / WORLD COUNTERPLAN:
KEY INFORMATION:
POWER START:
PROGRESSIVE BEATS:
TURN:
RESULT:
COST:
POWER END:
NEW QUESTION:
NEXT PRESSURE:
PROMISE CREATED / PAID:
```

## Sequence Rules
1. 一个 Sequence 不是“几场同主题戏”，而是一轮完整策略。
2. 结果必须改变下一轮可用方案。
3. 胜利也应付代价；失败也应获得信息、承诺或能力，否则只是挫折堆叠。
4. 对手必须从上一轮学到东西；相同招数连续奏效会让敌人失智。
5. Sequence 之间不能任意交换顺序；若可交换，检查因果依赖。

## Sequence Stress Tests

### PLAN TEST
主角到底打算怎样赢？如果说不清，Sequence 只是游荡。

### COUNTERPLAN TEST
对手如何保护自己的最好结果？若答案是“等主角来”，对手被动。

### COST TEST
这一轮结束时，什么东西比开始更难恢复？

### KNOWLEDGE TEST
谁得到了什么新信息？谁误读？谁知道对方不知道？

### EXIT TEST
结尾必须把人物推向下一 Sequence，而不是靠编剧切场。
