# SCENE ENGINE — 场景事务

## Scene Contract

```text
SCENE ID:
SOURCE:
POV:
GOAL:
ENTRY POWER:
ENTRY KNOWLEDGE:
ENTRY RELATIONSHIP:
TACTIC:
OPPOSITION:
EXPECTED:
ACTUAL:
GAP:
TACTIC SHIFT:
TURN:
EXIT POWER:
EXIT KNOWLEDGE:
EXIT RELATIONSHIP:
STATE MUTATION:
NEXT PRESSURE:
```

## Scene Rules
- 场景必须承接已存在的 Source。
- 重要人物进入场景时已经有目标，不等编剧“开始剧情”。
- `EXPECTED == ACTUAL` 连续发生，场景缺少阻力。
- 对手变化后，当前角色仍照旧执行台词，判为 `PARALLEL_MONOLOGUE`。
- 场景结束至少改变：计划 / 信息 / 关系 / 权力 / 资源 / 风险 /承诺 / 道德位置之一。
- 无状态变化的长场必须证明其不可替代功能，否则压缩或删除。

## Scene Delete Test
删掉整场，后面是否仍能靠一句补充说明无损继续？若是，优先合并或重写。

## Visual Action Test
删掉台词后，观众能否大致知道谁在争什么、什么变了？若完全不能，台词可能承担了过量解释。
