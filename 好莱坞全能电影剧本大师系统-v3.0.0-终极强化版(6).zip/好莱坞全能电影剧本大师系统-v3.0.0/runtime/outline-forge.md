# OUTLINE FORGE — 长片大纲锻造器

## 目的
把“故事想法”变成能支撑整部长片的因果大纲，而不是事件清单。

## 1. Outline Spine
先写一条不超过 20 个关键节点的脊柱，每个节点都用：

```text
CAUSE → CHARACTER CHOICE → OPPOSITION → RESULT → COST → NEW PRESSURE
```

如果一个节点只有 EVENT，没有 Choice / Cost / New Pressure，标为 `PASSIVE_NODE`。

## 2. Four-Layer Outline

### Layer A — Dramatic Spine
只看主角目标、反制、策略变化、危机、高潮。

### Layer B — Antagonist Counter-Spine
标出对手在主角看不见时做了什么；两条脊柱必须能真实碰撞。

### Layer C — Relationship / Information Spine
追踪关系信任、秘密、误判、证据、解释权的变化。

### Layer D — Promise / Payoff Spine
标出观众被承诺的悬念、能力、道具、关系问题与类型回报。

四层叠加后仍能看出一条清晰主线，才算可写。

## 3. Mandatory Feature Functions
不锁页码，但必须有功能：

- **OPENING PROMISE**：告诉观众这部电影将提供哪种体验、人物缺口与世界张力。
- **INCITING DISRUPTION**：原有平衡被具体事实破坏。
- **COMMITMENT**：主角做出不能轻易撤回的行动。
- **PROGRESSIVE COMPLICATIONS**：每轮尝试改变局势，而非同类麻烦加量。
- **MIDPOINT REFRAME**：电影问题被重新理解。
- **COMPRESSION / NO-RETURN**：选择空间缩小，退路被真实切断。
- **CRISIS CHOICE**：两个选项都损失真实价值。
- **CLIMAX OWNERSHIP**：主角以此前建立的东西完成最终行动。
- **CONSEQUENCE**：世界、关系、身份、道德位置留下持续结果。
- **CLOSING PROOF**：最后画面/动作/声音证明变化，而不是解释主题。

## 4. Causal Dependency Graph
关键节点写依赖：

```text
N08 requires: N02 information + N05 relationship rupture + N07 lost resource
```

### DELETE NODE TEST
删掉 Nxx：
- 后续若仍可原样发生 → 该节点可能是假推进；
- 后续只需一句解释即可补齐 → 节点重要性不足；
- 多个后续节点崩塌 → 依赖真实。

## 5. Strategy Evolution
主角每 1–2 个 Sequence 至少出现一次真实策略升级：

`旧办法 → 世界学会反制 → 失败/代价 → 新办法`

“更用力地做同一件事”不算新策略。

## 6. MIDPOINT REFRAME Test
中点前后各写一句：

```text
BEFORE: 主角/观众以为这部电影的问题是 ______。
AFTER: 现在知道真正的问题是 ______。
```

两句若只是“敌人更强了”，中点偏弱。

## 7. CRISIS CHOICE Test
两个选项都写：

```text
GAIN:
LOSE:
SELF-BETRAYAL RISK:
RELATIONSHIP / MORAL COST:
WHY NO THIRD FREE OPTION:
```

若存在明显免费第三路，先封死逻辑再写高潮。

## 8. Blockbuster Scale Without Empty Spectacle
大片升级优先增加：
- 选择后果；
- 系统级连锁反应；
- 关系/阵营裂变；
- 信息与资源变化；
- 时间/空间不可逆性。

爆炸规模可以变大，但必须是人物行动的后果，不是替代戏剧。

## 9. Outline Exit Gate

```text
[ ] 20 节点内可讲清主线
[ ] 每个核心节点有 Cause / Choice / Cost
[ ] 对手 Counter-Spine 独立成立
[ ] 中点真正重构问题
[ ] 危机没有免费正确答案
[ ] 高潮解法此前已建立
[ ] Ending Echo 已能回接 Opening Promise
[ ] Promise–Payoff 无明显 BROKEN
```
