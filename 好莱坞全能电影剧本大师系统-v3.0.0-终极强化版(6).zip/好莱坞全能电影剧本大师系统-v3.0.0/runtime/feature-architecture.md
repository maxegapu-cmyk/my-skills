# FEATURE ARCHITECTURE — 长片结构总控

## 原则
结构是压力的组织，不是模板的服从。

## 1. Three Scales

### Film Scale
维护全片 Dramatic Question、主角弧、对手计划、最终代价。

### Sequence Scale
每个 Sequence 是一次完整战略行动：目标明确、方案明确、对手适应、结果改变新局面。

### Scene Scale
每场只承担当前 Sequence 的具体战术任务。

禁止用 Scene 的局部漂亮掩盖 Film Scale 的主线缺口。

## 2. Structural Energy
每一段结构至少改变一种能量：
- agency
- danger
- intimacy
- knowledge
- resources
- legitimacy
- time
- moral cost
- irreversibility

连续三段只提高 danger 规模而不改变其它能量，标为 `MONOTONOUS_ESCALATION`。

## 3. Commitment Boundary
主角从“可以退出”到“退出也有代价”的边界必须可见。可以是签字、撒谎、越界、公开站队、偷走证据、发动行动、背叛关系。

## 4. Mid-Film Reframe
合格中点至少执行两项：
- reveal a hidden rule;
- reverse hunter/hunted;
- change what victory means;
- expose ally/enemy identity;
- convert private conflict into public conflict;
- force protagonist to own the fight;
- reveal the antagonist thesis as partly true.

## 5. No-Return Compression
后半段要减少“还能恢复原状”的空间。常见手段：
- 公开身份；
- 关键关系破裂；
- 资源永久损失；
- 时间窗口关闭；
- 对手获得主角弱点；
- 主角主动跨越自己的红线。

## 6. Crisis / Climax Separation
危机回答：**我选择成为谁？**
高潮回答：**我怎样用这个选择行动？**

如果高潮只是危机问题又问一遍，结构重复。

## 7. Closing Proof
最后不是总结，而是证据。优先用：
- 一个此前意义已建立的物件；
- 一种关系中的新行为；
- 世界规则留下的变化；
- 主角第一次能/不能做的动作；
- 一个声音或空间关系的回响。
