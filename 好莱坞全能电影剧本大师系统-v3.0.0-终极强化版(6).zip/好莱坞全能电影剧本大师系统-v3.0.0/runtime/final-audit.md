# FINAL AUDIT — 最终电影级审计

状态：`PASS / RISK / FAIL / N/A`

## Feature Gates
- F01 STORY CORE：核心问题、欲望、对手命题、胜利代价互相咬合。
- F02 CAUSALITY：关键后果可追溯到先前选择。
- F03 AGENCY：主角制造关键推进并拥有高潮。
- F04 ANTAGONIST AUTONOMY：对手独立行动、学习、适应。
- F05 OUTLINE DEPENDENCY：核心节点不可任意删除/交换。
- F06 SEQUENCE PROGRESSION：每轮策略与代价真正升级。
- F07 MIDPOINT REFRAME：中点改变电影问题或胜利条件。
- F08 CRISIS CHOICE：两个选项都有真实损失且无免费第三路。
- F09 CLIMAX OWNERSHIP：解法此前建立并由主角选择触发。
- F10 POWER / INFORMATION：权力与信息状态可追踪。
- F11 PROMISE / PAYOFF：高显著承诺已支付或有意识延宕。
- F12 SURPRISE INEVITABILITY：反转意外但可回看。
- F13 SCENE VALUE：核心场有不可替代变化。
- F14 CHARACTER TRUTH：人物知识、动机、策略成立。
- F15 DIALOGUE ACTION：对白在对对手做事，非作者说明。
- F16 SAYABILITY / VOICE：主要人物声音可辨、可演、关系化。
- F17 VISUAL WRITING：心理/主题有可拍证据。
- F18 GOLDEN SCENE FLOOR：关键场不是长期停在普通合格线。
- F19 ENDING ECHO：结尾回应开头承诺并留下后果。
- F20 CONTINUITY：知识、物件、伤势、时间、关系、世界规则连续。

## Evidence Card

```text
GATE:
STATUS:
EVIDENCE:
STRONGEST COUNTEREXAMPLE:
IMPACT:
REPAIR PASS:
```

不得用“整体高级”“很顺”“情绪很好”作为 PASS 证据。
