# REHEARSAL DIALOGUE — 排演式对白运行层

## 宪法
角色不替作者成全剧情。角色只使用自己拥有的知识，为自己的目标行动；总编剧负责把真实选择织成可拍场景。

## 1. Blind Actor Packet
每个角色只看：

```text
VISIBLE FACTS / PRIVATE KNOWLEDGE / MISBELIEF
WANT NOW / FEAR NOW / TACTIC NOW / RED LINE
RELATIONSHIP / POWER POSITION / WHAT I MUST PROTECT
```

禁止读取别人私密知识、未来剧情、主题答案、编剧希望的出口。

## 2. Tactic Clash
推进不是 A 说完 B 说，而是：

`A ACTION → B INTERPRETATION → B COUNTER → A READS CHANGE → A SHIFTS TACTIC`

有效 Beat 至少改变判断、策略、权力、关系、信息、承诺或边界之一。

## 3. Line Trigger Graph
重要句必须能追踪当前刺激：

```text
TRIGGER → INTERPRETATION → SPEECH ACT / ACTION → RESPONSE → SHIFT
```

删掉上一刺激后下一句仍原封不动成立，多次出现则检查是否只是并排信息。

## 4. Screenwriter Weave
排演先产 Beat，不先产“漂亮对白”。总编剧再：
- 合并重复 Beat；
- 把解释转成行动；
- 保留有价值误读；
- 让关键一句同时承担两个兼容任务；
- 不为了金句破坏知识边界。

## 5. COLD TABLE READ
第一次拿到剧本的演员要能回答：
- 我为什么现在说？
- 是什么刺激了我？
- 这句话是我的策略，还是作者给观众的说明？
- 嘴里说得顺吗？
- 对方刚做的更重要事情我为什么没回应？

## 6. ACTOR OBJECTION
允许五类反对：
- KNOWLEDGE
- MOTIVE
- VOICE
- TACTIC
- RESPONSE

成立的反对必须修，不得用“剧情需要”压掉。

## 7. SILENCE PASS
关键场尝试删去一部分解释性对白，让：物件、没回答的问题、任务中断、距离、称谓、交接、停手、拒绝等承担第二层。比例不是 KPI；删后因果变糊就恢复。

## 8. DOUBLE-DUTY DIALOGUE
关键台词优先同时完成两件兼容的事，例如：
- 回答表面问题 + 隐瞒真实目的；
- 安抚 + 夺回控制权；
- 讲事实 + 测试对方知道多少；
- 威胁 + 公开定义双方关系；
- 道歉 + 拒绝真正让步。

不是每一句都必须双层。纯物流/事实句允许单功能。

## 9. Sayability
朗读时优先修：书面句法、过长完整逻辑、同节奏轮流演讲、每个人都说“作者语言”、不必要主题总结。

## 10. Fake-Humanity Guard
“嗯、呃、抿嘴、吞咽、眼神复杂、随机停顿”不是活人味。真人感来自：目标、有限知识、对手刺激、策略、代价和不完全表达。
