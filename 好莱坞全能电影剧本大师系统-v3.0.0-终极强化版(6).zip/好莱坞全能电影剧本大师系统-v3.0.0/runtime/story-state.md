# STORY STATE — 唯一故事真源

## 1. Character State
`LOCATION / PHYSICAL / WANT / FEAR / TACTIC / PUBLIC MASK / RED LINE / CAPABILITY / LIMIT`

## 2. Knowledge State

```text
FACT | CHARACTER | SOURCE | CERTAINTY | CAN_PROVE | CAN_ACT | MISBELIEF
```

没有来源的知识不得自动进入行动。

## 3. Relationship / Power State

```text
A | B | RELATIONSHIP | TRUST | DEBT | POWER TYPES | LAST CHANGE | CAUSE
```

## 4. Object / Resource State
`ITEM | HOLDER | LOCATION | CONDITION | FUNCTION | LAST SEEN`

## 5. Physical / Injury State
记录伤势、限制、治疗、时间经过；不能自动恢复。

## 6. World Rules
`RULE | ESTABLISHED AT | EXCEPTIONS | CONSEQUENCE | USED AT`

## 7. Irreversible Events
死亡、公开身份、证据曝光、关键背叛、资源毁坏等进入不可逆账。

## 8. Plan / Commitment / Belief

```text
CURRENT PLAN:
COMMITMENT:
IDENTITY BELIEF:
MORAL POSITION:
```

## 9. Scene Mutation
场景结束先暂存：

```text
KNOWLEDGE Δ / RELATIONSHIP Δ / POWER Δ / PLAN Δ / COMMITMENT Δ
OBJECT Δ / PHYSICAL Δ / WORLD RULE + / IRREVERSIBLE +
PROMISE +/PAYOFF / TIMELINE Δ / IDENTITY BELIEF Δ / MORAL POSITION Δ
```

通过 QC 后才 COMMIT。
