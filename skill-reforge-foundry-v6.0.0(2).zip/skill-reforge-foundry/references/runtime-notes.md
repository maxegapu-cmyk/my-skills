# 运行环境说明

## 通用 Agent Skills（Claude 等）

- 包根目录放 SKILL.md；文件夹名与 name 一致。
- name：小写字母、数字、连字符，不超过 64 字符；在 Claude 上不能含 anthropic 或 claude。
- description：非空，不超过 1024 字符，不含尖括号标签。它是常驻上下文的信息，决定技能是否被调用。
- frontmatter 默认只写 name 和 description；license、compatibility、metadata、allowed-tools 只在目标运行时支持时添加。
- 上传 ZIP 时，压缩包顶层应是技能文件夹；forgecheck pack 会以 name 作为顶层目录。
- 参考文件按需读取；脚本可以直接执行，不必把全部源码读进上下文。

## OpenAI / Codex

可选的 agents/openai.yaml 界面信息：display_name、short_description（25–64 字符）、default_prompt（包含 $技能名）。SKILL.md 大改后同步更新。图标或依赖只在真实存在时添加。

## Notion

- 一个技能 = 一个页面：页面正文放 SKILL.md 的正文（不含 frontmatter），技能描述栏填 description。没有描述的技能通常不会被自动使用，只能被点名调用。
- 参考文件改为子页面或折叠块，并在正文写明"需要时读子页面《……》"。
- 脚本无法执行：改写为检查步骤，或注明需在外部运行。
- 用户只能粘贴时，交付一份完整的页面正文 + 一段描述文字。

## 其他聊天平台（GPTs、项目指令、自定义指令）

合并为一份指令：目标 → 什么时候用 → 流程 → 规则 → 清单 → 范例。注意平台字数上限，超出时保留规则和清单，压缩范例。

## 无文件系统的对话环境

输出目录树 + 每个文件一个完整代码块；内容含三个反引号时外层用四个；说明由谁、在哪里落地；不声称已创建、已运行或已通过检查。
