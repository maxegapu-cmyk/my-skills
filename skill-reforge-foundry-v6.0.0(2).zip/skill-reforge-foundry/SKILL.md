---
name: skill-reforge-foundry
description: Turn a conversation, a person's hands-on experience, a rough prompt or SOP, or an existing Skill into a new, tested, reusable Agent Skill or a small family of Skills, guiding beginners step by step. Use when the user says things like "把刚才的经验做成skill", "把我的方法整理成一套系统/技能", "帮我做/升级/修补一个skill", "turn this chat into a skill", or provides an old Skill or a failure report to rebuild. Not for doing the one-off task itself, generic prompt polishing, or app development. 把对话与个人经验萃取成可复用技能，适合零基础用户。
---

# Skill Reforge Foundry

把用户在对话里展示出来的经验，变成以后一调用就能复现的技能。

**北极星**：用了新技能之后，用户不必再做一遍这次对话里做过的纠正。

## 1. 判断模式与用户水平

| 用户情况 | 模式 | 起点 |
|---|---|---|
| 刚和你完成一件事，想把做法存下来 | 萃取 | 当前对话 |
| 只有想法，对话里没有可学的过程 | 采访 | 五问访谈 |
| 有旧 Skill、提示词或 SOP | 重铸 | 旧材料 + 用户不满意的地方 |
| 某个技能用着出错 | 修补 | 出错现场 |
| 想要"一套系统"，经验涉及多件事 | 体系 | 先出技能地图 |

用户没用 Skill 相关术语、说自己不懂、或只说"帮我做个技能"时，按新手处理：读 `references/novice-guide.md` 并全程遵守。

## 2. 七步流程

**① 锁定目标**：写出一句"以后当你___时，它帮你___，做到___"。能从对话推断就不问，放进方案卡确认。

**② 挖经验**：读 `references/experience-mining.md`，产出经验账本——纠正点最优先；对比初稿与被认可的终稿；每条带证据和级别；过泛化三问；推断项标❓；脱敏。大型或多技能任务按 `assets/build-brief.template.yaml` 的结构记录。

**③ 补缺口**：只问会改变技能行为的事；每轮最多 3 问、最多 2 轮；每问附默认选项；用户说"你定"就取默认并记为假设。

**④ 唯一确认点**：展示方案卡（目标句、按类型分组的经验清单、技能结构、技能名）。用户回复"可以"后再写。用户说"直接做"时跳过，并在交付卡中列出全部假设。

**⑤ 写技能**：
- 结构：读 `references/package-shapes.md`，选最轻的结构；体系模式按其中的拆分规则。
- 写法：读 `references/distill-patterns.md`，以 `assets/skill-skeleton.md` 为骨架。
- 平台：读 `references/runtime-notes.md`；目标含 Codex 时参照 `agents/openai.yaml` 附界面信息。

**⑥ 自测**：读 `references/trial-bench.md`，按 `assets/trial.template.yaml` 写用例（参考本包的 `evals/trials.yaml`）。最少：3 条应触发、2 条不应触发、每条 S 级经验 1 条回放、1 条缺输入。挑最典型的一条完整走查，给出模拟输出片段。没过的用例回到 ⑤ 修根因，不堆例外。

**⑦ 交付**：先给技能本体，再按 `assets/handoff-card.md` 写交付卡。检查标签如实写（static / walkthrough / runtime / field）。

## 3. 写技能的硬规则

1. **经验保真**：每条 S/A 级经验都要在技能里有落点（流程、规则、清单或范例）；交付前对照账本逐条核对。
2. **不编经验**：用户没展示过的通用做法只能列为"建议补充"，用户同意后才写入。
3. **可检验**：规则写成能判断对错的句子，重要规则附"因为"。
4. **范例胜过形容词**：风格、口吻类经验至少给一组好/差对比，取自真实对话并脱敏。
5. **学方法不学内容**：不要把本次对话的具体题材、人物、数据写成通用规则，除非用户要的就是该专题技能。
6. **触发说明写准**：description = 做什么 + 什么时候用（用户原话说法）+ 不用于什么；不超过 1024 字符，不含尖括号标签。
7. **短**：SKILL.md 正文一般不超过 300 行，上限 500 行；长内容移入参考文件，在用到的步骤指向它。
8. **有出口**：写明缺输入时问什么、工具不可用时怎么降级、会编造事实时停下。
9. **隐私**：人名、联系方式、账号、密钥、内部数据一律替换，除非用户明确要求保留。
10. **对使用者友好**：新技能的使用者是新手时，开头给"直接这样说"的调用示例。

## 4. 体系模式

1. 列出经验中涉及的独立工作，按使用频率排序，画成技能地图（名称、做什么、什么时候用、依赖）。
2. 按 `references/package-shapes.md` 的拆分规则决定合并或拆分。
3. 先把频率最高的一个做到可交付，其余按地图依次完成或给出计划，由用户定顺序。
4. 每个技能独立可用；共用约定复制进各自的参考文件，不依赖跨技能读取。

## 5. 重铸与修补

**重铸**：先找出反复出现的工作和可观察的结果；区分持久行为与偶然措辞、过时补丁、重复指令；结构按当前工作重新选择，不继承旧文件树；弱的部分按需求重写，不叠加例外。重铸后应更好用，而不只是更新。

**修补**：复现失败 → 归因（没触发 / 误触发 / 指令缺失 / 指令冲突 / 范例误导 / 环境限制）→ 最小修改 → 把这次失败加为回放用例 → 版本号升第三位并写更新记录。

## 6. 检查与打包

有文件系统和 Python 3.8+ 时：

```bash
python scripts/forgecheck.py init <输出目录> <skill-name>
python scripts/forgecheck.py lint <skill-dir> --strict
python scripts/forgecheck.py pack <skill-dir> <release.zip>
```

lint 只检查包结构、元数据、引用、占位内容、隐私和用例数量，不证明行为质量。无法运行时如实标为未运行，不得声称已通过。

自检本工具：`python scripts/forgecheck.py lint . --strict`

## 7. 交付格式

| 环境 | 交付 |
|---|---|
| 能写文件 | 技能文件夹或 ZIP + 交付卡 + 实际运行过的检查 + SHA-256 |
| 只能对话 | 目录树 + 每个文件一个完整代码块（内容含三个反引号时外层用四个）+ 交付卡；不声称已创建或已运行 |
| Notion | 页面正文版 + 单独一段可粘贴的技能描述；参考文件改为子页面或折叠块 |
| 其他聊天平台 | 合并为一份可粘贴的指令 + 交付卡 |

新技能版本从 1.0.0 开始：修补升第三位，新增能力升第二位，结构重做升第一位。交付消息只写用户用得上的：成品、怎么用、做了哪些检查、哪些没测、做了哪些假设。
