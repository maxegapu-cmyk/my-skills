# 按平台选择只读检查

只运行目标系统已有的工具。以下命令是候选，不是每次都要执行的清单；把 `<host>` 换成受影响服务的公开主机名，把 `<port>` 换成现场确认的端口。不要把完整代理 URL、认证头或原始日志贴到公开报告中。

## Windows

先看网卡、地址、默认网关与 DNS：`Get-NetAdapter`、`Get-NetIPConfiguration`、`Get-DnsClientServerAddress`。在“只有某个网站/应用失败”时，再对该目标用 `Resolve-DnsName <host> -Type A`、`Resolve-DnsName <host> -Type AAAA` 和 `Test-NetConnection <host> -Port 443`；连网关都不稳定时，优先查 Wi-Fi/有线链路。若 Codex 实际在 WSL 中运行，改从相同的 WSL 发行版测 DNS 和代理，不能只测 Windows。

有代理或 VPN 时，对照“应用实际使用的代理”和“当前在监听的代理”，而不是凭习惯猜端口：Windows 设置中的“网络和 Internet → 代理”、`netsh winhttp show proxy`、与应用相关的 `HTTP_PROXY`/`HTTPS_PROXY`/`NO_PROXY`，以及 `Get-NetTCPConnection -LocalPort <port> -State Listen`。避免打印含用户名或密码的代理 URL。Windows 系统代理、VPN 连接的代理和应用自己的环境变量可能是不同入口。

如果 Wi-Fi 本身反复断开，参考 Microsoft 的网关测试、网络疑难解答、驱动和路由器检查。`网络重置`是官方列出的最后步骤，会移除网卡及设置，不能作为默认第一步。

## macOS

先看系统设置中的 Wi-Fi/以太网连接与网络详情。可用 `route -n get default` 看网关，`scutil --proxy` 看系统代理，`scutil --dns` 看解析配置，`dig A <host>` 与 `dig AAAA <host>` 分开看解析，`curl -I https://<host>` 看 HTTPS 是否到达。若只有无线网络不稳定，使用“无线诊断”；Apple 说明它会分析问题而不修改网络设置。若有 VPN、安全软件或过滤器，用另一网络和另一设备做对照，再检查相关设置。必要时可利用 macOS 网络位置保存旧设置并建立测试位置。

## Linux

先确认本机实际使用 NetworkManager、systemd-networkd、Netplan 还是其他管理器。NetworkManager 环境可用 `nmcli device status` 和 `nmcli connection show --active`；通用只读检查包括 `ip address`、`ip route`、`resolvectl status`（若系统使用 systemd-resolved）、`getent ahosts <host>`、`ss -ltn` 与针对目标的 `curl -I https://<host>`。不同发行版、容器和 WSL 的管理方式不同；不要直接覆盖 `/etc/resolv.conf` 或随意添加默认路由。

## 对照的含义

- 其他设备同网也失败：优先查路由器、上游或服务状态。
- 本机换网络即恢复：优先查原网络的路由、DNS、过滤或运营商路径。
- 同网其他应用正常、目标应用失败：优先查应用版本、代理、证书和认证。
- 显式通过代理的 `curl` 可达，应用仍失败：继续查应用是否真的采用同一路径，以及流式协议和长连接；不要宣布“网络已修好”。
- A 正常而 AAAA 报错，或 IPv4 可达而 IPv6 不通：进入 [DNS 定位](dns-diagnosis.md)，先确定出错的是目标名还是代理名、解析器和运行环境；不要直接全局关闭 IPv6。
- 模式切换时断、稳定后恢复：检查代理核心是否重启或旧连接是否被清理；应在目标模式稳定后复测，不把切换瞬间当作长期故障。

平台依据：[Microsoft Windows Wi-Fi 排障](https://support.microsoft.com/en-us/windows/experience/connectivity-networking/fix-wi-fi-connection-issues-in-windows)、[Microsoft Windows 代理配置](https://support.microsoft.com/en-us/windows/experience/connectivity-networking/use-a-proxy-server-in-windows)、[Apple 无线诊断](https://support.apple.com/en-gw/guide/mac-help/mchlf4de377f/mac)、[Apple VPN 与安全软件排查](https://support.apple.com/en-gb/102281)、[NetworkManager nmcli 手册](https://networkmanager.dev/docs/api/latest/nmcli.html)、[Ubuntu 网络配置说明](https://ubuntu.com/server/docs/explanation/networking/configuring-networks/)。
