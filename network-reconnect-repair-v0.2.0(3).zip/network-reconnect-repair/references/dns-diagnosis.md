# DNS：先确定谁在解析

仅当解析错误、连接前超时、IPv4/IPv6 差异、VPN 切换后旧结果，或“浏览器可用而目标进程不可用”指向 DNS 时读取。DNS 排障的第一问是**故障进程实际在哪个环境发请求、由谁解析目标名和代理名**。系统 DNS、浏览器安全 DNS、代理客户端、WSL/容器和远端代理可能得到不同答案；Windows 上的 `Resolve-DnsName` 不能证明 WSL 内的解析结果。

## 把现象分开

1. 同时记录目标服务域名和代理服务器主机名（如果使用代理）的 A、AAAA、失败码、耗时与所用解析器。区分 `NXDOMAIN`、`SERVFAIL`、超时和空的正常回答；`A` 有结果不代表 `AAAA` 查询也正常。
2. 再测对应地址族的连接：同一运行环境内对照 `curl -4` 与 `curl -6` 的无凭据 HTTPS 请求，或等价的 TCP/TLS 测试。解析成功而 TCP 不通是路由/地址族问题，不能靠刷新缓存下结论；HTTP 返回说明已经越过 DNS/TCP/TLS 的一部分，但不证明应用流式请求成功。
3. 若使用代理，先确认目标名由本机还是代理解析，并分别验证代理主机名与目标服务名。代理主机名的 AAAA `SERVFAIL`、目标名仅返回不可达 IPv6，以及代理本地端口无人监听，是三种不同故障。
4. 若出现虚拟地址，核对当前代理是否启用 Fake-IP/TUN。mihomo 的 `fake-ip` 模式本来就会返回合成地址；只有在故障与该映射有可复现的对应关系时，才考虑一个域名的临时过滤或路由修正。保留原配置，复测后恢复或最小化提交；不要把整个域名后缀、全局 IPv6 或全系统 DNS 一并改掉。
5. 若切网、唤醒或切 VPN 后才失败，比较新旧 DNS 服务器和解析结果，以及代理或应用进程是否仍缓存旧路径。先重启受影响的应用或代理组件作有界对照；仅在确有缓存不一致时才处理相应缓存。

## 可选只读命令

Windows：`Resolve-DnsName <host> -Type A`、`Resolve-DnsName <host> -Type AAAA`、`Get-DnsClientServerAddress`、`Get-DnsClientCache`。需要排查分流或某台 DNS 服务器时，可用 `Resolve-DnsName <host> -Server <known-dns-server>` 对照已配置或组织批准的服务器；这只是诊断请求，不应直接改系统 DNS。先确定应用是原生 Windows 进程还是 WSL 进程；若在 WSL，再从同一发行版执行 Linux 检查。

macOS：`scutil --dns` 查看系统解析配置；`dig A <host>` 和 `dig AAAA <host>` 可对照 DNS 服务器回答，但不能单独证明应用使用了 `dig` 的路径。Linux/WSL：按实际解析栈使用 `resolvectl status`、`resolvectl query <host>`、`getent ahosts <host>` 或 `dig A/AAAA <host>`；在容器内执行时不要拿宿主机结果代替。

对 Windows+WSL，先确认 WSL 网络模式、DNS tunneling、代理继承和 `/etc/resolv.conf` 实况；Microsoft 说明 WSL 的 DNS tunneling 用虚拟化回答 Linux 侧 DNS 请求，且与 VPN 等复杂网络的兼容性有关。不要把开启 mirrored mode 或 DNS tunneling 写成无条件修复。

## 修复边界

优先修已证实失效的单个代理主机名、解析策略或进程入口；临时改用已核实的地址可用于诊断，但固定 IP 可能过期，也可能改变证书/SNI、CDN 路由或组织策略，不能作为永久默认。对地址族差异，先核实路由和应用的回退行为；不要直接全局关闭 IPv6。DNS 服务器更换、全局缓存清理、hosts 覆盖、关闭 DoH 或删除 VPN DNS 策略都需要具体证据和恢复计划。

依据：[Microsoft DNS 客户端排障](https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/troubleshoot-dns-client-resolution-issues)、[Microsoft WSL 网络](https://learn.microsoft.com/en-us/windows/wsl/networking)、[mihomo DNS 配置](https://wiki.metacubex.one/en/config/dns/)、[IETF RFC 8305 双栈连接](https://www.rfc-editor.org/rfc/rfc8305.html)。
