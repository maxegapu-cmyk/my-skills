# QC & Repair 2.0

## 1. 先硬门，后审美

单张依次检查：
1. P0 garment；
2. 人物/身份/人体；
3. 本张卖点；
4. Style CORE；
5. SCG 场景与光向；
6. 配饰、道具、文字、Logo；
7. 最后才看“是不是更漂亮”。

## 2. 常见失败模式

### F01：衣服变成“同类新设计”
症状：领口、背部、开衩、扣子、图案被模型美化。
修法：减少无关 style 图；带 P0 对应 B 图；明确 `do not reinterpret or redesign`；连续失败则切 try-on/后期。

### F02：第 6 张已经不像第 1 张
症状：脸、身材、衣长、配饰逐步漂。
根因：链式把上一张当唯一锚点。
修法：每张回看 Master Anchor；上一张只作为场景补充，不作为身份总源。

### F03：很像参考图，但像“翻拍”
症状：同一主体位置、同一动作、同一背景关系。
修法：保留光线/调色/镜头族，改 zone、机位、动作和构图变量；必要时降低 composition 参考强度。

### F04：每张都漂亮，整套像 8 个摄影师
症状：色温、黑位、太阳方向、颗粒、焦段乱跳。
修法：回到 Style CORE + SCG；建立 batch-grade lock；不要每张临时“再高级一点”。

### F05：造型太用力
症状：包、首饰、帽子遮衣服或抢主体。
修法：删除而非继续添加；主图优先裸净造型。

### F06：人体/手失败
只修局部；若局部编辑导致衣服变形，回 Master Anchor 重生本镜头。

## 3. Micro-edit 模板

`Edit Image 1. Change only [one defect] to match Image [evidence]. Preserve exactly: [face/identity], [all P0 garment attributes], pose, framing, lighting direction, scene, color grade, accessories, and image quality. Success check: [observable result]. Do not redesign or add anything.`

## 4. Repair ladder

- Level 1: single local edit；
- Level 2: evidence refresh；
- Level 3: regenerate shot from Master Anchor；
- Level 4: route switch；
- Level 5: post composite / manual correction。

同一错误修两次仍失败，自动升级一级，不继续盲抽。

## 5. 套图终检

逐张看完后再做 contact-sheet 思维检查：
- 八张缩略图放一起，是否第一眼像同一批；
- 是否有一张色温/曝光明显跳出；
- 是否有重复废片；
- 是否有遗漏的商品视角；
- 是否主图不够强却有副图更适合主图。
