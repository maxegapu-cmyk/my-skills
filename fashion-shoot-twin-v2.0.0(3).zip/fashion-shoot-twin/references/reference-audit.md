# Reference Audit — 多图证据审计

目的：防止“看到一张漂亮图就把偶然特征当成摄影师风格”。

## 1. 每张参考图先分角色

为 A1…An 标注：
- `style_strength`: strong / medium / weak
- `location_value`: high / medium / low
- `lighting_value`: high / medium / low
- `composition_value`: high / medium / low
- `sequence_role`: hero / full-body / transition / detail / atmosphere / unknown
- `conflicts`: 与其他图冲突的地方

同一张图可以对光线很有价值、对构图却是离群点。

## 2. 参考图权重

优先级：
1. 同一摄影项目、同一时间段、多张一致；
2. 同摄影师不同项目但重复出现的习惯；
3. 单张明显效果；
4. 无法确认来源或经过重度二次编辑的图。

不要因为某张视觉冲击最强就自动给最高权重。

## 3. 多数派规则

建议记录支持率：`support = 支持此特征的有效图片数 / 有能力判断此特征的图片数`。

- support ≥ 0.60：可进入 CORE 候选；
- 0.30–0.59：FLEX 候选；
- < 0.30：默认 OUTLIER；
- 低频但高度独特的特征可人工提升，但必须说明理由。

注意“有能力判断”：例如一张纯面部特写不能用来判断全身裁切习惯。

## 4. 冲突拆分

出现以下情况时分 cluster：
- 室内直闪 vs 户外柔光；
- 极端广角 vs 长焦压缩；
- 高饱和商业棚拍 vs 低饱和纪实；
- 一组精致摆拍 vs 一组强抓拍。

不要把互相矛盾的两套语言平均成“柔和又硬朗、纪实又棚拍”。

## 5. 防复制检查

列出每张 A 图的 `content fingerprint`，包括：
- 原模特身份；
- 原服装；
- 独特姿势组合；
- 独特道具组合；
- 精确主体位置 + 机位 + 背景元素的组合。

这些属于禁止复制的内容，不进入 Style Fingerprint。
