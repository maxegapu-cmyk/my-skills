# GPT 图像模型：最佳实践与本技能的用法

资料来源（2026-10 查阅，模型与参数以官方当前页面为准）：
- OpenAI《Image prompting》指南：developers.openai.com/api/docs/guides/image-prompting
- OpenAI Cookbook《GPT Image Generation Models Prompting Guide》：developers.openai.com/cookbook/examples/multimodal/image-gen-models-prompting-guide
- OpenAI《Image generation》API 指南：developers.openai.com/api/docs/guides/image-generation

## 模型与参数（API）

- 查阅时官方列出 **GPT Image 2.5**：`gpt-image-2.5-sunburst`（基础模型，质量优先）和 `gpt-image-2.5-flare`（小模型，速度优先，质量与 GPT Image 2 相当），两者都加强了精确编辑与主体保持。`gpt-image-2` 仍是 Cookbook 推荐的稳定默认。
- 新流程建议：先用质量优先的模型把效果做达标，再用同样的提示词测试速度优先的模型，达标才切换。
- `quality`：GPT Image 2.5 支持 `auto/low/medium/high/xhigh/max`；`gpt-image-2` 支持 `low/medium/high`。本技能建议：规划和草稿用 `medium`，终稿用 `high`；`xhigh/max` 只在能解决未达标问题时使用。
- `size`：两边都是 16 的倍数，长边不超过 3840，长短边比例不超过 3:1，总像素在 655,360–8,294,400 之间；超过 2560×1440 的总像素属于实验性，结果更不稳定。
- 电商常用尺寸：3:4 → `1536x2048`，4:5 → `1280x1600`，1:1 → `1536x1536`，9:16 → `1152x2048`，常规竖图 → `1024x1536`。
- `gpt-image-2` 始终以高保真处理输入图，会忽略 `input_fidelity`，不要设置它；输入参考图越多，输入 token 越多。
- 多张参考图通过 images.edit 的 `image` 数组传入。

## ChatGPT 网页或 App 中使用

不能设置参数时，在提示词里写画幅（如"vertical 3:4"）和"photorealistic"。按本技能给出的顺序上传图片，并在提示词里用"第几张图"指代。一次上传数量受限时，分批上传并在每批说明编号；之后的生成尽量只引用锚点图和当次需要的图。

## 官方最佳实践 → 本技能怎么做

| 官方做法 | 在本技能中的落地 |
|---|---|
| 结构化提示词：场景 → 主体 → 关键细节 → 约束，并写明用途 | 模板固定为 Purpose / Inputs / Scene / Model / Garment lock / Styling / Camera / Light & grade / Pose / Constraints |
| 写实要明确写 photorealistic 或 real photograph；相机参数只是外观提示 | 每张都写 photorealistic；镜头焦段写成"35mm look"这类外观描述 |
| 写清人物取景、视线与互动，如 "full body visible, feet included" | 镜头表中的景别和视线直接写成这类句子 |
| 多图输入按编号写明角色，并说明它们如何组合 | 每张提示词开头列出 Image 1…n 各自的角色：锚点、风格、服装视图 |
| 编辑时写"只改 X"，并在每轮重复保留清单以减少漂移 | 锁定清单每张都重复；修图只改一项 |
| 换装时锁定人物身份，只允许衣服改变，要求真实合身与一致的光影 | 服装锁定清单 + 写明真实布料褶皱、遮挡与接触阴影 |
| 风格迁移：给参考图指定具体角色（色板、质感、媒介），新内容单独描述 | 参考图只承担光线、调色、构图习惯与地点，明确不使用其模特和服装 |
| 角色一致性：建立可复用的角色锚点，换场景时重复其定义 | 第一张通过质检的全身图作为锚点，后续每张都带上 |
| 迭代：上一张输出作为下一次输入，一次一处修改 | 修图流程固定为"输入上一版 + 只改 X + 保留清单" |
| 必须逐像素不变的区域，应合成，不要只靠提示词 | 印花或标识反复失真时，建议用户后期合成平铺图上的原始图案 |
| 写明排除项：无文字、无水印、无无关 logo | 约束段固定包含 |

## 每张的输入组合

- **锚点图**：服装平铺（正/背/侧，按需）+ 搭配图 + 2–3 张最典型的参考图 +（可选）模特参考图。
- **后续镜头**：锚点图 + 1–2 张与本镜头光线或区域最接近的参考图 + 本镜头相关的服装视图（背面镜头带背面平铺，细节镜头带细节图）。
- 输入不是越多越好：与本镜头无关的图会分散模型的注意力。

## 提示词语言

默认用英文写提示词主体（摄影术语更精确），每张附一行中文说明，方便用户核对；用户要求中文提示词时用中文。服装颜色和细节两种语言都要写准确。
