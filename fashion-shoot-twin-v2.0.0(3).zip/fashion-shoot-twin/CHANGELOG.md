# Changelog

## 2.0.0 — 2026-10-02

- 从“提示词型 Skill”升级为证据驱动的组照工作流。
- 新增 Reference Audit：多图多数派/离群点/cluster，防止单图过拟合。
- Style DNA 升级为八层 Style Fingerprint：capture/light/color/composition/direction/environment/imperfection/sequence。
- 新增 Scene Continuity Graph 与跨图状态表，锁定地点、时间、天气、光向、道具状态。
- 新增 Garment Evidence Graph，服装属性绑定来源图并分 P0/P1/P2。
- 新增 Selling Point Coverage Matrix 和组照商业任务。
- 新增 Shot Portfolio Optimizer，管理 6–8 张节奏和防重复。
- 新增 Master Anchor Protocol 与“禁止链式污染”规则。
- 新增模型路由：多图编辑模型 / ComfyUI 解耦式高级链。
- 新增三层 QC、硬门评分与 Repair Ladder。
- 新增当季趋势检索门槛；无实时检索时不伪称“当季爆款”。
- 新增压力测试集与发布静态验证脚本。

## 1.0.0

- 初版：风格 DNA、相连场景、服装锁定、卖点镜头、6–8 张规划、GPT 图像提示词、锚点、质检与修图。
