# Shoot Bible — 套图圣经

## A. Reference Audit
- Style refs: A1–A【】
- 有效 cluster：【】
- 置信度：【高/中/低】
- 离群图：【】

## B. Style Fingerprint
| # | CORE / FLEX | 摄影习惯 | 证据 | 提示词落地 |
|---|---|---|---|---|
| 1 | CORE | 【】 | A1/A3/A5 | 【】 |

## C. Scene Continuity Graph
- Parent location：【】
- Time / weather：【】
- Sun vector：【】
- Zone Z1：【】
- Zone Z2：【】
- Zone Z3：【】
- Continuity anchors：【】

## D. Garment Evidence Graph
| 属性 | 锁定值 | P0/P1/P2 | 来源 | 置信度 |
|---|---|---|---|---|
| 【】 | 【】 | P0 | B1/B2 | high |

## E. Selling Point Coverage
| 卖点 | 主镜头 | 辅助镜头 | 遮挡风险 |
|---|---|---|---|
| 【】 | #【】 | #【】 | 【】 |

## F. Styling
- accessories：【】
- props：【】
- hair & makeup：【】
- trend mode：realtime / contemporary-neutral

## G. Shot Sequence
见 shot-list。

## H. Assumptions / Risks
- R1：【】
