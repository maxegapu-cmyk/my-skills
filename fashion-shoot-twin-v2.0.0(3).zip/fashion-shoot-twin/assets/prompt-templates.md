# Prompt Templates 2.0

原则：每个输入图只承担明确角色。提示词不要把“身份、服装、风格、构图”混成一团。

## 1. Master Anchor

```text
PURPOSE
Create the master anchor for a photorealistic [N]-image fashion campaign. This is a completely new photograph of a new model/outfit, but it must follow the recurring photographic language inferred from the STYLE references. Do not recreate any reference frame.

INPUT ROLES
- Images 1-[a]: STYLE ONLY. Learn recurring lighting, lens/perspective family, composition grammar, directing style, color pipeline, environment language, and imperfection signature. Do not copy their people, garments, logos, text, or exact framing.
- Images [b]-[c]: GARMENT EVIDENCE. These define the product and override aesthetic improvisation.
- Image [d] (optional): MODEL IDENTITY. Preserve this person's identity only; do not preserve this image's pose, background, or lighting unless explicitly requested.

STYLE CORE
[8-12 observable recurring rules with evidence-derived wording]

SCENE CONTINUITY
Parent location: [ ]. Zone: [ ]. Same time window: [ ]. Weather: [ ]. Sun/key-light vector: [ ]. Materials/palette: [ ]. Continuity anchors: [ ].

MODEL LOCK
[identity/body/hair/makeup constraints]

GARMENT P0 LOCK — MUST MATCH THE GARMENT EVIDENCE
[category, silhouette, exact color placement, neckline, sleeves, closures, back structure, slit/cutout/ties, print/logo placement, critical hardware count and location, length proportions]
Do not reinterpret, redesign, simplify, beautify, recolor, add, remove, or relocate any P0 feature.

GARMENT P1
[material appearance, texture, sheen, secondary construction]
Fit naturally on the body with realistic drape, folds, tension, occlusion and contact shadows.

COMMERCIAL JOB
[hero / front silhouette / etc.] Show [selling point] clearly and unobstructed.

CAMERA & COMPOSITION
[shot size], [angle], [camera height], [lens/perspective family], [subject placement], [negative space], [crop habits], [ratio].

POSE & GAZE
[action], [gaze], [hands].

STYLING
[accessories/props/hair/makeup]. Nothing may cover [selling point].

LIGHT & COLOR
[key direction/height/softness], [fill/contrast], [exposure bias], [white balance], [skin rendering], [highlight/shadow tint], [saturation/black point/grain].

CONSTRAINTS
Photorealistic real-camera look. Natural skin and fabric. Anatomically plausible body and hands. No extra text, watermark, or unrelated logos. Preserve garment evidence over stylistic embellishment.
```

## 2. Subsequent shot

```text
PURPOSE
Create image [i] of the SAME campaign. This is a new shot, not a remake of any STYLE reference.

INPUT ROLES
- Image 1: MASTER ANCHOR. It is the authority for model identity, body proportions, master garment appearance, hair/makeup, and batch-level photographic continuity.
- Images 2-[s]: STYLE references relevant to THIS shot only. Use recurring photographic language, not their content.
- Image [g]: GARMENT evidence for [back/detail/side/print]. It is the authority for the product feature shown here.

PRESERVE FROM MASTER ANCHOR
[same identity, same body, same outfit, same global color pipeline, same time/weather, same scene family]

ALLOWED CHANGES FOR THIS SHOT ONLY
- zone: [ ]
- camera position / size: [ ]
- pose / gaze: [ ]
- prop state: [ ]

GARMENT P0 LOCK
[repeat full P0 list]

COMMERCIAL JOB
[ ] — clearly reveal [selling point].

CONTINUITY LOCK
[light vector, scene materials, repeated anchor, styling state]

CAMERA / POSE / LIGHT / COLOR
[shot-specific instructions]

CONSTRAINTS
Do not drift identity, garment design, location family, time of day, sun direction, or batch color grade. Do not copy the STYLE reference's exact composition.
```

## 3. Micro repair

```text
Edit Image 1.
CHANGE ONLY: [one defect] so it matches Image [evidence] exactly in [observable property].
PRESERVE EXACTLY: face/identity, body, all other garment P0/P1 details, pose, framing, camera perspective, scene, light direction, color grade, accessories and image quality.
SUCCESS CHECK: [what must be visibly true].
Do not redesign or add anything else.
```

## 4. Batch-level grade repair

```text
Edit Image 1 only for batch color continuity. Match the approved Master Anchor's white balance, skin tone rendering, black point, contrast curve, saturation, highlight/shadow tint, grain and overall exposure family. Do not change the face, garment, pose, composition, background geometry, lighting direction, accessories or textures.
```
