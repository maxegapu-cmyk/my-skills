# Style Fingerprint Card

Reference: A1–A【】｜Cluster：【】｜Confidence：【High / Medium / Low】

## CORE — 必须持续命中
| # | Layer | Habit | Support / evidence | Prompt phrase |
|---|---|---|---|---|
| 1 | light | 【】 | 4/5, A1/A2/A4/A5 | 【】 |

## FLEX — 为卖点服务时可变化
| # | Layer | Range | Evidence |
|---|---|---|---|
| 1 | shot size | full → medium | A1–A5 |

## OUTLIER — 不自动继承
- A【】：【】

## FORBID — 原作品内容，不复制
- 模特身份 / 原服装 / Logo / 水印 / 独特原帧组合：【】

## Sequence grammar
【】
