# Fashion Shoot Twin v2.0.0

**多参考图 → 摄影师拍摄语言 → 相连场景 → 服装证据图谱 → 6–8 张商业套图。**

这个 Skill 面向服装电商、Lookbook、种草套图：用户给两批核心图片——A 组摄影参考、B 组自家服装正背侧/细节/搭配图，可选 C 组模特身份——系统不逐帧翻拍，而是提取参考组中反复出现的光线、镜头、构图、导演、场景、调色和组照节奏，重建一场“同摄影语言、同一天、同一个相连地点”的新拍摄。

v2.0 的目标不只是“像”，还要解决两个商业问题：**衣服不能漂**，以及**8 张不能像 8 次独立抽卡**。

## v2.0 新架构

1. **Reference Audit**：逐张判断参考图对光线/构图/地点分别有多大价值，按多数证据建 Style Fingerprint，避免被单张偶然效果带偏。
2. **Style Fingerprint 2.0**：拆成 capture / light / color / composition / direction / environment / imperfection / sequence 八层。
3. **Scene Continuity Graph**：建立 3–5 个相邻 zone、时间窗、天气、太阳/主光方向、材质和连续性锚点。
4. **Garment Evidence Graph**：每个服装细节绑定 B 图证据，分 P0/P1/P2；P0 错一处就不能交付。
5. **Selling Point Coverage**：卖点必须映射到镜头，不让“艺术氛围”牺牲商品信息。
6. **Shot Portfolio Optimizer**：6–8 张按商业任务和组照节奏排列，不是机械凑正/背/侧。
7. **Master Anchor Protocol**：所有后续图都回看总锚点，阻止链式漂移。
8. **Model Routing**：GPT Image 走多图编辑；本地高级链把 identity / style / pose / garment 分开控制。
9. **3-Level QC**：单张硬门、套图连续性、商业有效性三层验收。
10. **Repair Ladder**：单点修 → 刷新证据 → 从 Master Anchor 重生 → 换路线 → 后期合成，避免无穷抽卡。

## 最简单的用法

上传：
- A 组：4–12 张同一摄影师/同一组摄影作品；
- B 组：正面、背面、侧面、局部、平铺或搭配图；
- C 组（可选）：想保持的模特身份。

然后说：

> “A 是风格参考，B 是我的衣服，卖点是背部绑带和缎面垂感，做 7 张，小红书 3:4。要像同一个摄影师同一天在一个相连地点拍，但别复制原图构图。直接出规划。”

系统会先给一页 Shoot Bible；如果你说“直接出，不用确认”，会跳过确认并继续。

## 三种执行方式

### 1. ChatGPT / 支持多图编辑的图像模型
最省事。把 `portable/chatgpt-instructions.md` 放进项目/GPT 指令，按 Skill 给的图像顺序上传。

### 2. Skill / Agent 环境
上传整个 ZIP。Agent 读取 `SKILL.md`，根据需要再读 references 和 assets。

### 3. ComfyUI / 本地高级链
用于身份、结构、姿势或风格反复漂移的难例。参考 `references/model-routing.md`：把 Identity、Style、Pose、Garment 结构拆成独立控制分支。

## 文件地图

- `SKILL.md`：唯一主流程与硬规则
- `references/reference-audit.md`：多参考图审计
- `references/style-dna.md`：摄影师指纹
- `references/continuity-engine.md`：场景与光线连续性
- `references/garment-evidence.md`：服装证据图谱
- `references/styling-trend-engine.md`：造型/趋势
- `references/shot-planning.md`：6–8 张组照规划
- `references/model-routing.md`：GPT / ComfyUI 路由
- `references/qc-and-fix.md`：失败诊断与修复
- `references/scoring-rubric.md`：硬门与评分
- `assets/shoot-bible.template.md`：总规划模板
- `assets/style-dna-card.md`：风格指纹模板
- `assets/shot-list.template.md`：镜头组合模板
- `assets/prompt-templates.md`：生成/修图模板
- `evals/trials.yaml`：基础行为测试
- `evals/stress.yaml`：压力测试用例
- `scripts/validate_skill.py`：发布前静态验收

## 为什么 v2.0 比“same photographer + same location”更稳

因为真正的批量失败通常不是形容词不够，而是**条件互相抢控制权**：参考图想控制构图，服装图想控制结构，模特图想控制脸，上一张生成图又把误差继续传给下一张。v2.0 给每个输入分角色、给每个属性定权威来源，并要求每张回到 Master Anchor。

## 商业与许可提醒

- 参考作品只用于抽象拍摄手法，不复制原模特、原服装、品牌、水印或独特原帧。
- 本地 VTON / identity 项目各自有代码、权重、底模和数据集许可。尤其部分 VTON 项目为非商业许可；商用前必须逐项核对，不能因为 GitHub 可下载就默认能商用。
- 必须逐像素保真的印花、Logo、文字，优先后期合成，不建议无限依赖生成模型。
