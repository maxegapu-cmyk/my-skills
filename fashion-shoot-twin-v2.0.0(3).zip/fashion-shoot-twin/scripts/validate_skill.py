from pathlib import Path
import re, sys

ROOT = Path(__file__).resolve().parents[1]
required = [
    'SKILL.md','README.md','CHANGELOG.md',
    'references/reference-audit.md','references/style-dna.md',
    'references/continuity-engine.md','references/garment-evidence.md',
    'references/styling-trend-engine.md','references/shot-planning.md',
    'references/model-routing.md','references/qc-and-fix.md',
    'references/scoring-rubric.md','assets/shoot-bible.template.md',
    'assets/style-dna-card.md','assets/shot-list.template.md',
    'assets/prompt-templates.md','portable/chatgpt-instructions.md',
    'evals/trials.yaml','evals/stress.yaml'
]

errors=[]
for f in required:
    p=ROOT/f
    if not p.exists(): errors.append(f'missing: {f}')
    elif p.stat().st_size < 100: errors.append(f'too small: {f}')

skill=(ROOT/'SKILL.md').read_text(encoding='utf-8')
for token in ['Master Anchor','Garment Evidence Graph','Scene Continuity Graph','Reference Audit','P0','6–8']:
    if token not in skill: errors.append(f'SKILL missing concept: {token}')

if 'fashion-shoot-twin' not in skill.split('---',2)[1]:
    errors.append('front matter name missing')

# No stale same-as-previous shorthand in prompt templates.
prompts=(ROOT/'assets/prompt-templates.md').read_text(encoding='utf-8').lower()
if 'same as above' in prompts or '同上' in prompts:
    errors.append('prompt template uses ambiguous shorthand')

# Ensure stress suite is substantial without requiring PyYAML.
stress=(ROOT/'evals/stress.yaml').read_text(encoding='utf-8')
case_count=len(re.findall(r'^- id:', stress, flags=re.M))
if case_count < 10: errors.append(f'not enough stress cases: {case_count}')

if errors:
    print('FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print(f'PASS: {len(required)} required files; {case_count} stress cases')
