from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
required = [
    ROOT / "SKILL.md",
    ROOT / "README.md",
    ROOT / "references/01-platform-lens.md",
    ROOT / "references/02-hook-engine.md",
    ROOT / "references/03-emotion-engine.md",
    ROOT / "references/04-plot-architecture.md",
    ROOT / "references/05-character-engine.md",
    ROOT / "references/06-genre-playbooks.md",
    ROOT / "references/07-style-dialogue.md",
    ROOT / "references/08-review-rubric.md",
    ROOT / "references/09-content-originality.md",
    ROOT / "references/10-adaptation-lens.md",
    ROOT / "templates/story-brief.md",
    ROOT / "templates/beat-sheet.md",
    ROOT / "templates/review-report.md",
    ROOT / "evals/adversarial-cases.md",
]

for p in required:
    if not p.exists() or p.stat().st_size < 30:
        raise SystemExit(f"MISSING_OR_EMPTY: {p.relative_to(ROOT)}")

skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
for heading in [
    "平台锁定", "自动路由", "开篇钩子引擎", "情绪波形引擎",
    "场景发动机", "人物引擎", "信息差与反转", "连续性铁律",
    "爽点与兑现", "题材适配器", "完整创作流程", "审稿闸门",
    "评分系统", "参考作品拆解协议", "输出契约", "成功标准"
]:
    if heading not in skill:
        raise SystemExit(f"MISSING_SECTION: {heading}")

# Core execution invariants
for rule in [
    "因果账", "知情账", "证据账", "时空账", "承诺账",
    "角色获得了其不可能知道的信息", "不承诺“必爆”"
]:
    if rule not in skill:
        raise SystemExit(f"MISSING_RULE: {rule}")

# Evaluation floor
evals = (ROOT / "evals/adversarial-cases.md").read_text(encoding="utf-8")
if len(re.findall(r"^## Case", evals, flags=re.M)) < 20:
    raise SystemExit("TOO_FEW_EVAL_CASES")

print("PASS: structure, core workflow, continuity rules, and evaluation floor")
