# PLAYBOOK — Story Dynamics Workbench v2.0

## 0. Intake

Identify:
- project/version;
- current story time;
- mode;
- active cast;
- location(s);
- source range;
- desired output;
- hard constraints;
- whether the task may mutate canon.

If the user asks to continue a long project, do not immediately write. Build the current state first.

## 1. DISCOVER: reconstruct before inventing

For supplied novel/script material, build:

### 1.1 Objective event table
`event -> cause -> choice -> direct result -> delayed result`

### 1.2 Two timelines
- chronological occurrence order;
- audience presentation/reveal order.

### 1.3 Character knowledge snapshots
At major turns, store:
- knows;
- suspects;
- falsely believes;
- does not know;
- hides;
- plans.

### 1.4 Unresolved story debt
- promises;
- mysteries;
- unreturned objects;
- threats;
- obligations;
- relationship questions;
- ticking clocks.

## 2. CHARACTER: build a life model

For each major character:

### Step 2.1 Life chronology
Break into periods such as early childhood, later childhood, adolescence, early adulthood, current story period. Do not invent exact ages when unnecessary.

### Step 2.2 Formative events
For each supported/invented event, record:
- objective event;
- perceived event;
- agency/control;
- social meaning;
- immediate emotion;
- immediate action;
- memory importance;
- later interpretation;
- belief created;
- strategy learned;
- relationship consequence.

### Step 2.3 Memory network
Link memories by trigger:
- person;
- place;
- sensory cue;
- phrase;
- object;
- social situation;
- power dynamic;
- loss/rejection/success pattern.

### Step 2.4 Present psyche
Derive, with evidence labels:
- self-image;
- hidden self-image;
- core wants;
- feared outcomes;
- values;
- boundaries;
- shame/pride points;
- default coping;
- conflict tactics;
- intimacy tactics;
- stress behavior;
- change threshold.

### Step 2.5 Relationship-specific selves
A person may behave differently with a parent, rival, lover, subordinate, stranger, or authority. Track the cause of the difference.

## 3. CURRENT STATE: prepare the simulation point

Compile:
- objective situation;
- each active character's internal situation;
- relationship vectors;
- resources and constraints;
- secrets and information asymmetry;
- physical/institutional pressures;
- active promises;
- reader knowledge.

## 4. SIMULATE: independent actor passes

Before constructing plot branches, ask each decisive actor privately:
- what do I want now?
- what am I afraid will happen?
- what do I believe is true?
- what relevant memory is active?
- what tactic do I prefer?
- what will make me switch tactics?
- what line won't I cross?
- what am I likely to misread?

Do not let one character's hidden context leak into another's pass.

## 5. SIMULATE: collision

Resolve simultaneous intentions using:
- timing;
- distance;
- access;
- resources;
- hierarchy;
- physical rules;
- institutional rules;
- other actors;
- chance only when explicitly allowed by the project's design.

## 6. SIMULATE: branch construction

Generate 3–5 branches whose **causal engines differ**.

Useful divergence sources:
- different decisive character choice;
- information arrives early/late;
- one relationship crosses a threshold;
- resource disappears;
- misunderstanding persists or is corrected;
- institutional actor intervenes;
- hidden cost comes due;
- character repeats an old pattern vs breaks it.

Each branch records:
- divergence point;
- decisive actor;
- active memory/belief;
- choice;
- immediate world delta;
- immediate knowledge delta;
- relationship delta;
- short-horizon consequence;
- medium-horizon consequence;
- long-horizon pressure;
- new promise/debt;
- continuity risk;
- first playable scene.

## 7. Consequence propagation

Use at least three rings:

### Ring 1 — Direct
Who is physically/socially affected immediately?

### Ring 2 — Interpretation
Who learns about it, what do they think happened, and what do they decide?

### Ring 3 — Persistence
What now remains true even after the scene is over?

For major events add:
- documentary evidence;
- rumor/public narrative;
- resource shifts;
- institutional response;
- psychological residue;
- relationship debt;
- new constraints.

## 8. Compare branches

Compare without declaring one universally “best.” Use the task's goal:
- character fidelity;
- causal integrity;
- dramatic pressure;
- novelty;
- thematic pressure;
- future story energy;
- payoff value;
- continuity cost;
- production feasibility if relevant.

Show trade-offs. The writer chooses.

## 9. NOVEL workflow

`Context Pack -> Scene Question -> POV memory/knowledge -> Objective/Obstacle -> Tactic changes -> Turn -> Aftermath -> Draft -> Audit`

Novel checks:
- POV cannot access illegal information;
- interior thought changes or complicates action rather than repeating it;
- sensory detail is selective and character-linked;
- repeated motifs evolve rather than replay verbatim;
- exposition enters because the present activates it;
- backstory is released when it changes the meaning of the current scene.

## 10. SCREENPLAY workflow

`Context Pack -> Scene Function -> Entry Value -> Objective -> Opposition -> Tactics -> Turn -> Exit Value -> Visual Beat Sheet -> Dialogue/Subtext -> Fountain Draft -> Audit`

Screenplay checks:
- action is filmable;
- dialogue is action, not explanation alone;
- silence and blocking carry information;
- no invisible thought unless externalized or intentionally narrated;
- every scene changes information, power, relationship, decision, risk, resource, or expectation;
- sequence escalation is visible, not just stated.

## 11. ADAPT workflow

1. Segment source.
2. Extract factual anchors.
3. Extract character/relationship anchors.
4. Mark protected beats.
5. Decide omission/compression/combination.
6. Build scene map.
7. Draft.
8. Fidelity audit.
9. Repair only failed anchors.

## 12. AUDIT workflow

Audit in this order:
1. hard facts;
2. chronology;
3. knowledge boundaries;
4. motivation and choice;
5. causal chain;
6. relationship continuity;
7. promise/payoff;
8. scene function;
9. theme/arc coherence;
10. format/production constraints.

## 13. ACCEPT workflow

When the writer explicitly accepts a branch/scene/chapter:
1. freeze the accepted text/version id;
2. extract objective events;
3. compute character state deltas;
4. compute knowledge/belief deltas;
5. compute relationship deltas;
6. update resources/locations/items;
7. update promise ledger;
8. append accepted events;
9. snapshot derived state;
10. leave rejected alternatives untouched in branch storage.

## 14. REPAIR workflow

Use `IDENTIFY -> TRACE -> PATCH -> RECHECK`.

Never rewrite a whole arc merely because one layer failed.

## 15. Failure conditions

Mark a beat as forced if it requires:
- impossible knowledge;
- a sudden new value with no catalyst;
- a tactic the character has no reason to choose;
- a physical/logistical impossibility;
- forgotten consequences;
- a relationship jump with no event cause;
- a payoff with no setup;
- an old setup silently disappearing.
