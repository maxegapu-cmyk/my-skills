# Version 2.0.0

Full rebuild.

## Major additions

- character life-history engine;
- formative-event and episodic-memory model;
- memory triggers, distortion/reinterpretation, belief formation;
- character self/world/other models;
- multi-dimensional relationship graph;
- temporal event graph with occurrence, learning, reveal, and validity times;
- independent actor simulation before branch construction;
- three-ring consequence propagation;
- long-form Context Pack compiler;
- promise/setup/payoff ledger;
- snapshot and rollback tools;
- stricter novel and screenplay scene mechanics;
- adaptation fidelity anchors;
- continuity/knowledge/causality auditor;
- clean package layout and expanded regression suite.

## Compatibility

v2 uses new schemas. v1 projects should be migrated manually rather than silently upgraded.
