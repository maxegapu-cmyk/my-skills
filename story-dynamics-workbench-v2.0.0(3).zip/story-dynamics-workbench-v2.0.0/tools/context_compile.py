#!/usr/bin/env python3
import argparse, json, re
from pathlib import Path

def score_memory(m, cues):
    s=0.45*float(m.get('importance',0))+0.25*float(m.get('accessibility',0))
    hay=' '.join(m.get('triggers',[])+[m.get('objective_event',''),m.get('perceived_event','')]).lower()
    if cues:
        matches=sum(1 for c in cues if c.lower() in hay)
        s += min(0.3,0.1*matches)
    return round(s,4)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('project'); ap.add_argument('character'); ap.add_argument('--cue',action='append',default=[]); ap.add_argument('--limit',type=int,default=6); a=ap.parse_args()
    root=Path(a.project); c=json.loads((root/'characters'/f'{a.character}.json').read_text(encoding='utf-8'))
    mem=[]
    for mid in c.get('memory_ids',[]):
        p=root/'memories'/f'{mid}.json'
        if p.exists():
            m=json.loads(p.read_text(encoding='utf-8')); m['_score']=score_memory(m,a.cue); mem.append(m)
    mem.sort(key=lambda x:x['_score'], reverse=True)
    print(json.dumps({'character':c,'memories':mem[:a.limit]},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
