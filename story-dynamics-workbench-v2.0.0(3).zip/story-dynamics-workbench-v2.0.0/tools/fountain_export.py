#!/usr/bin/env python3
import argparse, json
from pathlib import Path

def export(data):
    out=[]
    if data.get('title'): out += [f"Title: {data['title']}", '']
    for sc in data.get('scenes',[]):
        out.append(sc.get('slugline','INT. UNKNOWN - DAY').upper())
        out.append('')
        for beat in sc.get('beats',[]):
            if beat.get('type')=='action': out.append(beat.get('text',''))
            elif beat.get('type')=='dialogue':
                out += ['', beat.get('character','').upper(), beat.get('text','')]
            elif beat.get('type')=='transition': out += ['', beat.get('text','CUT TO:').upper()]
        out.append('')
    return '\n'.join(out).strip()+'\n'

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('input'); ap.add_argument('output'); a=ap.parse_args()
    d=json.loads(Path(a.input).read_text(encoding='utf-8')); Path(a.output).write_text(export(d),encoding='utf-8')
if __name__=='__main__': main()
