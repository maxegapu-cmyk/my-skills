#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil, hashlib
from pathlib import Path
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def dump_json(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, indent=2, ensure_ascii=False)+"\n", encoding='utf-8')

def iter_jsonl(path):
    p=Path(path)
    if not p.exists(): return []
    out=[]
    for i,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1):
        if line.strip():
            try: out.append(json.loads(line))
            except Exception as e: raise ValueError(f'{p}:{i}: {e}')
    return out

def append_jsonl(path, obj):
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('a',encoding='utf-8') as f:
        f.write(json.dumps(obj, ensure_ascii=False)+'\n')

def project_paths(project):
    p=Path(project)
    return {
      'root':p,'project':p/'project.json','events':p/'state'/'canon_events.jsonl',
      'promises':p/'state'/'promises.jsonl','branches':p/'branches','chars':p/'characters',
      'memories':p/'memories','snapshots':p/'snapshots','drafts':p/'drafts'
    }

def init_project(project):
    ps=project_paths(project); root=ps['root']; root.mkdir(parents=True, exist_ok=True)
    for k in ('branches','chars','memories','snapshots','drafts'):
        ps[k].mkdir(parents=True, exist_ok=True)
    (root/'state').mkdir(exist_ok=True)
    if not ps['project'].exists():
        data=load_json(ROOT/'templates'/'project.json'); data['project_id']=root.name
        dump_json(ps['project'],data)
    for key in ('events','promises'):
        ps[key].touch(exist_ok=True)
    if not (root/'relationships.json').exists(): dump_json(root/'relationships.json',[])
    return root

def validate(project):
    ps=project_paths(project); errors=[]; warnings=[]
    if not ps['project'].exists(): errors.append('missing project.json')
    else:
        try:
            pj=load_json(ps['project'])
            for k in ('project_id','title','canon_version'):
                if k not in pj: errors.append(f'project.json missing {k}')
        except Exception as e: errors.append(f'project.json invalid: {e}')
    try:
        evs=iter_jsonl(ps['events']); ids=set()
        for e in evs:
            if e.get('status')!='CANON': errors.append(f"non-canon event in canon ledger: {e.get('id')}")
            if e.get('id') in ids: errors.append(f"duplicate event id: {e.get('id')}")
            ids.add(e.get('id'))
    except Exception as e: errors.append(str(e))
    for f in sorted(ps['chars'].glob('*.json')) if ps['chars'].exists() else []:
        try:
            c=load_json(f)
            if not c.get('id'): errors.append(f'{f.name}: missing id')
            if 'current_state' not in c: errors.append(f'{f.name}: missing current_state')
        except Exception as e: errors.append(f'{f.name}: {e}')
    return errors,warnings

def sha_tree(project):
    root=Path(project); h=hashlib.sha256()
    for p in sorted(x for x in root.rglob('*') if x.is_file() and 'snapshots' not in x.parts):
        h.update(str(p.relative_to(root)).encode()); h.update(b'\0'); h.update(p.read_bytes()); h.update(b'\0')
    return h.hexdigest()

def snapshot(project,name):
    ps=project_paths(project); dest=ps['snapshots']/name
    if dest.exists(): raise SystemExit(f'snapshot exists: {name}')
    dest.mkdir(parents=True)
    for rel in ['project.json','state','characters','memories','relationships.json']:
        src=ps['root']/rel
        if src.is_dir(): shutil.copytree(src,dest/rel)
        elif src.exists(): (dest/rel).parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dest/rel)
    meta={'name':name,'created_at':datetime.now(timezone.utc).isoformat(),'source_hash':sha_tree(project)}
    dump_json(dest/'SNAPSHOT.json',meta); return dest

def rollback(project,name):
    ps=project_paths(project); src=ps['snapshots']/name
    if not src.exists(): raise SystemExit(f'no snapshot {name}')
    for rel in ['project.json','state','characters','memories','relationships.json']:
        target=ps['root']/rel; snap=src/rel
        if target.is_dir(): shutil.rmtree(target)
        elif target.exists(): target.unlink()
        if snap.is_dir(): shutil.copytree(snap,target)
        elif snap.exists(): target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(snap,target)

def commit_branch(project,branch_file):
    ps=project_paths(project); b=load_json(branch_file)
    if b.get('status')!='ACCEPTED': raise SystemExit('branch must be explicitly marked ACCEPTED before commit')
    for d in b.get('projected_deltas',[]):
        if d.get('kind')=='event':
            ev=d.get('value',{}).copy(); ev['status']='CANON'; append_jsonl(ps['events'],ev)
    pj=load_json(ps['project']); pj['canon_version']=int(pj.get('canon_version',0))+1; dump_json(ps['project'],pj)

def build_context(project, character=None):
    ps=project_paths(project); pj=load_json(ps['project']); evs=iter_jsonl(ps['events'])
    out={'project':pj,'recent_events':evs[-8:],'open_promises':[x for x in iter_jsonl(ps['promises']) if x.get('status') in ('OPEN','ADVANCED')]}
    if character:
        cf=ps['chars']/f'{character}.json'
        if cf.exists():
            c=load_json(cf); out['character']=c
            mem=[]
            for mid in c.get('memory_ids',[]):
                mf=ps['memories']/f'{mid}.json'
                if mf.exists(): mem.append(load_json(mf))
            mem.sort(key=lambda x:(x.get('importance',0)*0.5+x.get('accessibility',0)*0.5), reverse=True)
            out['relevant_memories']=mem[:6]
    return out

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    x=sub.add_parser('init'); x.add_argument('project')
    x=sub.add_parser('validate'); x.add_argument('project')
    x=sub.add_parser('snapshot'); x.add_argument('project'); x.add_argument('name')
    x=sub.add_parser('rollback'); x.add_argument('project'); x.add_argument('name')
    x=sub.add_parser('commit'); x.add_argument('project'); x.add_argument('branch_file')
    x=sub.add_parser('context'); x.add_argument('project'); x.add_argument('--character')
    a=ap.parse_args()
    if a.cmd=='init': print(init_project(a.project))
    elif a.cmd=='validate':
        e,w=validate(a.project); print(json.dumps({'ok':not e,'errors':e,'warnings':w},ensure_ascii=False,indent=2)); raise SystemExit(1 if e else 0)
    elif a.cmd=='snapshot': print(snapshot(a.project,a.name))
    elif a.cmd=='rollback': rollback(a.project,a.name); print('rolled back')
    elif a.cmd=='commit': commit_branch(a.project,a.branch_file); print('committed')
    elif a.cmd=='context': print(json.dumps(build_context(a.project,a.character),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
