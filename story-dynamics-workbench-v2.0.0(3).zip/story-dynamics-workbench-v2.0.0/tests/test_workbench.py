import json, tempfile, unittest, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SF=ROOT/'tools'/'storyforge.py'
AUD=ROOT/'tools'/'audit.py'
BR=ROOT/'tools'/'branch_lab.py'
FNT=ROOT/'tools'/'fountain_export.py'

def run(*args, check=True):
    return subprocess.run([sys.executable,*map(str,args)],text=True,capture_output=True,check=check)

class WorkbenchTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.p=Path(self.tmp.name)/'p'; run(SF,'init',self.p)
    def tearDown(self): self.tmp.cleanup()
    def test_init_and_validate(self):
        r=run(SF,'validate',self.p); self.assertIn('"ok": true',r.stdout.lower())
    def test_noncanon_branch_cannot_commit(self):
        b=self.p/'branches'/'b.json'; b.write_text(json.dumps({'id':'b','status':'PROPOSED','divergence':'x','steps':[{'event':'x'}],'projected_deltas':[]}),encoding='utf-8')
        r=run(SF,'commit',self.p,b,check=False); self.assertNotEqual(r.returncode,0)
    def test_accepted_branch_commits_event(self):
        b=self.p/'branches'/'b.json'; b.write_text(json.dumps({'id':'b','status':'ACCEPTED','divergence':'x','steps':[{'event':'x'}],'projected_deltas':[{'kind':'event','value':{'id':'ev_x','summary':'x'}}]}),encoding='utf-8')
        run(SF,'commit',self.p,b); txt=(self.p/'state'/'canon_events.jsonl').read_text(); self.assertIn('ev_x',txt)
        pj=json.loads((self.p/'project.json').read_text()); self.assertEqual(pj['canon_version'],1)
    def test_snapshot_and_rollback(self):
        run(SF,'snapshot',self.p,'s1'); pj=json.loads((self.p/'project.json').read_text()); pj['title']='changed'; (self.p/'project.json').write_text(json.dumps(pj)); run(SF,'rollback',self.p,'s1'); self.assertNotEqual(json.loads((self.p/'project.json').read_text())['title'],'changed')
    def test_context_character_memory(self):
        c=json.loads((ROOT/'templates'/'character.json').read_text()); c['id']='a'; c['name']='A'; c['memory_ids']=['m1']; (self.p/'characters'/'a.json').write_text(json.dumps(c)); m=json.loads((ROOT/'templates'/'memory_episode.json').read_text()); m['id']='m1'; m['character_id']='a'; m['objective_event']='storm'; m['perceived_event']='storm'; (self.p/'memories'/'m1.json').write_text(json.dumps(m)); r=run(SF,'context',self.p,'--character','a'); self.assertIn('m1',r.stdout)
    def test_audit_missing_memory(self):
        c=json.loads((ROOT/'templates'/'character.json').read_text()); c['id']='a'; c['name']='A'; c['memory_ids']=['missing']; (self.p/'characters'/'a.json').write_text(json.dumps(c)); r=run(AUD,self.p,check=False); self.assertNotEqual(r.returncode,0); self.assertIn('missing_memory',r.stdout)
    def test_branch_validator(self):
        b=self.p/'branches'/'b.json'; b.write_text(json.dumps({'id':'b','status':'PROPOSED','divergence':'x','steps':[{'choice':'go'}]})); r=run(BR,b); self.assertIn('"ok": true',r.stdout.lower())
    def test_branch_validator_rejects_empty(self):
        b=self.p/'branches'/'b.json'; b.write_text(json.dumps({'id':'b','status':'PROPOSED','divergence':'x','steps':[]})); r=run(BR,b,check=False); self.assertNotEqual(r.returncode,0)
    def test_fountain_export(self):
        i=self.p/'drafts'/'s.json'; o=self.p/'drafts'/'s.fountain'; i.write_text(json.dumps({'title':'T','scenes':[{'slugline':'INT. SHOP - NIGHT','beats':[{'type':'action','text':'Mira locks the door.'},{'type':'dialogue','character':'Mira','text':'Not tonight.'}]}]})); run(FNT,i,o); t=o.read_text(); self.assertIn('INT. SHOP - NIGHT',t); self.assertIn('MIRA',t)
    def test_example_validates(self):
        r=run(SF,'validate',ROOT/'examples'/'harbor_glass'); self.assertIn('"ok": true',r.stdout.lower())

if __name__=='__main__': unittest.main()
