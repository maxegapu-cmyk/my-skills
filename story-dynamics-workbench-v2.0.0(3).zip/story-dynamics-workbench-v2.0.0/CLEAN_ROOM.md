# Clean-Room Statement

This package is an independent implementation built from:

1. publicly documented open-source narrative / agent-memory projects listed in `references/GITHUB_NOTES.md`;
2. general storytelling and software-engineering concepts;
3. user-approved functional requirements for fiction and screenplay work.

## Isolation rules

- No private prompts are imported.
- No private schemas, internal naming systems, hidden tests, proprietary workflows, or reverse-engineerable structures are used as design sources.
- Private project content is not included in examples, fixtures, regression cases, documentation, or provenance notes.
- Public projects are used only for high-level architectural inspiration unless their license explicitly permits code reuse; this package contains no copied third-party implementation code.
- All examples in this package are newly written and generic.
